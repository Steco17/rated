-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 17, 2022 at 02:36 PM
-- Server version: 10.3.34-MariaDB-log
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thebri42_rated`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_transactions`
--

CREATE TABLE `account_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `from_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_id` bigint(20) NOT NULL,
  `current_balance` decimal(8,2) NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `add_ons`
--

CREATE TABLE `add_ons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `f_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `f_name`, `l_name`, `phone`, `email`, `image`, `password`, `remember_token`, `created_at`, `updated_at`, `role_id`) VALUES
(1, 'Rated', 'App', '9143730387', 'info@teamafricorp.com', '2021-12-09-61b1cedac6e5f.png', '$2y$10$l4y0XMJYt2wIkloK7I3T9OnV2GDqV8odS3PbRw8EcGEYtElxgkmS2', 'kqbcjlG1eCb4U3t7DKS9qEBV80Et076FjIM00fSptOSnpwyolrAJa8ltqQt5', '2021-11-11 15:13:12', '2021-12-24 17:26:47', 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin_roles`
--

CREATE TABLE `admin_roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modules` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_roles`
--

INSERT INTO `admin_roles` (`id`, `name`, `modules`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Master Admin', NULL, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_wallets`
--

CREATE TABLE `admin_wallets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` bigint(20) UNSIGNED NOT NULL,
  `total_commission_earning` decimal(8,2) NOT NULL DEFAULT 0.00,
  `digital_received` decimal(8,2) NOT NULL DEFAULT 0.00,
  `manual_received` decimal(8,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `delivery_charge` decimal(8,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

CREATE TABLE `attributes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `data` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `zone_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `title`, `type`, `image`, `status`, `data`, `created_at`, `updated_at`, `zone_id`) VALUES
(1, 'Post Your First Rating', 'restaurant_wise', '2021-11-27-61a15d7630e07.png', 0, '22', '2021-11-27 10:04:34', '2021-12-26 18:20:16', 1),
(2, 'Rate New Music', 'restaurant_wise', '2021-11-27-61a165584328e.png', 0, '23', '2021-11-27 10:38:12', '2021-12-26 18:20:17', 1),
(3, 'Breaking News', 'restaurant_wise', '2021-11-27-61a1aab0bf9bd.png', 0, '25', '2021-11-27 15:34:04', '2021-12-26 18:20:15', 1),
(4, 'Local New', 'restaurant_wise', '2021-11-27-61a1aaccbce03.png', 0, '25', '2021-11-27 15:34:32', '2021-12-26 18:20:14', 1),
(5, 'Live Streams', 'restaurant_wise', '2021-11-27-61a1b0b253d6f.png', 1, '26', '2021-11-27 15:59:42', '2021-12-26 19:20:01', 1),
(6, 'Memes', 'restaurant_wise', '2021-11-27-61a1b19c7c54d.png', 1, '27', '2021-11-27 16:03:36', '2021-12-26 19:19:55', 1),
(7, 'gif', 'restaurant_wise', '2021-12-26-61c8b25346e7d.png', 1, '21', '2021-12-26 18:20:03', '2021-12-26 18:20:03', 1);

-- --------------------------------------------------------

--
-- Table structure for table `business_settings`
--

CREATE TABLE `business_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `business_settings`
--

INSERT INTO `business_settings` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 'cash_on_delivery', '{\"status\":\"1\"}', '2021-05-11 03:56:38', '2021-09-09 22:27:34'),
(2, 'stripe', '{\"status\":\"0\",\"api_key\":null,\"published_key\":null}', '2021-05-11 03:57:02', '2021-09-09 22:28:18'),
(4, 'mail_config', NULL, NULL, '2021-05-11 04:14:06'),
(5, 'fcm_project_id', NULL, NULL, NULL),
(6, 'push_notification_key', NULL, NULL, NULL),
(7, 'order_pending_message', '{\"status\":0,\"message\":null}', NULL, NULL),
(8, 'order_confirmation_msg', '{\"status\":0,\"message\":null}', NULL, NULL),
(9, 'order_processing_message', '{\"status\":0,\"message\":null}', NULL, NULL),
(10, 'out_for_delivery_message', '{\"status\":0,\"message\":null}', NULL, NULL),
(11, 'order_delivered_message', '{\"status\":0,\"message\":null}', NULL, NULL),
(12, 'delivery_boy_assign_message', '{\"status\":0,\"message\":null}', NULL, NULL),
(13, 'delivery_boy_start_message', '{\"status\":0,\"message\":null}', NULL, NULL),
(14, 'delivery_boy_delivered_message', '{\"status\":0,\"message\":null}', NULL, NULL),
(15, 'terms_and_conditions', NULL, NULL, '2021-06-29 06:44:49'),
(16, 'business_name', 'Rated', NULL, NULL),
(17, 'currency', 'USD', NULL, NULL),
(18, 'logo', '2021-12-09-61b1cf1182461.png', NULL, NULL),
(19, 'phone', '914-373-0387', NULL, NULL),
(20, 'email_address', 'info@ratedapp.com', NULL, NULL),
(21, 'address', 'Florida, USA', NULL, NULL),
(22, 'footer_text', 'Ratedapp.com', NULL, NULL),
(23, 'customer_verification', '0', NULL, NULL),
(24, 'map_api_key', 'AIzaSyAe6Xqiu_wSEgmhEal5dBXJRlLy-Hr_o7o', NULL, NULL),
(25, 'privacy_policy', NULL, NULL, '2021-06-28 09:46:55'),
(26, 'about_us', NULL, NULL, '2021-06-29 06:43:25'),
(27, 'minimum_shipping_charge', '0', NULL, NULL),
(28, 'per_km_shipping_charge', '0', NULL, NULL),
(29, 'ssl_commerz_payment', '{\"status\":\"0\",\"store_id\":null,\"store_password\":null}', '2021-07-04 08:52:20', '2021-09-09 22:28:30'),
(30, 'razor_pay', '{\"status\":\"0\",\"razor_key\":null,\"razor_secret\":null}', '2021-07-04 08:53:04', '2021-09-09 22:28:25'),
(31, 'digital_payment', '{\"status\":\"1\"}', '2021-07-04 08:53:10', '2021-10-16 03:11:55'),
(32, 'paypal', '{\"status\":\"0\",\"paypal_client_id\":null,\"paypal_secret\":null}', '2021-07-04 08:53:18', '2021-09-09 22:28:36'),
(33, 'paystack', '{\"status\":\"0\",\"publicKey\":null,\"secretKey\":null,\"paymentUrl\":null,\"merchantEmail\":null}', '2021-07-04 09:14:07', '2021-10-16 03:12:17'),
(34, 'senang_pay', '{\"status\":null,\"secret_key\":null,\"published_key\":null,\"merchant_id\":null}', '2021-07-04 09:14:13', '2021-09-09 22:28:04'),
(35, 'order_handover_message', '{\"status\":0,\"message\":null}', NULL, NULL),
(36, 'order_cancled_message', '{\"status\":0,\"message\":null}', NULL, NULL),
(37, 'timezone', 'US/Eastern', NULL, NULL),
(38, 'order_delivery_verification', '0', NULL, NULL),
(39, 'currency_symbol_position', 'left', NULL, NULL),
(40, 'schedule_order', '1', NULL, NULL),
(41, 'app_minimum_version', '0', NULL, NULL),
(42, 'tax', NULL, NULL, NULL),
(43, 'admin_commission', '10', NULL, NULL),
(44, 'country', 'US', NULL, NULL),
(45, 'app_url', 'up_comming', NULL, NULL),
(46, 'default_location', '{\"lat\":\"0\",\"lng\":\"0\"}', NULL, NULL),
(47, 'twilio_sms', '{\"status\":\"1\",\"sid\":\"AC7a7074d8854ab81a5b4e15f1cca34800\",\"messaging_service_id\":\"MG60c86e7a538fcf99dbeebe237710a39b\",\"token\":\"b573f3cb83c55901f81e468c64e36621\",\"from\":\"+17163207279\",\"otp_template\":\"Your otp is #OTP#.\"}', '2021-11-18 16:32:04', '2021-11-18 16:32:04'),
(48, 'nexmo_sms', '{\"status\":0,\"api_key\":null,\"api_secret\":null,\"signature_secret\":\"\",\"private_key\":\"\",\"application_id\":\"\",\"from\":null,\"otp_template\":\"Your otp is #OTP#.\"}', '2021-11-18 16:32:04', '2021-11-18 16:32:04'),
(49, '2factor_sms', '{\"status\":0,\"api_key\":\"Your otp is #OTP#.\"}', '2021-11-18 16:32:04', '2021-11-18 16:32:04'),
(50, 'msg91_sms', '{\"status\":0,\"template_id\":null,\"authkey\":null}', '2021-11-18 16:32:04', '2021-11-18 16:32:04'),
(51, 'admin_order_notification', '1', NULL, NULL),
(52, 'free_delivery_over', NULL, NULL, NULL),
(53, 'maintenance_mode', '0', '2021-09-09 21:33:55', '2021-09-09 21:33:58'),
(54, 'app_minimum_version_android', NULL, NULL, NULL),
(55, 'app_minimum_version_ios', NULL, NULL, NULL),
(56, 'app_url_android', NULL, NULL, NULL),
(57, 'app_url_ios', NULL, NULL, NULL),
(58, 'dm_maximum_orders', '1', NULL, NULL),
(59, 'flutterwave', '{\"status\":\"1\",\"public_key\":null,\"secret_key\":null,\"hash\":null}', '2021-09-23 06:51:28', '2021-10-16 03:12:01'),
(60, 'order_confirmation_model', 'restaurant', NULL, NULL),
(61, 'mercadopago', '{\"status\":null,\"public_key\":null,\"access_token\":null}', NULL, '2021-10-16 03:12:09'),
(62, 'popular_food', '1', NULL, NULL),
(63, 'popular_restaurant', '1', NULL, NULL),
(64, 'new_restaurant', '1', NULL, NULL),
(65, 'map_api_key_server', 'AIzaSyAe6Xqiu_wSEgmhEal5dBXJRlLy-Hr_o7o', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `campaigns`
--

CREATE TABLE `campaigns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `admin_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaigns`
--

INSERT INTO `campaigns` (`id`, `title`, `image`, `description`, `status`, `admin_id`, `created_at`, `updated_at`, `start_date`, `end_date`, `start_time`, `end_time`) VALUES
(1, 'First Rating', '2021-11-27-61a1abe7cb34b.png', 'First time you Rate anything on Rated you receive 25% off your next purchase.', 1, NULL, '2021-11-27 15:39:15', '2021-11-27 15:39:15', '2022-01-02', '2025-01-02', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `campaign_restaurant`
--

CREATE TABLE `campaign_restaurant` (
  `campaign_id` bigint(20) UNSIGNED NOT NULL,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'def.png',
  `parent_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `image`, `parent_id`, `position`, `status`, `created_at`, `updated_at`, `priority`) VALUES
(1, 'Active Life', '2022-02-14-620a88eb009eb.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-14 16:52:59', 0),
(2, 'ATV Rentals/Tours', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(3, 'Airsoft', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(4, 'Amateur Sports Teams', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(5, 'Amusement Parks', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(6, 'Aquariums', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(7, 'Archery', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(8, 'Axe Throwing', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(9, 'Badminton', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(10, 'Baseball Fields', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(11, 'Basketball Courts', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(12, 'Batting Cages', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(13, 'Beach Equipment Rentals', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(14, 'Beaches', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(15, 'Bike Parking', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(16, 'Bike Rentals', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(17, 'Boating', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(18, 'Bobsledding', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(19, 'Bocce Ball', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(20, 'Bowling', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(21, 'Bubble Soccer', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(22, 'Bungee Jumping', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(23, 'Canyoneering', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(24, 'Carousels', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(25, 'Challenge Courses', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(26, 'Climbing', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(27, 'Cycling Classes', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(28, 'Dart Arenas', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(29, 'Day Camps', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(30, 'Disc Golf', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(31, 'Diving', '2022-02-14-620a89e1b7ed2.png', 1, 0, 1, '2022-02-09 11:47:57', '2022-02-14 16:57:05', 0),
(32, 'Free Diving', 'def.png', 31, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(33, 'Scuba Diving', 'def.png', 31, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(34, 'Escape Games', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(35, 'Fencing Clubs', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(36, 'Fishing', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(37, 'Fitness & Instruction', '2022-02-16-620ca17e8859a.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:02:22', 0),
(38, 'Aerial Fitness', 'def.png', 37, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(39, 'Barre Classes', 'def.png', 37, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(40, 'Boot Camps', 'def.png', 37, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(41, 'Boxing', 'def.png', 37, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(42, 'Cardio Classes', 'def.png', 37, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(43, 'Dance Studios', 'def.png', 37, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(44, 'Golf Lessons', 'def.png', 37, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(45, 'Gyms', '2022-02-16-620c9f2b31c53.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:52:27', 0),
(46, 'Circuit Training Gyms', 'def.png', 45, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(47, 'Interval Training Gyms', 'def.png', 45, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(48, 'Martial Arts', '2022-02-16-620c9f47295dc.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:52:55', 0),
(49, 'Brazilian Jiu-jitsu', 'def.png', 48, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(50, 'Chinese Martial Arts', 'def.png', 48, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(51, 'Karate', 'def.png', 48, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(52, 'Kickboxing', 'def.png', 48, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(53, 'Muay Thai', 'def.png', 48, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(54, 'Taekwondo', 'def.png', 48, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(55, 'Meditation Centers', '2022-02-16-620c9f5e0f7fe.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:53:18', 0),
(56, 'Pilates', 'def.png', 55, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(57, 'Qi Gong', 'def.png', 55, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(58, 'Self-defense Classes', 'def.png', 55, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(59, 'Swimming Lessons/Schools', 'def.png', 55, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(60, 'Tai Chi', 'def.png', 55, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(61, 'Trainers', 'def.png', 55, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(62, 'Yoga', 'def.png', 55, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(63, 'Flyboarding', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(64, 'Go Karts', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(65, 'Golf', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(66, 'Gun/Rifle Ranges', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(67, 'Gymnastics', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(68, 'Hang Gliding', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(69, 'Hiking', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(70, 'Horse Racing', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(71, 'Horseback Riding', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(72, 'Hot Air Balloons', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(73, 'Indoor Playcentre', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(74, 'Jet Skis', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(75, 'Kids Activities', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(76, 'Kiteboarding', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(77, 'Lakes', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(78, 'Laser Tag', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(79, 'Mini Golf', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(80, 'Mountain Biking', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(81, 'Nudist', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(82, 'Paddleboarding', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(83, 'Paintball', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(84, 'Paragliding', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(85, 'Parasailing', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(86, 'Parks', '2022-02-16-620ca22508304.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:05:09', 0),
(87, 'Dog Parks', 'def.png', 86, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(88, 'Skate Parks', 'def.png', 86, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(89, 'Pickleball', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(90, 'Playgrounds', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(91, 'Races & Competitions', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(92, 'Racing Experience', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(93, 'Rafting/Kayaking', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(94, 'Recreation Centers', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(95, 'Rock Climbing', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(96, 'Sailing', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(97, 'Scavenger Hunts', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(98, 'Scooter Rentals', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(99, 'Senior Centers', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(100, 'Skating Rinks', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(101, 'Skydiving', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(102, 'Sledding', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(103, 'Snorkeling', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(104, 'Soccer', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(105, 'Sports Clubs', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(106, 'Squash', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(107, 'Summer Camps', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(108, 'Surfing', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(109, 'Swimming Pools', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(110, 'Tennis', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(111, 'Trampoline Parks', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(112, 'Tubing', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(113, 'Water Parks', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(114, 'Wildlife Hunting Ranges', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(115, 'Ziplining', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(116, 'Zoos', '2022-02-16-620ca3fb4cfce.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:12:59', 0),
(117, 'Petting Zoos', 'def.png', 116, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(118, 'Zorbing', 'def.png', 1, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(119, 'Automotive', '2022-02-16-620ca3d012e0f.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:12:16', 0),
(120, 'Aircraft Dealers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(121, 'Aircraft Repairs', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(122, 'Auto Customization', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(123, 'Auto Detailing', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(124, 'Auto Glass Services', '2022-02-16-620ca392817b5.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:11:14', 0),
(125, 'Car Window Tinting', 'def.png', 124, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(126, 'Auto Loan Providers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(127, 'Auto Parts & Supplies', '2022-02-16-620ca38362c8e.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:10:59', 0),
(128, 'Motorcycle Parts & Supplies', 'def.png', 127, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(129, 'Auto Repair', '2022-02-16-620ca36f5783a.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:10:39', 0),
(130, 'DIY Auto Shop', 'def.png', 129, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(131, 'Auto Security', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(132, 'Auto Upholstery', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(133, 'Aviation Services', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(134, 'Boat Dealers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(135, 'Boat Parts & Supplies', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(136, 'Body Shops', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(137, 'Car Auctions', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(138, 'Car Brokers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(139, 'Car Buyers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(140, 'Car Dealers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(141, 'Car Inspectors', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(142, 'Car Share Services', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(143, 'Car Stereo Installation', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(144, 'Car Wash', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(145, 'Commercial Truck Dealers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(146, 'Commercial Truck Repair', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(147, 'EV Charging Stations', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(148, 'Fuel Docks', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(149, 'Gas Stations', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(150, 'Golf Cart Dealers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(151, 'Hybrid Car Repair', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(152, 'Interlock Systems', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(153, 'Marinas (marinas)', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(154, 'Mobile Dent Repair', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(155, 'Mobility Equipment Sales & Services', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(156, 'Motorcycle Dealers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(157, 'Motorcycle Repair', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(158, 'Motorsport Vehicle Dealers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(159, 'Motorsport Vehicle Repairs', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(160, 'Oil Change Stations', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(161, 'Parking', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(162, 'RV Dealers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(163, 'RV Repair', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(164, 'Registration Services', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(165, 'Roadside Assistance', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(166, 'Service Stations', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(167, 'Smog Check Stations', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(168, 'Tires', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(169, 'Towing', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(170, 'Trailer Dealers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(171, 'Trailer Rental', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(172, 'Trailer Repair', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(173, 'Transmission Repair', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(174, 'Truck Rental', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(175, 'Used Car Dealers', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(176, 'Vehicle Shipping', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(177, 'Vehicle Wraps', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(178, 'Wheel & Rim Repair', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(179, 'Windshield Installation & Repair', 'def.png', 119, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(180, 'Beauty & Spas', '2022-02-16-620ca87c89494.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:32:12', 0),
(181, 'Acne Treatment', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(182, 'Barbers', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(183, 'Cosmetics & Beauty Supply', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(184, 'Day Spas', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(185, 'Eyebrow Services', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(186, 'Eyelash Service', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(187, 'Hair Extensions', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(188, 'Hair Loss Centers', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(189, 'Hair Removal', '2022-02-16-620ca8bc4cf41.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:33:16', 0),
(190, 'Laser Hair Removal', 'def.png', 189, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(191, 'Sugaring', 'def.png', 189, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(192, 'Threading Services', 'def.png', 189, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(193, 'Waxing', 'def.png', 189, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(194, 'Hair Salons', 'Hair Salons.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(195, 'Blow Dry/Out Services', 'def.png', 195, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(196, 'Hair Extensions', 'def.png', 195, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(197, 'Hair Stylists', 'def.png', 195, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(198, 'Kids Hair Salons', 'def.png', 195, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(199, 'Men?s Hair Salons', 'def.png', 195, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(200, 'Hot Springs', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(201, 'Makeup Artists', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(202, 'Massage', '2022-02-16-620ca955420ae.png', 180, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:35:49', 0),
(203, 'Medical Spa', 'Medical Spas (2).png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:37:24', 0),
(204, 'Aestheticians', 'def.png', 203, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(205, 'Nail Salons', '2022-02-16-620ca69d05865.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:24:13', 0),
(206, 'Nail Technicians', 'def.png', 205, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(207, 'Perfume', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(208, 'Permanent Makeup', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(209, 'Piercing', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(210, 'Skin Care', '2022-02-16-620ca60e03da8.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:21:50', 0),
(211, 'Estheticians', 'def.png', 210, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(212, 'Tanning', '2022-02-16-620ca5ff6feb2.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:21:35', 0),
(213, 'Spray Tanning', 'def.png', 212, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(214, 'Tanning Beds', 'def.png', 212, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(215, 'Tattoo', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(216, 'Teeth Whitening', 'def.png', 180, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(217, 'Education', '2022-02-16-620ca5de52e32.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:21:02', 0),
(218, 'Adult Education', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(219, 'Art Classes', '2022-02-16-620ca5b938563.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:20:25', 0),
(220, 'Glass Blowing', 'def.png', 219, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(221, 'College Counseling', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(222, 'Colleges & Universities', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(223, 'Educational Services', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(224, 'Elementary Schools', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(225, 'Middle Schools & High Schools', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(226, 'Montessori Schools', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(227, 'Preschools', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(228, 'Private Schools', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(229, 'Private Tutors', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(230, 'Religious Schools', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(231, 'Special Education', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(232, 'Specialty Schools', '2022-02-16-620ca593cb3df.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:19:47', 0),
(233, 'Art Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(234, 'Bartending Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(235, 'CPR Classes', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(236, 'Cheerleading', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(237, 'Childbirth Education', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(238, 'Cooking Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(239, 'Cosmetology Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(240, 'DUI Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(241, 'Dance Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(242, 'Drama Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(243, 'Driving Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(244, 'Firearm Training', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(245, 'First Aid Classes', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(246, 'Flight Instruction', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(247, 'Food Safety Training', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(248, 'Language Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(249, 'Massage Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(250, 'Nursing Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(251, 'Parenting Classes', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(252, 'Photography Classes', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(253, 'Pole Dancing Classes', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(254, 'Ski Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(255, 'Speech Training', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(256, 'Surf Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(257, 'Swimming Lessons/Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(258, 'Traffic Schools', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(259, 'Vocational & Technical School', 'def.png', 232, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(260, 'Tasting Classes', '2022-02-14-620a89385e899.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-14 16:54:16', 0),
(261, 'Cheese Tasting Classes', 'def.png', 260, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(262, 'Wine Tasting Classes', 'def.png', 260, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(263, 'Test Preparation', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(264, 'Tutoring Centers', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(265, 'Waldorf Schools', 'def.png', 217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(266, 'Event Planning & Services', '2022-02-14-620a894b7bdae.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-14 16:54:35', 0),
(267, 'Balloon Services', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(268, 'Bartenders', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(269, 'Boat Charters', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(270, 'Cards & Stationery', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(271, 'Caricatures', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(272, 'Caterers', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(273, 'Clowns', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(274, 'DJs', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(275, 'Face Painting', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(276, 'Floral Designers', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(277, 'Game Truck Rental', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(278, 'Golf Cart Rentals', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(279, 'Henna Artists', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(280, 'Hotel', '2022-02-14-620a8a8478719.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-14 16:59:48', 0),
(281, 'Mountain Huts', 'def.png', 280, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(282, 'Residences', 'def.png', 280, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(283, 'Rest Stops', 'def.png', 280, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(284, 'Magicians', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(285, 'Mohels', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(286, 'Musicians', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(287, 'Officiants', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(288, 'Party & Event Planning', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(289, 'Party Bike Rentals', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(290, 'Party Bus Rentals', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(291, 'Party Characters', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(292, 'Party Equipment Rentals', '2022-02-16-620ca16b1851d.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:02:03', 0),
(293, 'Audio/Visual Equipment Rental', 'def.png', 292, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(294, 'Bounce House Rentals', 'def.png', 292, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(295, 'Karaoke Rentals', 'def.png', 292, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(296, 'Party Supplies', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(297, 'Personal Chefs', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(298, 'Photo Booth Rentals', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(299, 'Photographers', '2022-02-16-620c9fa64b169.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:54:30', 0),
(300, 'Boudoir Photography', 'def.png', 299, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(301, 'Event Photography', 'def.png', 299, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(302, 'Session Photography', 'def.png', 299, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(303, 'Silent Disco', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(304, 'Sommelier Services', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(305, 'Team Building Activities', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(306, 'Trivia Hosts', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(307, 'Valet Services', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(308, 'Venues & Event Spaces', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(309, 'Videographers', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(310, 'Wedding Chapels', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(311, 'Wedding Planning', 'def.png', 266, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(312, 'Financial Services', '2022-02-16-620c9f70a2613.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:53:36', 0),
(313, 'Banks & Credit Unions', 'def.png', 312, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(314, 'Business Financing', 'def.png', 312, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(315, 'Check Cashing/Pay-day Loans', 'def.png', 312, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(316, 'Currency Exchange', 'def.png', 312, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(317, 'Debt Relief Services', 'def.png', 312, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(318, 'Financial Advising', 'def.png', 312, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(319, 'Installment Loans', 'def.png', 312, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(320, 'Insurance', '2022-02-16-620ca0a018b44.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:58:40', 0),
(321, 'Auto Insurance', 'def.png', 320, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(322, 'Home & Rental Insurance', 'def.png', 320, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(323, 'Life Insurance', 'def.png', 320, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(324, 'Investing', 'def.png', 312, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(325, 'Mortgage Lenders', 'def.png', 312, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(326, 'Tax Services', 'def.png', 312, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(327, 'Title Loans', 'def.png', 312, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(328, 'Food', '2022-02-16-620ca0111fcbe.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:56:17', 0),
(329, 'Acai Bowls', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(330, 'Bagels', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(331, 'Bakeries', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(332, 'Beer, Wine & Spirits', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(333, 'Beverage Store', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(334, 'Breweries', '2022-02-16-620ca247e7082.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:05:43', 0),
(335, 'Brewpubs', 'def.png', 334, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(336, 'Bubble Tea', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(337, 'Butcher', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(338, 'CSA', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(339, 'Chimney Cakes', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(340, 'Cideries', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(341, 'Coffee & Tea', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(342, 'Coffee Roasteries', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(343, 'Convenience Stores', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(344, 'Cupcakes', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(345, 'Custom Cakes', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(346, 'Desserts', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(347, 'Distilleries', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(348, 'Do-It-Yourself Food', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(349, 'Donuts', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(350, 'Empanadas', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(351, 'Farmers Market', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(352, 'Food Delivery Services', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(353, 'Food Trucks', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(354, 'Gelato', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(355, 'Grocery', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(356, 'Honey', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(357, 'Ice Cream & Frozen Yogurt', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(358, 'Imported Food', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(359, 'International Grocery', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(360, 'Internet Cafes', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(361, 'Juice Bars & Smoothies', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(362, 'Kombucha', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(363, 'Meaderies', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(364, 'Organic Stores', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(365, 'Patisserie/Cake Shop', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(366, 'Piadina', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(367, 'Poke', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(368, 'Pretzels', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(369, 'Shaved Ice', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(370, 'Shaved Snow', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(371, 'Smokehouse', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(372, 'Specialty Food', '2022-02-16-620ca3ec73891.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:12:44', 0),
(373, 'Candy Stores', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(374, 'Cheese Shops', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(375, 'Chocolatiers & Shops', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(376, 'Fruits & Veggies', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(377, 'Health Markets', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(378, 'Herbs & Spices', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(379, 'Macarons', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(380, 'Meat Shops', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(381, 'Olive Oil', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(382, 'Pasta Shops', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(383, 'Popcorn Shops', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(384, 'Seafood Markets', 'def.png', 372, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(385, 'Street Vendors', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(386, 'Tea Rooms', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(387, 'Water Stores', 'def.png', 328, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(388, 'Wineries', '2022-02-16-620ca2b5a594d.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:07:33', 0),
(389, 'Wine Tasting Room', 'def.png', 388, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(390, 'Health & Medical', '2022-02-16-620ca443e6885.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:14:11', 0),
(391, 'Acupuncture', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(392, 'Alternative Medicine', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(393, 'Animal Assisted Therapy', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(394, 'Assisted Living Facilities', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(395, 'Ayurveda', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(396, 'Behavior Analysts', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(397, 'Blood & Plasma Donation Centers', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(398, 'Body Contouring', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(399, 'Cannabis Clinics', '2022-02-16-620ca7ad48cc8.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:28:45', 0),
(400, 'Cannabis Dispensaries', 'def.png', 399, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(401, 'Cannabis Foods', 'def.png', 399, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(402, 'Chiropractors', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(403, 'Colonics', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(404, 'Concierge Medicine', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(405, 'Counseling & Mental Health', '2022-02-16-620ca7cbc10cc.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:29:15', 0),
(406, 'Psychologists', 'def.png', 405, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(407, 'Sex Therapists', 'def.png', 405, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(408, 'Sports Psychologists', 'def.png', 405, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(409, 'Crisis Pregnancy Centers', '2022-02-16-620ca7ee7f530.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:29:50', 0),
(410, 'Faith-based Crisis Pregnancy Centers', 'def.png', 409, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(411, 'Cryotherapy', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(412, 'Dental Hygienists', 'def.png', 413, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(413, 'Dentists', '2022-02-16-620ca80c74132.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:30:20', 0),
(414, 'Cosmetic Dentists', 'def.png', 413, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(415, 'Endodontists', 'def.png', 413, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(416, 'General Dentistry', 'def.png', 413, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(417, 'Oral Surgeons', 'def.png', 413, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(418, 'Orthodontists', 'def.png', 413, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(419, 'Pediatric Dentists', 'def.png', 413, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(420, 'Periodontists', 'def.png', 413, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(421, 'Diagnostic Services', '2022-02-16-620ca82e8fff5.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:30:54', 0),
(422, 'Diagnostic Imaging', 'def.png', 421, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(423, 'Laboratory Testing', 'def.png', 421, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(424, 'Dialysis Clinics', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(425, 'Dietitians', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(426, 'Doctors', '2022-02-16-620ca852c7cfa.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:31:30', 0),
(427, 'Addiction Medicine', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(428, 'Allergists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(429, 'Anesthesiologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(430, 'Audiologist', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(431, 'Cardiologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(432, 'Cosmetic Surgeons', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(433, 'Dermatologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(434, 'Ear Nose & Throat', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(435, 'Emergency Medicine', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(436, 'Endocrinologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(437, 'Family Practice', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(438, 'Fertility', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(439, 'Gastroenterologist', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(440, 'Geneticists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(441, 'Gerontologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(442, 'Hepatologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(443, 'Hospitalists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(444, 'Immunodermatologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(445, 'Infectious Disease Specialists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(446, 'Internal Medicine', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(447, 'Naturopathic/Holistic', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(448, 'Nephrologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(449, 'Neurologist', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(450, 'Neuropathologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(451, 'Neurotologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(452, 'Obstetricians & Gynecologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(453, 'Oncologist', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(454, 'Ophthalmologists', '2022-02-16-620ca903cca28.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:34:27', 0),
(455, 'Retina Specialists', 'def.png', 454, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(456, 'Orthopedists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(457, 'Osteopathic Physicians', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(458, 'Otologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(459, 'Pain Management', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(460, 'Pathologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(461, 'Pediatricians', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(462, 'Phlebologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(463, 'Plastic Surgeons', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(464, 'Podiatrists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(465, 'Preventive Medicine', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(466, 'Proctologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(467, 'Psychiatrists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(468, 'Pulmonologist', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(469, 'Radiologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(470, 'Rheumatologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(471, 'Spine Surgeons', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(472, 'Sports Medicine', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(473, 'Surgeons', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(474, 'Tattoo Removal', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(475, 'Toxicologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(476, 'Undersea/Hyperbaric Medicine', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(477, 'Urologists', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(478, 'Vascular Medicine', 'def.png', 426, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(479, 'Doulas', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(480, 'Emergency Rooms', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(481, 'Float Spa', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(482, 'Habilitative Services', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(483, 'Halfway Houses', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(484, 'Halotherapy', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(485, 'Health Coach', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(486, 'Health Insurance Offices', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(487, 'Hearing Aid Providers', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(488, 'Herbal Shops', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(489, 'Home Health Care', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(490, 'Hospice', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(491, 'Hospitals', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(492, 'Hydrotherapy', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(493, 'Hypnosis/Hypnotherapy', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(494, 'IV Hydration', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(495, 'Lactation Services', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(496, 'Laser Eye Surgery/Lasik', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(497, 'Lice Services', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(498, 'Massage Therapy', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(499, 'Medical Cannabis Referrals', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(500, 'Medical Centers', '2022-02-16-620ca53f29cac.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:18:23', 0),
(501, 'Walk-in Clinics', 'def.png', 500, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(502, 'Medical Spas', 'Medical Spas (2).png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(503, 'Aestheticians', 'def.png', 502, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(504, 'Medical Transportation', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(505, 'Memory Care', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(506, 'Midwives', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(507, 'Nurse Practitioner', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(508, 'Nutritionists', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(509, 'Occupational Therapy', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(510, 'Optometrists', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(511, 'Organ & Tissue Donor Services', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(512, 'Orthotics', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(513, 'Oxygen Bars', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(514, 'Personal Care Services', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(515, 'Pharmacy', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(516, 'Physical Therapy', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(517, 'Placenta Encapsulations', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(518, 'Prenatal/Perinatal Care', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(519, 'Prosthetics', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(520, 'Prosthodontists', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(521, 'Reflexology', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(522, 'Rehabilitation Center', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(523, 'Reiki', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(524, 'Reproductive Health Services', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0);
INSERT INTO `categories` (`id`, `name`, `image`, `parent_id`, `position`, `status`, `created_at`, `updated_at`, `priority`) VALUES
(525, 'Retirement Homes', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(526, 'Saunas', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(527, 'Skilled Nursing', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(528, 'Sleep Specialists', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(529, 'Speech Therapists', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(530, 'Sperm Clinic', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(531, 'Traditional Chinese Medicine', '2022-02-14-620a89559fbbd.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-14 16:54:45', 0),
(532, 'Tui Na', 'def.png', 531, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(533, 'Ultrasound Imaging Centers', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(534, 'Urgent Care', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(535, 'Weight Loss Centers', 'def.png', 390, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(536, 'Home Services', '2022-02-14-620a89c5afd24.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-14 16:56:37', 0),
(537, 'Artificial Turf', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(538, 'Building Supplies', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(539, 'Cabinetry', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(540, 'Carpenters', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(541, 'Carpet Installation', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(542, 'Carpeting', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(543, 'Childproofing', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(544, 'Chimney Sweeps', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(545, 'Contractors', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(546, 'Countertop Installation', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(547, 'Damage Restoration', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(548, 'Decks & Railing', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(549, 'Demolition Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(550, 'Door Sales/Installation', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(551, 'Drywall Installation & Repair', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(552, 'Electricians', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(553, 'Excavation Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(554, 'Fences & Gates', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(555, 'Fire Protection Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(556, 'Fireplace Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(557, 'Firewood', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(558, 'Flooring', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(559, 'Foundation Repair', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(560, 'Furniture Assembly', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(561, 'Garage Door Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(562, 'Gardeners', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(563, 'Glass & Mirrors', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(564, 'Grout Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(565, 'Gutter Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(566, 'Handyman', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(567, 'Heating & Air Conditioning/HVAC', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(568, 'Holiday Decorating Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(569, 'Home Automation', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(570, 'Home Cleaning', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(571, 'Home Energy Auditors', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(572, 'Home Inspectors', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(573, 'Home Network Installation', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(574, 'Home Organization', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(575, 'Home Theatre Installation', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(576, 'Home Window Tinting', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(577, 'House Sitters', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(578, 'Insulation Installation', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(579, 'Interior Design', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(580, 'Internet Service Providers', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(581, 'Irrigation', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(582, 'Keys & Locksmiths', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(583, 'Landscape Architects', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(584, 'Landscaping', '2022-02-16-620ca02027df3.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:56:32', 0),
(585, 'Lawn Services', 'def.png', 584, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(586, 'Lighting Fixtures & Equipment', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(587, 'Masonry/Concrete', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(588, 'Mobile Home Repair', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(589, 'Movers', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(590, 'Packing Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(591, 'Painters', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(592, 'Patio Coverings', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(593, 'Plumbing', '2022-02-16-620ca236b6718.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:05:26', 0),
(594, 'Backflow Services', 'def.png', 593, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(595, 'Pool & Hot Tub Service', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(596, 'Pool Cleaners', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(597, 'Pressure Washers', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(598, 'Real Estate Investment', '2022-02-16-620ca211cd2ed.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:04:49', 0),
(599, 'Apartments', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(600, 'Art Space Rentals', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(601, 'Commercial Real Estate', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(602, 'Condominiums', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(603, 'Estate Liquidation', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(604, 'Home Developers', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(605, 'Home Staging', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(606, 'Homeowner Association', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(607, 'Housing Cooperatives', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(608, 'Kitchen Incubators', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(609, 'Mobile Home Dealers', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(610, 'Mobile Home Parks', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(611, 'Mortgage Brokers', 'def.png', 615, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(612, 'Property Management', 'def.png', 615, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(613, 'Real Estate Agents', 'def.png', 615, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(614, 'Apartment Agents', 'def.png', 615, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(615, 'Real Estate Service', '2022-02-16-620ca1ab9f4bf.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:03:07', 0),
(616, 'Land Surveying', 'def.png', 615, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(617, 'Real Estate Photography', 'def.png', 615, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(618, 'Shared Office Spaces', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(619, 'University Housing', 'def.png', 598, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(620, 'Refinishing Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(621, 'Roof Inspectors', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(622, 'Roofing', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(623, 'Sauna Installation & Repair', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(624, 'Security Systems', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(625, 'Shades & Blinds', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(626, 'Shutters', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(627, 'Siding', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(628, 'Solar Installation', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(629, 'Solar Panel Cleaning', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(630, 'Structural Engineers', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(631, 'Stucco Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(632, 'Television Service Providers', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(633, 'Tiling', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(634, 'Tree Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(635, 'Utilities', '2022-02-16-620ca3a2d0a6d.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:11:30', 0),
(636, 'Electricity Suppliers', 'def.png', 635, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(637, 'Natural Gas Suppliers', 'def.png', 635, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(638, 'Water Suppliers', 'def.png', 635, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(639, 'Wallpapering', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(640, 'Water Heater Installation/Repair', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(641, 'Water Purification Services', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(642, 'Waterproofing', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(643, 'Window Washing', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(644, 'Windows Installation', 'def.png', 536, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(645, 'Hotels & Travel', '2022-02-16-620ca452eb2b6.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:14:26', 0),
(646, 'Airports', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(647, 'Shuttles', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(648, 'Bed & Breakfast', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(649, 'Campgrounds', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(650, 'Car Rental', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(651, 'Guest Houses', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(652, 'Health Retreats', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(653, 'Hostels', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(654, 'Hotels', 'Hotels (2).png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(655, 'Mountain Huts', 'def.png', 654, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(656, 'Residences', 'def.png', 654, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(657, 'Rest Stops', 'def.png', 654, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(658, 'Motorcycle Rental', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(659, 'RV Parks', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(660, 'RV Rental', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(661, 'Resorts', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(662, 'Ski Resorts', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(663, 'Tours', '2022-02-16-620ca7dcaaf97.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:29:32', 0),
(664, 'Aerial Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(665, 'Architectural Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(666, 'Art Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(667, 'Beer Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(668, 'Bike tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(669, 'Boat Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(670, 'Bus Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(671, 'Food Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(672, 'Historical Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(673, 'Scooter Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(674, 'Walking Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(675, 'Whale Watching Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(676, 'Wine Tours', 'def.png', 663, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(677, 'Train Stations', '2022-02-16-620ca840b1945.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:31:12', 0),
(678, 'Transportation', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(679, 'Airlines', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(680, 'Airport Shuttles', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(681, 'Bike Sharing', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(682, 'Bus Stations', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(683, 'Buses', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(684, 'Cable Cars', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(685, 'Ferries', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(686, 'Limos', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(687, 'Metro Stations', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(688, 'Pedicabs', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(689, 'Private Jet Charter', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(690, 'Public Transportation', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(691, 'Taxis', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(692, 'Town Car Service', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(693, 'Trains', 'def.png', 677, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(694, 'Travel Services', '2022-02-16-620ca88d6a93c.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:32:29', 0),
(695, 'Luggage Storage', 'def.png', 694, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(696, 'Passport & Visa Services', 'def.png', 694, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(697, 'Travel Agents', 'def.png', 694, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(698, 'Visitor Centers', 'def.png', 694, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(699, 'Vacation Rental Agents', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(700, 'Vacation Rentals', 'def.png', 645, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(701, 'Local Flavor', '2022-02-16-620ca8cee7c2e.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:33:34', 0),
(702, 'Rallies', 'def.png', 701, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(703, 'City Events', 'def.png', 701, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(704, 'RateNoun Live', 'def.png', 701, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(705, 'RateNoun Events', 'def.png', 701, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(706, 'Local Services', 'Local Services.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(707, '3D Printing', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(708, 'Adoption Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(709, 'Air Duct Cleaning', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(710, 'Appliances & Repair', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(711, 'Appraisal Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(712, 'Art Installation', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(713, 'Art Restoration', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(714, 'Awnings', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(715, 'Bail Bondsmen', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(716, 'Bike Repair/Maintenance', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(717, 'Biohazard Cleanup', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(718, 'Bookbinding', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(719, 'Bus Rental', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(720, 'Calligraphy', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(721, 'Carpet Cleaning', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(722, 'Carpet Dyeing', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(723, 'Child Care & Day Care', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(724, 'Clock Repair', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(725, 'Community Book Box', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(726, 'Community Gardens', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(727, 'Community Service/Non-Profit', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(728, 'Food Banks', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(729, 'Homeless Shelters', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(730, 'Couriers & Delivery Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(731, 'Crane Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(732, 'Donation Center', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(733, 'Elder Care Planning', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(734, 'Electronics Repair', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(735, 'Elevator Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(736, 'Engraving', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(737, 'Environmental Abatement', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(738, 'Environmental Testing', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(739, 'Farm Equipment Repair', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(740, 'Fingerprinting', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(741, 'Funeral Services & Cemeteries', '2022-02-16-620ca5a8e1c06.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:20:08', 0),
(742, 'Cremation Services', 'def.png', 741, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(743, 'Mortuary Services', 'def.png', 741, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(744, 'Furniture Rental', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(745, 'Furniture Repair', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(746, 'Furniture Reupholstery', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(747, 'Generator Installation/Repair', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(748, 'Grill Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(749, 'Gunsmith', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(750, 'Hazardous Waste Disposal', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(751, 'Hydro-jetting', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(752, 'IT Services & Computer Repair', '2022-02-16-620ca56cb2d93.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:19:08', 0),
(753, 'Data Recovery', 'def.png', 752, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(754, 'Mobile Phone Repair', 'def.png', 752, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(755, 'Telecommunications', 'def.png', 752, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(756, 'Ice Delivery', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(757, 'Jewelry Repair', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(758, 'Junk Removal & Hauling', '2022-02-16-620ca4f57db8a.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:17:09', 0),
(759, 'Moving Service', 'def.png', 758, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(760, 'Junkyards', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(761, 'Knife Sharpening', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(762, 'Laundry Services', '2022-02-16-620ca4d0edf18.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:16:33', 0),
(763, 'Dry Cleaning', 'def.png', 762, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(764, 'Laundromat', 'def.png', 762, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(765, 'Machine & Tool Rental', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(766, 'Machine Shops', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(767, 'Mailbox Centers', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(768, 'Metal Detector Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(769, 'Metal Fabricators', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(770, 'Misting System Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(771, 'Musical Instrument Services', '2022-02-14-620a8928296b2.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-14 16:54:00', 0),
(772, 'Guitar Stores', 'def.png', 771, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(773, 'Piano Services', 'def.png', 771, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(774, 'Piano Stores', 'def.png', 771, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(775, 'Vocal Coach', 'def.png', 771, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(776, 'Nanny Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(777, 'Notaries', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(778, 'Outdoor Power Equipment Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(779, 'Pest Control', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(780, 'Portable Toilet Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(781, 'Powder Coating', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(782, 'Printing Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(783, 'Propane', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(784, 'Recording & Rehearsal Studios', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(785, 'Recycling Center', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(786, 'Sandblasting', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(787, 'Screen Printing', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(788, 'Screen Printing/T-Shirt Printing', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(789, 'Self Storage', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(790, 'Septic Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(791, 'Sewing & Alterations', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(792, 'Shipping Centers', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(793, 'Shoe Repair', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(794, 'Shoe Shine', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(795, 'Snow Removal', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(796, 'Snuggle Services', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(797, 'Stonemasons', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(798, 'TV Mounting', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(799, 'Watch Repair', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(800, 'Water Delivery', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(801, 'Well Drilling', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(802, 'Wildlife Control', 'def.png', 706, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(803, 'Mass Media', '2022-02-14-620a89f4e0310.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-14 16:57:24', 0),
(804, 'Print Media', 'def.png', 803, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(805, 'Radio Stations', 'def.png', 803, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(806, 'Television Stations', 'def.png', 803, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(807, 'Nightlife', '2022-02-16-620c9edbdbd10.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:51:07', 0),
(808, 'Adult Parties', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(809, 'Strip Clubs', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(810, 'Striptease Dancers', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(811, 'Bar Crawl', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(812, 'Bars', '2022-02-16-620c9f1df0902.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:52:13', 0),
(813, 'Airport Lounges', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(814, 'Beer Bar', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(815, 'Champagne Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(816, 'Cigar Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(817, 'Cocktail Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(818, 'Dive Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(819, 'Drive-Thru Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(820, 'Gay Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(821, 'Hookah Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(822, 'Irish Pub', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(823, 'Lounges', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(824, 'Pubs', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(825, 'Speakeasies', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(826, 'Sports Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(827, 'Tiki Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(828, 'Vermouth Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(829, 'Whiskey Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(830, 'Wine Bars', 'def.png', 812, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(831, 'Beer Gardens', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(832, 'Club Crawl', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(833, 'Comedy Clubs', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(834, 'Country Dance Halls', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(835, 'Dance Clubs', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(836, 'Jazz & Blues', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(837, 'Karaoke', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(838, 'Music Venues', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(839, 'Piano Bars', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(840, 'Pool Halls', 'def.png', 807, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(841, 'Pets', '2022-02-16-620ca26b31bd4.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:06:19', 0),
(842, 'Animal Shelters', 'def.png', 841, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(843, 'Horse Boarding', 'def.png', 841, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(844, 'Pet Adoption', 'def.png', 841, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(845, 'Pet Services', '2022-02-16-620ca25be94e6.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:06:03', 0),
(846, 'Animal Physical Therapy', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(847, 'Aquarium Services', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(848, 'Dog Walkers', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(849, 'Emergency Pet Hospital', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(850, 'Farriers', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(851, 'Holistic Animal Care', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(852, 'Pet Breeders', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(853, 'Pet Cremation Services', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(854, 'Pet Groomers', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(855, 'Pet Hospice', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(856, 'Pet Insurance', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(857, 'Pet Photography', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(858, 'Pet Sitting', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(859, 'Pooper Scoopers', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(860, 'Pet Training', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(861, 'Pet Transportation', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(862, 'Pet Whispers', 'def.png', 845, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(863, 'Pet Stores', '2022-02-16-620ca1e112512.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:04:01', 0),
(864, 'Bird Shops', 'def.png', 863, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(865, 'Local Fish Stores', 'def.png', 863, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(866, 'Reptile Shops', 'def.png', 863, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(867, 'Veterinarians', 'def.png', 841, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(868, 'Professional Services', '2022-02-16-620ca1c0e21f6.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:03:28', 0),
(869, 'Accountants', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(870, 'Advertising', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(871, 'Architects', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(872, 'Art Consultants', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(873, 'Billing Services', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(874, 'Boat Repair', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(875, 'Bookkeepers', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(876, 'Business Consulting', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(877, 'Career Counseling', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(878, 'Commissioned Artists', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(879, 'Customs Brokers', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(880, 'Digitizing Services', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(881, 'Duplication Services', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(882, 'Editorial Services', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(883, 'Employment Agencies', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(884, 'Feng Shui', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(885, 'Graphic Design', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(886, 'Indoor Landscaping', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(887, 'Internet Service Providers', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(888, 'Lawyers', '2022-02-16-620ca3bf3e6e2.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:11:59', 0),
(889, 'Bankruptcy Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(890, 'Business Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(891, 'Consumer Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(892, 'Contract Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(893, 'Criminal Defense Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(894, 'DUI Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(895, 'Disability Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(896, 'Divorce & Family Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(897, 'Elder Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(898, 'Employment Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(899, 'Entertainment Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(900, 'Estate Planning Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(901, 'Wills, Trusts, & Probates', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(902, 'General Litigation', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(903, 'IP & Internet Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(904, 'Immigration Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(905, 'Medical Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(906, 'Personal Injury Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(907, 'Real Estate Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(908, 'Social Security Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(909, 'Tax Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(910, 'Traffic Ticketing Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(911, 'Workers Compensation Law', 'def.png', 888, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(912, 'Legal Services', '2022-02-16-620ca7bc1604c.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:29:00', 0),
(913, 'Court Reporters', 'def.png', 912, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(914, 'Process Servers', 'def.png', 912, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(915, 'Life Coach', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(916, 'Marketing', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(917, 'Matchmakers', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(918, 'Mediators', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(919, 'Music Production Services', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(920, 'Office Cleaning', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(921, 'Patent Law', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(922, 'Payroll Services', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(923, 'Personal Assistants', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(924, 'Private Investigation', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(925, 'Product Design', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(926, 'Public Adjusters', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(927, 'Public Relations', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(928, 'Security Services', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(929, 'Shredding Services', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(930, 'Signmaking', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(931, 'Software Development', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(932, 'Talent Agencies', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(933, 'Taxidermy', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(934, 'Tenant and Eviction Law', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(935, 'Translation Services', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(936, 'Video/Film Production', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(937, 'Web Design', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(938, 'Wholesalers', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(939, 'Restaurant Supplies', 'def.png', 868, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(940, 'Public Services & Government', '2022-02-16-620ca8624b2fc.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:31:46', 0),
(941, 'Civic Center', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(942, 'Community Centers', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(943, 'Courthouses', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(944, 'Departments of Motor Vehicles', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(945, 'Embassy', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(946, 'Fire Departments', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(947, 'Jails & Prisons', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(948, 'Landmarks & Historical Buildings', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(949, 'Libraries', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(950, 'Municipality', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(951, 'Police Departments', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(952, 'Post Offices', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(953, 'Town Hall', 'def.png', 941, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(954, 'Real Estate', '2022-02-16-620ca8ad1e44c.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:33:01', 0),
(955, 'Apartments', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(956, 'Art Space Rentals', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(957, 'Commercial Real Estate', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(958, 'Condominiums', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(959, 'Estate Liquidation', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(960, 'Home Developers', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(961, 'Home Staging', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(962, 'Homeowner Association', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(963, 'Housing Cooperatives', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(964, 'Kitchen Incubators', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(965, 'Mobile Home Dealers', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(966, 'Mobile Home Parks', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(967, 'Mortgage Brokers', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(968, 'Property Management', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(969, 'Real Estate Agents', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(970, 'Apartment Agents', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(971, 'Real Estate Services', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(972, 'Land Surveying', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(973, 'Real Estate Photography', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(974, 'Shared Office Spaces', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(975, 'University Housing', 'def.png', 954, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(976, 'Religious Organizations', '2022-02-16-620ca623da2c1.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:22:11', 0),
(977, 'Buddhist Temples', 'def.png', 976, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(978, 'Churches', 'def.png', 976, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(979, 'Hindu Temples', 'def.png', 976, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(980, 'Mosques', 'def.png', 976, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(981, 'Sikh Temples', 'def.png', 976, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(982, 'Synagogues', 'def.png', 976, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(983, 'Restaurants', '2022-02-16-620ca5f257304.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:21:22', 0),
(984, 'Afghan', 'def.png', 1087, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(985, 'African Foods', '2022-02-16-620ca5cfdf73b.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:20:47', 0),
(986, 'Senegalese', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(987, 'South African', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(988, 'Nigerian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(989, 'American ', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(990, 'Arabian', 'def.png', 1087, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(991, 'Argentine', 'def.png', 1081, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(992, 'Armenian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(993, 'Asian Fusion', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(994, 'Australian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(995, 'Austrian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(996, 'Bangladeshi', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(997, 'Barbeque', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(998, 'Basque', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(999, 'Belgian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1000, 'Brasseries', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1001, 'Brazilian', 'def.png', 1081, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1002, 'Breakfast & Brunch', '2022-02-16-620ca57b0ab64.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:19:23', 0),
(1003, 'Pancakes', 'def.png', 1002, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1004, 'British', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1005, 'Buffets', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1006, 'Bulgarian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1007, 'Burgers', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1008, 'Burmese', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1009, 'Cafes', '2022-02-16-620ca55a91603.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:18:50', 0),
(1010, 'Themed Cafes', 'def.png', 1009, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1011, 'Cafeteria', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1012, 'Cajun/Creole', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1013, 'Cambodian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1014, 'Caribbean Food', '2022-02-16-620ca4e531f2f.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:16:53', 0),
(1015, 'Dominican', 'def.png', 1014, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1016, 'Haitian', 'def.png', 1014, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1017, 'Puerto Rican', 'def.png', 1014, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1018, 'Trinidadian', 'def.png', 1014, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1019, 'Catalan', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1020, 'Cheesesteaks', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1021, 'Chicken Shop', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1022, 'Chicken Wings', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1023, 'Chinese Food', '2022-02-16-620ca4bcd76aa.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:16:12', 0),
(1024, 'Cantonese', 'def.png', 1023, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1025, 'Dim Sum', 'def.png', 1023, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1026, 'Hainan', 'def.png', 1023, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1027, 'Shanghainese', 'def.png', 1023, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1028, 'Szechuan', 'def.png', 1023, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1029, 'Comfort Food', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1030, 'Creperies', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1031, 'Cuban', 'def.png', 1014, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1032, 'Czech', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1033, 'Delis', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1034, 'Diners', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1035, 'Dinner Theater', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1036, 'Eritrean', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1037, 'Ethiopian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1038, 'Fast Food', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1039, 'Filipino', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1040, 'Fish & Chips', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1041, 'Fondue', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1042, 'Food Court', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1043, 'Food Stands', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1044, 'French', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0);
INSERT INTO `categories` (`id`, `name`, `image`, `parent_id`, `position`, `status`, `created_at`, `updated_at`, `priority`) VALUES
(1045, 'Cameroonian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1046, 'Ethiopian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1047, 'Game Meat', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1048, 'Gastropubs', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1049, 'Georgian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1050, 'German', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1051, 'Gluten-Free', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1052, 'Greek', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1053, 'Guamanian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1054, 'Halal', 'def.png', 1087, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1055, 'Hawaiian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1056, 'Himalayan/Nepalese', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1057, 'Honduran', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1058, 'Hong Kong Style Cafe', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1059, 'Hot Dogs', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1060, 'Hot Pot', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1061, 'Hungarian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1062, 'Iberian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1063, 'Indian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1064, 'Indonesian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1065, 'Irish', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1067, 'Calabrian', 'def.png', 1067, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1068, 'Sardinian', 'def.png', 1067, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1069, 'Sicilian', 'def.png', 1067, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1070, 'Tuscan', 'def.png', 1067, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1071, 'Japanese Food', '2022-02-16-620c9f3cead71.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:52:44', 0),
(1072, 'Conveyor Belt Sushi', '', 1072, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1073, 'Izakaya', 'def.png', 1072, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1074, 'Japanese Curry', 'def.png', 1072, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1075, 'Ramen', 'def.png', 1072, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1076, 'Teppanyaki', 'def.png', 1072, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1077, 'Kebab', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1078, 'Korean', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1079, 'Kosher', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1080, 'Laotian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1081, 'Latin American Food', '2022-02-16-620c9f8a99e47.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:54:02', 0),
(1082, 'Colombian', 'def.png', 1081, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1083, 'Salvadoran', 'def.png', 1081, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1084, 'Venezuelan', 'def.png', 1081, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1085, 'Live/Raw Food', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1086, 'Malaysian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1087, 'Mediterranean Food', '2022-02-16-620c9fe896eba.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 06:55:36', 0),
(1088, 'Falafel', 'def.png', 1087, 1088, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1089, 'Mexican', 'def.png', 1081, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1090, 'Tacos', 'def.png', 1081, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1091, 'Middle Eastern', 'def.png', 1087, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1092, 'Egyptian', 'def.png', 1087, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1093, 'Lebanese', 'def.png', 1087, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1094, 'Modern European', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1095, 'Mongolian', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1096, 'Moroccan', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1097, 'New Mexican Cuisine', 'def.png', 1081, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1098, 'Nicaraguan', 'def.png', 1081, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1099, 'Noodles', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1100, 'Pakistani', 'def.png', 1087, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1101, 'Pan Asia', 'def.png', 984, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1102, 'Persian/Iranian', 'def.png', 1087, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1103, 'Peruvian', 'def.png', 1081, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1104, 'Pizza', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1105, 'Polish', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1106, 'Polynesian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1107, 'Pop-Up Restaurants', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1108, 'Portuguese', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1109, 'Poutineries', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1110, 'Russian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1111, 'Salad', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1112, 'Sandwiches', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1113, 'Scandinavian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1114, 'Scottish', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1115, 'Seafood', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1116, 'Singaporean', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1117, 'Slovakian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1118, 'Somali', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1119, 'Soul Food', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1120, 'Soup', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1121, 'Southern', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1122, 'Spanish', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1123, 'Sri Lankan', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1124, 'Steakhouses', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1125, 'Supper Clubs', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1126, 'Sushi Bars', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1127, 'Syrian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1128, 'Taiwanese', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1129, 'Tapas Bars', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1130, 'Tapas/Small Plates', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1131, 'Tex-Mex', 'def.png', 1081, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1132, 'Thai', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1133, 'Turkish', 'def.png', 1087, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1134, 'Ukrainian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1135, 'Uzbek', 'def.png', 1087, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1136, 'Vegan', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1137, 'Vegetarian', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1138, 'Vietnamese', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1139, 'Waffles', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1140, 'Wraps', 'def.png', 983, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1141, 'Shopping', '2022-02-16-620ca3de1d785.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:12:30', 0),
(1142, 'Adult', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1143, 'Antiques', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1144, 'Art Galleries', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1145, 'Arts & Crafts', '2022-02-16-620ca3b11cdbb.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:11:45', 0),
(1146, 'Art Supplies', 'def.png', 1145, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1147, 'Cards & Stationery', 'def.png', 1145, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1148, 'Cooking Classes', 'def.png', 1145, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1149, 'Costumes', 'def.png', 1145, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1150, 'Embroidery & Crochet', 'def.png', 1145, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1151, 'Fabric Stores', 'def.png', 1145, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1152, 'Framing', 'def.png', 1145, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1153, 'Paint-Your-Own Pottery', 'def.png', 1145, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1154, 'Auction Houses', '2022-02-16-620ca3587b663.png', 1141, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:10:16', 0),
(1155, 'Baby Gear & Furniture', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1156, 'Battery Stores', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1157, 'Bespoke Clothing', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1158, 'Books, Mags, Music & Video', '2022-02-16-620ca435967b7.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:13:57', 0),
(1159, 'Bookstores', 'def.png', 1158, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1160, 'Comic Books', 'def.png', 1158, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1161, 'Music & DVDs', 'def.png', 1158, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1162, 'Newspapers & Magazines', 'def.png', 1158, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1163, 'Video Game Stores', 'def.png', 1158, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1164, 'Videos & Video Game Rental', 'def.png', 1158, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1165, 'Vinyl Records', 'def.png', 1158, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1166, 'Brewing Supplies', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1167, 'Bridal', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1168, 'Cannabis Dispensaries', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1169, 'Computers', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1170, 'Cosmetics & Beauty Supply', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1171, 'Customized Merchandise', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1172, 'Department Stores', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1173, 'Diamond Buyers', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1174, 'Discount Store', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1175, 'Drones', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1176, 'Drugstores', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1177, 'Duty-Free Shops', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1178, 'Electronics', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1179, 'Eyewear & Opticians', '2022-02-16-620ca7fdbace9.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:30:05', 0),
(1180, 'Sunglasses', 'def.png', 1179, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1181, 'Farming Equipment', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1182, 'Fashion', '2022-02-16-620ca81ce02ff.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:30:36', 0),
(1183, 'Accessories', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1184, 'Ceremonial Clothing', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1185, 'Children?s Clothing', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1186, 'Clothing Rental', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1187, 'Department Stores', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1188, 'Formal Wear', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1189, 'Fur Clothing', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1190, 'Hats', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1191, 'Leather Goods', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1192, 'Lingerie', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1193, 'Maternity Wear', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1194, 'Men?s Clothing', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1195, 'Plus Size Fashion', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1196, 'Shoe Stores', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1197, 'Sports Wear', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1198, 'Dance Wear', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1199, 'Surf Shop', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1200, 'Swimwear', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1201, 'Traditional Clothing', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1202, 'Used, Vintage & Consignment', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1203, 'Women?s Clothing', 'def.png', 1182, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1204, 'Fireworks', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1205, 'Fitness/Exercise Equipment', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1206, 'Flea Markets', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1207, 'Flowers & Gifts', '2022-02-16-620ca89d2c2c2.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:32:45', 0),
(1208, 'Cards & Stationery', 'def.png', 1207, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1209, 'Florists', 'def.png', 1207, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1210, 'Gift Shops', 'def.png', 1207, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1211, 'Gemstones & Minerals', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1212, 'Gold Buyers', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1213, 'Guns & Ammo', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1214, 'Head Shops', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1215, 'High Fidelity Audio Equipment', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1216, 'Hobby Shops', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1217, 'Home & Garden', 'Home & Garden.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1218, 'Appliances', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1219, 'Candle Stores', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1220, 'Christmas Trees', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1221, 'Furniture Stores', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1222, 'Grilling Equipment', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1223, 'Hardware Stores', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1224, 'Holiday Decorations', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1225, 'Home Decor', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1226, 'Hot Tub & Pool', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1227, 'Kitchen & Bath', '2022-02-16-620ca73aad4a8.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:26:50', 0),
(1228, 'Kitchen Supplies', 'def.png', 1227, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1229, 'Lighting Stores', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1230, 'Mattresses', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1231, 'Nurseries & Gardening', '2022-02-16-620ca63450d98.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:22:28', 0),
(1232, 'Hydroponics', 'def.png', 1131, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1233, 'Outdoor Furniture Stores', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1234, 'Paint Stores', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1235, 'Playsets', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1236, 'Pumpkin Patches', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1237, 'Rugs', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1238, 'Sheds & Outdoor Storage', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1239, 'Tableware', 'def.png', 1217, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1240, 'Horse Equipment Shops', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1241, 'Jewelry', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1242, 'Knitting Supplies', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1243, 'Livestock Feed & Supply', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1244, 'Luggage', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1245, 'Medical Supplies', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1246, 'Military Surplus', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1247, 'Mobile Phone Accessories', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1248, 'Mobile Phones', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1249, 'Motorcycle Gear', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1250, 'Musical Instruments & Teachers', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1251, 'Office Equipment', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1252, 'Outlet Stores', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1253, 'Packing Supplies', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1254, 'Pawn Shops', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1255, 'Perfume', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1256, 'Personal Shopping', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1257, 'Photography Stores & Services', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1258, 'Pool & Billiards', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1259, 'Pop-up Shops', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1260, 'Props', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1261, 'Public Markets', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1262, 'Religious Items', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1263, 'Safe Stores', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1264, 'Safety Equipment', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1265, 'Shopping Centers', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1266, 'Souvenir Shops', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1267, 'Spiritual Shop', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1268, 'Sporting Goods', '2022-02-16-620ca529564a1.png', 0, 0, 1, '2022-02-09 11:47:57', '2022-02-16 07:18:01', 0),
(1269, 'Bikes', 'def.png', 1268, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1270, 'Dive Shops', 'def.png', 1268, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1271, 'Golf Equipment', 'def.png', 1268, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1272, 'Hockey Equipment', 'def.png', 1268, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1273, 'Hunting & Fishing Supplies', 'def.png', 1268, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1274, 'Outdoor Gear', 'def.png', 1268, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1275, 'Skate Shops', 'def.png', 1268, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1276, 'Ski & Snowboard Shops', 'def.png', 1268, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1277, 'Sports Wear', 'def.png', 1268, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1278, 'Dance Wear', 'def.png', 1268, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1279, 'Tabletop Games', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1280, 'Teacher Supplies', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1281, 'Thrift Stores', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1282, 'Tobacco Shops', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1283, 'Toy Stores', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1284, 'Trophy Shops', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1285, 'Uniforms', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1286, 'Used Bookstore', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1287, 'Vape Shops', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1288, 'Vitamins & Supplements', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1289, 'Watches', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1290, 'Wholesale Stores', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1291, 'Wigs', 'def.png', 1141, 1, 1, '2022-02-09 11:47:57', '2022-02-09 11:47:57', 0),
(1298, 'Entrees', '2022-02-18-62106ac10a9c0.png', 0, 0, 1, '2022-02-19 03:57:53', '2022-02-19 03:57:53', 0),
(1299, 'Angelina\'s Ristorante', 'def.png', 1298, 1, 1, '2022-02-19 04:03:18', '2022-02-19 04:03:18', 0),
(1300, 'Housemade Pastas', '2022-02-18-62106e0413d20.png', 0, 0, 1, '2022-02-19 04:11:48', '2022-02-19 04:11:48', 0),
(1301, 'Antipasti', '2022-02-18-62107885a00ee.png', 0, 0, 1, '2022-02-19 04:56:37', '2022-02-19 04:56:37', 0),
(1302, 'Pizzette', '2022-02-18-621078b288848.png', 0, 0, 1, '2022-02-19 04:57:22', '2022-02-19 04:57:22', 0),
(1303, 'Soups & Salads', '2022-02-18-621078de9301a.png', 0, 0, 1, '2022-02-19 04:58:06', '2022-02-19 04:58:06', 0),
(1304, 'Grappa', '2022-02-23-6216f2dede05b.png', 0, 0, 1, '2022-02-24 02:52:14', '2022-02-24 02:52:14', 0),
(1305, 'First Course', '2022-02-23-6216f30004c1d.png', 0, 0, 1, '2022-02-24 02:52:48', '2022-02-24 02:52:48', 0),
(1306, 'Single Malt / Aged Acotch', '2022-02-23-6216f3ad5b2e1.png', 0, 0, 1, '2022-02-24 02:55:41', '2022-02-24 02:55:41', 0),
(1307, 'Cognac/Armagnac', '2022-02-23-6216f3f55e47d.png', 0, 0, 1, '2022-02-24 02:56:53', '2022-02-24 02:56:53', 0),
(1308, 'Collectors Cognac', '2022-02-23-6216f43423394.png', 0, 0, 1, '2022-02-24 02:57:56', '2022-02-24 02:57:56', 0),
(1309, 'Fresh From The Sea', '2022-02-23-6216f498930e4.png', 0, 0, 1, '2022-02-24 02:59:36', '2022-02-24 02:59:36', 0),
(1310, 'Salads & Starters', '2022-02-23-6216f4d732e36.png', 0, 0, 1, '2022-02-24 03:00:39', '2022-02-24 03:00:39', 0),
(1311, 'Brunch Pizzette', '2022-02-23-6216f5558669d.png', 0, 0, 1, '2022-02-24 03:02:45', '2022-02-24 03:02:45', 0),
(1312, 'Main', '2022-02-23-6216f5767080f.png', 0, 0, 1, '2022-02-24 03:03:18', '2022-02-24 03:03:18', 0),
(1313, 'Brunch Cocktails', '2022-02-23-6216f59d3b61c.png', 0, 0, 1, '2022-02-24 03:03:57', '2022-02-24 03:03:57', 0),
(1314, 'Bellini Bar', '2022-02-23-6216f5bc9a220.png', 0, 0, 1, '2022-02-24 03:04:28', '2022-02-24 03:04:28', 0),
(1315, 'Prezzo Fisso', '2022-02-23-6216f5f8dc481.png', 0, 0, 1, '2022-02-24 03:05:28', '2022-02-24 03:05:28', 0),
(1316, 'Prezzo Fisso 1st Course', '2022-02-23-6216f61b62a9c.png', 0, 0, 1, '2022-02-24 03:06:03', '2022-02-24 03:06:03', 0),
(1317, 'Entrée Course', '2022-02-23-6216f63b6a332.png', 0, 0, 1, '2022-02-24 03:06:35', '2022-02-24 03:06:35', 0),
(1318, 'Prezzo Fisso Dolce', '2022-02-23-6216f67bc6945.png', 0, 0, 1, '2022-02-24 03:07:39', '2022-02-24 03:07:39', 0),
(1319, 'White Wines By The Glass', '2022-02-23-6216f6b72b047.png', 0, 0, 1, '2022-02-24 03:08:39', '2022-02-24 03:08:39', 0),
(1320, 'Red Wines By The Glass', '2022-02-23-6216f6d6363a7.png', 0, 0, 1, '2022-02-24 03:09:10', '2022-02-24 03:09:10', 0),
(1321, 'Half Bottles', '2022-02-23-6216f704d7e99.png', 0, 0, 1, '2022-02-24 03:09:56', '2022-02-24 03:09:56', 0),
(1322, 'Sparkling', '2022-02-23-6216f71d6fb29.png', 0, 0, 1, '2022-02-24 03:10:21', '2022-02-24 03:10:21', 0),
(1323, 'Italian Wine', '2022-02-23-6216f739de958.png', 0, 0, 1, '2022-02-24 03:10:49', '2022-02-24 03:10:49', 0),
(1324, 'German & Austrian Wine', '2022-02-23-6216f76a031f2.png', 0, 0, 1, '2022-02-24 03:11:38', '2022-02-24 03:11:38', 0),
(1325, 'French Wine', '2022-02-23-6216f7852b86c.png', 0, 0, 1, '2022-02-24 03:12:05', '2022-02-24 03:12:05', 0),
(1326, 'New Zealand & Australian Wine', '2022-02-23-6216f9c170a73.png', 0, 0, 1, '2022-02-24 03:21:37', '2022-02-24 03:21:37', 0),
(1327, 'South American Wine', '2022-02-23-6216fa05ae3f1.png', 0, 0, 1, '2022-02-24 03:22:45', '2022-02-24 03:22:45', 0),
(1328, 'South African Wine', '2022-02-23-6216fa2ea5f3e.png', 0, 0, 1, '2022-02-24 03:23:26', '2022-02-24 03:23:26', 0),
(1329, 'Spanish Wine', '2022-02-23-6216fa4bc7690.png', 0, 0, 1, '2022-02-24 03:23:55', '2022-02-24 03:23:55', 0),
(1330, 'American Wine', '2022-02-23-6216fa644978d.png', 0, 0, 1, '2022-02-24 03:24:20', '2022-02-24 03:24:20', 0),
(1334, 'PIEDMONT', '2022-02-23-6216fac92bb34.png', 0, 0, 1, '2022-02-24 03:26:01', '2022-02-24 03:26:01', 0),
(1335, 'SICILY & SARDINIA', '2022-02-23-6216fae396fa5.png', 0, 0, 1, '2022-02-24 03:26:27', '2022-02-24 03:26:27', 0),
(1336, 'VENETO', '2022-02-23-6216faf82a168.png', 0, 0, 1, '2022-02-24 03:26:48', '2022-02-24 03:26:48', 0),
(1337, 'TUSCANY', '2022-02-23-6216fb0d112a0.png', 0, 0, 1, '2022-02-24 03:27:09', '2022-02-24 03:27:09', 0),
(1338, 'CHIANTI', '2022-02-23-6216fb1f75452.png', 0, 0, 1, '2022-02-24 03:27:27', '2022-02-24 03:27:27', 0),
(1339, 'SUPER TUSCAN', '2022-02-23-6216fb321a791.png', 0, 0, 1, '2022-02-24 03:27:46', '2022-02-24 03:27:46', 0),
(1340, 'Madeira', '2022-02-23-6216fb4c253fe.png', 0, 0, 1, '2022-02-24 03:28:12', '2022-02-26 17:00:48', 0),
(1341, 'UMBRIA', '2022-02-23-6216fb65dd5c8.png', 0, 0, 1, '2022-02-24 03:28:37', '2022-02-24 03:28:37', 0),
(1342, 'BORDEAUX', '2022-02-23-6216fb879bcf8.png', 0, 0, 1, '2022-02-24 03:29:11', '2022-02-24 03:29:11', 0),
(1343, 'BURGUNDY', '2022-02-23-6216fb9b8bf2b.png', 0, 0, 1, '2022-02-24 03:29:31', '2022-02-24 03:29:31', 0),
(1344, 'Ports', '2022-02-23-6216fbba382f2.png', 0, 0, 1, '2022-02-24 03:30:02', '2022-02-26 17:00:16', 0),
(1347, 'Dessert Menu', '2022-02-26-621ae9756ebfd.png', 0, 0, 1, '2022-02-27 03:01:09', '2022-02-27 03:01:09', 0),
(1348, 'Brunch', '2022-03-02-621f3f87316f2.png', 0, 0, 1, '2022-03-02 09:57:27', '2022-03-02 09:57:27', 0),
(1350, 'Wine List', '2022-03-06-62245d151c8fe.png', 0, 0, 1, '2022-03-06 07:04:53', '2022-03-06 07:04:53', 0),
(1351, 'Curbside Carry-Out', '2022-03-06-62245f8003eb1.png', 0, 0, 1, '2022-03-06 07:15:12', '2022-03-06 07:15:12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `conversations`
--

CREATE TABLE `conversations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checked` tinyint(1) NOT NULL DEFAULT 0,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `min_purchase` decimal(8,2) NOT NULL DEFAULT 0.00,
  `max_discount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `discount_type` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percentage',
  `coupon_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `limit` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `data` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `title`, `code`, `start_date`, `expire_date`, `min_purchase`, `max_discount`, `discount`, `discount_type`, `coupon_type`, `limit`, `status`, `created_at`, `updated_at`, `data`) VALUES
(1, 'kkkkkkkkkkkkk', 'kkkkkkkkkkkkkkk', '2021-12-09', '2021-12-24', 250.00, 0.00, 20.00, 'amount', 'zone_wise', 30, 1, '2021-11-15 08:46:50', '2021-12-09 10:34:45', '[\"1\"]');

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_symbol` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exchange_rate` decimal(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `country`, `currency_code`, `currency_symbol`, `exchange_rate`, `created_at`, `updated_at`) VALUES
(1, 'US Dollar', 'USD', '$', 1.00, NULL, NULL),
(2, 'Canadian Dollar', 'CAD', 'CA$', 1.00, NULL, NULL),
(3, 'Euro', 'EUR', '€', 1.00, NULL, NULL),
(4, 'United Arab Emirates Dirham', 'AED', 'د.إ.‏', 1.00, NULL, NULL),
(5, 'Afghan Afghani', 'AFN', '؋', 1.00, NULL, NULL),
(6, 'Albanian Lek', 'ALL', 'L', 1.00, NULL, NULL),
(7, 'Armenian Dram', 'AMD', '֏', 1.00, NULL, NULL),
(8, 'Argentine Peso', 'ARS', '$', 1.00, NULL, NULL),
(9, 'Australian Dollar', 'AUD', '$', 1.00, NULL, NULL),
(10, 'Azerbaijani Manat', 'AZN', '₼', 1.00, NULL, NULL),
(11, 'Bosnia-Herzegovina Convertible Mark', 'BAM', 'KM', 1.00, NULL, NULL),
(12, 'Bangladeshi Taka', 'BDT', '৳', 1.00, NULL, NULL),
(13, 'Bulgarian Lev', 'BGN', 'лв.', 1.00, NULL, NULL),
(14, 'Bahraini Dinar', 'BHD', 'د.ب.‏', 1.00, NULL, NULL),
(15, 'Burundian Franc', 'BIF', 'FBu', 1.00, NULL, NULL),
(16, 'Brunei Dollar', 'BND', 'B$', 1.00, NULL, NULL),
(17, 'Bolivian Boliviano', 'BOB', 'Bs', 1.00, NULL, NULL),
(18, 'Brazilian Real', 'BRL', 'R$', 1.00, NULL, NULL),
(19, 'Botswanan Pula', 'BWP', 'P', 1.00, NULL, NULL),
(20, 'Belarusian Ruble', 'BYN', 'Br', 1.00, NULL, NULL),
(21, 'Belize Dollar', 'BZD', '$', 1.00, NULL, NULL),
(22, 'Congolese Franc', 'CDF', 'FC', 1.00, NULL, NULL),
(23, 'Swiss Franc', 'CHF', 'CHf', 1.00, NULL, NULL),
(24, 'Chilean Peso', 'CLP', '$', 1.00, NULL, NULL),
(25, 'Chinese Yuan', 'CNY', '¥', 1.00, NULL, NULL),
(26, 'Colombian Peso', 'COP', '$', 1.00, NULL, NULL),
(27, 'Costa Rican Colón', 'CRC', '₡', 1.00, NULL, NULL),
(28, 'Cape Verdean Escudo', 'CVE', '$', 1.00, NULL, NULL),
(29, 'Czech Republic Koruna', 'CZK', 'Kč', 1.00, NULL, NULL),
(30, 'Djiboutian Franc', 'DJF', 'Fdj', 1.00, NULL, NULL),
(31, 'Danish Krone', 'DKK', 'Kr.', 1.00, NULL, NULL),
(32, 'Dominican Peso', 'DOP', 'RD$', 1.00, NULL, NULL),
(33, 'Algerian Dinar', 'DZD', 'د.ج.‏', 1.00, NULL, NULL),
(34, 'Estonian Kroon', 'EEK', 'kr', 1.00, NULL, NULL),
(35, 'Egyptian Pound', 'EGP', 'E£‏', 1.00, NULL, NULL),
(36, 'Eritrean Nakfa', 'ERN', 'Nfk', 1.00, NULL, NULL),
(37, 'Ethiopian Birr', 'ETB', 'Br', 1.00, NULL, NULL),
(38, 'British Pound Sterling', 'GBP', '£', 1.00, NULL, NULL),
(39, 'Georgian Lari', 'GEL', 'GEL', 1.00, NULL, NULL),
(40, 'Ghanaian Cedi', 'GHS', 'GH¢', 1.00, NULL, NULL),
(41, 'Guinean Franc', 'GNF', 'FG', 1.00, NULL, NULL),
(42, 'Guatemalan Quetzal', 'GTQ', 'Q', 1.00, NULL, NULL),
(43, 'Hong Kong Dollar', 'HKD', 'HK$', 1.00, NULL, NULL),
(44, 'Honduran Lempira', 'HNL', 'L', 1.00, NULL, NULL),
(45, 'Croatian Kuna', 'HRK', 'kn', 1.00, NULL, NULL),
(46, 'Hungarian Forint', 'HUF', 'Ft', 1.00, NULL, NULL),
(47, 'Indonesian Rupiah', 'IDR', 'Rp', 1.00, NULL, NULL),
(48, 'Israeli New Sheqel', 'ILS', '₪', 1.00, NULL, NULL),
(49, 'Indian Rupee', 'INR', '₹', 1.00, NULL, NULL),
(50, 'Iraqi Dinar', 'IQD', 'ع.د', 1.00, NULL, NULL),
(51, 'Iranian Rial', 'IRR', '﷼', 1.00, NULL, NULL),
(52, 'Icelandic Króna', 'ISK', 'kr', 1.00, NULL, NULL),
(53, 'Jamaican Dollar', 'JMD', '$', 1.00, NULL, NULL),
(54, 'Jordanian Dinar', 'JOD', 'د.ا‏', 1.00, NULL, NULL),
(55, 'Japanese Yen', 'JPY', '¥', 1.00, NULL, NULL),
(56, 'Kenyan Shilling', 'KES', 'Ksh', 1.00, NULL, NULL),
(57, 'Cambodian Riel', 'KHR', '៛', 1.00, NULL, NULL),
(58, 'Comorian Franc', 'KMF', 'FC', 1.00, NULL, NULL),
(59, 'South Korean Won', 'KRW', 'CF', 1.00, NULL, NULL),
(60, 'Kuwaiti Dinar', 'KWD', 'د.ك.‏', 1.00, NULL, NULL),
(61, 'Kazakhstani Tenge', 'KZT', '₸.', 1.00, NULL, NULL),
(62, 'Lebanese Pound', 'LBP', 'ل.ل.‏', 1.00, NULL, NULL),
(63, 'Sri Lankan Rupee', 'LKR', 'Rs', 1.00, NULL, NULL),
(64, 'Lithuanian Litas', 'LTL', 'Lt', 1.00, NULL, NULL),
(65, 'Latvian Lats', 'LVL', 'Ls', 1.00, NULL, NULL),
(66, 'Libyan Dinar', 'LYD', 'د.ل.‏', 1.00, NULL, NULL),
(67, 'Moroccan Dirham', 'MAD', 'د.م.‏', 1.00, NULL, NULL),
(68, 'Moldovan Leu', 'MDL', 'L', 1.00, NULL, NULL),
(69, 'Malagasy Ariary', 'MGA', 'Ar', 1.00, NULL, NULL),
(70, 'Macedonian Denar', 'MKD', 'Ден', 1.00, NULL, NULL),
(71, 'Myanma Kyat', 'MMK', 'K', 1.00, NULL, NULL),
(72, 'Macanese Pataca', 'MOP', 'MOP$', 1.00, NULL, NULL),
(73, 'Mauritian Rupee', 'MUR', 'Rs', 1.00, NULL, NULL),
(74, 'Mexican Peso', 'MXN', '$', 1.00, NULL, NULL),
(75, 'Malaysian Ringgit', 'MYR', 'RM', 1.00, NULL, NULL),
(76, 'Mozambican Metical', 'MZN', 'MT', 1.00, NULL, NULL),
(77, 'Namibian Dollar', 'NAD', 'N$', 1.00, NULL, NULL),
(78, 'Nigerian Naira', 'NGN', '₦', 1.00, NULL, NULL),
(79, 'Nicaraguan Córdoba', 'NIO', 'C$', 1.00, NULL, NULL),
(80, 'Norwegian Krone', 'NOK', 'kr', 1.00, NULL, NULL),
(81, 'Nepalese Rupee', 'NPR', 'Re.', 1.00, NULL, NULL),
(82, 'New Zealand Dollar', 'NZD', '$', 1.00, NULL, NULL),
(83, 'Omani Rial', 'OMR', 'ر.ع.‏', 1.00, NULL, NULL),
(84, 'Panamanian Balboa', 'PAB', 'B/.', 1.00, NULL, NULL),
(85, 'Peruvian Nuevo Sol', 'PEN', 'S/', 1.00, NULL, NULL),
(86, 'Philippine Peso', 'PHP', '₱', 1.00, NULL, NULL),
(87, 'Pakistani Rupee', 'PKR', 'Rs', 1.00, NULL, NULL),
(88, 'Polish Zloty', 'PLN', 'zł', 1.00, NULL, NULL),
(89, 'Paraguayan Guarani', 'PYG', '₲', 1.00, NULL, NULL),
(90, 'Qatari Rial', 'QAR', 'ر.ق.‏', 1.00, NULL, NULL),
(91, 'Romanian Leu', 'RON', 'lei', 1.00, NULL, NULL),
(92, 'Serbian Dinar', 'RSD', 'din.', 1.00, NULL, NULL),
(93, 'Russian Ruble', 'RUB', '₽.', 1.00, NULL, NULL),
(94, 'Rwandan Franc', 'RWF', 'FRw', 1.00, NULL, NULL),
(95, 'Saudi Riyal', 'SAR', 'ر.س.‏', 1.00, NULL, NULL),
(96, 'Sudanese Pound', 'SDG', 'ج.س.', 1.00, NULL, NULL),
(97, 'Swedish Krona', 'SEK', 'kr', 1.00, NULL, NULL),
(98, 'Singapore Dollar', 'SGD', '$', 1.00, NULL, NULL),
(99, 'Somali Shilling', 'SOS', 'Sh.so.', 1.00, NULL, NULL),
(100, 'Syrian Pound', 'SYP', 'LS‏', 1.00, NULL, NULL),
(101, 'Thai Baht', 'THB', '฿', 1.00, NULL, NULL),
(102, 'Tunisian Dinar', 'TND', 'د.ت‏', 1.00, NULL, NULL),
(103, 'Tongan Paʻanga', 'TOP', 'T$', 1.00, NULL, NULL),
(104, 'Turkish Lira', 'TRY', '₺', 1.00, NULL, NULL),
(105, 'Trinidad and Tobago Dollar', 'TTD', '$', 1.00, NULL, NULL),
(106, 'New Taiwan Dollar', 'TWD', 'NT$', 1.00, NULL, NULL),
(107, 'Tanzanian Shilling', 'TZS', 'TSh', 1.00, NULL, NULL),
(108, 'Ukrainian Hryvnia', 'UAH', '₴', 1.00, NULL, NULL),
(109, 'Ugandan Shilling', 'UGX', 'USh', 1.00, NULL, NULL),
(110, 'Uruguayan Peso', 'UYU', '$', 1.00, NULL, NULL),
(111, 'Uzbekistan Som', 'UZS', 'so\'m', 1.00, NULL, NULL),
(112, 'Venezuelan Bolívar', 'VEF', 'Bs.F.', 1.00, NULL, NULL),
(113, 'Vietnamese Dong', 'VND', '₫', 1.00, NULL, NULL),
(114, 'CFA Franc BEAC', 'XAF', 'FCFA', 1.00, NULL, NULL),
(115, 'CFA Franc BCEAO', 'XOF', 'CFA', 1.00, NULL, NULL),
(116, 'Yemeni Rial', 'YER', '﷼‏', 1.00, NULL, NULL),
(117, 'South African Rand', 'ZAR', 'R', 1.00, NULL, NULL),
(118, 'Zambian Kwacha', 'ZMK', 'ZK', 1.00, NULL, NULL),
(119, 'Zimbabwean Dollar', 'ZWL', 'Z$', 1.00, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer_addresses`
--

CREATE TABLE `customer_addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `address_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `contact_person_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `zone_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `delivery_histories`
--

CREATE TABLE `delivery_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `delivery_man_id` bigint(20) UNSIGNED DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `longitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `delivery_man_wallets`
--

CREATE TABLE `delivery_man_wallets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `delivery_man_id` bigint(20) UNSIGNED NOT NULL,
  `collected_cash` decimal(8,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `total_earning` decimal(8,2) NOT NULL DEFAULT 0.00,
  `total_withdrawn` decimal(8,2) NOT NULL DEFAULT 0.00,
  `pending_withdraw` decimal(8,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `delivery_men`
--

CREATE TABLE `delivery_men` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `f_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identity_number` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identity_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identity_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auth_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fcm_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zone_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `earning` tinyint(1) NOT NULL DEFAULT 1,
  `current_orders` int(11) NOT NULL DEFAULT 0,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'zone_wise',
  `restaurant_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `discounts`
--

CREATE TABLE `discounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `min_purchase` decimal(8,2) NOT NULL DEFAULT 0.00,
  `max_discount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `discount_type` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percentage',
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `d_m_reviews`
--

CREATE TABLE `d_m_reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `delivery_man_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `comment` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_verifications`
--

CREATE TABLE `email_verifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee_roles`
--

CREATE TABLE `employee_roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modules` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `category_ids` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `add_ons` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attributes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `choice_options` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(8,2) NOT NULL DEFAULT 0.00,
  `tax_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percent',
  `discount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `discount_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percent',
  `available_time_starts` time DEFAULT NULL,
  `available_time_ends` time DEFAULT NULL,
  `set_menu` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `order_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`id`, `name`, `description`, `image`, `category_id`, `category_ids`, `variations`, `add_ons`, `attributes`, `choice_options`, `price`, `tax`, `tax_type`, `discount`, `discount_type`, `available_time_starts`, `available_time_ends`, `set_menu`, `status`, `restaurant_id`, `created_at`, `updated_at`, `order_count`) VALUES
(1, 'tshirt1', 'jj', '2021-11-19-6196a52787509.png', 32, '[{\"id\":\"32\",\"position\":1}]', '[]', '[]', '[]', '[]', 1.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 10, '2021-11-19 06:55:31', '2021-11-19 06:55:31', 0),
(2, 'tshirt2', 'iiiiiiiiiiii', '2021-11-19-6196a54aae8ed.png', 32, '[{\"id\":\"32\",\"position\":1}]', '[]', '[]', '[]', '[]', 100.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 10, '2021-11-19 06:56:06', '2021-11-19 06:56:06', 0),
(3, 'tshirt3', 'j', '2021-11-19-6196a5629a0f0.png', 32, '[{\"id\":\"32\",\"position\":1}]', '[]', '[]', '[]', '[]', 1.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 10, '2021-11-19 06:56:30', '2021-11-19 06:56:30', 0),
(4, 'Fountain Drinks', 'Coke, Diet Coke, Sprite, Barq\'s Root Beer, ginger ale, Gold Peak iced tea (raspberry, sweetened, or unsweetened)', '2021-11-26-61a0a61ba4050.png', 56, '[{\"id\":\"34\",\"position\":1},{\"id\":\"56\",\"position\":2}]', '[]', '[]', '[]', '[]', 3.50, 0.00, 'percent', 0.00, 'percent', '15:00:00', '21:00:00', 0, 1, 10, '2021-11-26 21:02:15', '2022-01-11 17:14:09', 0),
(8, '3 Movers', '3 United States military veterans to do your medium, to large size move.', '2022-02-16-620cb0c2c4915.png', 589, '[{\"id\":\"536\",\"position\":1},{\"id\":\"589\",\"position\":2}]', '[]', '[]', '[]', '[]', 180.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1673, '2022-02-16 08:07:30', '2022-02-16 08:07:30', 0),
(9, '2 Movers', NULL, '2022-02-16-620cb12dd169c.png', 589, '[{\"id\":\"536\",\"position\":1},{\"id\":\"589\",\"position\":2}]', '[]', '[]', '[]', '[]', 110.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1673, '2022-02-16 08:09:17', '2022-02-24 02:19:26', 0),
(10, 'Eggplant Rolatini', NULL, '2022-02-18-620ff96a2a199.png', 1301, '[{\"id\":\"1301\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 19:54:18', '2022-02-24 02:19:42', 0),
(12, 'Fried Calamari & Snappe', NULL, '2022-02-18-620ff99a5be5f.png', 1301, '[{\"id\":\"1301\",\"position\":1}]', '[]', '[]', '[]', '[]', 21.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 19:55:06', '2022-02-24 02:19:58', 0),
(13, 'Seasonal Melon & Speck', NULL, '2022-02-18-620ffa0c20199.png', 1301, '[{\"id\":\"1301\",\"position\":1}]', '[]', '[]', '[]', '[]', 17.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 19:57:00', '2022-02-24 02:20:24', 0),
(16, 'Baked Cheese & Eggs', 'Baked Local Organic Eggs from Circle \"C\" Farm, Baked Tomino Cheese, Fennel Marmellata, Rosemary, Crostini', '2022-02-18-620ffad6a3d54.png', 1301, '[{\"id\":\"1301\",\"position\":1}]', '[]', '[]', '[]', '[]', 16.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:00:22', '2022-02-24 02:20:45', 0),
(17, 'Mussels', 'Prince Edward Island Mussels, Tomato, Red Chili Flake, Butter, Chicken Stock, Extra Virgin Olive Oil, Basil, Lemon', '2022-02-18-620ffb1a8c670.png', 1301, '[{\"id\":\"1301\",\"position\":1}]', '[]', '[]', '[]', '[]', 21.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:01:30', '2022-02-24 02:21:01', 0),
(18, 'Meatballs', 'Calabrese Style Meatballs, Fresh Herbs, Marinara, Sheep\'s Milk Ricotta Cheese, Chili Flake', '2022-02-18-620ffb616666b.png', 1301, '[{\"id\":\"1301\",\"position\":1}]', '[]', '[]', '[]', '[]', 16.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:02:41', '2022-02-24 02:21:18', 0),
(19, 'Margherita', 'San Marzano Tomato, Basil, Mozzarella, Extra Virgin Olive Oil', '2022-02-18-620ffb910a3c1.png', 1302, '[{\"id\":\"1302\",\"position\":1}]', '[]', '[]', '[]', '[]', 14.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:03:29', '2022-02-24 02:21:35', 0),
(20, 'Fra Diavolo', 'Spicy Casalingo, Marinara & Parmigiano-Reggiano Bel Paese, Calabrian Chile & Taggiasca Olive', '2022-02-18-620ffc093aff5.png', 1302, '[{\"id\":\"1302\",\"position\":1}]', '[]', '[]', '[]', '[]', 17.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:05:29', '2022-02-24 02:21:46', 0),
(21, 'Butternut Squash Ravioli', 'Roasted Butternut Squash & Mascarpone Filled Handmade Ravioli, Sauce of Orange, Sun-Dried Tomato & Butter, Truffle Oil, Arugula, Candied Pecan', '2022-02-18-620ffc5611fe0.png', 1300, '[{\"id\":\"1300\",\"position\":1}]', '[]', '[]', '[]', '[]', 28.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:06:46', '2022-02-19 10:39:48', 0),
(22, 'Tomato Caprese', 'Housemade Mozzarella, Heirloom Cherry Tomato, Basil, Garlic, Balsamic Vinegar, Extra Virgin Olive Oil', '2022-02-18-620ffc9c0d2ce.png', 1303, '[{\"id\":\"1303\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:07:56', '2022-02-19 10:22:11', 0),
(23, 'Caesar', 'Romaine, House-Made Caesar Dressing, Hand-Cut Seasoned Croutons, Shaved Parmigiano-Reggiano', '2022-02-18-620ffcce9ea87.png', 1303, '[{\"id\":\"1303\",\"position\":1}]', '[]', '[]', '[]', '[]', 14.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:08:46', '2022-02-24 02:24:13', 0),
(25, 'Little Gem Wedge', 'Little Gem Lettuce, Gorgonzola Dolce Dressing, Baby Heirloom Tomato, Radish, Pancetta, Gorgonzola Dolce', '2022-02-18-620ffcfc37768.png', 1303, '[{\"id\":\"1303\",\"position\":1}]', '[]', '[]', '[]', '[]', 14.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:09:32', '2022-02-24 02:24:26', 0),
(26, 'Cacio e Pepe', 'Telecherry Black Pepper, Parmigiano-Reggiano, Pecorino Romano, Butter & House Made Spaghetti', '2022-02-18-620ffd313ea7f.png', 1300, '[{\"id\":\"1300\",\"position\":1}]', '[]', '[]', '[]', '[]', 13.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:10:25', '2022-02-24 02:24:41', 0),
(27, 'Veal Agnolotti', 'Slow Roasted Veal Filled Agnolotti, Wild Mushrooms, Veal Stock, Balsamic, Herbs, Truffle Oil, Fenne', '2022-02-18-620ffd72e7b61.png', 1300, '[{\"id\":\"1300\",\"position\":1}]', '[]', '[]', '[]', '[]', 18.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:11:30', '2022-02-19 04:15:43', 0),
(28, 'Butternut Squash Ravioli', 'Roasted Butternut Squash & Mascarpone Filled Handmade Ravioli, Sauce of Orange, Sun-Dried Tomato & Butter, Truffle Oil, Arugula, Candied Pecan', '2022-02-18-620ffdc75adde.png', 1300, '[{\"id\":\"1300\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:12:55', '2022-02-24 02:23:04', 0),
(29, 'Pappardelle \'Capri\'', 'Handcut Pappardelle, San Marzano Tomato Sauce, Basil, Buffalo Mozzarella, Sorrento Lemon Olive Oil', '2022-02-18-620ffe407a5b4.png', 1300, '[{\"id\":\"1300\",\"position\":1}]', '[]', '[]', '[]', '[]', 14.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:14:56', '2022-02-24 02:23:16', 0),
(30, 'Veal Bolognese', 'Veal, Tomatoes, Onion, Carrots, Basil & Sheep\'s Milk Ricotta. Slow Simmered & Tossed with Pappardelle', '2022-02-18-620ffe7cf05de.png', 1300, '[{\"id\":\"1300\",\"position\":1}]', '[]', '[]', '[]', '[]', 17.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:15:57', '2022-02-24 02:23:56', 0),
(31, 'Veal Bolognese', 'Veal, Tomatoes, Onion, Carrots, Basil & Sheep\'s Milk Ricotta. Slow Simmered & Tossed with Pappardelle', '2022-02-18-620ffe7da0e5f.png', 1300, '[{\"id\":\"1300\",\"position\":1}]', '[]', '[]', '[]', '[]', 32.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:15:57', '2022-02-24 02:23:32', 0),
(32, 'Shrimp Orecchiette', NULL, '2022-02-18-620ffebd303f4.png', 1300, '[{\"id\":\"1300\",\"position\":1}]', '[]', '[]', '[]', '[]', 17.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:17:01', '2022-02-24 02:13:31', 0),
(33, 'Sea Salt Baked Snapper for Two', NULL, '2022-02-18-620fff281cf55.png', 1299, '[{\"id\":\"1298\",\"position\":1},{\"id\":\"1299\",\"position\":2}]', '[]', '[]', '[]', '[]', 90.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:18:48', '2022-02-24 02:22:14', 0),
(34, 'American Red Snapper Piccatta', 'American Red Snapper Served with Baked Parmesan & Bacon Ziti Cake, Broccolini & Yellow Peperonata. Finished with White Wine Lemon-Caper Sauce.', '2022-02-18-620fff63e6684.png', 1299, '[{\"id\":\"1298\",\"position\":1},{\"id\":\"1299\",\"position\":2}]', '[]', '[]', '[]', '[]', 45.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:19:47', '2022-02-24 02:22:33', 0),
(35, 'Fra Diavolo Risotto', 'Rock Shrimp, Calabrian Chiles, Chili Flakes, Cherry Tomato, Basil, Mascarpone', '2022-02-18-620fff96616e1.png', 1299, '[{\"id\":\"1298\",\"position\":1},{\"id\":\"1299\",\"position\":2}]', '[]', '[]', '[]', '[]', 36.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:20:38', '2022-02-24 02:15:10', 0),
(36, 'Veal Milanese', 'Fourteen Ounce Bone-In Veal Chop Pounded Thin & Breaded. Topped with Balsamic Glaze, Arugula, Heirloom Cherry Tomato & Parmesan', '2022-02-18-620ffff325cd2.png', 1299, '[{\"id\":\"1298\",\"position\":1},{\"id\":\"1299\",\"position\":2}]', '[]', '[]', '[]', '[]', 58.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:22:11', '2022-02-24 02:25:02', 0),
(37, 'Filet of Wagyu Beef', 'Eight Ounce Filet of Wagyu Beef, Potato Puree, Garlic, Green Beans, Red Onion, Roasted Tomato, Herb Butter, Sun-Dried Tomato & Balsamic Sauce', '2022-02-18-6210001db33ce.png', 1299, '[{\"id\":\"1298\",\"position\":1},{\"id\":\"1299\",\"position\":2}]', '[]', '[]', '[]', '[]', 64.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:22:53', '2022-02-24 02:15:29', 0),
(38, 'Free Range Chicken Breast', 'Free Range Chicken Breast, Yukon Gold Potato Puree, Hunter\'s Style Chicken Thighs Braised in Taggiasca Olives, San Marzano Tomatoes & Red Win', '2022-02-18-621000541cd9c.png', 1299, '[{\"id\":\"1298\",\"position\":1},{\"id\":\"1299\",\"position\":2}]', '[]', '[]', '[]', '[]', 34.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:23:48', '2022-02-24 02:15:41', 0),
(39, 'Veal Marsala', 'eal Tenderloin Scallopini, Wild Mushrooms, Marsala Sauce, Broccolini, Roasted Potatoes', '2022-02-18-6210008a0b5e0.png', 1299, '[{\"id\":\"1298\",\"position\":1},{\"id\":\"1299\",\"position\":2}]', '[]', '[]', '[]', '[]', 42.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:24:42', '2022-02-24 02:15:53', 0),
(40, 'Pork Osso Buco', 'Sixteen Ounce Braised Pork Osso Buco, Natural Reduction, Yukon Gold Potato Puree, Pickled Fennel', '2022-02-18-621000cf91106.png', 1299, '[{\"id\":\"1298\",\"position\":1},{\"id\":\"1299\",\"position\":2}]', '[]', '[]', '[]', '[]', 39.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:25:51', '2022-02-24 02:25:27', 0),
(41, 'Pork Osso Buco', 'Sixteen Ounce Braised Pork Osso Buco, Natural Reduction, Yukon Gold Potato Puree, Pickled Fennel', '2022-02-18-621000d0e7c9e.png', 1298, '[{\"id\":\"1298\",\"position\":1}]', '[]', '[]', '[]', '[]', 39.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:25:52', '2022-02-24 02:16:22', 0),
(42, 'Wild Mushroom Risotto', 'Hen of the Wood & King Trumpet Mushrooms, Chicken Stock, Parmigiano-Reggiano, Mascarpone, Truffle Oil.', '2022-02-18-62100121db3fb.png', 1299, '[{\"id\":\"1298\",\"position\":1},{\"id\":\"1299\",\"position\":2}]', '[]', '[]', '[]', '[]', 16.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-18 20:27:13', '2022-02-24 02:16:35', 0),
(44, 'Prime Beef Carpaccio', NULL, '2022-02-19-62107af43deee.png', 1301, '[{\"id\":\"1301\",\"position\":1}]', '[]', '[]', '[]', '[]', 23.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-19 05:07:00', '2022-02-24 02:16:49', 0),
(45, 'Antipasti', NULL, '2022-02-19-62107b7eb7f3d.png', 1301, '[{\"id\":\"1301\",\"position\":1}]', '[]', '[]', '[]', '[]', 24.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-19 05:09:18', '2022-02-24 02:22:47', 0),
(46, 'Wild Mushroom Risotto', 'Hen of the Wood & King Trumpet Mushrooms, Chicken Stock, Parmigiano-Reggiano, Mascarpone, Truffle Oil.', '2022-02-19-6210c6824c4f2.png', 1298, '[{\"id\":\"1298\",\"position\":1}]', '[]', '[]', '[]', '[]', 30.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-19 10:29:22', '2022-02-24 02:17:01', 0),
(47, 'Shrimp Orecchiette', 'Rock Shrimp, Basil Pesto, Cream, Parmigiano-Reggiano & House Made Orecchiette Topped with Toasted Pine Nuts', '2022-02-19-6210c7bc8e521.png', 1300, '[{\"id\":\"1300\",\"position\":1}]', '[]', '[]', '[]', '[]', 32.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-19 10:34:36', '2022-02-24 02:12:43', 0),
(48, 'Cacio e Pepe', 'Telecherry Black Pepper, Parmigiano-Reggiano, Pecorino Romano, Butter & House Made Spaghetti', '2022-02-19-6210c871a7b49.png', 1300, '[{\"id\":\"1300\",\"position\":1}]', '[]', '[]', '[]', '[]', 24.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-19 10:37:37', '2022-02-24 02:12:09', 0),
(49, 'Angelina\'s Signature Zeppolis', 'Fried Dough, Light and Airy, Tossed in Cinnamon-Sugar, Served with Dark Chocolate & Berry Sauces. (This item takes 15 minutes to cook)', '2022-02-26-621aea2657bb8.png', 1347, '[{\"id\":\"1347\",\"position\":1}]', '[]', '[]', '[]', '[]', 16.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-27 03:04:06', '2022-02-27 03:04:06', 0),
(50, 'House-made Tiramisu', 'Whipped Mascarpone, Ladyfingers, Espresso, Myer\'s Rum, Chocolate Shavings', '2022-02-26-621aea81066c8.png', 1347, '[{\"id\":\"1347\",\"position\":1}]', '[]', '[]', '[]', '[]', 12.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-27 03:05:37', '2022-02-27 03:05:37', 0),
(51, 'Cannoli', 'Our Homemade Cannoli Shells Filled with Our Signature Cannoli Filling', '2022-02-26-621aeb09606a7.png', 1347, '[{\"id\":\"1347\",\"position\":1}]', '[]', '[]', '[]', '[]', 12.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-27 03:07:53', '2022-02-27 03:07:53', 0),
(52, 'OMG…I Love Chocolate', 'Dark Chocolate Cake, Dark Chocolate Ganache & Raspberry Center. Covered in Dark Chocolate', '2022-02-26-621aeb557bf7f.png', 1347, '[{\"id\":\"1347\",\"position\":1}]', '[]', '[]', '[]', '[]', 13.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-02-27 03:09:09', '2022-02-27 03:11:55', 0),
(53, 'Oysters on the Half Shell', 'Half Dozen West Coast Oysters, White Balsamic Mignonette, Wedge of Lemon.', '2022-03-03-6220987365917.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 21.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-03 10:29:07', '2022-03-03 10:29:07', 0),
(54, 'Shrimp Cocktail', 'Gulf Shrimp, Vodka Cocktail Sauce, Lemon.', '2022-03-03-6220a680a1ea9.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 18.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-03 11:29:05', '2022-03-03 11:29:05', 0),
(57, 'Chilled Maine Lobster', 'Half Lobster, Mustard Sauce, Lemon.', '2022-03-03-6220b1f7a5252.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 32.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-03 12:17:59', '2022-03-03 12:17:59', 0),
(58, 'Burrata Salad', 'Prosciutto, Arugula, Peaches, Pecans, Balsamic', '2022-03-04-6221cf4f82466.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 17.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-04 08:35:27', '2022-03-04 08:35:27', 0),
(60, 'Baked Eggs in Purgatory', 'Eggs, Spicy Tomato Sauce, Garlic Crostini, Parmigiano-Reggiano.', '2022-03-04-6221d259a54e7.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 18.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-04 08:48:26', '2022-03-04 21:26:06', 0),
(62, 'Margherita', 'San Marzano Tomato, Basil, Mozzarella, Extra Virgin Olive Oil', '2022-03-04-622288ff1fa99.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 14.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-04 21:47:43', '2022-03-04 21:47:43', 0),
(63, 'Pie for Breakfast', 'Basil Pesto Sauce, Shaved Fingerling Potato, Nueske\'s Bacon,\r\n Bel Paese Cheese, Chive, Fried Circle C Egg.', '2022-03-04-62228babf3d34.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 18.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-04 21:59:08', '2022-03-04 21:59:08', 0),
(64, 'Smoked Salmon', 'Smoked Salmon, Whipped Cream Cheese, Arugula,\r\n Red Onion, Capers (Served Cool).', '2022-03-05-6222f1db988ff.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 18.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 05:15:07', '2022-03-05 05:15:07', 0),
(65, 'Blueberry Ricotta French Toast', 'Blueberry, Lemon & Sweet Ricotta Filled French Toast, \r\nHomemade Blueberry Compote, Maple Syrup.', '2022-03-05-6222f454bd272.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 18.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 05:25:40', '2022-03-05 05:25:40', 0),
(66, 'Overnight Oats', 'Old-Fashioned Oats, Goat\'s Milk Yogurt, \r\nStrawberries, Pistachios (Served Cold).', '2022-03-05-6222f8db90bb4.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 05:44:59', '2022-03-05 05:44:59', 0),
(67, 'Frittata', 'Royal Trumpet Mushrooms, Hen of the Woods Mushrooms, Roasted Tomato, \r\nSausage, & Ricotta Cheese. Served with Smashed Parmesan Potatoes.', '2022-03-05-6222fa49de1c6.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 19.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 05:51:05', '2022-03-05 05:51:05', 0),
(68, 'talian-American Breakfast', 'Circle C Farm Eggs Scrambled, Mascarpone & Truffle Oil,\r\n Nueske\'s Bacon or Breakfast Sausage, Smashed Parmesan Potatoes', '2022-03-05-6222fd26a76c1.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 17.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 06:03:18', '2022-03-05 06:03:18', 0),
(69, 'Eggs Benedict', 'Poached Circle C Farm Eggs, Crispy Pancetta, Heirloom Tomato,\r\n Choron Sauce, English Muffin, Arugula Salad.', '2022-03-05-6222fed680da1.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 21.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 06:10:30', '2022-03-05 06:10:30', 0),
(70, 'Shrimp & Polenta', 'Local Shrimp, Creamy Parmesan \r\nPolenta, Prosciutto, Red Onion, Butter', '2022-03-05-622304459909b.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 26.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 06:33:41', '2022-03-05 06:33:41', 0),
(71, 'The Burger', 'Two Ground-in-House Brisket Beef Patties, Fresh Mozzarella, \r\nBalsamic Marinated Tomato, Fresh Basil, Pesto Aioli.', '2022-03-05-622306193014e.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 21.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 06:41:29', '2022-03-05 06:41:29', 0),
(72, 'Shrimp Orecchiette', 'Rock Shrimp, Basil Pesto, Cream, Parmigiano-Reggiano &\r\n House Made Orecchiette Topped with Toasted Pine Nuts.', '2022-03-05-62230763d2242.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 30.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 06:46:59', '2022-03-05 06:46:59', 0),
(73, 'Butternut Squash Ravioli', 'Roasted Butternut Squash & Mascarpone Filled Handmade Ravioli, \r\nSauce of Orange, Sun-Dried Tomato & Butter, Truffle Oil, Arugula, Candied Pecans.', '2022-03-05-6223136eb65ef.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 28.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 07:38:22', '2022-03-05 07:38:22', 0),
(74, 'Spaghetti Carbonara', 'Homemade Spaghetti, Guanciale, Pecorino, Parmigiano-Reggiano, Egg, Black Pepper.', '2022-03-05-6223161ca1182.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 29.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 07:49:48', '2022-03-05 07:49:48', 0),
(75, 'Prime + Steak & Eggs', 'Prime + New York Strip, Local Farm Eggs, Fingerling Potatoes, \r\nArugula Salad, Oregano & Lemon Gremolata.', '2022-03-05-6223196253363.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 42.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 08:03:46', '2022-03-05 08:03:46', 0),
(76, 'Angelina\'s Bloody Mary', 'Wheatley Vodka, St. George Green Chile Vodka, Four Roses Bourbon,\r\n House Bloody Mary Mix, Topped with Chef\'s Giardiniera', '2022-03-05-62231b2e70baf.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 08:11:26', '2022-03-05 08:11:26', 0),
(77, 'Leaning Bellini Martini', '360 Peach Vodka, Peach Schnapps, Peach Nectar & Finished with Prosecco. Served Up\r\n with a House Made Peach Sugar Rim', '2022-03-05-62231dbb347f3.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 12.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 08:22:19', '2022-03-05 08:22:19', 0),
(78, 'Espresso & Oranges', 'Espresso, Cointreau, Vanilla Vodka, Godiva Dark, Espresso Vodka\r\n. Served Hot or as a Martini', '2022-03-05-62236925c40fc.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 13:44:05', '2022-03-05 13:44:05', 0),
(79, 'Fumo Segale', 'Sagamore Rye, House Made Sour, Orange Bitters, Fee Foam. Shaken &\r\n Served Over Ice in a Walnut Wood Smoked Glass', '2022-03-05-62236aec06c0d.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 16.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 13:51:40', '2022-03-05 13:51:40', 0),
(80, 'The Unicorn', 'Rum Chata Limon, 360 Vanilla Vodka, Purple Iridescence. \r\nTopped with Fleur de Charmant infused Whipped Cream \r\n Served on the Rocks', '2022-03-05-62236c939615d.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 14.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 13:58:43', '2022-03-05 13:58:43', 0),
(81, 'Vitamin C', '360 Mandarin Orange Vodka, Orange Liqueur, Orangecello,\r\n Finished with Fresh Orange Juice. \r\nShaken & Served Up with an Orange Slice.', '2022-03-05-62236f04530d3.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 12.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-05 14:09:08', '2022-03-05 14:09:08', 0),
(82, 'Key to Life', 'Captiva Spirits Honey Key Lime Vodka, Cream of Coconut, Limeade,\r\n Graham Cracker Rim. Shaken & Served Up', '2022-03-05-62237250b2ad3.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 14:23:12', '2022-03-05 14:23:12', 0),
(83, 'Italian Sangria', 'Our Red or White Sangria Made with Italian Wine, Blood Orange Liqueur & Stone Fruit Liqueur. \r\nMacerated with Fresh Orange & Pineapple.', '2022-03-05-622374386f161.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 12.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 14:31:20', '2022-03-05 14:31:20', 0),
(84, 'The Heavy Hand', 'Don Julio 1942, Gran Marnier, Lime Juice, \r\nFlamed Orange Peel, Served with a Large Cube & Salted Rim', '2022-03-05-6223775e3f907.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 45.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 14:44:46', '2022-03-05 14:44:46', 0),
(85, 'Orange', NULL, '2022-03-05-622379ce45dea.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 32.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 14:55:10', '2022-03-05 14:55:10', 0),
(86, 'Peach', NULL, '2022-03-05-62237bc688d81.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 32.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 15:03:34', '2022-03-05 15:03:34', 0),
(87, 'Pomegranate', NULL, '2022-03-05-62237dbf76bec.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 32.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-05 15:11:59', '2022-03-05 15:11:59', 0),
(88, 'Blood Orange', NULL, '2022-03-05-62237edad737d.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 32.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 15:16:42', '2022-03-05 15:16:42', 0),
(89, 'Cranberry', NULL, '2022-03-05-6223800e8a9e2.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 32.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 15:21:50', '2022-03-05 15:21:50', 0),
(90, 'Prime Beef Carpaccio', 'Thinly Sliced Prime New York Strip, Truffle Aioli, Arugula, Shaved Truffle Pecorino,\r\n Pickled Royal Trumpet Mushrooms.', '2022-03-05-6223867199c23.png', 1348, '[{\"id\":\"1348\",\"position\":1}]', '[]', '[]', '[]', '[]', 23.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 15:49:05', '2022-03-05 15:49:05', 0),
(91, 'Meatballs', 'Calabrese Style Meatballs, Fresh Herbs, Marinara, Sheep\'s \r\nMilk Ricotta Cheese, Chili Flake', '2022-03-05-622395b505e06.png', 1315, '[{\"id\":\"1315\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 16:54:13', '2022-03-05 16:58:41', 0),
(92, 'Seasonal Melon & Speck', 'Prosciutto di Parma, Seasonal Fresh Melon\r\n Marinated in Marsala, Fresh Figs, Lemon', '2022-03-05-622399a52c9a9.png', 1315, '[{\"id\":\"1315\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 17:11:01', '2022-03-05 17:11:01', 0),
(93, 'Cream of Mushroom Soup with Taleggio', 'Button Mushrooms, Prosciutto, Taleggio', '2022-03-05-62239abf87a93.png', 1315, '[{\"id\":\"1315\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 17:15:43', '2022-03-05 17:15:43', 0),
(94, 'Caesar', 'Romaine, House-Made Caesar Dressing, Hand-Torn Seasoned \r\nCroutons, Shaved Parmigiano-Reggiano', '2022-03-05-62239eaeed468.png', 1315, '[{\"id\":\"1315\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 17:32:31', '2022-03-05 17:32:31', 0),
(95, 'Free Range Chicken Breast', 'Free-Range Chicken Breast, Yukon Gold Potato Puree, \r\nHunter\'s Style Chicken Thighs Braised in Taggiasca Olives, \r\nSan Marzano Tomatoes & Red Wine', '2022-03-05-6223a1eff3968.png', 1315, '[{\"id\":\"1315\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 17:46:24', '2022-03-05 17:46:24', 0),
(96, 'Veal Bolognese', 'Veal, Tomatoes, Onion, Carrots, Basil & Sheep\'s\r\n Milk Ricotta Slow Simmered & Tossed with Pappardelle', '2022-03-05-6223a3f5dd465.png', 1315, '[{\"id\":\"1315\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 17:55:01', '2022-03-05 17:55:01', 0),
(97, 'Pork Osso Buco', 'Sixteen Ounce Braised Pork, Natural Reduction \r\nYukon Gold Potato Puree, Pickled Fennel', '2022-03-05-6223a5fc7af80.png', 1315, '[{\"id\":\"1315\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 18:03:40', '2022-03-05 18:03:40', 0),
(98, 'Shrimp Orecchiette', 'Rock Shrimp, Basil Pesto, Cream, Parmigiano-Reggiano &\r\n House Made Orecchiette Topped with Toasted Pine Nuts', '2022-03-05-6223a8802ab1c.png', 1315, '[{\"id\":\"1315\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 18:14:24', '2022-03-05 18:14:24', 0),
(99, 'Angelina\'s Signature Zeppoli for Two', 'Fried Dough, Light & Airy, Tossed in Cinnamon-Sugar with Chocolate & Berry Sauce', '2022-03-05-6223ab40a5004.png', 1315, '[{\"id\":\"1315\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 18:26:08', '2022-03-05 18:26:08', 0),
(100, 'Gelato or Sorbetto', 'Your Choice of One Flavor. Please Ask Your Server for the Flavors of the Day.', '2022-03-05-6223ac2640e67.png', 1315, '[{\"id\":\"1315\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-05 18:29:58', '2022-03-05 18:29:58', 0),
(101, 'Eggplant Rollatini', 'Eggplant, Mozzarella, Parmigiano-Reggiano, Basil & Marinara', '2022-03-06-6224634e21653.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 07:31:26', '2022-03-06 07:31:26', 0),
(102, 'Seasonal Melon & Speck', 'Watermelon, Seasonal Melon, Speck, Meridith Farm Sheep\'s Milk Feta Puree,\r\n Taggiasca Olives, Pickled Watermelon Rind', '2022-03-06-6224663de81dd.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 17.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 07:43:58', '2022-03-06 07:43:58', 0),
(103, 'Antipasti Misto', 'Cured Italian Meats, Specialty Italian Cheeses, Assorted Italian Olives, Giardinera, Grissini', '2022-03-06-622467978028f.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 24.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-06 07:49:43', '2022-03-06 07:49:43', 0),
(104, 'Cream of Mushroom Soup with Taleggio', 'Button Mushrooms, Prosciutto, Taleggio', '2022-03-06-6224687b4e157.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 14.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 07:53:31', '2022-03-06 07:53:31', 0),
(105, 'Tomato Caprese', NULL, '2022-03-06-62246972c5535.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 07:57:38', '2022-03-06 07:57:38', 0),
(106, 'Little Gem Wedge', 'Little Gem Lettuce, Gorgonzola Dolce Dressing,\r\n Heirloom Tomato, Radish, Pancetta, Gorgonzola Dolce', '2022-03-06-62246aedf1ad5.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-06 08:03:58', '2022-03-06 08:03:58', 0),
(107, 'American Red Snapper Piccatta', 'Red Snapper Served with Baked Parmesan & Bacon Ziti Cake, Broccolini, \r\nYellow Peperonata. White Wine Lemon Caper Sauce', '2022-03-06-62246c317bf56.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 45.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 08:09:21', '2022-03-06 08:09:21', 0),
(108, 'Veal Milanese', '14 Oz. Bone-In Chop Pounded Thin & Breaded. Arugula, Heirloom Cherry Tomato, \r\nParmesan & Balsamic Glaze', '2022-03-06-62246d70ed16a.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 58.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 08:14:41', '2022-03-06 08:14:41', 0),
(109, 'Filet of Wagyu Beef', 'Eight oz. Wagyu Filet, Potato Puree, Garlic, Green Beans, Red Onion, \r\nTomato, Herb Butter, Sun-Dried Tomato & Balsamic Sauce', '2022-03-06-62246e7ca4ffc.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 64.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 08:19:08', '2022-03-06 08:19:08', 0),
(110, 'Veal Marsala', 'Veal Tenderloin Scallopini, Wild Mushrooms, Marsala Sauce, Broccolini, Fingerlings', '2022-03-06-62246f49d7894.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 42.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 08:22:33', '2022-03-06 08:22:33', 0),
(111, 'Free Range Chicken Breast', 'Belle & Evans Free Range Chicken Breast, Yukon Gold Potato Puree, Hunter\'s Style Chicken \r\nThighs Braised in Taggiasca Olives, San Marzano Tomatoes & Red Wine', '2022-03-06-622472d34583b.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 34.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 08:37:39', '2022-03-06 08:37:39', 0),
(112, 'Pork Osso Buco', 'Sixteen Ounce Braised Pork Osso Bucco, Natural Reduction, Yukon Gold Potato, Puree, Pickled Fennel', '2022-03-06-622474630511c.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 39.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 08:44:19', '2022-03-06 08:44:19', 0),
(113, 'Veal Agnolotti', 'Slow Roasted Veal Filled Agnolotti, Wild Mushrooms, Veal Stock,\r\nBalsamic, Herbs, Truffle Oil, Fennel Pollen', '2022-03-06-6224760923303.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 18.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 08:51:21', '2022-03-06 08:51:21', 0),
(114, 'Butternut Squash Ravioli', 'Roasted Butternut Squash & Mascarpone Filled Handmade Ravioli, Sauce of Orange, \r\nSun-Dried Tomato & Butter, Truffle Oil, Arugula, Candied Pecans', '2022-03-06-62247915c213b.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 09:04:21', '2022-03-06 09:04:21', 0),
(115, 'Shrimp Orecchiette', 'Rock Shrimp, Basil Pesto, Cream, Parmigiano-Reggiano & \r\nHouse Made Orecchiette Topped with Toasted Pine Nuts', '2022-03-06-62247b3e065a7.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 17.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 09:13:34', '2022-03-06 09:13:34', 0),
(116, 'Spaghetti and Meatballs', 'House Made Spaghetti tossed with Marinara Topped with Calabrese Style Pork Meatballs,\r\n Fresh Herbs, Marinara, Ricotta Cheese & Chili Flakes', '2022-03-06-622482b7b4db6.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 28.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 09:45:27', '2022-03-06 09:45:27', 0),
(117, 'Wild Mushroom Risotto', 'Hen of the Wood & King Trumpet Mushrooms, Chicken Stock, \r\nParmigiano-Reggiano, Mascarpone, Truffle Oil', '2022-03-06-622484c5d9722.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 16.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 09:54:13', '2022-03-06 09:54:13', 0),
(118, 'Caesar Salad', NULL, '2022-03-06-622501d4dfecc.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 20.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-06 18:47:49', '2022-03-06 18:47:49', 0),
(119, 'Tomato Caprese', NULL, '2022-03-07-6225d32aae8d2.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 25.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-07 09:40:58', '2022-03-07 09:40:58', 0),
(120, 'Spaghetti and House Meatballs', NULL, '2022-03-07-6225d5dc10912.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-07 09:52:28', '2022-03-07 09:52:28', 0),
(121, 'Eggplant Parmesan, Spaghetti, and Marinara', NULL, '2022-03-07-6225d7195b87e.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 50.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-07 09:57:45', '2022-03-07 09:57:45', 0),
(122, 'Chicken Parmesan, Spaghetti, and Marinara', NULL, '2022-03-07-6225d83caa1f6.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 60.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-07 10:02:36', '2022-03-07 10:02:36', 0),
(123, 'Veal Parmesan, Spaghetti, and Marinara', NULL, '2022-03-07-6225d9f610454.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 80.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-07 10:09:58', '2022-03-07 10:09:58', 0),
(124, 'Angelina\'s Signature Zeppoli for Two', NULL, '2022-03-07-6225ddff327c4.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 16.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-07 10:27:11', '2022-03-07 10:27:11', 0),
(125, 'Cannolis', 'Our Homemade Cannoli Shells Filled with Our Signature Cannoli Filling', '2022-03-07-6225df023081a.png', 1351, '[{\"id\":\"1351\",\"position\":1}]', '[]', '[]', '[]', '[]', 12.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-07 10:31:30', '2022-03-07 10:31:30', 0),
(126, 'Champagne, Taittinger, Brut, \"La Française\"', NULL, '2022-03-07-6225e49943618.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 19.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-07 10:55:21', '2022-03-07 10:55:21', 0),
(127, 'Chardonnay, B.R. Cohn, Russian River Valley', NULL, '2022-03-08-6226e81aa2fcb.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 16.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 05:22:34', '2022-03-08 05:22:34', 0),
(128, 'Chardonnay, Tieffenbruner, Alto Adige', NULL, '2022-03-08-6226ea7e5857f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 13.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 05:32:46', '2022-03-08 05:32:46', 0),
(129, 'Garganega, Suavia, Soave Classico, Veneto', NULL, '2022-03-08-6226ebe2dae77.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 13.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-08 05:38:42', '2022-03-08 05:38:42', 0),
(130, 'Pinot Grigio, Biago, Sicily', NULL, '2022-03-08-6226ecb43cb82.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 8.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 05:42:12', '2022-03-08 05:42:12', 0),
(131, 'Pinot Grigio, Zenato, Venezia-Giulia', NULL, '2022-03-08-6226eda497555.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 11.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 05:46:12', '2022-03-08 05:46:12', 0),
(132, 'Prosecco, Maschio, Brut', NULL, '2022-03-08-6226eea2cd5f9.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 10.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 05:50:26', '2022-03-08 05:50:26', 0),
(133, 'Riesling, Bischöflische Weingüter Trier, Mosel', NULL, '2022-03-08-6226f05c34e51.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 16.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 05:57:48', '2022-03-08 05:57:48', 0),
(134, 'Sauvignon Blanc, Infamous Goose, Marlborough, NZ', NULL, '2022-03-08-6226f172be25d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 12.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 06:02:26', '2022-03-08 06:02:26', 0),
(135, 'Rose, Zenato, Bardolino Chiaretto, Veneto', NULL, '2022-03-08-6226f22c63911.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 9.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 06:05:32', '2022-03-08 06:05:32', 0),
(136, 'Verdicchio, Pievalta, Castelli di Jesi, Marche', NULL, '2022-03-08-6226f667496a1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 12.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 06:23:35', '2022-03-08 06:23:35', 0),
(137, 'Cabernet Sauvignon, Grayson Cellars, CA', NULL, '2022-03-08-6226f970852c8.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 11.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 06:36:32', '2022-03-08 06:36:32', 0),
(138, 'Cabernet Sauvignon, Tommasi, Tuscany', NULL, '2022-03-08-6226fa7a874cb.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 13.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-08 06:40:58', '2022-03-08 06:40:58', 0),
(139, 'Malbec, Catena Zapata, Lunlunta, Mendoza, Argentina', NULL, '2022-03-08-6227002dc62f6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 07:05:17', '2022-03-08 07:05:17', 0),
(140, 'Montepulciano, Masciarelli, Abruzzo', NULL, '2022-03-08-62270143e3dc8.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 9.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 07:09:55', '2022-03-08 07:09:55', 0),
(141, 'Pinot Noir, Picket Fence, Russian River Valley, CA', NULL, '2022-03-08-6227049ce3114.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 07:24:13', '2022-03-08 07:24:13', 0),
(142, 'Pinot Noir, Picket Fence, Russian River Valley, CA', NULL, '2022-03-08-62270632d494c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 07:30:58', '2022-03-08 07:30:58', 0),
(143, 'Super Tuscan, Banfi, \"Aska,\" Bolgheri, Tuscany', NULL, '2022-03-08-62270f119c82d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 19.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 08:08:49', '2022-03-08 08:08:49', 0),
(144, 'Super Tuscan, Tua Rita, \"Rosso dei Notri,\" Tuscany', NULL, '2022-03-08-6227121ec6c8e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 08:21:50', '2022-03-08 08:21:50', 0),
(145, 'Valpolicella, Zenato, Superiore, Veneto', NULL, '2022-03-08-622712d12d628.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 12.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 08:24:49', '2022-03-08 08:24:49', 0),
(146, 'Sangiovese, Castello di Bossi, Chianti Classico, Tuscany', NULL, '2022-03-08-622714d16a172.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 15.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 08:33:21', '2022-03-08 08:33:21', 0),
(147, 'Amarone della Valpolicella, Tommasi, Classico, Veneto, \'16', NULL, '2022-03-08-622715c508c21.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 92.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 08:37:25', '2022-03-08 08:37:25', 0),
(148, 'Cabernet Sauvignon, Silverado, Napa, CA, \'15', NULL, '2022-03-08-622716c05e00c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 75.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 08:41:36', '2022-03-08 08:41:36', 0),
(149, 'Champagne, Billecart-Salmon, Rosé, Brut, NV', NULL, '2022-03-08-622717c4dea00.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 117.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 08:45:56', '2022-03-08 08:45:56', 0),
(150, 'Champagne, Perrier-Jouët, Grand Brut, NV', NULL, '2022-03-08-62271da5b812d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 94.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 09:11:01', '2022-03-08 09:11:01', 0),
(151, 'Champagne, Taittinger, Brut La Francaise, NV', NULL, '2022-03-08-62271e33a8a43.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 64.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 09:13:23', '2022-03-08 09:13:23', 0),
(152, 'Chardonnay, Stags\' Leap, Napa Valley, CA, \'20', NULL, '2022-03-08-62272b947a363.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 41.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 10:10:28', '2022-03-08 10:10:28', 0),
(153, 'Merlot, Duckhorn, Napa Valley, CA, \'18', NULL, '2022-03-08-62272c33c027c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 75.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 10:13:07', '2022-03-08 10:13:07', 0),
(154, 'Pinot Noir, Ken Wright, \"Latchkey Vyd.,\" Willamette Valley, OR, \'18', NULL, '2022-03-08-622732bb2416a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 75.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 10:40:59', '2022-03-08 10:40:59', 0),
(155, 'Sangiovese, Brunello di Montalcino, Castello Banfi, \'15', NULL, '2022-03-08-622735a17a46d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 10:53:21', '2022-03-08 10:53:21', 0),
(156, 'Sangiovese, Chianti, Famiglia Zingarelli, Rocca delle Maciè, Classico, Italy, \'17', NULL, '2022-03-08-6227364fb65e2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 33.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 10:56:15', '2022-03-08 10:56:15', 0),
(157, 'Sauvignon Blanc, Duckhorn, Napa Valley, CA, \'18', NULL, '2022-03-08-6227377ea6b2a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 45.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 11:01:18', '2022-03-08 11:01:18', 0),
(158, 'Sauvignon Blanc, Silverado, \"Miller Ranch,\" Napa Valley, \'18', NULL, '2022-03-08-62273951e22ca.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 39.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-08 11:09:06', '2022-03-08 11:09:06', 0),
(159, 'Sparkling, Schramsberg, Blanc de Blancs, Brut, North Coast, CA, \'16', NULL, '2022-03-08-62273ae709b7b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 11:15:51', '2022-03-08 11:15:51', 0),
(160, 'Champagne, Billecart-Salmon, Brut Réserve, NV', NULL, '2022-03-08-62273caadc4c2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 132.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 11:23:22', '2022-03-08 11:23:22', 0),
(161, 'Champagne, Billecart-Salmon, Brut Rosé, N', NULL, '2022-03-08-62273d9bd6d91.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 199.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 11:27:23', '2022-03-08 11:27:23', 0),
(162, 'Champagne, Duval-LeRoy, Brut, NV', NULL, '2022-03-08-62273e57da30e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 159.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 11:30:31', '2022-03-08 11:30:31', 0),
(163, 'Champagne, Krug, Brut, \'02', NULL, '2022-03-08-6227afc4d176d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 569.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 19:34:29', '2022-03-08 19:34:29', 0),
(164, 'Champagne, Moët & Chandon, \"Impérial\" Brut, NV', NULL, '2022-03-08-6227b061cbfc9.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 159.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 19:37:05', '2022-03-08 19:37:05', 0);
INSERT INTO `food` (`id`, `name`, `description`, `image`, `category_id`, `category_ids`, `variations`, `add_ons`, `attributes`, `choice_options`, `price`, `tax`, `tax_type`, `discount`, `discount_type`, `available_time_starts`, `available_time_ends`, `set_menu`, `status`, `restaurant_id`, `created_at`, `updated_at`, `order_count`) VALUES
(165, 'Champagne, Piper-Heidsieck, \"Cuveé Sublime,\" Demi-Sec, NV', NULL, '2022-03-08-6227b163d0f02.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 149.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 19:41:23', '2022-03-08 19:41:23', 0),
(166, 'Champagne, Piper Heidsieck, \"Rare,\" 2002', NULL, '2022-03-08-6227b1f205ee3.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 300.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 19:43:46', '2022-03-08 19:43:46', 0),
(167, 'hampagne, Salon, \"Le Mesnil,\" Blanc de Blancs, Brut, \'0', NULL, '2022-03-08-6227b2c188649.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 999.99, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 19:47:13', '2022-03-08 19:47:13', 0),
(168, 'Champagne, Taittinger, \"Comtes de Champagne,\" Blanc de Blancs, \'07', NULL, '2022-03-08-6227b3acc7679.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 400.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 19:51:08', '2022-03-08 19:51:08', 0),
(169, 'Champagne, Veuve Clicquot, Brut, NV', NULL, '2022-03-08-6227b4f8c0651.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 177.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 19:56:40', '2022-03-08 19:56:40', 0),
(170, 'Franciacorta, Barone Pizzini, \"Animante,\" Brut, NV', NULL, '2022-03-08-6227b6795c553.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 93.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 20:03:05', '2022-03-08 20:03:05', 0),
(171, 'Champagne, Veuve Clicquot, \"La Grande Dame,\" Brut, \'12', NULL, '2022-03-08-6227b7177908f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 360.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 20:05:43', '2022-03-08 20:05:43', 0),
(172, 'Franciacorta, Ca\' del Bosco, \"Cuvée Prestige,\" Brut', NULL, '2022-03-08-6227b7e189b88.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 20:09:05', '2022-03-08 20:09:05', 0),
(173, 'Franciacorta, Barone Pizzini, Rosé, Brut, \'12', NULL, '2022-03-08-6227b8eedac45.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 121.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 20:13:34', '2022-03-08 20:13:34', 0),
(174, 'Lambrusco, Cleto Chiarli e Figli, \"Vecchia Modena,\" di Sorbara Secco', NULL, '2022-03-08-6227bd5d2cd98.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 47.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 20:32:29', '2022-03-08 20:32:29', 0),
(175, 'Franciacorta, Ronco Calino, Brut Satèn, NV', NULL, '2022-03-08-6227bec3d0021.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 20:38:27', '2022-03-08 20:38:27', 0),
(176, 'Prosecco, Bellussi, Valdobbiadene Prosecco Superiore, Extra Dry, NV', NULL, '2022-03-08-6227bfde17234.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 44.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 20:43:10', '2022-03-08 20:43:10', 0),
(177, 'Lambrusco, Lini 910, \"Labrusca,\" dell\'Emilia', NULL, '2022-03-08-6227c123f2e3f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 39.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 20:48:36', '2022-03-08 20:48:36', 0),
(178, 'Prosecco, Marsuret, \"San Boldo,\" Valdobbiadene Prosecco Superiore, Brut, NV', NULL, '2022-03-08-6227c2f8e5851.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 45.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 20:56:25', '2022-03-08 20:56:25', 0),
(179, 'Prosecco, Caposaldo, Brut, Veneto, NV', NULL, '2022-03-08-6227c3b8d8516.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 38.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-08 20:59:36', '2022-03-08 20:59:36', 0),
(180, 'Sparkling, Pico Maccario, Rosato Brut, Piemonte', NULL, '2022-03-08-6227c459f2a0d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 52.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 21:02:18', '2022-03-08 21:02:18', 0),
(181, 'Sparkling, Castello Banfi, \"Cuvée Aurora,\" Brut, Rosé, Alta Langa, \'16', NULL, '2022-03-08-6227c4e09b3a7.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 84.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 21:04:32', '2022-03-08 21:04:32', 0),
(182, 'Sparkling, Schramsberg, Crémant, Demi-Sec, Napa Valley, \'16', NULL, '2022-03-08-6227c58f0d1be.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 107.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-08 21:07:27', '2022-03-08 21:07:27', 0),
(183, 'Sparkling, Zardetto, Extra Dry Rosé, Conegliano, Italy, NV', NULL, '2022-03-08-622827e9045af.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 04:07:05', '2022-03-09 04:07:05', 0),
(184, 'Sparkling, Zenato, Metodo Classico Brut, Lugana, \'13/\'15', NULL, '2022-03-08-622829e1ae41b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 74.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-09 04:15:29', '2022-03-09 04:15:29', 0),
(185, 'Arneis, Monchiero Carbone, \"Cecu d\'la Biunda,\" Roero, Piemonte, \'16', NULL, '2022-03-08-62282c525ee8a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 04:25:54', '2022-03-09 04:25:54', 0),
(186, 'Arneis, Vietti, Roero, Piemonte, \'20', NULL, '2022-03-08-62282d45c0cd7.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 52.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 04:29:57', '2022-03-09 04:29:57', 0),
(187, 'Catarratto, Tasca d\'Almerita, Tenuta Regaleali, \"Antisa,\" Sicily, \'18', NULL, '2022-03-08-62282dcf572ef.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 04:32:15', '2022-03-09 04:32:15', 0),
(188, 'Chardonnay, Antinori, \"Bramito della Sala,\" Umbria, \'19', NULL, '2022-03-08-62282f7198494.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 108.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 04:39:13', '2022-03-09 04:39:13', 0),
(189, 'Chardonnay, Cabreo, \"La Pietra,\" Tuscany, \'18', NULL, '2022-03-08-622830b588ade.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 86.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 04:44:37', '2022-03-09 04:44:37', 0),
(190, 'Chardonnay, Damilano, \"G.D.,\" Langhe, Piemonte, \'16', NULL, '2022-03-08-6228318d6c190.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 169.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 04:48:13', '2022-03-09 04:48:13', 0),
(191, 'Chardonnay, Sauvignon, Bastianich, \"Vespa,\" Friuli-Venezia-Giulia, \'16', NULL, '2022-03-08-62283241780a8.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 112.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 04:51:13', '2022-03-09 04:51:13', 0),
(192, 'Chardonnay, Sauvignon Blanc, Gaja, \"Rossj Bass,\" Langhe, \'15', NULL, '2022-03-08-62283314c72d5.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 244.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 04:54:44', '2022-03-09 04:54:44', 0),
(193, 'Chardonnay, Sauvignon Blanc, Tramin, \"Stoan,\" Alto Adige, \'19', NULL, '2022-03-08-62283396f0cef.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 92.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 04:56:55', '2022-03-09 04:56:55', 0),
(194, 'Chardonnay, Vermentino, Agricola Punica, \"Samas,\" Sardinia, \'20', NULL, '2022-03-08-62283440bedef.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 55.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 04:59:44', '2022-03-09 04:59:44', 0),
(195, 'Coda di Volpe, Mastroberardino, \"Lacryma Christi del Vesuvio,\" Campania, \'16', NULL, '2022-03-09-622841ca712eb.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 47.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 05:57:30', '2022-03-09 05:57:30', 0),
(196, 'Cortese, Michele Chiarlo, \"Le Marne,\" Gavi, Piedmont, \'19', NULL, '2022-03-09-6228426d442cd.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 55.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:00:13', '2022-03-09 06:00:13', 0),
(197, 'Cortese, Pio Cesare, di Gavi, Piedmont, \'19', NULL, '2022-03-09-622843053a167.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:02:45', '2022-03-09 06:02:45', 0),
(198, 'Falanghina, Cantina del Taburno, del Sannio, \'17', NULL, '2022-03-09-622844cd045d0.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 44.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-09 06:10:21', '2022-03-09 06:10:21', 0),
(199, 'Falanghina, Feudi di San Gregorio, del Sannio, \'17', NULL, '2022-03-09-62284568678bc.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:12:56', '2022-03-09 06:12:56', 0),
(200, 'Falanghina, Mastroberardino, del Sannio, \'18', NULL, '2022-03-09-6228461bd395d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 48.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:15:55', '2022-03-09 06:15:55', 0),
(201, 'Fiano, Mastroberardino, di Avellino, \"Radici,\" \'19', NULL, '2022-03-09-62284a6d974e3.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:34:21', '2022-03-09 06:34:21', 0),
(202, 'Garganega, Pieropan, \"La Rocca,\" Soave Classico, Veneto, \'16', NULL, '2022-03-09-62284b01c005b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 80.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:36:49', '2022-03-09 06:36:49', 0),
(203, 'Garganega, Pra, \"Monte Grande,\" Soave Classico, Veneto, \'17', NULL, '2022-03-09-62284b89a6d17.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 74.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:39:05', '2022-03-09 06:39:05', 0),
(204, 'Gewürz., Sauv. Bl., Fattoria le Pupille, \"Poggio Argentato,\" Toscana, \'14', NULL, '2022-03-09-62284c143a8ef.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 45.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:41:24', '2022-03-09 06:41:24', 0),
(205, 'Gewürztraminer, Tramin, Alto Adige, \'16', NULL, '2022-03-09-62284cce85bb0.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:44:30', '2022-03-09 06:44:30', 0),
(206, 'Greco, Terredora di Paolo, di Tufo, Campania, \'18', NULL, '2022-03-09-62284d66cf3b1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:47:02', '2022-03-09 06:47:02', 0),
(207, 'Grillo, Tasca d\'Almerita, Tenuta Regaleali, \"Cavallo delle Fate,\" Sicily, \'19', NULL, '2022-03-09-62284e7b97989.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:51:39', '2022-03-09 06:51:39', 0),
(208, 'Grillo, Valle dell\'Acate, \"Zagra,\" Sicily, \'15', NULL, '2022-03-09-62284f1284d73.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 53.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:54:10', '2022-03-09 06:54:10', 0),
(209, 'Kerner, Abbazia di Novacella, Alto Adige – Valle Isarco, \'19', NULL, '2022-03-09-62284f9c292d2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 48.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:56:28', '2022-03-09 06:56:28', 0),
(210, 'Müller-Thurgau, Kettmeir, Alto Adige, \'19', NULL, '2022-03-09-622850246844a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 06:58:44', '2022-03-09 06:58:44', 0),
(211, 'Nosiola, Foradori, \"Fontanasanta,\" delle Dolomiti, \'19', NULL, '2022-03-09-622850c1dbff5.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 119.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 07:01:21', '2022-03-09 07:01:21', 0),
(212, 'Petite Arvine, Les Crêtes, Valle d\'Aosta, \'19', NULL, '2022-03-09-622855c1bd252.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 64.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 07:22:41', '2022-03-09 07:22:41', 0),
(213, 'Pinot Grigio, Maso Canali, Trentino, \'18', NULL, '2022-03-09-622862249def0.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 46.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-09 07:25:00', '2022-03-09 08:15:32', 0),
(214, 'Pinot Grigio, Pighin, Collio, Friuli-Venezia-Giulia, \'20', NULL, '2022-03-10-6229d145c1807.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 10:21:57', '2022-03-10 10:21:57', 0),
(215, 'Pinot Grigio, Talis, Friuli, \'17', NULL, '2022-03-10-6229d2491a6af.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 39.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 10:26:17', '2022-03-10 10:26:17', 0),
(216, 'Pinot Grigio, Tolloy, Alto Adige, \'19', NULL, '2022-03-10-6229d32249383.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 10:29:54', '2022-03-10 10:29:54', 0),
(217, 'Rosé, Fattoria Sardi, Toscana, \'19', NULL, '2022-03-10-6229d3d7acce1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 10:32:55', '2022-03-10 10:32:55', 0),
(218, 'Rosé, Refosco, Masi, \"Rosa dei Masi,\" delle Venezie, \'18', NULL, '2022-03-10-6229d4865d32c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 44.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 10:35:50', '2022-03-10 10:35:50', 0),
(219, 'Rosé, Sangiovese, La Spinetta, \"Il Rosé di Casanova,\" Toscana, \'20', NULL, '2022-03-10-6229d5135949d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 47.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 10:38:11', '2022-03-10 10:38:11', 0),
(222, 'Trebbiano, Masciarelli, Marina Cvetić, Riserva, Abruzzo, \'15', NULL, '2022-03-10-6229d6f47d707.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 131.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 10:46:12', '2022-03-10 10:46:12', 0),
(224, 'Trebbiano, Suavia, \"Massifitti,\" Soave, Veronese, \'16', NULL, '2022-03-10-6229e75f0414e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 11:56:15', '2022-03-10 11:56:15', 0),
(225, 'Trebbiano, Zenato, \"San Benedetto,\" Lugana, \'18', NULL, '2022-03-10-6229e813c37bb.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 35.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 11:59:15', '2022-03-10 11:59:15', 0),
(226, 'Trebbiano, Zenato, \"Sergio Zenato,\" Lugana Riserva, Veneto, \'17', NULL, '2022-03-10-6229e8d83cd02.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 12:02:32', '2022-03-10 12:02:32', 0),
(227, 'Vermentino, Antinori, Tenuta Guado al Tasso, Bolgheri, Tuscany, \'19', NULL, '2022-03-10-6229ecb4345d0.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 67.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 12:19:00', '2022-03-10 12:19:00', 0),
(228, 'Vermentino, Argiolas, \"IS Argiolas,\" Sardinia, \'19', NULL, '2022-03-10-6229f0bf32f14.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 12:36:15', '2022-03-10 12:36:15', 0),
(229, 'Vermentino, Jankara, di Gallura, Superiore, Sardinia, \'19', NULL, '2022-03-10-6229f15069478.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 12:38:40', '2022-03-10 12:38:40', 0),
(230, 'Vermentino, Jankara, di Gallura, Superiore, Sardinia, \'19', NULL, '2022-03-10-6229f21830c83.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 48.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-10 12:42:00', '2022-03-10 12:42:00', 0),
(231, 'White Blend, Cantina Terlano, \"Terlan,\" Classico, Alto Adige, \'17', NULL, '2022-03-10-6229f2b342ac1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 74.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 12:44:35', '2022-03-10 12:44:35', 0),
(232, 'White Blend, Donnafugata, \"Anthìlia,\" Sicily, \'19', NULL, '2022-03-10-6229f3bfd7543.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 45.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 12:49:03', '2022-03-10 12:49:03', 0),
(233, 'White Blend, Salviano, Orvieto Classico Superiore, Umbria, \'18', NULL, '2022-03-10-6229f45eec5dd.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 12:51:42', '2022-03-10 12:51:42', 0),
(234, 'Grüner Veltliner, Fred Loimer, \"Lois,\" Kamptal, Austria, \'20', NULL, '2022-03-10-6229f532263ef.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 44.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 12:55:14', '2022-03-10 12:55:14', 0),
(235, 'Riesling, G. Albrecht Schneider, Niersteiner Hipping, Spätlese, Rheinhessen, \'16', NULL, '2022-03-10-6229f6014c789.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 55.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 12:58:41', '2022-03-10 12:58:41', 0),
(236, 'Riesling, Schloss Vollrads, Qualitätswein, Rheingau, \'19', NULL, '2022-03-10-6229f6f9907cd.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 13:02:49', '2022-03-10 13:02:49', 0),
(237, 'Riesling, Schloss Vollrads, Spätlese, QmP, Rheingau, \'17', NULL, '2022-03-10-6229f7f71539c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 13:07:03', '2022-03-10 13:07:03', 0),
(238, 'Riesling, Bischöflische Weingüter Trier, Ayler Kupp, Kabinett, Mosel, \'15', NULL, '2022-03-10-6229f8a6b9059.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-10 13:09:58', '2022-03-10 13:09:58', 0),
(239, 'Chardonnay, Bouchard Père et Fils, Beaune 1er Cru, Clos Saint-Landry, \'18', NULL, '2022-03-11-622b31f408e96.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 199.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 11:26:44', '2022-03-11 11:26:44', 0),
(240, 'Chardonnay, Bret Brothers, Pouilly-Fuissé, \"Le Clos Reyssié,\" \'17', NULL, '2022-03-11-622b329fab6b0.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 129.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 11:29:35', '2022-03-11 11:29:35', 0),
(241, 'Chardonnay, Bret Brothers, \"La Soufrandière,\" Pouilly-Vinzelles, \'18', NULL, '2022-03-11-622b33bbb9fa9.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 139.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 11:34:19', '2022-03-11 11:34:19', 0),
(242, 'Chardonnay, Château de la Crée, \"Les Tourelles de la Crée,\" Montagny 1er Cru, \'18', NULL, '2022-03-11-622b3597d2e61.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 11:42:15', '2022-03-11 11:42:15', 0),
(243, 'Chardonnay, Domaine François Carillon, Puligny-Montrachet, \'19', NULL, '2022-03-11-622b36a31a8e1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 179.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 11:46:43', '2022-03-11 11:46:43', 0),
(244, 'Chardonnay, Domaine Roux Père & Fils, Chassagne-Montrachet, \'18', NULL, '2022-03-11-622b3721ba195.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 234.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 11:48:49', '2022-03-11 11:48:49', 0),
(245, 'Chardonnay, Louis Jadot, Mâcon-Villages, \'20', NULL, '2022-03-11-622b3a0795c3a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 12:01:11', '2022-03-11 12:01:11', 0),
(246, 'Chardonnay, Louis Michel et Fils, 1er Cru Butteaux Chablis, \'18', NULL, '2022-03-11-622b3b4bbad33.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 119.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 12:06:35', '2022-03-11 12:06:35', 0),
(247, 'Chardonnay, Simonnet-Febvre, Grand Cru, \"Les Clos,\" Chablis, \'18', NULL, '2022-03-11-622b3c4d8c544.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 119.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 12:10:53', '2022-03-11 12:10:53', 0),
(248, 'Chenin Blanc, Domaine Huet, \"Le Haut-Lieu,\" Vouvray, \'19', NULL, '2022-03-11-622b403c6b3ea.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 12:27:40', '2022-03-11 12:27:40', 0),
(249, 'Pinot Blanc, Cave de Turckheim, Alsace, \'17', NULL, '2022-03-11-622b40b9371f8.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 12:29:45', '2022-03-11 12:29:45', 0),
(250, 'Riesling, Gustave Lorentz, Réserve, Alsace, \'16', NULL, '2022-03-11-622b4151a5a84.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 12:32:17', '2022-03-11 12:32:17', 0),
(252, 'Riesling, Trimbach, Alsace, \'14', NULL, '2022-03-11-622b423202d9e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 84.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 12:36:02', '2022-03-11 12:36:02', 0),
(253, 'Rosé, Triennes, Méditerranée IGP, \'20', NULL, '2022-03-11-622b45f012fb5.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 44.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 12:52:00', '2022-03-11 12:52:00', 0),
(254, 'Sauvignon Blanc, Alphonse Mellot, \"La Moussiere,\" Sancerre, \'19', NULL, '2022-03-11-622b47dfbc0a5.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 74.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 13:00:15', '2022-03-11 13:00:15', 0),
(255, 'Sauvignon Blanc, Alphonse Mellot, \"La Moussiere,\" Sancerre, \'19', NULL, '2022-03-11-622b47e2907a2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 74.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 13:00:18', '2022-03-11 13:00:18', 0),
(256, 'Sauvignon Blanc, Château Carbonnieux Blanc, Pessac-Léognan, \'18', NULL, '2022-03-11-622b48773263b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 139.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 13:02:47', '2022-03-11 13:02:47', 0),
(257, 'Sauvignon Blanc, de Ladoucette, Pouilly-Fumé, \'15', NULL, '2022-03-11-622b498f6bdb4.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 127.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 13:07:27', '2022-03-11 13:07:27', 0),
(258, 'Sauvignon Blanc, Michel Redde, \"La Moynerie,\" Pouilly-Fumé, \'17', NULL, '2022-03-11-622b4a3f248a7.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 13:10:23', '2022-03-11 13:10:23', 0),
(259, 'Viognier, Domaine Rostaing, \"Les Lézardes,\" IGP Collines Rhodaniennes, \'15', NULL, '2022-03-11-622b4b3b63c2e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 94.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 13:14:35', '2022-03-11 13:14:35', 0),
(260, 'White Blend, Château de Beaucastel Blanc, Châteauneuf-du-Pape, \'14', NULL, '2022-03-11-622b4cfb48b29.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 231.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-11 13:22:03', '2022-03-11 13:22:03', 0),
(261, 'Chardonnay, Kumeu River, Estate, New Zealand, \'18', NULL, '2022-03-11-622b4e24ea8c2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 94.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 13:27:00', '2022-03-11 13:27:00', 0),
(262, 'Chardonnay, Vasse Felix, \"Filius,\" Margaret River, Australia, \'20', NULL, '2022-03-11-622b4ee58eac0.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 82.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 13:30:13', '2022-03-11 13:30:13', 0),
(263, 'Riesling, Pikes, \"Hills & Valleys,\" Clare Valley, Australia, \'19', NULL, '2022-03-11-622b4f862079f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 39.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 13:32:54', '2022-03-11 13:32:54', 0),
(264, 'Sauvignon Blanc, Cloudy Bay, Marlborough, New Zealand, \'21', NULL, '2022-03-11-622b50155e253.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 91.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 13:35:17', '2022-03-11 13:35:17', 0),
(265, 'Sauvignon Blanc, Kim Crawford, Marlborough, New Zealand, \'20', NULL, '2022-03-11-622b508d52383.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-11 13:37:17', '2022-03-11 13:37:17', 0),
(266, 'Chardonnay, Casa Lapostolle, \"Cuvée Alexander,\" Chile, \'16', NULL, '2022-03-12-622cbd496d5c8.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 15:33:29', '2022-03-12 15:33:29', 0),
(267, 'Chardonnay, Catena Zapata, \"Catena Alta,\" Historic Rows, Mendoza, \'17', NULL, '2022-03-12-622cbee543fa6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 15:40:21', '2022-03-12 15:40:21', 0),
(268, 'Chardonnay, Catena Zapata, \"White Stones,\" Adrianna Vyd., Mendoza, \'09', NULL, '2022-03-12-622cc06f6580a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 195.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 15:46:55', '2022-03-12 15:46:55', 0),
(269, 'Chardonnay, Catena Zapata, \"White Stones,\" Adrianna Vyd., Mendoza, \'17', NULL, '2022-03-12-622cc11a078b3.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 185.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 15:49:46', '2022-03-12 15:49:46', 0),
(270, 'Chenin Blanc, Groote Post, Darling Hills, South Africa, \'16', NULL, '2022-03-12-622cc261daf28.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 15:55:13', '2022-03-12 15:55:13', 0),
(272, 'Rosé, Pinot Noir, Bodega Garzón, Reserva, Uruguay, \'20', NULL, '2022-03-12-622cc53d27d3b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 39.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 16:07:25', '2022-03-12 16:07:25', 0),
(281, 'Rosé, Syrah, Montes, \"Cherub,\" Colchagua, Chile, \'18', NULL, '2022-03-12-622ccb6a4d545.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 54.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 16:33:46', '2022-03-12 16:33:46', 0),
(282, 'Torrontés, Bodega Colomé, Salta, Argentina, \'19', NULL, '2022-03-12-622ccc0a2c368.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 54.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 16:36:26', '2022-03-12 16:36:26', 0),
(283, 'Torrontés, Bodega Colomé, Salta, Argentina, \'19', NULL, '2022-03-12-622ccc0a40542.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 54.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 16:36:26', '2022-03-12 16:36:26', 0),
(284, 'Albariño, Burgans, Rías Baixas, \'18', NULL, '2022-03-12-622cccc45a0a3.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 44.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 16:39:32', '2022-03-12 16:39:32', 0),
(285, 'Albariño, Morgadio, Rías Baixas, \'17', NULL, '2022-03-12-622ccd7df2ae7.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 54.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 16:42:38', '2022-03-12 16:42:38', 0),
(286, 'Godello, Avancia, \"Cuvée de O,\" Valdeorras, \'13', NULL, '2022-03-12-622cce3b8f803.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 16:45:47', '2022-03-12 16:45:47', 0),
(287, 'Verdejo, Viña Gormaz, Rueda, \'16', NULL, '2022-03-12-622ccf07dcee1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 38.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 16:49:12', '2022-03-12 16:49:12', 0),
(288, 'Viura, Finca Antigua, La Mancha, \'15', NULL, '2022-03-12-622ccfa70a36c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 29.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 16:51:51', '2022-03-12 16:51:51', 0),
(289, 'Viura, Malvasía, Bodegas Muga, Rioja, \'20', NULL, '2022-03-12-622cd06adaf24.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 39.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 16:55:06', '2022-03-12 16:55:06', 0),
(290, 'Chardonnay, Archery Summit, Eola-Amity Hills, OR, \'18', NULL, '2022-03-12-622cd27d71b91.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 90.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 17:03:57', '2022-03-12 17:03:57', 0),
(291, 'Chardonnay, Aubert, Sonoma Coast, Sonoma County, CA, \'17', NULL, '2022-03-12-622cd33a91735.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 159.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 17:07:06', '2022-03-12 17:07:06', 0),
(292, 'Chardonnay, Cakebread, Napa, CA, \'19', NULL, '2022-03-12-622cd3c24de25.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 109.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 17:09:22', '2022-03-12 17:09:22', 0),
(293, 'Chardonnay, Cambria, \"Katherine\'s Vyd.,\" Sta. Maria Valley, CA, \'19', NULL, '2022-03-12-622cd47565479.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 17:12:21', '2022-03-12 17:12:21', 0),
(294, 'Chardonnay, Unoaked, Chehalem, \"Inox,\" Willamette Valley, OR, \'19', NULL, '2022-03-12-622d0a68e4fb8.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:02:32', '2022-03-12 21:02:32', 0),
(295, 'Chardonnay, Croix, Bacigalupi Vyd., Russian River Valley, \'19', NULL, '2022-03-12-622d0de72f54d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 129.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:17:27', '2022-03-12 21:17:27', 0),
(296, 'Chardonnay, Domaine Serene, \"Evenstad Reserve,\" Dundee Hills, OR, \'18', NULL, '2022-03-12-622d0e64b78d6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 175.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:19:32', '2022-03-12 21:19:32', 0),
(297, 'Chardonnay, Enfield, Haynes Vineyard, Coombsville, Napa, CA, \'15', NULL, '2022-03-12-622d0f7f34e7d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 115.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:24:15', '2022-03-12 21:24:15', 0),
(298, 'Chardonnay, Etude, Grace Benoist Ranch, Carneros, CA, \'15', NULL, '2022-03-12-622d102c04a1c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 139.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:27:08', '2022-03-12 21:27:08', 0),
(299, 'Chardonnay, Fisher, \"Mountain Estate,\" Sonoma County, CA, \'18', NULL, '2022-03-12-622d10f9a5552.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 169.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:30:33', '2022-03-12 21:30:33', 0),
(300, 'Chardonnay, Fisher, \"Unity,\" Sonoma/Mendocino, CA \'17', NULL, '2022-03-12-622d116fcebaf.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:32:31', '2022-03-12 21:32:31', 0),
(301, 'Chardonnay, Groth, Hillview Vineyard, Napa Valley, CA, \'19', NULL, '2022-03-12-622d11eef2e7a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:34:39', '2022-03-12 21:34:39', 0),
(302, 'hardonnay, Hanzell, Sonoma Valley, Sonoma County, CA, \'15', NULL, '2022-03-12-622d12a79bb98.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 119.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:37:43', '2022-03-12 21:37:43', 0),
(303, 'Chardonnay, Unoaked, Iron Horse, Estate, Green Valley, Russian River, CA, \'17', NULL, '2022-03-12-622d1322e9d35.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:39:46', '2022-03-12 21:39:46', 0),
(304, 'Chardonnay, Keenan, Spring Mountain Dist., Napa, CA, \'18', NULL, '2022-03-12-622d13bd12831.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 104.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:42:21', '2022-03-12 21:42:21', 0),
(305, 'Chardonnay, Kosta Browne, \"One Sixteen,\" Russian River, CA, \'17', NULL, '2022-03-12-622d145504df3.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 194.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:44:53', '2022-03-12 21:44:53', 0),
(306, 'Chardonnay, Littorai, Charles Heintz Vineyard, Sonoma Coast, CA, \'19', NULL, '2022-03-12-622d14e489d83.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 199.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:47:16', '2022-03-12 21:47:16', 0),
(307, 'Chardonnay, Nicolas-Jay, \"Affinités,\" Willamette Valley, OR, \'18', NULL, '2022-03-12-622d156cae646.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 124.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:49:32', '2022-03-12 21:49:32', 0),
(308, 'Chardonnay, Patz & Hall, Dutton Ranch, Russian River, CA, \'17', NULL, '2022-03-12-622d15e94eb49.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 125.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 21:51:37', '2022-03-12 21:51:37', 0),
(309, 'Chardonnay, Paul Hobbs, Russian River Valley, CA, \'19', NULL, '2022-03-12-622d18cd050c3.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 145.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:03:57', '2022-03-12 22:03:57', 0),
(310, 'Chardonnay, Plumpjack, Napa Valley, CA, \'19', NULL, '2022-03-12-622d194c1d70b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 139.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:06:04', '2022-03-12 22:06:04', 0),
(311, 'Chardonnay, Talley, Arroyo Grande Valley, CA, \'18', NULL, '2022-03-12-622d1a0733768.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 74.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:09:11', '2022-03-12 22:09:11', 0),
(312, 'Chardonnay, Truchard, Carneros, Napa Valley, CA, \'16', NULL, '2022-03-12-622d1a934522b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 85.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:11:31', '2022-03-12 22:11:31', 0),
(313, 'Chenin Blanc/Viognier, Pine Ridge, CA, \'17', NULL, '2022-03-12-622d1b07de65a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:13:27', '2022-03-12 22:13:27', 0),
(314, 'Grenache Blanc, Seabold, \"Mission Ranch,\" Arroyo Seco, Monterey, CA, \'18', NULL, '2022-03-12-622d1b89975e7.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:15:37', '2022-03-12 22:15:37', 0),
(315, 'Pinot Blanc, Ponzi, Willamette Valley, OR, \'17', NULL, '2022-03-12-622d1c2a006c1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 164.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:18:18', '2022-03-12 22:18:18', 0),
(316, 'Pinot Gris, Chehalem, \"Three Vineyard,\" Willamette Valley, OR, \'16', NULL, '2022-03-12-622d1ca141648.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 63.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:20:17', '2022-03-12 22:20:17', 0),
(317, 'Pinot Gris, Ponzi, Willamette Valley, OR, \'19', NULL, '2022-03-12-622d1daf533cb.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:24:47', '2022-03-12 22:24:47', 0),
(318, 'Riesling, Chehalem, \"Three Vineyard,\" Dry, Willamette Valley, OR, \'14', NULL, '2022-03-12-622d1e6c041c4.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 65.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:27:56', '2022-03-12 22:27:56', 0),
(319, 'Rosé, Pinot Noir, Sokol Blosser, Willamette Valley, OR, \'20', NULL, '2022-03-12-622d1f0bc2d9b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 45.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:30:35', '2022-03-12 22:30:35', 0),
(320, 'Sauvignon Blanc, Cade, Napa Valley, CA, \'20', NULL, '2022-03-12-622d1fe762a4f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:34:15', '2022-03-12 22:34:15', 0),
(321, 'Sauvignon Blanc, Cakebread, Napa Valley, CA, \'20', NULL, '2022-03-12-622d20a19b71a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:37:21', '2022-03-12 22:37:21', 0),
(322, 'Sauvignon Blanc, Duckhorn, Napa Valley, CA, \'17', NULL, '2022-03-12-622d214012c6e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 97.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:40:00', '2022-03-12 22:40:00', 0),
(323, 'Sauvignon Blanc, Groth, Napa Valley, CA, \'17', NULL, '2022-03-12-622d21cbb1067.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:42:19', '2022-03-12 22:42:19', 0),
(324, 'Sauvignon Blanc, Honig, Napa Valley, CA, \'20', NULL, '2022-03-12-622d223d70fb7.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 54.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:44:13', '2022-03-12 22:44:13', 0),
(325, 'Sauvignon Blanc, Peter Michael, \"L\'Aprés-Midi,\" Knights Valley, Sonoma, CA, \'16', NULL, '2022-03-12-622d22efe4f7e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 149.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:47:11', '2022-03-12 22:47:11', 0),
(326, 'Sauvignon Blanc, St. Supéry, \"Dollarhide,\" Napa Valley, CA, \'17/\'18', NULL, '2022-03-12-622d2382d660e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-12 22:49:38', '2022-03-12 22:49:38', 0),
(327, 'Sauvignon Blanc, Twomey, Sonoma & Napa Counties, CA, \'17', NULL, '2022-03-13-622e0736543f6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:01:10', '2022-03-13 15:01:10', 0),
(328, 'Sauvignon Blanc, The Withers, \"Charles Vineyard,\" Anderson Valley, CA, \'20', NULL, '2022-03-13-622e082edf9ea.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 82.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:05:18', '2022-03-13 15:05:18', 0),
(329, 'Sauvignon Blanc, Utopium, Sonoma Valley, CA, \'12', NULL, '2022-03-13-622e08e0a4308.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 64.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:08:16', '2022-03-13 15:08:16', 0),
(330, 'White Blend, Sokol Blosser, \"Evolution,\" OR, \'20', NULL, '2022-03-13-622e09c3b4970.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:12:03', '2022-03-13 15:12:03', 0),
(331, 'Merlot, Valori, \"InKiostro,\" Colli Aprutini,\" Abruzzo, \'12', NULL, '2022-03-13-622e0af5a0a73.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 82.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:17:09', '2022-03-13 15:17:09', 0),
(332, 'Montepulciano, Aglianico, Di Majo Norante, \"Ramitello,\" Molise, \'16', NULL, '2022-03-13-622e0b9c17d91.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:19:56', '2022-03-13 15:19:56', 0),
(333, 'Montepulciano, Masciarelli, Marina Cvetić, Riserva, Abruzzo, \'17', NULL, '2022-03-13-622e0c7b650b2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 74.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:23:39', '2022-03-13 15:23:39', 0),
(334, 'Sangiovese, San Patrignano, \"Ora,\" Superiore, Emilia-Romagna, \'15', NULL, '2022-03-13-622e0d9713f3d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 54.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:28:23', '2022-03-13 15:28:23', 0),
(335, 'Aglianico, Bisceglia, \"Gudarrà,\" del Vulture, Basilicata, \'16', NULL, '2022-03-13-622e0fa8ee6b6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:37:13', '2022-03-13 15:37:13', 0),
(336, 'Aglianico, Elena Fucci, \"Titolo,\" del Vulture, Basilicata, \'13', NULL, '2022-03-13-622e10554831f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 104.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:40:05', '2022-03-13 15:40:05', 0),
(337, 'Aglianico, Feudi di San Gregorio, \"Serpico,\" Riserva, Irpinia, Campania, \'08', NULL, '2022-03-13-622e110ed9fba.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 199.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:43:10', '2022-03-13 15:43:10', 0),
(338, 'Aglianico, Galardi, \"Terra di Lavoro,\" Roccamonfina, Campania, \'17', NULL, '2022-03-13-622e11d3cf68c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 189.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:46:27', '2022-03-13 15:46:27', 0),
(339, 'Aglianico, Mastroberardino, \"Radici,\" Taurasi Riserva, Campania, \'14', NULL, '2022-03-13-622e12713cc28.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 159.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:49:05', '2022-03-13 15:49:05', 0),
(340, 'Aglianico, Mastroberardino, \"Radici,\" Taurasi, Campania, \'16', NULL, '2022-03-13-622e130eac905.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 134.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:51:42', '2022-03-13 15:51:42', 0),
(341, 'Aglianico, Terredora di Paola, Taurasi, \"Fatica Contadina,\" Campania, \'12', NULL, '2022-03-13-622e13a92388f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:54:17', '2022-03-13 15:54:17', 0),
(342, 'Aglianico, Mastroberardino, \"Redimore,\" Irpinia, Campania, \'18', NULL, '2022-03-13-622e142fd7417.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 64.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:56:31', '2022-03-13 15:56:31', 0);
INSERT INTO `food` (`id`, `name`, `description`, `image`, `category_id`, `category_ids`, `variations`, `add_ons`, `attributes`, `choice_options`, `price`, `tax`, `tax_type`, `discount`, `discount_type`, `available_time_starts`, `available_time_ends`, `set_menu`, `status`, `restaurant_id`, `created_at`, `updated_at`, `order_count`) VALUES
(343, 'Aglianico, Merlot, Syrah, Bisceglia, \"Tréje,\" Basilicata, \'13', NULL, '2022-03-13-622e14c64b529.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 54.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 15:59:02', '2022-03-13 15:59:02', 0),
(344, 'Aglianico, Tormaresca, \"Bocca di Lupo,\" Campania, \'14', NULL, '2022-03-13-622e154841e15.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 155.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:01:12', '2022-03-13 16:01:12', 0),
(345, 'Negroamaro, Tenuta Rubino, Marmorelle Rosso, Salento, \'13', NULL, '2022-03-13-622e15cfea463.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 39.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:03:27', '2022-03-13 16:03:27', 0),
(346, 'Gaglioppo, Cabernet, Librandi, \"Gravello,\" Val di Neto, Calabria, \'17', NULL, '2022-03-13-622e166a6fcd7.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:06:02', '2022-03-13 16:06:02', 0),
(347, 'Nero di Troia, Botromagno, Puglia, \'17', NULL, '2022-03-13-622e16e0ecdea.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 54.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:08:00', '2022-03-13 16:08:00', 0),
(348, 'Cabernet, Merlot, Marchese Gonzaga, \"Terre di San Leonardo,\" Trentino-Alto Adige, \'16', NULL, '2022-03-13-622e1d19500db.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 74.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:34:33', '2022-03-13 16:34:33', 0),
(349, 'Merlot, Scarbolo, \"Campo del Viotto,\" Venezia-Giulia, \'13', NULL, '2022-03-13-622e1dccd0793.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:37:32', '2022-03-13 16:37:32', 0),
(350, 'Pinot Nero, Les Crêtes, Valle d\'Aosta, \'19', NULL, '2022-03-13-622e1e6959313.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 58.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:40:09', '2022-03-13 16:40:09', 0),
(351, 'Petit Rouge, Mayolet, Château Feuillet, Torrette, Valle d\'Aosta, \'16', NULL, '2022-03-13-622e1f082508b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 64.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:42:48', '2022-03-13 16:42:48', 0),
(352, 'Refosco, Scarbolo, Venezia-Giulia, \'13', NULL, '2022-03-13-622e1fbc0da49.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:45:48', '2022-03-13 16:45:48', 0),
(353, 'Teroldego, Elisabetta Foradori, Trentino, \'19', NULL, '2022-03-13-622e20538c58e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 74.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:48:19', '2022-03-13 16:48:19', 0),
(354, 'Barbera d\'Alba, Bruno Giacosa, \'18', NULL, '2022-03-13-622e2131b1a8e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:52:01', '2022-03-13 16:52:01', 0),
(355, 'Barbera d\'Alba, La Spinetta, \"Gallina,\" \'13', NULL, '2022-03-13-622e224858151.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 135.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 16:56:40', '2022-03-13 16:56:40', 0),
(356, 'Barbera d\'Asti, Michele Chiarlo, \"Le Orme,\" \'17', NULL, '2022-03-13-622e352a042e9.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 18:17:14', '2022-03-13 18:17:14', 0),
(357, 'Dolcetto, Annamaria Abbona, \"Sorì dij But,\" Dogliani, \'16', NULL, '2022-03-13-622e35f02a67d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 18:20:32', '2022-03-13 18:20:32', 0),
(358, 'Dolcetto, Beni di Batasiolo, Dogliani, \'17', NULL, '2022-03-13-622e3bd977d9d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 44.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 18:45:45', '2022-03-13 18:45:45', 0),
(359, 'Dolcetto, Pecchenino, \"Bricco Botti,\" Supiore, Dogliani, \'16', NULL, '2022-03-13-622e3c6a08ca9.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 82.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 18:48:10', '2022-03-13 18:48:10', 0),
(360, 'Nebbiolo, Aldo Conterno, \"Il Favot,\" Langhe, \'18', NULL, '2022-03-13-622e3d2240f27.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 120.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 18:51:14', '2022-03-13 18:51:14', 0),
(361, 'Nebbiolo, Barbera, Gaja, \"Costa Russi,\" Langhe, \'07', NULL, '2022-03-13-622e3df6c384c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 742.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '19:00:00', 0, 1, 1674, '2022-03-13 18:54:46', '2022-03-13 18:54:46', 0),
(362, 'Nebbiolo, Barbera, La Spinetta, \"Pin,\" Monferrarto, \'14', NULL, '2022-03-13-622e3e7c9fa9b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 139.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 18:57:00', '2022-03-13 18:57:00', 0),
(363, 'Nebbiolo, Merlot & Cabernet, Gaja, \"Sito Moresco,\" Langhe, \'17', NULL, '2022-03-13-622e3efe255d6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 153.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 18:59:10', '2022-03-13 18:59:10', 0),
(364, 'Nebbiolo, Achille Boroli, Barolo, \'13', NULL, '2022-03-13-622e3f7b3149c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 129.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 19:01:15', '2022-03-13 19:01:15', 0),
(365, 'Nebbiolo, Achille Boroli, \"Brunella,\" Barolo, \'13', NULL, '2022-03-13-622e3ffcc66b1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 299.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-13 19:03:24', '2022-03-13 19:03:24', 0),
(366, 'Nebbiolo, Aurelio Settimo, Barolo, \'13', NULL, '2022-03-14-622ecbcee9886.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 107.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 04:59:58', '2022-03-14 04:59:58', 0),
(367, 'Nebbiolo, Aurelio Settimo, Barolo, \"Rocche dell\'Annunziata,\" \'13', NULL, '2022-03-14-622eccb90a29e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 132.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:03:53', '2022-03-14 05:03:53', 0),
(368, 'Nebbiolo, Bruno Giacosa, Barbaresco, \"Asili,\" \'16', NULL, '2022-03-14-622ecd501db90.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 999.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:06:24', '2022-03-14 05:06:24', 0),
(369, 'Nebbiolo, Castello di Neive, Barbaresco, \'18', NULL, '2022-03-14-622ece27c0bce.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:09:59', '2022-03-14 05:09:59', 0),
(370, 'Nebbiolo, Castello di Neive, Barbaresco, \"Santo Stefano,\" \'16', NULL, '2022-03-14-622ece9ccbe16.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 175.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:11:56', '2022-03-14 05:11:56', 0),
(371, 'Nebbiolo, Ceretto, Barolo, \'15', NULL, '2022-03-14-622ecf10c1bfe.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 149.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:13:52', '2022-03-14 05:13:52', 0),
(372, 'Nebbiolo, Ceretto, Barbaresco, \"Bricco Asili,\" \'07', NULL, '2022-03-14-622ed0af3b10e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 321.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:20:47', '2022-03-14 05:20:47', 0),
(373, 'Nebbiolo, Ceretto, Barolo, \"Bricco Rocche,\" \'07', NULL, '2022-03-14-622ed11541334.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 612.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:22:29', '2022-03-14 05:22:29', 0),
(374, 'Nebbiolo, Ceretto, Barolo, \"Prapó,\" \'11', NULL, '2022-03-14-622ed18b98309.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 327.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:24:27', '2022-03-14 05:24:27', 0),
(375, 'Nebbiolo, Conterno-Fantino, Barolo, \"Vigna del Gris,\" \'16', NULL, '2022-03-14-622ed33e657a1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 249.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:31:42', '2022-03-14 05:31:42', 0),
(376, 'Nebbiolo, Damilano, Barolo, \"Cannubi,\" \'16', NULL, '2022-03-14-622ed3dde1748.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 180.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:34:21', '2022-03-14 05:34:21', 0),
(377, 'Nebbiolo, Damilano, Barolo, \"Lecinquevigne,\" \'15', NULL, '2022-03-14-622ed4a0eeaa9.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 124.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:37:37', '2022-03-14 05:37:37', 0),
(378, 'Nebbiolo, E. Pira, Barolo, \"Cannubi,\" \'12', NULL, '2022-03-14-622ed534c1dcf.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 249.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:40:04', '2022-03-14 05:40:04', 0),
(380, 'Nebbiolo, Gaja, Barbaresco, \'18', NULL, '2022-03-14-622ed6dca380d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 460.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:47:08', '2022-03-14 05:47:08', 0),
(381, 'Nebbiolo, Gaja, Barolo, \"Conteisa,\" Langhe, \'15', NULL, '2022-03-14-622ed9c8dba81.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 540.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 05:59:36', '2022-03-14 05:59:36', 0),
(382, 'Nebbiolo, Giacomo Borgogno, Barolo, Riserva, \'82', NULL, '2022-03-14-622edba186b39.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 422.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 06:07:29', '2022-03-14 06:07:29', 0),
(383, 'Nebbiolo, Giacomo Borgogno, Barolo, Riserva, \'85', NULL, '2022-03-14-622edc864d5bf.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 402.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 06:11:18', '2022-03-14 06:11:18', 0),
(384, 'Nebbiolo, Giuseppe Cortese, Barbaresco, \'17', NULL, '2022-03-14-622edde6c7a3d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 06:17:10', '2022-03-14 06:17:10', 0),
(385, 'Nebbiolo, Giuseppe Cortese, \"Rabaja,\" Barbaresco, \'17', NULL, '2022-03-14-622ee037d0acd.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 125.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 06:27:03', '2022-03-14 06:27:03', 0),
(386, 'Nebbiolo, La Spinetta, Barbaresco, \"Vigneto Bordini,\" \'18', NULL, '2022-03-14-622ee17d26f09.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 145.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 06:32:29', '2022-03-14 06:32:29', 0),
(387, 'Nebbiolo, La Spinetta, Langhe, \'17', NULL, '2022-03-14-622ee566e72ed.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 06:49:10', '2022-03-14 06:49:10', 0),
(388, 'Nebbiolo, Luigi Einaudi, Barolo, \"Cannubi,\" \'14', NULL, '2022-03-14-622ee7686e98a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 235.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 06:57:44', '2022-03-14 06:57:44', 0),
(389, 'Nebbiolo, Luigi Einaudi, Barolo, \"Terlo Vigna Costa Grimaldi,\" \'15/\'17', NULL, '2022-03-14-622ee82d3618d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 299.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 07:01:01', '2022-03-14 07:01:01', 0),
(390, 'Nebbiolo, Marcarini, Barolo, \"Brunnate,\" \'14', NULL, '2022-03-14-622ee96d61d4a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 160.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 07:06:21', '2022-03-14 07:06:21', 0),
(391, 'Nebbiolo, Marchesi di Gresy, Barbaresco, \"Martinenga,\" \'17', NULL, '2022-03-14-622eeb37e3fd7.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 164.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 07:13:59', '2022-03-14 07:13:59', 0),
(392, 'Nebbiolo, Michele Chiarlo, Barolo, \"Cerequio, \'17', NULL, '2022-03-14-622eec070487b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 219.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 07:17:27', '2022-03-14 07:17:27', 0),
(393, 'Nebbiolo, Michele Chiarlo, Barolo, \"Cerequio, \'17', NULL, '2022-03-14-622eec0737602.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 219.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 07:17:27', '2022-03-14 07:17:27', 0),
(394, 'Nebbiolo, Nada, Barbaresco, \"Casot,\" \'17', NULL, '2022-03-14-622eecdabf61c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 07:20:58', '2022-03-14 07:20:58', 0),
(395, 'Nebbiolo, Nervi, Gattinara, \'16', NULL, '2022-03-14-622ef1775f2d7.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 149.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 07:40:39', '2022-03-14 07:40:39', 0),
(396, 'Nebbiolo, Pecchenino, Barolo, \"Bussia,\" \'15', NULL, '2022-03-14-622ef34072a25.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 175.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 07:48:16', '2022-03-14 07:48:16', 0),
(397, 'Nebbiolo, Paolo Scavino, Barolo, \"Bricco Ambrogio,\" \'17', NULL, '2022-03-14-622ef42a76ddf.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 149.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 07:52:10', '2022-03-14 07:52:10', 0),
(398, 'Nebbiolo, Prunotto, Barolo, \'16', NULL, '2022-03-14-622ef4d8edde2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 145.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-14 07:55:05', '2022-03-14 07:55:05', 0),
(399, 'Nebbiolo, Produttori del Barbaresco, Barbaresco, \'17', NULL, '2022-03-14-622ef5aab183a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 119.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 07:58:34', '2022-03-14 07:58:34', 0),
(400, 'Cannonau, Argiolas, \"Senes,\" Riserva, Sardinia, \'16', NULL, '2022-03-14-622ef6ea793f6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 08:03:54', '2022-03-14 08:03:54', 0),
(401, 'Cannonau, Sella e Mosca, Riserva, Sardinia, \'18', NULL, '2022-03-14-622ef7d141201.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 64.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 08:07:45', '2022-03-14 08:07:45', 0),
(402, 'Carignano, Agricola Punica, \"Barrua,\" Isola dei Nuraghi, Sardinia, \'14', NULL, '2022-03-14-622ef8400204a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 138.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 08:09:36', '2022-03-14 08:09:36', 0),
(403, 'Nerello Mascalese, Le Casematte, Faro, Sicily, \'13', NULL, '2022-03-14-622ef8ccb55c9.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 08:11:56', '2022-03-14 08:11:56', 0),
(404, 'Nero d\'Avola, COS, \"Contrada,\" Sicily, \'09', NULL, '2022-03-14-622ef962b94ae.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 188.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 08:14:26', '2022-03-14 08:14:26', 0),
(405, 'Nero d\'Avola, Donnafugata, \"Sedàra,\" Sicily, \'18', NULL, '2022-03-14-622efa354c9cb.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 55.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 08:17:57', '2022-03-14 08:17:57', 0),
(406, 'Nero d\'Avola, Feudi del Pisciotto, Sicily, \'19', NULL, '2022-03-14-622efa9ed3a0c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 08:19:42', '2022-03-14 08:19:42', 0),
(407, 'Nero d\'Avola, Feudo Maccari, \"Saia,\" Sicily, \'17', NULL, '2022-03-14-622efb1ce6802.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 98.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 08:21:48', '2022-03-14 08:21:48', 0),
(408, 'Nero d\'Avola, Tasca d\'Almerita, \"Lamùri,\" Sicilia, \'16', NULL, '2022-03-14-622efb8366871.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 08:23:31', '2022-03-14 08:23:31', 0),
(409, 'Nero d\'Avola, Valle dell\'Acate, \"Il Moro,\" Sicily, \'15', NULL, '2022-03-14-622efbfa14a9f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 62.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '23:00:00', 0, 1, 1674, '2022-03-14 08:25:30', '2022-03-14 08:25:30', 0),
(410, 'Red Blend, Jankara, \"Lu Nieddu,\" Colli del Limbara, Sardinia, \'18', NULL, '2022-03-14-622efc5c17649.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 109.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 08:27:08', '2022-03-14 08:27:08', 0),
(411, 'Amarone della Valpolicella, Allegrini, Classico, \'16', NULL, '2022-03-14-622fb66f6583e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 189.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 21:41:03', '2022-03-14 21:41:03', 0),
(412, 'Amarone della Valpolicella, Bertani, \'64', NULL, '2022-03-14-622fb74a3fa43.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 637.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 21:44:42', '2022-03-14 21:44:42', 0),
(413, 'Amarone della Valpolicella, Bertani, Classico, \'08', NULL, '2022-03-14-622fb8e054e0e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 289.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-14 21:51:28', '2022-03-14 21:51:28', 0),
(414, 'Amarone della Valpolicella, Masi, Classico, \"Costasera,\" \'15', NULL, '2022-03-15-62302ef19f408.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 152.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:15:13', '2022-03-15 06:15:13', 0),
(415, 'Amarone della Valpolicella, Romano dal Forno, \'06', NULL, '2022-03-15-62302f83cb46d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 799.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:17:39', '2022-03-15 06:17:39', 0),
(416, 'Amarone della Valpolicella, Romano dal Forno, \'12', NULL, '2022-03-15-62303023448d1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 599.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:20:19', '2022-03-15 06:20:19', 0),
(417, 'Amarone della Valpolicella, Tommasi, Classico, \'16', NULL, '2022-03-15-623030d51125c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 179.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:23:17', '2022-03-15 06:23:17', 0),
(418, 'Corvina, Allegrini, \"Palazzo della Torre,\" Veronese, \'16', NULL, '2022-03-15-62303158a8b23.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:25:28', '2022-03-15 06:25:28', 0),
(419, 'Merlot, Sansonina, Veronese, \'17', NULL, '2022-03-15-6230325c9aeae.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 85.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:29:48', '2022-03-15 06:29:48', 0),
(420, 'Ripasso, Bertani, Valpolicella, \'18', NULL, '2022-03-15-623032ed565e2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 66.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:32:13', '2022-03-15 06:32:13', 0),
(421, 'Ripasso, Speri, Valpolicella Superiore, \'17', NULL, '2022-03-15-623033addb261.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:35:25', '2022-03-15 06:35:25', 0),
(422, 'Valpolicella, Romano dal Forno, Superiore, \'13', NULL, '2022-03-15-623034556f007.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 275.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:38:13', '2022-03-15 06:38:13', 0),
(423, 'Amarone della Valpolicella, Bertani, \'68', NULL, '2022-03-15-6230356094385.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 637.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:42:40', '2022-03-15 06:42:40', 0),
(424, 'Amarone della Valpolicella, Bertani, Classico, \'12', NULL, '2022-03-15-623035e999848.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 269.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:44:57', '2022-03-15 06:44:57', 0),
(425, 'Amarone della Valpolicella, Remo Farina, Classico, \'17', NULL, '2022-03-15-6230365bb97cf.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 120.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:46:51', '2022-03-15 06:46:51', 0),
(426, 'Amarone della Valpolicella, Romano dal Forno, \'08', NULL, '2022-03-15-623037029ab3f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 689.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:49:38', '2022-03-15 06:49:38', 0),
(427, 'Amarone della Valpolicella, Speri, Classico, Monte Sant\'Urbano, \'17', NULL, '2022-03-15-623038091f730.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 199.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:54:01', '2022-03-15 06:54:01', 0),
(428, 'Amarone della Valpolicella, Zenato, Classico, \'16', NULL, '2022-03-15-623038c38fee9.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 168.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 06:57:07', '2022-03-15 06:57:07', 0),
(429, 'Corvina, Syrah, Allegrini, \"La Grola,\" Veronese, \'16', NULL, '2022-03-15-62303a0928ac9.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 07:02:33', '2022-03-15 07:02:33', 0),
(430, 'Ripasso, Acinum, Valpolicella, \'17', NULL, '2022-03-15-62303b07d604d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 07:06:47', '2022-03-15 07:06:47', 0),
(431, 'Ripasso, Masi \"Campofiorin,\" Veneto, \'17', NULL, '2022-03-15-623041ffa66fd.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 07:36:31', '2022-03-15 07:36:31', 0),
(432, 'Ripasso, Zenato, \"Ripassa,\" Valpolicella Superiore, \'17', NULL, '2022-03-15-62304422af0ab.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 76.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 07:45:38', '2022-03-15 07:45:38', 0),
(433, 'Valpolicella, Speri, Classico Superiore, Sant\' Urbano, \'17', NULL, '2022-03-15-623045730461f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 07:51:15', '2022-03-15 07:51:15', 0),
(434, 'Sangiovese, Antinori, \"Peppoli,\" Classico, \'18', NULL, '2022-03-15-6230460296772.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 07:53:38', '2022-03-15 07:53:38', 0),
(435, 'Sangiovese, Castello di Bossi, \"Berardo,\" Classico, Riserva, \'16', NULL, '2022-03-15-623046efe0881.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 84.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 07:57:35', '2022-03-15 07:57:35', 0),
(436, 'Sangiovese, Castello di Querceto, \"Il Picchio,\" Classico, Gran Selezione, \'17', NULL, '2022-03-15-62304777b5e6e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 149.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 07:59:51', '2022-03-15 07:59:51', 0),
(437, 'Sangiovese, Familia Zingarelli, Rocca delle Maciè, Classico, Riserva, \'17', NULL, '2022-03-15-6230482e2827c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 94.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 08:02:54', '2022-03-15 08:02:54', 0),
(438, 'Sangiovese, Fontodi, Classico, Riserva, \"Vigna del Sorbo,\" \'99', NULL, '2022-03-15-62304937e8569.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 248.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 08:07:19', '2022-03-15 08:07:19', 0),
(439, 'Sangiovese, Fontodi, Classico, Riserva, \"Vigna del Sorbo,\" \'13', NULL, '2022-03-15-62304acd6e51c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 249.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 08:14:05', '2022-03-15 08:14:05', 0),
(440, 'Sangiovese, Marchesi de Frescobaldi, \"Nipozzano,\" Riserva, Rufina, \'18', NULL, '2022-03-15-62304b6ae114d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 73.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 08:16:42', '2022-03-15 08:16:42', 0),
(441, 'Sangiovese, Nozzole, Classico, Riserva, \'17', NULL, '2022-03-15-62304c4f75871.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 08:20:31', '2022-03-15 08:20:31', 0),
(442, 'Sangiovese, Castello di Volpaia, Classico, Riserva, \'18', NULL, '2022-03-15-62304d2985e26.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 08:24:09', '2022-03-15 08:24:09', 0),
(443, 'Sangiovese, Fontodi, Classico, Riserva, \"Vigna del Sorbo,\" \'98', NULL, '2022-03-15-62304e30963cc.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 245.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 08:28:32', '2022-03-15 08:28:32', 0),
(444, 'Sangiovese, Fontodi, Classico, Riserva, \"Vigna del Sorbo,\" \'08', NULL, '2022-03-15-6230506531079.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 242.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 08:37:57', '2022-03-15 08:37:57', 0),
(446, 'Sangiovese, Lamole di Lamole, Classico Gran Selezione, \'16', NULL, '2022-03-15-623052b0cdfa6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 94.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 08:47:44', '2022-03-15 08:47:44', 0),
(447, 'Sangiovese, Mazzei, Fonterutoli, Classico, \'17', NULL, '2022-03-15-6230540fe81a4.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 87.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 08:53:35', '2022-03-15 08:53:35', 0),
(448, 'Cabernet, Alicante, Petit Verdot, Tenuta Sette Ponti, \"Poggio al Lupo,\" \'18', NULL, '2022-03-15-623059c94a7d6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 145.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 09:18:01', '2022-03-15 09:18:01', 0),
(449, 'Cabernet Franc, Le Macchiole, \"Paleo\" Rosso, \'17', NULL, '2022-03-15-62305b0c10c2d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 249.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 09:23:24', '2022-03-15 09:23:24', 0),
(450, 'Cabernet, Cabernet Franc, Grattamacco, Bolgheri Rosso \'19', NULL, '2022-03-15-62305ba10745e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 09:25:53', '2022-03-15 09:25:53', 0),
(451, 'Cabernet, Merlot, Tenuta San Guido, \"Guidalberto,\" \'19', NULL, '2022-03-15-62305c134cdd6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 120.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 09:27:47', '2022-03-15 09:27:47', 0),
(452, 'Cabernet, Merlot, Cabernet Franc, Tenuta dell\'Ornellaia, Bolgheri Superiore, \'16', NULL, '2022-03-15-62305cf9f09c1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 450.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 09:31:38', '2022-03-15 09:31:38', 0),
(453, 'Cabernet, Merlot, Sangiovese, Castello Banfi, \"Cum Laude,\" \'16', NULL, '2022-03-15-62305d93609ea.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 95.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 09:34:11', '2022-03-15 09:34:11', 0),
(454, 'Cabernet, Sangiovese, Cabernet Franc, Antinori, \"Solaia,\" \'11', NULL, '2022-03-15-62305e27073ac.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 553.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 09:36:39', '2022-03-15 09:36:39', 0),
(455, 'Malbec, Merlot, Cabernet, Tenuta Sette Cieli, \"Indaco,\" \'13', NULL, '2022-03-15-6230650ead0ab.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 135.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 10:06:06', '2022-03-15 10:06:06', 0),
(456, 'Merlot, Le Macchiole, \"Messorio,\" Bolgheri, \'17', NULL, '2022-03-15-623065adc36f4.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 550.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 10:08:45', '2022-03-15 10:08:45', 0),
(457, 'Merlot, Tua Rita, \"Redigaffi,\" \'11', NULL, '2022-03-15-6230663dc7bf9.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 732.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 10:11:09', '2022-03-15 10:11:09', 0),
(458, 'Merlot, Tua Rita, \"Redigaffi,\" \'13', NULL, '2022-03-15-623066fd6e45d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 732.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 10:14:21', '2022-03-15 10:14:21', 0),
(459, 'Merlot, Tua Rita, \"Redigaffi,\" \'15', NULL, '2022-03-15-623067a44e4ee.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 749.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 10:17:08', '2022-03-15 10:17:08', 0),
(460, 'Sangiovese, Cabernet, Cabernet Franc, Antinori, \"Tignanello,\" \'18', NULL, '2022-03-15-62306818886a4.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 259.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 10:19:04', '2022-03-15 10:19:04', 0),
(461, 'Sangiovese, Cabernet, Merlot, Syrah, Antinori, \"Villa Antinori,\" \'18', NULL, '2022-03-15-6230689c0879f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 10:21:16', '2022-03-15 10:21:16', 0),
(462, 'Sangiovese, Cabernet, Tenuta San Guido, \"Le Difese,\" \'19', NULL, '2022-03-15-623069216a25d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 10:23:29', '2022-03-15 10:23:29', 0),
(463, 'Sangiovese, Merlot, Cabernet, Tenuta dell\'Ornellaia, \"Le Volte,\" \'19', NULL, '2022-03-15-623069b3b59f0.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 84.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 10:25:55', '2022-03-15 10:25:55', 0),
(464, 'Sangiovese, Fèlsina, \"Fontalloro,\" \'90', NULL, '2022-03-15-62306e330b6bb.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 605.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 10:45:07', '2022-03-15 10:45:07', 0),
(465, 'Sangiovese, Fèlsina, \"Fontalloro,\" \'98', NULL, '2022-03-15-62306ff256fc4.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 305.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 10:52:34', '2022-03-15 10:52:34', 0),
(466, 'Sangiovese, Fèlsina, \"Fontalloro,\" \'00', NULL, '2022-03-15-62307445ef438.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 260.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 11:11:02', '2022-03-15 11:11:02', 0),
(467, 'Sangiovese, Fèlsina, \"Fontalloro,\" \'04', NULL, '2022-03-15-623074fa8ca92.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 224.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 11:14:02', '2022-03-15 11:14:02', 0),
(468, 'Sangiovese, Fontodi, \"Flaccianello della Pieve,\" \'00', NULL, '2022-03-15-623077ff41396.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 445.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 11:26:55', '2022-03-15 11:26:55', 0),
(469, 'Sangiovese, Fontodi, \"Flaccianello della Pieve,\" \'08', NULL, '2022-03-15-623078eee896e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 330.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 11:30:54', '2022-03-15 11:30:54', 0),
(470, 'Sangiovese, La Mozza, \"Aragone,\" Maremma, \'11', NULL, '2022-03-15-62307bee21c59.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 11:43:42', '2022-03-15 11:43:42', 0),
(471, 'Sangiovese, Merlot, Syrah, Rocca di Montemassi, \"Sassabruna,\" Maremma, \'17', NULL, '2022-03-15-62307d4b2c32b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 64.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-15 11:49:31', '2022-03-15 11:49:31', 0),
(472, 'Syrah, Merlot, Cabernet, Tenuta di Biserno, \"Insoglio del Cinghiale,\" \'19', NULL, '2022-03-15-6231501b45907.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 95.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 02:48:59', '2022-03-16 02:48:59', 0),
(473, 'Cabernet Franc, Le Macchiole, \"Paleo\" Rosso, \'12', NULL, '2022-03-15-6231517a69c2c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 199.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 02:54:50', '2022-03-16 02:54:50', 0),
(474, 'Cabernet Franc, Merlot, Tenuta di Biserno, \"Il Pino di Biserno,\" \'18', NULL, '2022-03-15-6231522b7b7ab.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 159.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 02:57:47', '2022-03-16 02:57:47', 0),
(475, 'Cabernet, Cabernet Franc, Tenuta San Guido, \"Sassicaia,\" Bolgheri Sassicaia, \'18', NULL, '2022-03-15-623152b34574f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 450.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:00:03', '2022-03-16 03:00:03', 0),
(476, 'Cabernet, Merlot, Cabernet Franc, Antinori, \"Guado al Tasso,\" Superiore, Bolgheri, \'16', NULL, '2022-03-15-62315347581c2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 299.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:02:31', '2022-03-16 03:02:31', 0),
(477, 'Cabernet, Merlot, Cabernet Franc, Tua Rita, \"Giusto di Notri,\" \'19', NULL, '2022-03-15-623153d4c1ca1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 209.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:04:52', '2022-03-16 03:04:52', 0),
(478, 'Cabernet, Sangiovese, Cabernet Franc, Antinori, \"Solaia,\" \'98', NULL, '2022-03-15-62315453ea192.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 716.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:06:59', '2022-03-16 03:06:59', 0),
(479, 'Cabernet, Sangiovese, Cabernet Franc, Antinori, \"Solaia,\" \'14', NULL, '2022-03-15-623154da15031.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 506.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:09:14', '2022-03-16 03:09:14', 0),
(480, 'Merlot, Cabernet, Castello Banfi, \"Excelsus,\" \'16', NULL, '2022-03-15-623156080c3b5.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 199.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:14:16', '2022-03-16 03:14:16', 0),
(481, 'Merlot, Tua Rita, \"Redigaffi,\" \'07', NULL, '2022-03-15-62315692611a1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 732.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:16:34', '2022-03-16 03:16:34', 0),
(482, 'Merlot, Tua Rita, \"Redigaffi,\" \'12', NULL, '2022-03-15-623157f98cf1d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 732.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:22:33', '2022-03-16 03:22:33', 0),
(483, 'Merlot, Tua Rita, \"Redigaffi,\" \'14', NULL, '2022-03-15-623158dc0e168.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 732.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:26:20', '2022-03-16 03:26:20', 0),
(484, 'Merlot, Tua Rita, \"Redigaffi,\" \'16', NULL, '2022-03-15-6231598f8f339.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 599.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:29:19', '2022-03-16 03:29:19', 0),
(485, 'Sangiovese, Cabernet, Merlot, Ruffino, \"Modus,\" \'17', NULL, '2022-03-15-62315a267bb99.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:31:50', '2022-03-16 03:31:50', 0),
(486, 'Sangiovese, Cabernet, Merlot, Tenuta Sette Ponti, \"Oreno,\" \'17', NULL, '2022-03-15-62315aa3761d5.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 212.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:33:55', '2022-03-16 03:33:55', 0),
(487, 'Sangiovese, Merlot, Cabernet, Fattoria Carpineta Fontalpino, \"Do ut Des,\" \'00', NULL, '2022-03-15-62315c4d0aee6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 194.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:41:01', '2022-03-16 03:41:01', 0),
(488, 'Sangiovese, Castello Banfi, \"Bel Nero,\" \'16', NULL, '2022-03-15-62315d0e04634.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:44:14', '2022-03-16 03:44:14', 0),
(489, 'Sangiovese, Fèlsina, \"Fontalloro,\" \'93', NULL, '2022-03-15-62315d993145b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 515.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:46:33', '2022-03-16 03:46:33', 0),
(490, 'Sangiovese, Fèlsina, \"Fontalloro,\" \'99', NULL, '2022-03-15-62315f9ecfa46.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 278.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:55:10', '2022-03-16 03:55:10', 0),
(491, 'Sangiovese, Fèlsina, \"Fontalloro,\" \'03', NULL, '2022-03-15-623160294dd3b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 360.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:57:29', '2022-03-16 03:57:29', 0),
(492, 'Sangiovese, Fontodi, \"Flaccianello della Pieve,\" \'95', NULL, '2022-03-15-623160b59bf65.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 399.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 03:59:49', '2022-03-16 03:59:49', 0),
(493, 'Sangiovese, Fontodi, \"Flaccianello della Pieve,\" \'05', NULL, '2022-03-16-6231614a278c1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 401.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 04:02:18', '2022-03-16 04:02:18', 0),
(494, 'Sangiovese, Fontodi, \"Flaccianello della Pieve,\" \'10', NULL, '2022-03-16-623163344a254.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 399.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 04:10:28', '2022-03-16 04:10:28', 0),
(495, 'Sangiovese, Merlot, Fonterutoli, \"Siepi,\" \'03', NULL, '2022-03-16-623163b1e951b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 261.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 04:12:33', '2022-03-16 04:12:33', 0),
(496, 'Sangiovese, Syrah, Merlot, Ruffino, \"Il Ducale,\" \'16', NULL, '2022-03-16-623164735e3ba.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 04:15:47', '2022-03-16 04:15:47', 0),
(497, 'Sangiovese, Altesino, \"Montosoli,\" Brunello, \'16', NULL, '2022-03-16-6231912316654.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 299.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:26:27', '2022-03-16 07:26:27', 0),
(498, 'Sangiovese, Altesino, Rosso di Montalcino, \'18', NULL, '2022-03-16-623192066fc76.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:30:14', '2022-03-16 07:30:14', 0),
(499, 'Sangiovese, Argiano, Brunello, \'16', NULL, '2022-03-16-6231927f311c1.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 160.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:32:15', '2022-03-16 07:32:15', 0),
(500, 'Sangiovese, Biondi-Santi, Tenuta Greppo, Brunello, \'12', NULL, '2022-03-16-623192f8be8d8.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 399.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:34:16', '2022-03-16 07:34:16', 0),
(501, 'Sangiovese, Biondi-Santi, Tenuta Greppo, Brunello, Riserva, \'97', NULL, '2022-03-16-623193ace2d98.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 1299.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:37:16', '2022-03-16 07:37:16', 0),
(502, 'Sanviovese, Camigliano, Brunello, \'16', NULL, '2022-03-16-6231947a98c0d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 135.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:40:42', '2022-03-16 07:40:42', 0),
(503, 'Sangiovese, Canalicchio di Sopra, Brunello, \'05', NULL, '2022-03-16-62319544827db.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 191.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:44:04', '2022-03-16 07:44:04', 0),
(504, 'Sangiovese, Castello di Banfi, Brunello, \'15', NULL, '2022-03-16-623195f92fbe5.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 175.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:47:05', '2022-03-16 07:47:05', 0),
(505, 'Sangiovese, Castello di Banfi, \"Poggio alle Mura,\" Brunello, Riserva, \'09', NULL, '2022-03-16-6231969ef36e7.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 275.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:49:51', '2022-03-16 07:49:51', 0),
(506, 'Sangiovese, Castello di Banfi, Rosso di Montalcino, \'19', NULL, '2022-03-16-623197706d1fe.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:53:20', '2022-03-16 07:53:20', 0),
(507, 'Sangiovese, Gaja, Pieve Santa Restituta, Brunello, \'16', NULL, '2022-03-16-623198004ba07.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 199.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:55:44', '2022-03-16 07:55:44', 0),
(508, 'Sangiovese, Il Marroneto, \"Madonna delle Grazie,\" Brunello, \'12', NULL, '2022-03-16-6231987ada2bf.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 399.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:57:46', '2022-03-16 07:57:46', 0),
(509, 'Sangiovese, Podere le Ripi, \"Amore e Magia,\" Brunello, \'15', NULL, '2022-03-16-623198f8f2338.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 299.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 07:59:53', '2022-03-16 07:59:53', 0),
(510, 'Sangiovese, Poggio Antico, Brunello, Riserva, \'06', NULL, '2022-03-16-62319ca526262.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 333.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 08:15:33', '2022-03-16 08:15:33', 0),
(511, 'Sangiovese, Poggio di Sotto, Brunello, \'07', NULL, '2022-03-16-62319d61ef574.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 495.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 08:18:41', '2022-03-16 08:18:41', 0),
(512, 'Sangiovese, Poggio di Sotto, Brunello, \'08', NULL, '2022-03-16-62319de7e4706.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 402.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 08:20:55', '2022-03-16 08:20:55', 0);
INSERT INTO `food` (`id`, `name`, `description`, `image`, `category_id`, `category_ids`, `variations`, `add_ons`, `attributes`, `choice_options`, `price`, `tax`, `tax_type`, `discount`, `discount_type`, `available_time_starts`, `available_time_ends`, `set_menu`, `status`, `restaurant_id`, `created_at`, `updated_at`, `order_count`) VALUES
(513, 'Sangiovese, Poggio di Sotto, Brunello, \'09', NULL, '2022-03-16-62319e8dd276b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 495.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 08:23:41', '2022-03-16 08:23:41', 0),
(514, 'Sangiovese, Salicutti, Rosso di Montalcino \'17', NULL, '2022-03-16-62319f0b06bff.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 119.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 08:25:47', '2022-03-16 08:25:47', 0),
(515, 'Sangiovese, Salvioni, Brunello, \'09', NULL, '2022-03-16-62319fcaebe6c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 499.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 08:28:59', '2022-03-16 08:28:59', 0),
(516, 'Sangiovese, Tenuta Friggiali, \"Donna Olga,\" Brunello, \'97', NULL, '2022-03-16-6231a05b053b8.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 375.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 08:31:23', '2022-03-16 08:31:23', 0),
(517, 'Sangiovese, Tenuta Friggiali, \"Donna Olga,\" Brunello, \'99', NULL, '2022-03-16-6231a1c119c9d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 375.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 08:37:21', '2022-03-16 08:37:21', 0),
(518, 'Sangiovese, Tenuta Friggiali, \"Donna Olga,\" Brunello, \'01', NULL, '2022-03-16-6231a32528b72.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 329.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 08:43:17', '2022-03-16 08:43:17', 0),
(519, 'Sanviovese, Tenuta San Giorgio, \"Ugolforte,\" Brunello, \'15', NULL, '2022-03-16-6231a39e95d02.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 149.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 08:45:18', '2022-03-16 08:45:18', 0),
(520, 'Sangiovese, Tenute Silvio Nardi, Brunello, \'16', NULL, '2022-03-16-6231a4e4a0def.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 165.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 08:50:44', '2022-03-16 08:50:44', 0),
(521, 'Sangiovese, Uccelliera, Brunello, \'15', NULL, '2022-03-16-62324e2f9feb2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 359.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 14, '2022-03-16 20:53:03', '2022-03-16 20:53:03', 0),
(522, 'Sangiovese, Valdicava, Brunello, \'05', NULL, '2022-03-16-62324edeeeda2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 282.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 20:55:59', '2022-03-16 20:55:59', 0),
(523, 'Sangiovese, Valdicava, Riserva, \"Madonna del Piano,\" Brunello, \'96', NULL, '2022-03-16-62324f66e2bee.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 330.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 20:58:14', '2022-03-16 20:58:14', 0),
(524, 'Sangiovese, Valdicava, Riserva, \"Madonna del Piano,\" Brunello, \'98', NULL, '2022-03-16-62325019c06cc.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 352.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 21:01:13', '2022-03-16 21:01:13', 0),
(525, 'Sangiovese, Valdicava, Riserva, \"Madonna del Piano,\" Brunello, \'03', NULL, '2022-03-16-6232534e79a3a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 513.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 21:14:54', '2022-03-16 21:14:54', 0),
(528, 'Sangiovese, Valdicava, Riserva, \"Madonna del Piano,\" Brunello, \'05', NULL, '2022-03-16-623255278381e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 498.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 21:22:47', '2022-03-16 21:22:47', 0),
(529, 'Sangiovese, Valdicava, Riserva, \"Madonna del Piano,\" Brunello, \'06', NULL, '2022-03-16-62325587a9c00.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 572.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 21:24:23', '2022-03-16 21:24:23', 0),
(530, 'Sangiovese, Sagrantino, Arnaldo Caprai, Montefalco Rosso, \'17', NULL, '2022-03-16-62325997460ed.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 21:41:43', '2022-03-16 21:41:43', 0),
(531, 'Sangiovese, Sagrantino, Arnaldo Caprai, Montefalco Rosso Riserva, \'15', NULL, '2022-03-16-62325b7a1ad8c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 109.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 21:49:46', '2022-03-16 21:49:46', 0),
(532, 'Sangiovese, Sagrantino, Bocale, Montefalco Rosso, \'14', NULL, '2022-03-16-62325e3a41e24.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 92.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 22:01:30', '2022-03-16 22:01:30', 0),
(533, 'Sangiovese, Cabernet, Merlot, Salviano, \"Turlo,\" Lago di Corbana, \'16', NULL, '2022-03-16-62325ee27381e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-16 22:04:18', '2022-03-16 22:04:18', 0),
(534, 'Cabernet Franc, Keenan, Spring Mountain District, Napa, CA, \'17', NULL, '2022-03-17-6232cf4cd875b.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 169.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 06:03:56', '2022-03-17 06:03:56', 0),
(535, 'Cabernet Sauvignon, Avalon, Napa, CA, \'18', NULL, '2022-03-17-6232cfef8ac0d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 06:06:39', '2022-03-17 06:06:39', 0),
(536, 'Cabernet Sauvignon, B.R. Cohn, \"Silver Label,\" North Coast, CA, \'19', NULL, '2022-03-17-6232d2bbed7b5.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 65.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 06:18:35', '2022-03-17 06:19:00', 0),
(537, 'Cabernet Sauvignon, Chateau Montelena, Napa Valley, CA, \'18', NULL, '2022-03-17-6232d35eb06dd.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 159.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 06:21:18', '2022-03-17 06:21:18', 0),
(538, 'Cabernet Sauvignon, Fisher, \"Unity,\" Napa Valley/Sonoma Valley, \'18', NULL, '2022-03-17-6232d49b9b304.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 109.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 06:26:35', '2022-03-17 06:26:35', 0),
(539, 'Cabernet Sauvignon, Flora Springs, Napa Valley, CA, \'16', NULL, '2022-03-17-6232d5ba2c9bd.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 92.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 06:31:22', '2022-03-17 06:31:22', 0),
(540, 'Cabernet Sauvignon, Frog\'s Leap, Rutherford, Napa Valley, CA, \'18', NULL, '2022-03-17-6232dc8620a55.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 129.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:00:22', '2022-03-17 07:00:22', 0),
(541, 'Cabernet Sauvignon, Gargiulo Vineyards, \"Money Road Ranch,\" Oakville, \'15', NULL, '2022-03-17-6232de689277e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 225.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:08:24', '2022-03-17 07:08:24', 0),
(542, 'Cabernet Sauvignon, Groth, Napa Valley, CA, \'87', NULL, '2022-03-17-6232df86022ed.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 360.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:13:10', '2022-03-17 07:13:10', 0),
(543, 'Cabernet Sauvignon, Groth, Oakville, Napa Valley, CA, \'06', NULL, '2022-03-17-6232dff66e5b7.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 225.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:15:02', '2022-03-17 07:15:02', 0),
(544, 'Cabernet Sauvignon, Harlan Estate, Napa Valley, CA, \'12', NULL, '2022-03-17-6232e1d8d0efc.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 1600.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:23:04', '2022-03-17 07:23:04', 0),
(545, 'Cabernet Sauvignon, Harlan Estate, Napa Valley, CA, \'14', NULL, '2022-03-17-6232e290951ad.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 2300.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:26:08', '2022-03-17 07:26:08', 0),
(546, 'Cabernet Sauvignon, Harlan Estate, Napa Valley, CA, \'15', NULL, '2022-03-17-6232e308efe53.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 2500.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:28:09', '2022-03-17 07:28:09', 0),
(547, 'Cabernet Sauvignon, Harlan Estate, Napa Valley, CA, \'16', NULL, '2022-03-17-6232e3895fefc.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 2700.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:30:17', '2022-03-17 07:30:17', 0),
(548, 'Cabernet Sauvignon, Harlan Estate, Napa Valley, CA, \'17', NULL, '2022-03-17-6232e6379e242.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 2800.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:41:43', '2022-03-17 07:41:43', 0),
(549, 'Cabernet Sauvignon, Hess, \"Allomi Vineyard,\" Napa Valley, CA, \'18', NULL, '2022-03-17-6232e757cc601.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 89.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:46:31', '2022-03-17 07:46:31', 0),
(550, 'Cabernet Sauvignon, Honig, Napa Valley, CA, \'18', NULL, '2022-03-17-6232e811f226e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 107.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:49:38', '2022-03-17 07:49:38', 0),
(551, 'Cabernet Sauvignon, Justin, Paso Robles, CA, \'18', NULL, '2022-03-17-6232e8c91accc.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 80.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 07:52:41', '2022-03-17 07:52:41', 0),
(552, 'Cabernet Sauvignon, Penfolds, \"Bin 704,\" Napa Valley, CA, \'18', NULL, '2022-03-17-6232ef174a66f.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 149.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 08:19:35', '2022-03-17 08:19:35', 0),
(553, 'Cabernet Sauvignon, Pine Ridge, Napa Valley, CA, \'17', NULL, '2022-03-17-6232f1835de3e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 119.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 08:29:55', '2022-03-17 08:29:55', 0),
(554, 'Cabernet Sauvignon, Sequoia Grove, Rutherford, Napa, CA, \'18', NULL, '2022-03-17-6232f27453589.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 115.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 08:33:56', '2022-03-17 08:33:56', 0),
(555, 'Cabernet Sauvignon, Shafer, \"One Point Five,\" Stags Leap, Napa, CA, \'18', NULL, '2022-03-17-6232fadc4aaab.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 199.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 09:09:48', '2022-03-17 09:09:48', 0),
(556, 'Cabernet Sauvignon, Shafer, \"Hillside Select,\" Stags Leap, Napa, CA, \'17', NULL, '2022-03-17-6232fbe6640e2.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 554.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 09:14:14', '2022-03-17 09:14:14', 0),
(557, 'Cabernet Sauvignon, Silverado, Napa Valley, CA, \'17', NULL, '2022-03-17-6232fc8d970a8.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 139.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 09:17:01', '2022-03-17 09:17:01', 0),
(558, 'Cabernet Sauvignon, Silverado, \"Solo,\" Stags Leap Dist., Napa Valley, CA, \'16', NULL, '2022-03-17-6232fd7469753.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 229.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 09:20:52', '2022-03-17 09:20:52', 0),
(559, 'Cabernet Sauvignon, Silver Oak, Alexander Valley, CA, \'17', NULL, '2022-03-17-623303c44a64d.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 189.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 09:47:48', '2022-03-17 09:47:48', 0),
(560, 'Cabernet Sauvignon, Silver Oak, Napa Valley, CA, \'17', NULL, '2022-03-17-6233074ecdb57.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 259.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 10:02:54', '2022-03-17 10:02:54', 0),
(561, 'Cabernet Sauvignon, Staglin Family Vineyard, Rutherford, CA, \'15', NULL, '2022-03-17-6233080a84046.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 439.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 10:06:02', '2022-03-17 10:06:02', 0),
(562, 'Cabernet Sauvignon, St. Supéry, Napa Valley, CA, \'18', NULL, '2022-03-17-62330f6830c16.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 10:37:28', '2022-03-17 10:37:28', 0),
(563, 'Cabernet Sauvignon, Tom Eddy, \"Elodian,\" Knight\'s Valley, Sonoma, CA, \'15', NULL, '2022-03-17-6233102369b4a.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 119.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 10:40:35', '2022-03-17 10:40:35', 0),
(564, 'Cabernet Sauvignon, Utopium, Sonoma Valley, CA, \'10', NULL, '2022-03-17-623310c27b4fb.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 112.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 10:43:14', '2022-03-17 10:43:14', 0),
(565, 'Cabernet Sauvignon, Utopium, Sonoma Valley, CA, \'11', NULL, '2022-03-17-6233130b5b174.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 112.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 10:52:59', '2022-03-17 10:52:59', 0),
(566, 'Cabernet Sauvignon, Venge, \"Silencieux,\" Oakville, CA, \'19', NULL, '2022-03-17-62331387639ad.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 199.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 10:55:03', '2022-03-17 10:55:03', 0),
(567, 'Cabernet Sauvignon, ZD Wines, Napa Valley, CA, \'10', NULL, '2022-03-17-6233141e1dc72.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 219.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 10:57:34', '2022-03-17 10:57:34', 0),
(568, 'Merlot, Duckhorn, Napa Valley, CA, \'17', NULL, '2022-03-17-6233152948fc8.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 159.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 11:02:01', '2022-03-17 11:02:01', 0),
(569, 'Merlot, Frog\'s Leap, Rutherford, Napa Valley, CA, \'18', NULL, '2022-03-17-623315e821d34.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 99.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 11:05:12', '2022-03-17 11:05:12', 0),
(570, 'Merlot, Markham, Napa Valley, CA, \'18', NULL, '2022-03-17-623325726bd22.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 69.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 12:11:30', '2022-03-17 12:11:30', 0),
(571, 'Merlot, Robert Hall, Paso Robles, CA, \'17', NULL, '2022-03-17-623326006f431.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 12:13:52', '2022-03-17 12:13:52', 0),
(572, 'Merlot, Silverado, \"Mt. George,\" Napa, \'16', NULL, '2022-03-17-623326a1808a6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 105.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 12:16:33', '2022-03-17 12:16:33', 0),
(573, 'Merlot, Swanson Vineyards, Napa, \'18', NULL, '2022-03-17-6233289bd2dd6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 12:24:59', '2022-03-17 12:24:59', 0),
(574, 'Merlot, Twomey, Napa, \'15', NULL, '2022-03-17-6233298b84009.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 149.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 12:28:59', '2022-03-17 12:28:59', 0),
(575, 'Petite Sirah, Three Wine Company, Contra Costa County, CA, \'17', NULL, '2022-03-17-62332b20e5341.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 12:35:44', '2022-03-17 12:35:44', 0),
(576, 'Pinot Noir, A to Z Wine Works, OR, \'17', NULL, '2022-03-17-62332c37936b9.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 49.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 12:40:23', '2022-03-17 12:40:23', 0),
(577, 'Pinot Noir, Bethel Heights, Eola-Amity Hills, Willamette Valley, OR, \'18', NULL, '2022-03-17-623335b049732.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 78.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 13:20:48', '2022-03-17 13:20:48', 0),
(578, 'Pinot Noir, Bien Nacido, \"The Captain,\" Santa Maria Valley, CA, \'14 / \'15', NULL, '2022-03-17-623337439ade8.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 219.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 13:27:31', '2022-03-17 13:27:31', 0),
(579, 'Pinot Noir, Calera, \"Jensen Vineyard,\" Mt. Harlan, CA, \'13', NULL, '2022-03-17-62333c3d9b83e.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 199.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 13:48:45', '2022-03-17 13:48:45', 0),
(580, 'Pinot Noir, Cambria, Julia\'s Vineyard, Sta. Maria Valley, CA, \'19', NULL, '2022-03-17-62333cc6cf0bc.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 80.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 13:51:02', '2022-03-17 13:51:02', 0),
(581, 'Pinot Noir, Cattleya, \"Cuvee Number One,\" Russian River Valley, CA, \'17', NULL, '2022-03-17-62333d560fa13.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 125.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 13:53:26', '2022-03-17 13:53:26', 0),
(582, 'Pinot Noir, Chehalem, \"Chehalem Mountains,\" Willamette Valley, OR, \'19', NULL, '2022-03-17-62333e20bd250.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 79.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 13:56:48', '2022-03-17 13:56:48', 0),
(583, 'Pinot Noir, Croix Estate, Bacigalupi Vineyard, Russian River Valley, CA, \'16', NULL, '2022-03-17-62333ecd638be.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 149.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 13:59:41', '2022-03-17 13:59:41', 0),
(584, 'Pinot Noir, Domaine Serene, \"Evenstad Reserve,\" Willamette Valley, OR, \'17', NULL, '2022-03-17-62333f5e76786.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 182.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 14:02:06', '2022-03-17 14:02:06', 0),
(585, 'Pinot Noir, Domaine Serene, \"Grace,\" Dundee Hills, OR, \'16', NULL, '2022-03-17-6233401306327.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 499.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 14:05:07', '2022-03-17 14:05:07', 0),
(586, 'Pinot Noir, Domaine Serene, \"Mark Bradford,\" Dundee Hills, OR, \'16', NULL, '2022-03-17-62334154ebff4.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 399.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 14:10:28', '2022-03-17 14:10:28', 0),
(587, 'Pinot Noir, Domaine Serene, \"Monogram,\" Willamette Valley, OR, \'14', NULL, '2022-03-17-623341ee30b99.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 620.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 14:13:02', '2022-03-17 14:13:02', 0),
(588, 'Pinot Noir, Domaine Serene, \"Yamhill Cuvée,\" Willamette Valley, OR, \'17', NULL, '2022-03-17-6233427404d98.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 139.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 14:15:16', '2022-03-17 14:15:16', 0),
(589, 'Pinot Noir, Donelan, \"Two Brothers,\" Sonoma County, \'13', NULL, '2022-03-17-623342e331da6.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 169.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 14:17:07', '2022-03-17 14:17:07', 0),
(590, 'Pinot Noir, Estancia, Monterey County, CA, \'18', NULL, '2022-03-17-6233435014a6c.png', 1350, '[{\"id\":\"1350\",\"position\":1}]', '[]', '[]', '[]', '[]', 59.00, 0.00, 'percent', 0.00, 'percent', '10:00:00', '22:00:00', 0, 1, 1674, '2022-03-17 14:18:56', '2022-03-17 14:18:56', 0);

-- --------------------------------------------------------

--
-- Table structure for table `item_campaigns`
--

CREATE TABLE `item_campaigns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `admin_id` bigint(20) UNSIGNED NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `category_ids` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `add_ons` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attributes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `choice_options` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(8,2) NOT NULL DEFAULT 0.00,
  `tax_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percent',
  `discount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `discount_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percent',
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mail_configs`
--

CREATE TABLE `mail_configs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `host` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `driver` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encryption` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_05_05_081114_create_admins_table', 1),
(5, '2021_05_05_102600_create_attributes_table', 1),
(6, '2021_05_05_102742_create_categories_table', 1),
(7, '2021_05_06_102004_create_vendors_table', 1),
(8, '2021_05_06_153204_create_restaurants_table', 1),
(9, '2021_05_08_113436_create_add_ons_table', 2),
(47, '2021_05_08_123446_create_food_table', 10),
(48, '2021_05_08_141209_create_currencies_table', 10),
(49, '2021_05_09_050232_create_orders_table', 10),
(50, '2021_05_09_051907_create_reviews_table', 10),
(51, '2021_05_09_054237_create_order_details_table', 10),
(52, '2021_05_10_105324_create_mail_configs_table', 10),
(53, '2021_05_10_152713_create_business_settings_table', 10),
(54, '2021_05_11_111722_create_banners_table', 11),
(55, '2021_05_11_134442_create_coupons_table', 11),
(56, '2021_05_12_053344_create_conversations_table', 11),
(57, '2021_05_12_055454_create_delivery_men_table', 12),
(58, '2021_05_12_060138_create_d_m_reviews_table', 12),
(59, '2021_05_12_060527_create_track_deliverymen_table', 12),
(60, '2021_05_12_061345_create_email_verifications_table', 12),
(61, '2021_05_12_061454_create_delivery_histories_table', 12),
(62, '2021_05_12_061718_create_wishlists_table', 12),
(63, '2021_05_12_061924_create_notifications_table', 12),
(64, '2021_05_12_062152_create_customer_addresses_table', 12),
(68, '2021_05_12_062412_create_order_delivery_histories_table', 13),
(69, '2021_05_19_115112_create_zones_table', 13),
(70, '2021_05_19_120612_create_restaurant_zone_table', 13),
(71, '2021_06_07_103835_add_column_to_vendor_table', 14),
(73, '2021_06_07_112335_add_column_to_vendors_table', 15),
(74, '2021_06_08_162354_add_column_to_restaurants_table', 16),
(77, '2021_06_09_115719_add_column_to_add_ons_table', 17),
(78, '2021_06_10_091547_add_column_to_coupons_table', 18),
(79, '2021_06_12_070530_rename_banners_table', 19),
(80, '2021_06_12_091154_add_column_on_campaigns_table', 20),
(87, '2021_06_12_091848_create_item_campaigns_table', 21),
(92, '2021_06_13_155531_create_campaign_restaurant_table', 22),
(93, '2021_06_14_090520_add_item_campaign_id_column_to_reviews_table', 23),
(94, '2021_06_14_091735_add_item_campaign_id_column_to_order_details_table', 24),
(95, '2021_06_14_120713_create_new_banners_table', 25),
(96, '2021_06_15_103656_add_zone_id_column_to_banners_table', 26),
(97, '2021_06_16_110322_create_discounts_table', 27),
(100, '2021_06_17_150243_create_withdraw_requests_table', 28),
(103, '2016_06_01_000001_create_oauth_auth_codes_table', 30),
(104, '2016_06_01_000002_create_oauth_access_tokens_table', 30),
(105, '2016_06_01_000003_create_oauth_refresh_tokens_table', 30),
(106, '2016_06_01_000004_create_oauth_clients_table', 30),
(107, '2016_06_01_000005_create_oauth_personal_access_clients_table', 30),
(108, '2021_06_21_051135_add_delivery_charge_to_orders_table', 31),
(110, '2021_06_23_080009_add_role_id_to_admins_table', 32),
(111, '2021_06_27_140224_add_interest_column_to_users_table', 33),
(113, '2021_06_27_142558_change_column_to_restaurants_table', 34),
(114, '2021_06_27_152139_add_restaurant_id_column_to_wishlists_table', 35),
(115, '2021_06_28_142443_add_restaurant_id_column_to_customer_addresses_table', 36),
(118, '2021_06_29_134119_add_schedule_column_to_orders_table', 37),
(122, '2021_06_30_084854_add_cm_firebase_token_column_to_users_table', 38),
(123, '2021_06_30_133932_add_code_column_to_coupons_table', 39),
(127, '2021_07_01_151103_change_column_food_id_from_admin_wallet_histories_table', 40),
(129, '2021_07_04_142159_add_callback_column_to_orders_table', 41),
(131, '2021_07_05_155506_add_cm_firebase_token_to_vendors_table', 42),
(133, '2021_07_05_162404_add_otp_to_orders_table', 43),
(134, '2021_07_13_133941_create_admin_roles_table', 44),
(135, '2021_07_14_074431_add_status_to_delivery_men_table', 45),
(136, '2021_07_14_104102_create_vendor_employees_table', 46),
(137, '2021_07_14_110011_create_employee_roles_table', 46),
(138, '2021_07_15_124141_add_cover_photo_to_restaurants_table', 47),
(143, '2021_06_17_145949_create_wallets_table', 48),
(144, '2021_06_19_052600_create_admin_wallets_table', 48),
(145, '2021_07_19_103748_create_delivery_man_wallets_table', 48),
(146, '2021_07_19_105442_create_account_transactions_table', 48),
(147, '2021_07_19_110152_create_order_transactions_table', 48),
(148, '2021_07_19_134356_add_column_to_notifications_table', 49),
(149, '2021_07_25_125316_add_available_to_delivery_men_table', 50),
(150, '2021_07_25_154722_add_columns_to_restaurants_table', 51),
(151, '2021_07_29_162336_add_schedule_order_column_to_restaurants_table', 52),
(152, '2021_07_31_140756_create_phone_verifications_table', 53),
(153, '2021_08_01_151717_add_column_to_order_transactions_table', 54),
(154, '2021_08_01_163520_add_column_to_admin_wallets_table', 54),
(155, '2021_08_02_141909_change_time_column_to_restaurants_table', 55),
(157, '2021_08_02_183356_add_tax_column_to_restaurants_table', 56),
(158, '2021_08_04_215618_add_zone_id_column_to_restaurants_table', 57),
(159, '2021_08_06_123001_add_address_column_to_orders_table', 58),
(160, '2021_08_06_123326_add_zone_wise_topic_column_to_zones_table', 58),
(161, '2021_08_08_112127_add_scheduled_column_on_orders_table', 59),
(162, '2021_08_08_203108_add_status_column_to_users_table', 60),
(163, '2021_08_11_193805_add_product_discount_ammount_column_to_orders_table', 61),
(165, '2021_08_12_112511_add_addons_column_to_order_details_table', 62),
(166, '2021_08_12_195346_add_zone_id_to_notifications_table', 63),
(167, '2021_08_14_110131_create_user_notifications_table', 64),
(168, '2021_08_14_175657_add_order_count_column_to_foods_table', 65),
(169, '2021_08_14_180044_add_order_count_column_to_users_table', 65),
(170, '2021_08_19_051055_add_earnign_column_to_deliverymen_table', 66),
(171, '2021_08_19_051721_add_original_delivery_charge_column_to_orders_table', 66),
(172, '2021_08_19_055839_create_provide_d_m_earnings_table', 67),
(173, '2021_08_19_112810_add_original_delivery_charge_column_to_order_transactions_table', 67),
(174, '2021_08_19_114851_add_columns_to_delivery_man_wallets_table', 67),
(175, '2021_08_21_162616_change_comission_column_to_restaurants_table', 68),
(176, '2021_06_17_054551_create_soft_credentials_table', 69),
(177, '2021_08_22_232507_add_failed_column_to_orders_table', 69),
(178, '2021_09_04_172723_add_column_reviews_section_to_restaurants_table', 69),
(179, '2021_09_11_164936_change_delivery_address_column_to_orders_table', 70),
(180, '2021_09_11_165426_change_address_column_to_customer_addresses_table', 70),
(181, '2021_09_23_120332_change_available_column_to_delivery_men_table', 71),
(182, '2021_10_03_214536_add_active_column_to_restaurants_table', 72),
(183, '2021_10_04_123739_add_priority_column_to_categories_table', 72),
(184, '2021_10_06_200730_add_restaurant_id_column_to_demiverymen_table', 72),
(185, '2021_10_07_223332_add_self_delivery_column_to_restaurants_table', 72),
(186, '2021_10_11_214123_change_add_ons_column_to_order_details_table', 72),
(187, '2021_10_11_215352_add_adjustment_column_to_orders_table', 72),
(188, '2021_11_16_024605_add_google_form_url_restaurant_table', 73),
(189, '2022_01_07_174048_create_restaurant_reviews_table', 74);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tergat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zone_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('02c187400441f53687a30af580361503d21ab9e30fc263f729536e3e6fb8e013c5f10f170df66154', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-08-14 07:26:44', '2021-08-14 07:26:44', '2022-08-14 13:26:44'),
('034abb48ee5a61353d9576e935257f03770417868908913940490bf993e1d8d5472793d9f8ab4818', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-29 20:16:27', '2021-12-29 20:16:27', '2022-12-29 15:16:27'),
('03652f98734cb46633be656afd61eb9d6bef93da6cb3f97e5d862e758bc8a7458f4271c9fc525a03', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-07-04 04:56:56', '2021-07-04 04:56:56', '2022-07-04 10:56:56'),
('0766ac250c83324a7564971933bfe0bd2442b65c2ed191d40424949fe1ff8c500304cd17e4e59579', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:46:48', '2022-01-01 07:46:48', '2023-01-01 02:46:48'),
('0ce77d214106aa7d2691f22e57a52d61e83c4a74e232b6cf6409728c337a731412d5f011c265abf9', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-08-08 14:51:24', '2021-08-08 14:51:24', '2022-08-08 20:51:24'),
('10fa2f3a2d9ef162205232c2db4e5e992196544ccd26f806c9a52dc31557e5e63639b2c94c0c7f76', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-04 17:28:43', '2021-12-04 17:28:43', '2022-12-04 11:28:43'),
('14306aca042afd852e8909e799c9a403ff845ab9b05a50ada245b2f5721cfdae47db785e6a0101ca', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-29 20:57:48', '2021-12-29 20:57:48', '2022-12-29 15:57:48'),
('1601cf6f7b598d2f6d2c2d0790fa6b081e4de2f1ec33080accd1656e161639e7e4d301bada007f1d', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:51:20', '2022-01-01 15:51:20', '2023-01-01 10:51:20'),
('1796645666d7dd6ef53186e095fb9c39d2128e5cca19f2e1ac8e7e7da82d6174fe98b14e94925188', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-08-04 07:35:29', '2021-08-04 07:35:29', '2022-08-04 13:35:29'),
('1b6da857ad4abeba8d37c7e81455c8b74798a9a009d0e340ac0f9eca93f73817b201725d2d1a725b', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:26:51', '2022-01-01 15:26:51', '2023-01-01 10:26:51'),
('1e4028660c0e9b88fecc0cd91e71e5c703a449407f9f0a8fc242ad467bcc1198ada2cca68690c568', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-29 21:06:41', '2021-12-29 21:06:41', '2022-12-29 16:06:41'),
('242e685c43e66933886a48d83d5ed46b393058ef8b81fb0dbc2844198cfdc1d8face836351833968', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:22:01', '2022-01-01 07:22:01', '2023-01-01 02:22:01'),
('255d7c4d1a080437739f9b1b11207da94bf43078ee697f7b506b59cac4d9c5f2240713a7e6a365f1', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-30 06:21:32', '2021-12-30 06:21:32', '2022-12-30 01:21:32'),
('2919672ecc1e3dd9f2759d15f8cc54882d1d9f780cfda82fb83c8359de8654492ea6703956a7c50d', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-07-15 08:22:28', '2021-07-15 08:22:28', '2022-07-15 14:22:28'),
('2c3a1184677ccf06b7f1db62e4788f3ee92b5ecb416e2fac5a704554477d956a76a14726ea970725', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:37:00', '2022-01-01 15:37:00', '2023-01-01 10:37:00'),
('2f49586a4ac33179f846e60afba15e655ceef494cd64f6812d4ab109336f5fb008cb3005137f700c', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-08-03 13:21:13', '2021-08-03 13:21:13', '2022-08-03 19:21:13'),
('2f791df20a58371180fa30388eec3a182c301c83e021692a9f0f16df81aba166b102906c8b32b3fc', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:21:51', '2022-01-01 07:21:51', '2023-01-01 02:21:51'),
('3115e428f22908fa2d94bf2804d1ed2d9929cb27da233aedf24c8bc71dc8066f91b0c63a795c26e9', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-07-31 08:33:37', '2021-07-31 08:33:37', '2022-07-31 14:33:37'),
('329c478875e1dc102c2b2e02b1bff5b4a63f0c17c8eb3503def1aa67f74c257dc63f5cead94d7ce7', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:22:23', '2022-01-01 15:22:23', '2023-01-01 10:22:23'),
('36217e984b8904eb4dfd30ed62eef9d725c1e8e63a6c1485bb084ef323ad5eea852c84e17560bd54', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-07-14 00:51:51', '2021-07-14 00:51:51', '2022-07-14 06:51:51'),
('3abfb4980fdf3c858e1c371352db40dae9e1e40f095b00dcd09c84ff7c8189a305f1be985e4274b3', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-06-19 03:50:53', '2021-06-19 03:50:53', '2022-06-19 09:50:53'),
('3cd3269423e543961a7b64e8169875725eb47f8d0f309c69a4a770258de65e9c02057ed9000942da', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-08-04 07:35:04', '2021-08-04 07:35:04', '2022-08-04 13:35:04'),
('3d6f7e96f3db47ad6ac2fb335619c03dd2d8bcd5f9484940b168f2a83d1cb730cb2094a066c42e64', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-02 05:52:51', '2021-12-02 05:52:51', '2022-12-01 23:52:51'),
('3e923b1f4084faba1a2e5448bd8b72e09b74db6ed25fbe14f6960a5f005107496cc507c1ba15c6e1', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-06-22 01:32:58', '2021-06-22 01:32:58', '2022-06-22 07:32:58'),
('4140d5b9b3d16e4bbef1b676b01f13f75d9c3fb2cada6548e50b0b2679562aace3b9b44f82f15f30', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-08-19 17:10:26', '2021-08-19 17:10:26', '2022-08-19 23:10:26'),
('438836d58d614a7c5163756e6184c21b1adf07c576d88b3562a38bab417f0ae98d64459ab3cd6730', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-11-22 23:59:49', '2021-11-22 23:59:49', '2022-11-22 17:59:49'),
('45a655cb5f4f4e4e4626791cfd52c2355a9c8e01050d8f232edf5489468e5320012f8f854aa07305', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-31 04:49:18', '2022-01-31 04:49:18', '2023-01-30 23:49:18'),
('46907bd6f91f0e5f253119c4b96542fdd7c668244d3c630d062dc30e49c44ceb9cbd43fa6f46a1ab', 4, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-10 03:44:34', '2021-12-10 03:44:34', '2022-12-09 21:44:34'),
('4814c5eaafc09daddd6739733fdfdae9dbe908f64970a9c1185e86177070fbbcd83545dc68c128f9', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 06:45:08', '2022-01-01 06:45:08', '2023-01-01 01:45:08'),
('482c2648062f4b661ecf98843d4a12c3d3cfd5a109bcc9091e32a56d02412d70b7739042433b4217', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:31:48', '2022-01-01 15:31:48', '2023-01-01 10:31:48'),
('48c36f770a644c8976b8e937f0e4af3613826ad23048aaa3c2e1aa7bfedfb191b87d3bbcc08cb9ab', 11, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-02-23 16:04:49', '2022-02-23 16:04:49', '2023-02-23 11:04:49'),
('49cfea163940e3b4e10e4020d75f862c8b8f8d25d93fdbd95c4219645c494d7df1fbd44ccaac016c', 8, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-31 05:27:05', '2022-01-31 05:27:05', '2023-01-31 00:27:05'),
('4be831697f52a86a86e06aa9220f22e63097aa4e143e67b0a6fd00e114866ca853f05d6b351c4767', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:39:43', '2022-01-01 15:39:43', '2023-01-01 10:39:43'),
('4bec1fbc25b9b340a51e4dc6eaa373ff563e059410170022da9189a00af7d9b28fe9d4469d532695', 9, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-02-01 01:41:18', '2022-02-01 01:41:18', '2023-01-31 20:41:18'),
('4cab2bdb3c8ba2fa997440c4fd61fd3cf7df931de90b01f9878549e64fa37cf7bb375931a10c6110', 10, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-02-02 03:36:08', '2022-02-02 03:36:08', '2023-02-01 22:36:08'),
('4cfad08796e4a1eecfe8bbdc20e512e0954570168990fa60442ad41b5ecf05e4005cadcae08fbddd', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-06-19 03:29:52', '2021-06-19 03:29:52', '2022-06-19 09:29:52'),
('53afc11b36d08435d8ec82c42305f7aa4397d10b2d296f6e7d819e091d0d7c6d48e14cdc5e66e6c9', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-06-23 23:08:01', '2021-06-23 23:08:01', '2022-06-24 05:08:01'),
('5646d6337aaed0e662c059ed368372e2da241ff97a42df56310667ec321fdbf2252d92771988640a', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-08-04 07:37:55', '2021-08-04 07:37:55', '2022-08-04 13:37:55'),
('5757026ab247bd89e2484b9de42cacc320550cfb9c8a15a77fc515c7c1f86a4bfcea5c1a9430c109', 5, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-13 18:24:23', '2021-12-13 18:24:23', '2022-12-13 13:24:23'),
('59551e481bc1fb037bee07e1501d81dad38d4ff34fdca68a49c40d0cf423176ca111940acd359aeb', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-08-08 14:50:59', '2021-08-08 14:50:59', '2022-08-08 20:50:59'),
('62f3dd60d293b0cd27aab46fbbbe8758de38a7659621b64d4f41527f32f1dd00d7ff77531c1bc226', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:21:23', '2022-01-01 07:21:23', '2023-01-01 02:21:23'),
('638e6de7afb80dddd28a25723bc18a3b14503245dea726509f9b1f2ab75edf92939a835b3886b566', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-31 04:02:27', '2022-01-31 04:02:27', '2023-01-30 23:02:27'),
('65be60b1be0e85815d476948b79f1f29ca58cd34e448ec504be22333b5718b05808171ff45bde6a7', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 16:05:51', '2022-01-01 16:05:51', '2023-01-01 11:05:51'),
('670095f770bca76ceefd2773ed247413cc6c7bde0401822a2ad8b6277afb1e64591b6bd057cfd93c', 7, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-30 07:10:45', '2021-12-30 07:10:45', '2022-12-30 02:10:45'),
('68b06321c4bbbea81e7dfcbd8d5fae1a94a2fa0500041ee5774be2d9300c1ff7590d03604b77514a', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-07-28 02:33:54', '2021-07-28 02:33:54', '2022-07-28 08:33:54'),
('6f46ae52f96a08cf929345c6e316c2fae590b5eed7b035183121f2447a5954a01d0276a16138d53e', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-27 17:51:14', '2022-01-27 17:51:14', '2023-01-27 12:51:14'),
('6f4e3a26e205bbc2581d9afff31cc2d2325cc3d5961553c32b3e3f8865d916463b5dbda90af89e75', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:34:13', '2022-01-01 15:34:13', '2023-01-01 10:34:13'),
('6f65a4f93e7b8dbd7444a9731d4af760d1a410dfdc45661f17317423eddae62bd60b737c2424ed58', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:21:36', '2022-01-01 15:21:36', '2023-01-01 10:21:36'),
('723ceee668cd1a7fc2e977be48cab3f31aed1ace0883692711b5cc2ddf42c2f23c6d75461172105f', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-07-01 05:46:27', '2021-07-01 05:46:27', '2022-07-01 11:46:27'),
('72e6be2810cbc98f92e527fb40773a18c9e47f7bd526d3e75b896622433a5042d5c42bac24f7a05b', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:55:07', '2022-01-01 15:55:07', '2023-01-01 10:55:07'),
('74e2dd27429bb92c12e33f891ccff32f48c22463166666705d145cfd8968d96ec992fa2cc3a36e76', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-06-23 23:08:23', '2021-06-23 23:08:23', '2022-06-24 05:08:23'),
('761e47287a249cdd75892be6f1ade65958cfb6f02f6553f3607a6f655806ba05a976578cbf4d9fdd', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:47:20', '2022-01-01 07:47:20', '2023-01-01 02:47:20'),
('7692f301b243a7382660ba96ea263ff760a68b42d57fd04564cdf63989f80cc5033e07cb784a8589', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-05 00:05:57', '2021-12-05 00:05:57', '2022-12-04 18:05:57'),
('77c9389b2ab3031e09005a7e7be90d00496ff073dbbefeb57229cee5d0a240376c1f7c3c8a94faff', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-06-19 03:38:22', '2021-06-19 03:38:22', '2022-06-19 09:38:22'),
('77dd1f4753d32ca4b040258c18ddc7f543fbd732dd330a42463719523f00a04d4b331a164193e6e6', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-27 17:58:36', '2022-01-27 17:58:36', '2023-01-27 12:58:36'),
('7946c7f1a90e9cf94a49df502e38578be368758968848644d27d661d5ce4adac96d8f4c8f2cf3546', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:21:54', '2022-01-01 15:21:54', '2023-01-01 10:21:54'),
('89f0c35eb28f29004131510acd4a544381f07137eb3920bd9d704c55a4f52e8515b289c1ca88a768', 5, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-13 17:15:15', '2021-12-13 17:15:15', '2022-12-13 12:15:15'),
('8a20c4f8656e404615f9abc15a95f6754dd87e4e894677647dd17236b95d8a5d7cc243c38457b048', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-07-04 02:36:57', '2021-07-04 02:36:57', '2022-07-04 08:36:57'),
('8bfa9c92ff32254184056711f9b7c48b2d5ba0ba029cc58dea65a31443682afa309de5dc04a4264f', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-11-18 16:53:54', '2021-11-18 16:53:54', '2022-11-18 10:53:54'),
('8ffc458ddbcbbbec17035dc2153c4baeebb5c54796b3a9008f24c8699197a8a2fc1111c36cc1d7da', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-08-14 07:27:12', '2021-08-14 07:27:12', '2022-08-14 13:27:12'),
('907c243133cd3d60e8499dd11406d63d15cb99c8d82ead4497e350d385694e60a3c2df49b376a03d', 8, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-31 06:19:44', '2022-01-31 06:19:44', '2023-01-31 01:19:44'),
('96e976c494664401685dfdc5f6003646c59a3aeefb4cf9aa5330962991d484d3577ea8b085751596', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:31:37', '2022-01-01 07:31:37', '2023-01-01 02:31:37'),
('97727f8d7214b03d1d2923db9c341dfb11820414971d0108a413bf4bedcfa23a9445269a93d07cc5', 3, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-11-25 20:17:20', '2021-11-25 20:17:20', '2022-11-25 14:17:20'),
('97ce65368eb1479842d0af2fc10ff24b103bf5bad379f7d04deffccf9d08a43b7f2bb42961293e29', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:14:18', '2022-01-01 07:14:18', '2023-01-01 02:14:18'),
('99478ab96074fe7f5fba522208a2123de646f35022f4de8b45b50826037347f3eaaa0923d5d78f3c', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:23:15', '2022-01-01 07:23:15', '2023-01-01 02:23:15'),
('9aeefb31e2a89cb2793b8770869513df3b2f71eef58564668c2a38fcb0f8cb3ed9197923d355b39e', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:27:36', '2022-01-01 15:27:36', '2023-01-01 10:27:36'),
('9b872f16e42fd1a3b001b073ccd163af5f2ce55578721d76f4af6075099c111a7facc4c554b9c63d', 3, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-25 17:28:23', '2022-01-25 17:28:23', '2023-01-25 12:28:23'),
('9d94c15f7f4db7edc2d991018e371d90d68a938dec0a845207c6e5241fedeb9238528fda320009ab', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:23:37', '2022-01-01 07:23:37', '2023-01-01 02:23:37'),
('a092dc4a49ec27a06d8c9c335446de3d90e03363c6059cdf6fbf2113edaab5fe752053a794ac9236', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-08-08 10:12:49', '2021-08-08 10:12:49', '2022-08-08 16:12:49'),
('a3b23798a757b96498670603d98f076d65875b3dfd2cb983cde38b79fd080d1a53ca83d51411e43e', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-05 01:49:04', '2021-12-05 01:49:04', '2022-12-04 19:49:04'),
('a98c1e939b6570cec660d79d3b30ba6ba5ad06df26438765f0ae5dea2a4d1bdcacc5caeb05b3e775', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:28:09', '2022-01-01 15:28:09', '2023-01-01 10:28:09'),
('adfea7380b7f16c2e65d26d640a8619e997fa0c869532bbd50bf57ce985073db34d1c5eb99b18724', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 16:14:07', '2022-01-01 16:14:07', '2023-01-01 11:14:07'),
('af1c45527ef259108929dbe75f5aff49af9495826bcb1a587d5dc28b5fb64fcc6c0d2f4a34497574', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 16:05:06', '2022-01-01 16:05:06', '2023-01-01 11:05:06'),
('af221d2c6bc72d2d5315a3350f74d65fa0104dacb80d5ede9e76988bea28d7f9eee6a75cbdbfdc6c', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-03 18:44:07', '2022-01-03 18:44:07', '2023-01-03 13:44:07'),
('b2dab8128177e4ecef0c5f8078475a0d9443a36bc9edd11b40ab61a0b34dbdf3c1a23eb16459e05e', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-11-22 22:33:53', '2021-11-22 22:33:53', '2022-11-22 16:33:53'),
('b417717ddb6cf90b9c99684635d7afb03b2703f949585d881260844e8a82ad54f3114a2d58c65db3', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-31 23:15:07', '2021-12-31 23:15:07', '2022-12-31 18:15:07'),
('b4651c7e8bbe8a68b4959504c3a7e3705208cbdb79fcc2498b9b3d0efa9c7cadc77699590cf8f2d4', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-06-20 03:59:46', '2021-06-20 03:59:46', '2022-06-20 09:59:46'),
('ba1ff1488d480cdc90911ffd763c30959790ef098224943640262bf52bb2ed4991cba3a576ec9edf', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-05 00:29:13', '2021-12-05 00:29:13', '2022-12-04 18:29:13'),
('ba52e28871f2c06af0381010471c5a0cb092306d3d4b0b654d4b2988eb57f7191e6a931ed01c7837', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:23:47', '2022-01-01 07:23:47', '2023-01-01 02:23:47'),
('bad393f984bd4b3d4cc4757eda7c0e1921e011fc628b00a8f89bf2198e2c7322843395422f8ead8e', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:50:42', '2022-01-01 15:50:42', '2023-01-01 10:50:42'),
('bf24e16194d82c4e2982724df0fef68f7923d6d01ce8c5e1b64e2716d2412db6e62891f0f8dae8a6', 57, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-07-31 08:34:19', '2021-07-31 08:34:19', '2022-07-31 14:34:19'),
('c13ea86ccdcbf5cac9ca0eaa1f457735fa2bb35a73bbf431277afd155a29dd9a5709e270a384655a', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:24:53', '2022-01-01 15:24:53', '2023-01-01 10:24:53'),
('c1b7df78e7373f5eca5f64083ac9bbc6c9bd582adf6c143f520c8a65420d3ee050044e6f65f0a033', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-06-24 03:40:43', '2021-06-24 03:40:43', '2022-06-24 09:40:43'),
('c34924493e95c52092e9ae075bcfad8dabc424bafb06584b1dc55c42822143c9d17bb3bb0a42e564', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-05 00:49:34', '2021-12-05 00:49:34', '2022-12-04 18:49:34'),
('c834b2329109d64595abd9429369d35cd7ec6cf394ebafa5ea0892ab0ee613883b6b762583e4acae', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:46:15', '2022-01-01 07:46:15', '2023-01-01 02:46:15'),
('ca84303867121965245a5561e71e70673ade23a10a29e749799f4fd67db70f014c2b248192208512', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 17:19:51', '2022-01-01 17:19:51', '2023-01-01 12:19:51'),
('ca9bcd1db5e170dc9ef876d42db9f7dd70bac4a2d7f571c41fa9dbbd47c40ffd4c454807d6d37c65', 9, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-02-01 01:41:36', '2022-02-01 01:41:36', '2023-01-31 20:41:36'),
('d213de1b0633456a45e89287a89a174882df08fc1b1ec71b78d640d5962a0b22bf2bc3ac9d0f017d', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-02-08 02:36:28', '2022-02-08 02:36:28', '2023-02-07 21:36:28'),
('d59431363d50f2942fb8bdcae79d356bb09a30679235f7920f2857e9b15997e79dc8398ede65f11a', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:26:19', '2022-01-01 07:26:19', '2023-01-01 02:26:19'),
('d5de3cd5ff3b628ca1183ee93d490233d1310a2931120d5dbabdcb1d3d74a6b96f792784f18b1d71', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-02-11 19:21:35', '2022-02-11 19:21:35', '2023-02-11 14:21:35'),
('d6f1ef838b2655c960ac34459343fc02ae15efc502c467ec3e41687cd611ad31e7e61589d1c740ee', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:25:34', '2022-01-01 07:25:34', '2023-01-01 02:25:34'),
('dac4bf90f9dec4a284a4ce345719a2ecd10b53541204338708252046cad85cc85f446e58407921d4', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 07:22:36', '2022-01-01 07:22:36', '2023-01-01 02:22:36'),
('dd6578c99fc90f666b9433871d28f9913fefc860d9a60427388cfcf727be6f5c10eb8b764b39c557', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-06-28 10:20:50', '2021-06-28 10:20:50', '2022-06-28 16:20:50'),
('de297b3aa55dd28990db6595c4c8c4f5a28f58ff814ec0131386b63b41dc207e4b8c66c015a3bf03', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-11-18 16:40:53', '2021-11-18 16:40:53', '2022-11-18 10:40:53'),
('e4e86ffca2bbcdcb5be346c1d991f5c9803ceee84d86defa47096b73161aacdda32c559afd4b8314', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-30 06:26:03', '2021-12-30 06:26:03', '2022-12-30 01:26:03'),
('ea3ca170bd7935fe3f2a9c80c74d1e8e6eda8cc197ce2066305a286d175ad250475a4657e498779b', 56, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-06-21 01:24:25', '2021-06-21 01:24:25', '2022-06-21 07:24:25'),
('ebf3a335ceaf727f696007351aaac23bf90faecc102d9b3b5c5afabaab512852561b30a104c21589', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-30 06:11:56', '2021-12-30 06:11:56', '2022-12-30 01:11:56'),
('ee7fcd35636efed34907ee6a9cad291eae6520718280646c9924cf02817c268a9d10ec47935320c7', 2, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-11-22 23:50:05', '2021-11-22 23:50:05', '2022-11-22 17:50:05'),
('f67c486eb63ebdc63d87370dbb30b97fa488b1ab63bbce9cc6164bd7e9fbc8be86c7c36fc72bb3a1', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2022-01-01 15:21:20', '2022-01-01 15:21:20', '2023-01-01 10:21:20'),
('fc877a6885ff7e905944d8cc6b5972be7ac49b890961abed45be6b80991af5dc7e7c63ef00218185', 6, 1, 'RestaurantCustomerAuth', '[]', 0, '2021-12-30 06:18:14', '2021-12-30 06:18:14', '2022-12-30 01:18:14');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'qFAwGhxq8A6SDmolyxZunXyQ4mxOH0jEezXsgaxP', NULL, 'http://localhost', 1, 0, 0, '2021-06-19 03:27:59', '2021-06-19 03:27:59'),
(2, NULL, 'Laravel Password Grant Client', 'qdV021R3MGGAwRxvvqG0mWgnypwzolzusBq1L5W6', 'users', 'http://localhost', 0, 1, 0, '2021-06-19 03:27:59', '2021-06-19 03:27:59');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-06-19 03:27:59', '2021-06-19 03:27:59');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `order_amount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `coupon_discount_amount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `coupon_discount_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unpaid',
  `order_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `total_tax_amount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_reference` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_address_id` bigint(20) DEFAULT NULL,
  `delivery_man_id` bigint(20) UNSIGNED DEFAULT NULL,
  `coupon_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'delivery',
  `checked` tinyint(1) NOT NULL DEFAULT 0,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `delivery_charge` decimal(6,2) NOT NULL DEFAULT 0.00,
  `schedule_at` timestamp NULL DEFAULT NULL,
  `callback` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pending` timestamp NULL DEFAULT NULL,
  `accepted` timestamp NULL DEFAULT NULL,
  `confirmed` timestamp NULL DEFAULT NULL,
  `processing` timestamp NULL DEFAULT NULL,
  `handover` timestamp NULL DEFAULT NULL,
  `picked_up` timestamp NULL DEFAULT NULL,
  `delivered` timestamp NULL DEFAULT NULL,
  `canceled` timestamp NULL DEFAULT NULL,
  `refund_requested` timestamp NULL DEFAULT NULL,
  `refunded` timestamp NULL DEFAULT NULL,
  `delivery_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheduled` tinyint(1) NOT NULL DEFAULT 0,
  `restaurant_discount_amount` decimal(8,2) NOT NULL,
  `original_delivery_charge` decimal(8,2) NOT NULL DEFAULT 0.00,
  `failed` timestamp NULL DEFAULT NULL,
  `adjusment` decimal(8,2) NOT NULL DEFAULT 0.00,
  `edited` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `order_amount`, `coupon_discount_amount`, `coupon_discount_title`, `payment_status`, `order_status`, `total_tax_amount`, `payment_method`, `transaction_reference`, `delivery_address_id`, `delivery_man_id`, `coupon_code`, `order_note`, `order_type`, `checked`, `restaurant_id`, `created_at`, `updated_at`, `delivery_charge`, `schedule_at`, `callback`, `otp`, `pending`, `accepted`, `confirmed`, `processing`, `handover`, `picked_up`, `delivered`, `canceled`, `refund_requested`, `refunded`, `delivery_address`, `scheduled`, `restaurant_discount_amount`, `original_delivery_charge`, `failed`, `adjusment`, `edited`) VALUES
(100001, 10, 13.00, 0.00, '', 'unpaid', 'failed', 0.00, 'digital_payment', NULL, NULL, NULL, NULL, NULL, 'delivery', 1, 1674, '2022-02-27 03:14:05', '2022-03-02 09:26:47', 0.00, '2022-02-27 03:14:05', NULL, '7932', '2022-02-27 03:14:05', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '{\"contact_person_name\":\"Carl Spartacus\",\"contact_person_number\":\"+19143730382\",\"address_type\":\"others\",\"address\":\"South Atlantic Ocean\",\"longitude\":\"-0.10078601539134979\",\"latitude\":\"-0.13576994051079905\"}', 0, 0.00, 0.00, NULL, 0.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_delivery_histories`
--

CREATE TABLE `order_delivery_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `delivery_man_id` bigint(20) UNSIGNED DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `start_location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end_location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `food_id` bigint(20) UNSIGNED DEFAULT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `price` decimal(8,2) NOT NULL DEFAULT 0.00,
  `food_details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `add_ons` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_on_food` decimal(8,2) DEFAULT NULL,
  `discount_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'amount',
  `quantity` int(11) NOT NULL DEFAULT 1,
  `tax_amount` decimal(8,2) NOT NULL DEFAULT 1.00,
  `variant` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `item_campaign_id` bigint(20) UNSIGNED DEFAULT NULL,
  `total_add_on_price` decimal(8,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `food_id`, `order_id`, `price`, `food_details`, `variation`, `add_ons`, `discount_on_food`, `discount_type`, `quantity`, `tax_amount`, `variant`, `created_at`, `updated_at`, `item_campaign_id`, `total_add_on_price`) VALUES
(1, 52, 100001, 13.00, '{\"id\":52,\"name\":\"OMG\\u2026I Love Chocolate\",\"description\":\"Dark Chocolate Cake, Dark Chocolate Ganache & Raspberry Center. Covered in Dark Chocolate\",\"image\":\"2022-02-26-621aeb557bf7f.png\",\"category_id\":1347,\"category_ids\":[{\"id\":\"1347\",\"position\":1}],\"variations\":[],\"add_ons\":[],\"attributes\":[],\"choice_options\":[],\"price\":13,\"tax\":0,\"tax_type\":\"percent\",\"discount\":0,\"discount_type\":\"percent\",\"available_time_starts\":\"10:00:00\",\"available_time_ends\":\"23:00:00\",\"set_menu\":0,\"status\":1,\"restaurant_id\":1674,\"created_at\":\"2022-02-27T03:09:09.000000Z\",\"updated_at\":\"2022-02-27T03:11:55.000000Z\",\"order_count\":0,\"restaurant_name\":\"Angelina\'s Ristorante\",\"restaurant_discount\":0,\"restaurant_opening_time\":\"10:00\",\"restaurant_closing_time\":\"23:00\",\"schedule_order\":false,\"avg_rating\":0,\"rating_count\":0}', '[]', '[]', 0.00, 'discount_on_product', 1, 0.00, 'null', '2022-02-27 03:14:05', '2022-02-27 03:14:05', NULL, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_transactions`
--

CREATE TABLE `order_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `delivery_man_id` bigint(20) UNSIGNED DEFAULT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `order_amount` decimal(8,2) NOT NULL,
  `restaurant_amount` decimal(8,2) NOT NULL,
  `admin_commission` decimal(8,2) NOT NULL,
  `received_by` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `delivery_charge` decimal(8,2) NOT NULL DEFAULT 0.00,
  `original_delivery_charge` decimal(8,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(8,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `phone_verifications`
--

CREATE TABLE `phone_verifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `provide_d_m_earnings`
--

CREATE TABLE `provide_d_m_earnings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `delivery_man_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `minimum_order` decimal(6,2) NOT NULL DEFAULT 0.00,
  `comission` decimal(8,2) DEFAULT NULL,
  `schedule_order` tinyint(1) NOT NULL DEFAULT 0,
  `opening_time` time DEFAULT '10:00:00',
  `closeing_time` time DEFAULT '23:00:00',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `free_delivery` tinyint(1) NOT NULL DEFAULT 0,
  `rating` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery` tinyint(1) NOT NULL DEFAULT 1,
  `take_away` tinyint(1) NOT NULL DEFAULT 1,
  `food_section` tinyint(1) NOT NULL DEFAULT 1,
  `tax` decimal(6,2) NOT NULL DEFAULT 0.00,
  `zone_id` bigint(20) UNSIGNED DEFAULT NULL,
  `reviews_section` tinyint(1) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `off_day` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ' ',
  `gst` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `self_delivery_system` tinyint(1) NOT NULL DEFAULT 0,
  `pos_system` tinyint(1) NOT NULL DEFAULT 0,
  `delivery_charge` decimal(8,2) NOT NULL DEFAULT 0.00,
  `google_form_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`id`, `name`, `phone`, `email`, `logo`, `latitude`, `longitude`, `address`, `footer_text`, `minimum_order`, `comission`, `schedule_order`, `opening_time`, `closeing_time`, `status`, `vendor_id`, `created_at`, `updated_at`, `free_delivery`, `rating`, `cover_photo`, `delivery`, `take_away`, `food_section`, `tax`, `zone_id`, `reviews_section`, `active`, `off_day`, `gst`, `self_delivery_system`, `pos_system`, `delivery_charge`, `google_form_url`) VALUES
(10, 'Arsal Malik', '', 'atifzakariyan+2@gmail.com', '2022-01-16-61e461a4b10b7.png', '', '', NULL, NULL, 0.00, NULL, 0, '10:00:00', '23:00:00', 0, 125, '2022-01-20 21:20:37', '2022-02-19 04:30:04', 0, NULL, NULL, 1, 1, 1, 0.00, 1, 1, 1, ' ', NULL, 0, 0, 0.00, NULL),
(11, 'Arsal Malik', '', 'atifzakariyan+3@gmail.com', '2022-01-16-61e461a4b10b7.png', '', '', NULL, NULL, 0.00, NULL, 0, '10:00:00', '23:00:00', 0, 126, '2022-01-20 21:20:37', '2022-02-19 04:30:20', 0, NULL, NULL, 1, 1, 1, 0.00, 1, 1, 1, ' ', NULL, 0, 0, 0.00, NULL),
(12, 'ABC', '', 'atifzakariyan+4@gmail.com', '2022-01-20-61e9148348853.png', '', '', NULL, NULL, 0.00, NULL, 0, '10:00:00', '23:00:00', 0, 127, '2022-01-20 21:20:37', '2022-02-19 04:30:30', 0, NULL, NULL, 1, 1, 1, 0.00, 1, 1, 1, ' ', NULL, 0, 0, 0.00, NULL),
(13, 'Zari', '', 'atifzakariyan+5@gmail.com', '2022-01-20-61e9153dbb121.png', '', '', NULL, NULL, 0.00, NULL, 0, '10:00:00', '23:00:00', 0, 128, '2022-01-20 21:20:37', '2022-02-19 04:30:12', 0, NULL, NULL, 1, 1, 1, 0.00, 1, 1, 1, ' ', NULL, 0, 0, 0.00, NULL),
(14, 'Arsal Malik', '', 'a1@gmail.com', '2022-01-16-61e461a4b10b7.png', '', '', NULL, NULL, 0.00, NULL, 0, '10:00:00', '23:00:00', 0, 125, '2022-01-20 22:01:32', '2022-02-19 04:29:53', 0, NULL, NULL, 1, 1, 1, 0.00, 1, 1, 1, ' ', NULL, 0, 0, 0.00, NULL),
(15, 'Arsal Malik', '', 'a2@gmail.com', '2022-01-16-61e461a4b10b7.png', '', '', NULL, NULL, 0.00, NULL, 0, '10:00:00', '23:00:00', 0, 126, '2022-01-20 22:01:32', '2022-02-19 04:29:59', 0, NULL, NULL, 1, 1, 1, 0.00, 1, 1, 1, ' ', NULL, 0, 0, 0.00, NULL),
(1673, 'Sergeant Mover', '3047076010', 'sergeantmover@ratenow.com', '2022-02-16-620cb00a5ef56.png', '26.761070779034046', '-81.43768277353513', 'LaBelle, Florida', NULL, 0.00, NULL, 0, '10:00:00', '23:00:00', 1, 1755, '2022-02-16 08:04:26', '2022-02-26 07:52:17', 0, NULL, '2022-02-26-6219dc312ecc0.png', 1, 1, 1, 0.00, 1, 1, 1, ' ', NULL, 0, 0, 0.00, 'https://bit.ly/RateSergeantMover'),
(1674, 'Angelina\'s Ristorante', '239-390-3187', 'angelinas@ratenow.com', '2022-02-26-621acec8b844e.png', '26.339164233009136', '-81.77561914014575', '24041 S. Tamiami Trl.\r\nBonita Springs, FL 34134', NULL, 0.00, NULL, 0, '10:00:00', '23:00:00', 1, 1756, '2022-02-18 04:36:17', '2022-02-27 01:07:20', 0, NULL, '2022-02-26-621ace812e3c7.png', 1, 1, 1, 0.00, 1, 1, 1, ' ', NULL, 0, 0, 0.00, 'https://angelinasofbonitasprings.com');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_reviews`
--

CREATE TABLE `restaurant_reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `comment` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `restaurant_reviews`
--

INSERT INTO `restaurant_reviews` (`id`, `restaurant_id`, `user_id`, `comment`, `attachment`, `rating`, `created_at`, `updated_at`) VALUES
(1, 1, 5, 'I love this store', '[]', 5, NULL, NULL),
(2, 256, 6, 'lovely', '[]', 5, NULL, NULL),
(3, 512, 6, '{\"comment\":\"awesome food\",\"video\":\"https\"}', '[]', 5, NULL, NULL),
(4, 256, 8, '{\"comment\":\"very very awesome\",\"video\":\"https://firebasestorage.googleapis.com/v0/b/flutter-chat-app-61c03.appspot.com/o/files%2FVID-20220130-WA0011.mp4?alt=media&token=3d1d84fc-5f17-4277-b7c9-023ea1bd8654\"}', '[]', 5, NULL, NULL),
(5, 1, 8, '{\"comment\":\"good taste\",\"video\":\"https://firebasestorage.googleapis.com/v0/b/flutter-chat-app-61c03.appspot.com/o/files%2FVID-20220130-WA0011.mp4?alt=media&token=b5862909-aea5-4640-8118-e7d74ce1c5b1\"}', '[]', 5, NULL, NULL),
(6, 1536, 6, '{\"comment\":\"awesome\",\"video\":\"\"}', '[]', 5, NULL, NULL),
(7, 257, 6, '{\"comment\":\"jknkj\",\"video\":\"\"}', '[]', 5, NULL, NULL),
(8, 769, 6, '{\"comment\":\"kjnjk\",\"video\":\"\"}', '[]', 5, NULL, NULL),
(9, 1281, 8, '{\"comment\":\"very awesome 😍\",\"video\":\"https://firebasestorage.googleapis.com/v0/b/flutter-chat-app-61c03.appspot.com/o/files%2FREC1975375221290871678.mp4?alt=media&token=8b6420f1-41e9-497b-8a37-d799508fc53c\"}', '[]', 5, NULL, NULL),
(10, 770, 8, '{\"comment\":\"yummy nice \",\"video\":\"https://firebasestorage.googleapis.com/v0/b/flutter-chat-app-61c03.appspot.com/o/files%2FREC4706949286604310916.mp4?alt=media&token=71e7ce10-8930-481a-bad4-42375dd67321\"}', '[]', 5, NULL, NULL),
(11, 1026, 8, '{\"comment\":\"good\",\"video\":\"https://firebasestorage.googleapis.com/v0/b/flutter-chat-app-61c03.appspot.com/o/files%2FREC7755314799798182348.mp4?alt=media&token=c8c70041-7fa8-4c33-b44c-abf102607272\"}', '[]', 5, NULL, NULL),
(12, 1538, 8, '{\"comment\":\"nice\",\"video\":\"https://firebasestorage.googleapis.com/v0/b/flutter-chat-app-61c03.appspot.com/o/files%2FREC8598012008189591505.mp4?alt=media&token=26a5356e-bfb8-4143-9af1-2bd162d53a4f\"}', '[]', 5, NULL, NULL),
(13, 1546, 8, '{\"comment\":\"hbghhch\",\"video\":\"https://firebasestorage.googleapis.com/v0/b/flutter-chat-app-61c03.appspot.com/o/files%2FVID-20220202-WA0013.mp4?alt=media&token=297ef16e-61f5-4c69-89de-c949c736894e\"}', '[]', 5, NULL, NULL),
(14, 271, 8, '{\"comment\":\"hjbf\",\"video\":\"https://firebasestorage.googleapis.com/v0/b/flutter-chat-app-61c03.appspot.com/o/files%2FVID-20220203-WA0002.mp4?alt=media&token=09c7d286-7d6e-485f-b71f-377172fe94f7\"}', '[]', 5, NULL, NULL),
(15, 783, 8, '{\"comment\":\"bjg\",\"video\":\"https://firebasestorage.googleapis.com/v0/b/flutter-chat-app-61c03.appspot.com/o/files%2FREC9037651167570857072.mp4?alt=media&token=8055edc9-f1a0-43e1-9407-1054f2678386\"}', '[]', 5, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_wallets`
--

CREATE TABLE `restaurant_wallets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `total_earning` decimal(8,2) NOT NULL DEFAULT 0.00,
  `total_withdrawn` decimal(8,2) NOT NULL DEFAULT 0.00,
  `pending_withdraw` decimal(8,2) NOT NULL DEFAULT 0.00,
  `collected_cash` decimal(8,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `restaurant_wallets`
--

INSERT INTO `restaurant_wallets` (`id`, `vendor_id`, `total_earning`, `total_withdrawn`, `pending_withdraw`, `collected_cash`, `created_at`, `updated_at`) VALUES
(1, 18, 0.00, 0.00, 0.00, 0.00, '2021-11-19 06:50:38', '2021-11-19 06:50:38'),
(2, 19, 0.00, 0.00, 0.00, 0.00, '2021-11-19 06:52:00', '2021-11-19 06:52:00'),
(3, 20, 0.00, 0.00, 0.00, 0.00, '2021-12-26 19:38:49', '2021-12-26 19:38:49'),
(4, 70, 0.00, 0.00, 0.00, 0.00, '2021-12-28 15:08:35', '2021-12-28 15:08:35'),
(5, 75, 0.00, 0.00, 0.00, 0.00, '2021-12-29 20:01:45', '2021-12-29 20:01:45'),
(6, 113, 0.00, 0.00, 0.00, 0.00, '2022-01-16 18:26:04', '2022-01-16 18:26:04'),
(7, 125, 0.00, 0.00, 0.00, 0.00, '2022-01-20 22:02:30', '2022-01-20 22:02:30'),
(8, 1743, 0.00, 0.00, 0.00, 0.00, '2022-01-24 04:56:11', '2022-01-24 04:56:11'),
(9, 1751, 0.00, 0.00, 0.00, 0.00, '2022-01-24 05:06:54', '2022-01-24 05:06:54'),
(10, 1756, 0.00, 0.00, 0.00, 0.00, '2022-02-18 20:27:22', '2022-02-18 20:27:22');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_zone`
--

CREATE TABLE `restaurant_zone` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `food_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `comment` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` int(11) NOT NULL DEFAULT 0,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `item_campaign_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `soft_credentials`
--

CREATE TABLE `soft_credentials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `track_deliverymen`
--

CREATE TABLE `track_deliverymen` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `delivery_man_id` bigint(20) UNSIGNED DEFAULT NULL,
  `longitude` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `f_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_phone_verified` tinyint(1) NOT NULL DEFAULT 0,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `interest` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cm_firebase_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `order_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `f_name`, `l_name`, `phone`, `email`, `image`, `is_phone_verified`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `interest`, `cm_firebase_token`, `status`, `order_count`) VALUES
(1, 'testq', 'test1', '+11111111111', 'test@gmail.com', NULL, 1, NULL, '$2y$10$84jERTVikOrQjteOsBfMGO9haxFT8ezZsSlABAuH5PgZ4hYMQHJgG', NULL, NULL, NULL, NULL, NULL, 1, 0),
(2, 'testqr', 'test12', '+9779823020187', 'testy@gmail.com', NULL, 1, NULL, '$2y$10$84jERTVikOrQjteOsBfMGO9haxFT8ezZsSlABAuH5PgZ4hYMQHJgG', NULL, NULL, NULL, NULL, 'f5jfD6nvSW6S5Y7c9C4V4J:APA91bEcpo5BsnZUpX0SOF8JE38874BtPjD1yNRdsyGDvBK5IPQVRWca6quSUyroopVIVkjmxfoXmlHT7s-8-aaoVf3X5giMCD7-ZjeqtqgKu76XHTuk8N5TTdYWhb5hFbwurzpOBxBy', 1, 0),
(3, 'Carl', 'Carl', '+19143730387', 'carlicus@icloud.com', NULL, 0, NULL, '$2y$10$PY64jojYwtbphi1hcw0pxeJ120a99BD49n2Q2QKHjAgrt7DlQseOy', NULL, '2021-11-25 20:17:19', '2021-11-25 20:28:44', '[30,31,32]', 'eW8glT9aRLui5iGoggvytY:APA91bFgD8KpKMkViMlM6uz2cYMY-4Z3MbHcAZcGCqgucZmBH82vphBPD4bvHvIxpWxA63Zx1q1xveE5guQGYM6lhpS5ATHsmJ-4U48IKtaP8PZwVtnqC7iViZyxQNNkJF5SWYiTSfoV', 1, 0),
(4, 'Carl', 'Aries', '+19143820473', 'info@teamafricorp.com', NULL, 0, NULL, '$2y$10$0CVXSXBcHSoWr.3lVOkZhe65VxBaHHaRYTsazEWOx1sxgknqStZKu', NULL, '2021-12-10 03:44:34', '2021-12-10 03:44:34', NULL, NULL, 1, 0),
(5, 'Carl', 'Aries', '+19143730389', 'carlicus@gmail.com', '2021-12-15-61ba2fe37f165.png', 0, NULL, '$2y$10$AdM5K1nByHR5GPrR2IfmfeXEHr7GGbuN8bXSDLEvjdAQiPhgrKJ9S', NULL, '2021-12-13 17:15:14', '2021-12-15 18:11:47', '[30,38,39]', NULL, 1, 0),
(6, 'malik', 'arsal', '+923486690375', 'arsalfree3@gmail.com', NULL, 0, NULL, '$2y$10$03repG3ierkmtYXClGEBKOY5T/.BwHrCod..wtSwjc4WFyyHbvvHC', NULL, '2021-12-29 20:16:26', '2021-12-29 20:16:44', '[36,37,41]', 'eeI1mFf0SQ2lEcjBal3vlC:APA91bGF87-UAjZot7POTB_iMuardo3ARPiadoGKC9wv6_qeYTyiOakyb1_xmilM_yq78HfvqMV3dTQOg5J-Qt64UzQowfmAZLdwekzI76IdTcKl5oSiYLlDVJj10p5n-lAS58mR1D6j', 1, 0),
(7, 'Atif', 'Aslam', '03001234567', 'atifzakariyan@gmail.com', NULL, 0, NULL, '$2y$10$0WuSk6zYDA7WIbpmYgD.wuNBmOkK.nb/bix9.5fO0e5gQdXAwXzui', NULL, '2021-12-30 07:10:45', '2021-12-30 07:10:45', NULL, NULL, 1, 0),
(8, 'abc', 'xyz', '+923486690376', 'xyz@xyz.com', NULL, 0, NULL, '$2y$10$O2aXS/s6KZdGvuRcDCCEDuPoxQL3sezHiiIJeOmjgmayGCPMhtVqW', NULL, '2022-01-31 05:27:05', '2022-01-31 05:27:46', '[30]', 'f-IsVG8TQLWn_lPQ2kBxUH:APA91bFRXhHhRMHGy9upVPbGu_6IxGDeXgB1KGcxxt4GcLUqDjWrGp0QFH3UO3QTmjuR3hGOrGOGS9ICF2yo4lmJXofi2T0CgRqOTGr59-xVhz-Lac8PgurSYIhqxp6dT41axBoh9Kf3', 1, 0),
(9, 'Atif', 'Aslam', '03001234569', 'atifzakariyan+2@gmail.com', NULL, 0, NULL, '$2y$10$ob9MEIiMVT.uH02Zq3roZuBnSdtGvrOv.tAB7uVVlPIfqOgQzReb6', NULL, '2022-02-01 01:41:18', '2022-02-01 01:41:18', NULL, NULL, 1, 0),
(10, 'Carl', 'Spartacus', '+19143730382', 'mrpresident@teamafricorp.com', NULL, 0, NULL, '$2y$10$tbXczQQ0xFtBrcNEmaMZru2PcMAtOHLadhxdnIvcskfMqLThAyPxq', NULL, '2022-02-02 03:36:08', '2022-02-02 04:01:52', '[35,43,86,139]', NULL, 1, 0),
(11, 'boo', 'who', '+18457862950', 'carlicus1@icloud.com', NULL, 0, NULL, '$2y$10$ChsaOY6293Gv5iLPBUh8TeWN8OtK9obxiFeBubGTGwVJjOa31ULhO', NULL, '2022-02-23 16:04:49', '2022-02-23 16:04:49', NULL, NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_notifications`
--

CREATE TABLE `user_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `data` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `vendor_id` bigint(20) UNSIGNED DEFAULT NULL,
  `delivery_man_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `f_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `l_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branch` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `holder_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `firebase_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `f_name`, `l_name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `bank_name`, `branch`, `holder_name`, `account_no`, `image`, `status`, `firebase_token`, `auth_token`) VALUES
(18, 'rest1', 'test1', '3433433433', 'rest1@test.com', NULL, '$2y$10$pFUfUxGjP46gtK0Ut79tguiv1NgBYEKQFvOY32KfAl2PYZ2mpwGAe', NULL, '2021-11-18 16:51:58', '2021-11-18 16:51:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(19, 'Fas', 'hion', '3493349343', 'qmohamede.tan@usbvap.com', NULL, '$2y$10$2ECMyosKxwcZvraqRGFJkuku7EXuTXeSF7APSslqfG8GFB7aat8py', NULL, '2021-11-19 06:50:28', '2021-11-22 22:02:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(20, 'Jason', 'Billips', '2398885838', 'sergeantmover@mail.com', NULL, '$2y$10$lCgdPDKYkV5nR1cTOl8NHO.14LHpmlnGA0ikI49/BL0h68TqcKGei', NULL, '2021-11-25 21:17:34', '2021-11-25 21:17:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(21, 'store', 'owner', '239 656 5727', 'ristorantefabios@gmail.com', NULL, '$2y$10$c/Q6cZVE7.bgNi7AzGGAR.2yFoyul2iVkdsEyU6rtL2hFw.OD1uNe', NULL, '2021-11-26 20:51:54', '2021-11-26 20:51:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(22, 'AfriCorp', 'Media', '9143730387', 'info@teamafricorp.com', NULL, '$2y$10$Xb3Ap8n35xYdjLvVafZpy.R0w.QnEPTQOp63Tz3MnnzGwcIOeLmT2', NULL, '2021-11-27 10:34:30', '2021-11-27 10:34:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(23, 'AfriCorp', 'Media', '0000000000', 'mrpresident@teamafricorp.com', NULL, '$2y$10$b3OlVwcKqmLM.D9j9eZDRuzeQux797fsxs20okXPvx9itsLf4/LUq', NULL, '2021-11-27 10:51:12', '2021-11-27 10:51:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(24, 'AfriCorp', 'Media', '1111111111', 'example@email.com', NULL, '$2y$10$IY//36/JglaYd3ozDL9Gy.mt6nj49qPOS8/WUNpuGvaRoKcFrHIaK', NULL, '2021-11-27 15:31:33', '2021-11-27 15:31:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(25, 'AfriCorp', 'Media', '0000000001', 'livestreaming@teamafricorp.com', NULL, '$2y$10$QZL8VMASTMq0OsFVAChfd.PgXvJux2UGL0./GxAU0qPT7AhuO9mf6', NULL, '2021-11-27 15:58:53', '2021-11-27 15:58:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(26, 'AfriCorp', 'Media', '0000000002', 'memes@teamafricorp.com', NULL, '$2y$10$MJ1ugTfi3EH.IzYi9aE5WOnFU2lfwXcUligkPIJb4wHmoLDwPCM.a', NULL, '2021-11-27 16:03:07', '2021-11-27 16:03:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(27, 'Marathon', 'Fowler', '(239) 334-8178', 'marathonfowler1@teamafricorp.com', NULL, '$2y$10$Fu/aga8vf80.WuzSYuQoYea8Yjj/OIhEbit81xaBxRRwdGUExanZi', NULL, '2021-12-09 10:29:00', '2021-12-09 10:29:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(28, 'A1', 'Automotive', '2399619326', 'a1automotive2021@yahoo.com', NULL, '$2y$10$2Io/Y0ITrZ4SBlkPmmTub.7hyvjVP6Tg.SDHVmEk.GWMgWPmdwgz2', NULL, '2021-12-26 00:16:26', '2021-12-26 00:16:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(29, 'David', 'Russel', '2398789935', 'davidrussell@ratedapp.com', NULL, '$2y$10$kiuQhMw9BUHYu1hofmtB8ebi5bjXlq1./bcqH2KUYTUizPlI9UaGi', NULL, '2021-12-26 01:15:18', '2021-12-26 01:15:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(30, 'L&P', 'Designers', '5615031860', 'lpdesigners@gmail.com', NULL, '$2y$10$Wa0a0GapH8viOsfdOTYVyu8KPfeQaB9239FzVWsHUD6mialWhIvIa', NULL, '2021-12-26 01:18:50', '2021-12-26 01:18:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(31, 'Rapidempire', 'Transportation', '2392097586', 'rapidempiretransportation@ratedapp.com', NULL, '$2y$10$bcnZMvJjzCVd6Fdv3/LaXOXLLBwSAK1F382WBHkge/OnO7reXJFCO', NULL, '2021-12-26 01:22:57', '2021-12-26 01:22:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(32, 'Damon', 'Pitts', '2392366556', 'lightsrusbuffandstuff@ratedapp.com', NULL, '$2y$10$cffWGCNQdBEmt7Rku0sfxuU2kuB9RWxExMX0tmOz6vwwn0xk75KtS', NULL, '2021-12-26 01:26:57', '2021-12-26 01:26:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(33, 'The', 'Edge', '2392445153', 'theedge@ratedapp.com', NULL, '$2y$10$cUTTq9sgbDG9XQI6qz49fOCQKkhZifbzY8CjfxBfjr6to3vmnVTi6', NULL, '2021-12-26 01:29:17', '2021-12-26 01:29:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(34, 'Let It Shine', 'Wash & Detail', '2392886573', 'letitshinewashandbuffdetailing@ratedapp.comq', NULL, '$2y$10$JSB1CW.BsvDmBUcGPHLrpuIIjScBBvaSEVljctXzt7DNhQ3wWd15C', NULL, '2021-12-26 01:32:03', '2021-12-26 01:32:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(35, 'Portia', 'Nicole', '3477488045', 'portia.travels2021@gmail.com', NULL, '$2y$10$4tw2bGD3cT1kN0HyGolTbONKBaeEhTZSe/Uepu2O7iqHPCxDOKeKy', NULL, '2021-12-26 01:38:40', '2021-12-26 01:38:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(66, 'Deep', 'Lagoon', '(239) 689-5474', 'info@deeplagoon.com', NULL, '$2y$10$CGmImXPm1uZ5a.0MkbLAR.6Kub/ZHT5tlPh2qroDYdSxICTGUf72K', NULL, '2021-12-28 05:34:45', '2021-12-28 05:34:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(67, 'Cubans', 'Be Like', '(239) 789-1869', 'contactus@cubansbelike.com', NULL, '$2y$10$CS0chP2jj.sTAB5v6YQnJuasT.Vl9qck14v9OnfH1ZaLCvrXVzt12', NULL, '2021-12-28 05:51:50', '2021-12-28 05:51:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(68, 'South Beach', 'Bar \'N Grille', '(941) 964-0765', 'southbeachbar.ngrille@ratedapp.com', NULL, '$2y$10$Vzgk8BZ0JgAvKiHEL6s2p.7pCsdZGo4p9m8ocxQpStCrGRID7RKpG', NULL, '2021-12-28 06:03:53', '2021-12-28 06:03:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(69, 'Five Star', 'Latin Food', '(786) 557-6067', 'FiveStarsLatinFood@ratedapp.com', NULL, '$2y$10$9EbZ3zz6r9xXuqA4hmKFxORJUjXdwuAn0PC48C56oBENwpHBxBpOi', NULL, '2021-12-28 06:10:59', '2021-12-28 06:10:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(70, 'DEFY', 'Fort Myers', '(239) 344-8244', 'INFO@DEFY.COM', NULL, '$2y$10$2LU56/Q4VJ/tZYh6Dk6d.uRmGazlriBUft3zSnrSx2VLogU49I9H6', NULL, '2021-12-28 06:18:35', '2021-12-28 06:18:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(72, 'AutoZone', 'Store #3265', '(863) 612-0037', 'autozonestore3265@ratedapp.com', NULL, '$2y$10$EKn5Xn/zyWVX0y9J.GdwfumKf1cmdTyMgApXbVuIWdr2oYZspyyjm', NULL, '2021-12-29 06:38:41', '2021-12-29 06:38:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(73, 'Autozone', 'Store #4490', '(863) 301-6048', 'autozonestore4490@ratedapp.com', NULL, '$2y$10$rHQ84y71AvSl8ysIUDOGUOuP3a2zJmJPSRZ/oLoNMir5Pn.Ypdymi', NULL, '2021-12-29 06:50:23', '2021-12-29 06:50:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(74, 'Vision Ace Hardware', 'LaBelle', '(863) 675-2672', 'roy@visionacehardware.com', NULL, '$2y$10$TrrjxSk3aOiJUKY6OCd6bulq3ygb2Iow4CUkb80pj2cE19gC2TWWG', NULL, '2021-12-29 07:05:53', '2021-12-29 07:05:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(75, 'K And M', 'Drugs', '(863) 675-0004', 'pharmacist@kandmdrugs.com', NULL, '$2y$10$ygwM0Glifs5BBWWfdHBd9uCQxVAMwBLNJBiQ2gspJVd5rDpl5UBxy', NULL, '2021-12-29 07:13:56', '2021-12-29 07:13:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(77, 'Alligators', 'Inc.', '(863) 599-0086', 'swalker@alligator.org', NULL, '$2y$10$Wpn24r6Mc4VxdR4F5aYad.versCQ4AJVmV1YbgonfHd48ysrpr7uG', NULL, '2022-01-03 02:12:41', '2022-01-03 02:12:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(78, 'Harold P. Curtis', 'Honey Co.', '(863) 675-2187', 'info@curtishoney.com', NULL, '$2y$10$DMa2jFZuj4f7QAbIybvc9.U2Kzy6b/xJql3yvHUKnWV/le7C.1CMC', NULL, '2022-01-03 02:18:28', '2022-01-03 02:18:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(79, 'Tooley\'s', 'Café', '8286931373', '0101@ratedapp.com', NULL, '$2y$10$H83xJ17jpZEXwHPU6Adll.PZMF1qFyKp1nrO1pS8FrjH3V7pM72ze', NULL, '2022-01-11 16:30:25', '2022-01-11 16:30:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(80, 'Starlight', 'Lounge', '4128289842', '0022@ratedapp.com', NULL, '$2y$10$Cw3K.3S8tC57u.NntWEDouzattdTWx9JyVCc7gUOHnEX98kEL7QOC', NULL, '2022-01-11 16:30:25', '2022-01-11 16:30:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(81, 'test1', 'test1', '(343)344-3343', '010199@ratedapp.com', NULL, '$2y$10$3xRswTi/QoVf6jepv7/H6OUQ.7XT4cOC0nIn0TgeC/rKdhUp.sNsG', NULL, '2022-01-11 16:34:14', '2022-01-11 16:34:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(82, 'test2', 'test2', '(412)823-9842', '002999@ratedapp.com', NULL, '$2y$10$HerSttlNb2l9EElYQx1MBOdarnB4cRwG4nzKJAJV1Czi1/oHB5ZEG', NULL, '2022-01-11 16:34:14', '2022-01-11 16:34:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(83, 'Tooley\'s', 'Cafe', '(828)693-1373', '1@ratedapp.com', NULL, '$2y$10$hCLx/azF5fyp37ECVuHFqecmA3gDkD0WacjTUqfEsXJv.6nm9q2wO', NULL, '2022-01-11 16:42:54', '2022-01-11 16:42:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(84, 'Starlight', ' Lounge', '(412)828-9842', '2@ratedapp.com', NULL, '$2y$10$AtepWE08HVd/f4/Imv4Yo.USyCtgV5VKbNy5nEEW/kPaIwcaUkuda', NULL, '2022-01-11 16:42:54', '2022-01-11 16:42:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(85, 'Black', 'Water Bend Espresso', '(907)235-6884', '3@ratedapp.com', NULL, '$2y$10$KuCXk.HdnmshJnsydR.CaeaxhccPmAH0rsnmu3wR/RrAwi3o08Pu2', NULL, '2022-01-11 16:42:54', '2022-01-11 16:42:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(86, 'Restaurants', 'Unlimited', '(907)274-3502', '4@ratedapp.com', NULL, '$2y$10$1Y3ODofpzd7U4vabhME4GegPhtEqnBZVkMNi4r.GYgeNhPnBJfIdu', NULL, '2022-01-11 16:42:54', '2022-01-11 16:42:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(87, 'Club', '210 East', '(907)338-1422', '5@ratedapp.com', NULL, '$2y$10$8M2dvV2khJT/W54U27y1LOw11F/3MTkJvPTEfpjx7B3p/jJU47ouC', NULL, '2022-01-11 16:42:54', '2022-01-11 16:42:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(88, 'Dynasty', 'Gourmet Restaurant', '(907)277-1445', '6@ratedapp.com', NULL, '$2y$10$pkPo3w8ghMBbXsdoYuumJuRI9fEG2WLe23ZW8rTh3RenxsyEP8dNW', NULL, '2022-01-11 16:42:54', '2022-01-11 16:42:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(89, 'Bombay', 'Deluxe', '(907)277-1200', '7@ratedapp.com', NULL, '$2y$10$ETrpGZ9HfQ9y4dsEre5EwO/wQFPL0DQkKOFXGxf.VT4F0VcKtGF0.', NULL, '2022-01-11 16:42:54', '2022-01-11 16:42:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(90, 'Louie\'s', 'Place', '(907)349-6832', '8@ratedapp.com', NULL, '$2y$10$GMZp0LR7W1enixfRUA.YVuv5H1RNOGHBHHz/PuwK6kEn32MUtTTCe', NULL, '2022-01-11 16:42:54', '2022-01-11 16:42:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(91, 'Sourdough', 'Mining CO Restaurants', '(907)563-2272', '9@ratedapp.com', NULL, '$2y$10$1ek.GbthTV7HECaoUcWPAuje5v8FTvA74G75adTuQvMinjBCsQThu', NULL, '2022-01-11 16:42:54', '2022-01-11 16:42:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(92, 'Kaladi', 'Brothers Coffee CO - Brayton Square', '(907)344-6510', '10@ratedapp.com', NULL, '$2y$10$DNK7EHQWTlpxK0ccDdYqnOppvgyE0TfAr./XtWctrjkfRhbrEGvJK', NULL, '2022-01-11 16:42:54', '2022-01-11 16:42:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(93, 'Metroasis', ' Advanced Training Center', '(907)276-4110', '11@ratedapp.com', NULL, '$2y$10$qXPkW/OcrVtvuCLlXpXkKux.frWeZ4.x7uWJYBGSSfkJVs.wCz8m.', NULL, '2022-01-11 16:42:54', '2022-01-11 16:42:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(94, 'New', 'Lucky Strike Cafe', '(907)677-3933', '12@ratedapp.com', NULL, '$2y$10$oV64baa9VXpxLl9ToJnYNu07Eyy3QAX1n5NnSAw5vM8aMYbwJRft2', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(95, 'Piper\'s', 'Restaurant & Lounge', '(907)249-4444', '13@ratedapp.com', NULL, '$2y$10$lZMw7OIdSIkGJ2oGfv4sWeTVWKdabNDAVAiXsQjsfze9zdJnLbcCS', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(96, 'Jewel', 'Lake B&B (Ip)', '(907)245-7321', '14@ratedapp.com', NULL, '$2y$10$JRCHmIxblPwlDlbppDV2ne6JHBn51J7dTBpIb9BMSLTicJU1G9f1y', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(97, 'TOFU', 'House Restaurant', '(907)258-6715', '15@ratedapp.com', NULL, '$2y$10$h4ME/rNjk8I2W42/TT2Wh.xyEGomBKw3Yw8IRonKUVMLRNfAx4gMa', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(98, 'Denali', 'Foods Inc', '(907)562-3355', '16@ratedapp.com', NULL, '$2y$10$OQrN2Yb8lMaC9l3vyoj4KOBffM93TIO5FabjNTWi4Ml.sa0wsNQha', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(99, 'Hiland', 'Retreat B&B (Ip)', '(907)338-5946', '17@ratedapp.com', NULL, '$2y$10$Sf9g/8cglHjtci.OM6ZwE.4sUa8uRgPrtWaRsS435c1E3y3tK4bUe', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(100, 'Wayne\'s', 'Original Texas Bar-B-Que', '(907)569-9911', '18@ratedapp.com', NULL, '$2y$10$fVZwm49HeMObgIxWM20UaO0C39i.s6Qidgk4pTJTuufOuqOcVArhi', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(101, 'Kaladi', 'Brothers Coffee CO', '(907)563-0853', '19@ratedapp.com', NULL, '$2y$10$f5zZ.lXj9X0xoZ1PP5eieu.kOFNOY3uczy994DNM8a2W7tlr/jQ8W', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(102, 'Sourdoughs', 'Sourdoughs', '(907)274-6397', '20@ratedapp.com', NULL, '$2y$10$uN7I0UUX/5OIDGnsEOxpUOWDrwUhGCJwdW.5aTLY8fz9UDpiZ6/YO', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(103, 'O\'Brady\'s', 'Burger & Brew', '(907)344-8033', '21@ratedapp.com', NULL, '$2y$10$e22UHZJITvxdYv/5HwGEJecn52/ykGa.dXs7XHa/WAjJcfmHVuIbe', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(104, 'Fu', ' Do Chinese Restaurant', '(907)561-6610', '22@ratedapp.com', NULL, '$2y$10$hczmi0k08GZUJ1cELRELhu6.N3CEV3y/bzINLnl0GlsGCAGkGWKsy', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(105, 'Black', 'Angus Meat Market Restaurant', '(907)276-9117', '23@ratedapp.com', NULL, '$2y$10$pvnxlBtrGXGpupeDmMDsoOaLYVQxosQyrJUog77XJKNlHw.o1CFD2', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(106, 'How', 'How Chinese Restaurant', '(907)337-2116', '24@ratedapp.com', NULL, '$2y$10$Ri6Zl32imuqmeZKZJt42YuGdw/W1eHevrD4SgskpsYi9xsY0Nhcvi', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(107, 'Villa', 'Nova Restaurant &', '(907)561-1660', '25@ratedapp.com', NULL, '$2y$10$6yTW0xyt/WMDbKizegOSJuiZ94q01G3BVZogfhfb7NS.pjkk5IbNu', NULL, '2022-01-11 16:42:55', '2022-01-11 16:42:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(108, 'Mex', 'Express', '(907)349-5211', '26@ratedapp.com', NULL, '$2y$10$trND8CnL7qkHZHJdyxCGeOaBtyT0TxCR3MN25jRAtOS9GgKmjh1Sq', NULL, '2022-01-11 16:42:56', '2022-01-11 16:42:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(109, 'Middle', 'Way Cafe', '(907)272-6433', '27@ratedapp.com', NULL, '$2y$10$iULuJ8k1yKdVW9L5x1nDYe3LF81Ajmhcxj8dSUMtOo4lyQZyPccWW', NULL, '2022-01-11 16:42:56', '2022-01-11 16:42:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(110, 'New', 'Direction Ministries', '(907)561-3802', '28@ratedapp.com', NULL, '$2y$10$PBsI6dNDcSmDarsOXIX6f.XpIOFTdk.ItDRICciwbQcVdjBiMuw.u', NULL, '2022-01-11 16:42:56', '2022-01-11 16:42:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(111, 'Amigo\'s', 'Baja Grill', '(907)222-3031', '29@ratedapp.com', NULL, '$2y$10$rUzWz.ZYIR3c6njYP8PnjuPl0gfAoAaiP3ZiI5ThQP/AlkZTBxQd6', NULL, '2022-01-11 16:42:56', '2022-01-11 16:42:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(113, 'Arsal', 'Malik', NULL, '', NULL, '$2y$10$af9r/TnHSrnzVtvd2eRg4ONu.LrfPS1oIK9Y6w1N3HRlQpFuOZ6t2', NULL, '2022-01-16 18:19:16', '2022-01-16 18:19:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(114, 'malik', 'Malik', '', '', NULL, '$2y$10$j42XelAT/ChjObVQWvlIMedM/hXxiIbePkq83UV5U95NKVw.GUtUC', NULL, '2022-01-18 20:16:40', '2022-01-18 20:16:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(115, 'ABC', 'XYZ', NULL, '', NULL, '$2y$10$V8Hlb7m3TqH1itEjVSD0iem9Uy/ZjRHGggJ44PpOZpJL.nA3jHKx2', NULL, '2022-01-20 07:51:31', '2022-01-20 07:51:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(116, 'Arsal', 'Malik', NULL, '', NULL, '$2y$10$vtnTTa.OR0KdC0pr/8TbnOfaREvc.7AM0q1wvxoii8cA59J.LxK9C', NULL, '2022-01-20 07:54:37', '2022-01-20 07:54:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(117, 'Arsal', 'Malik', '', '', NULL, '$2y$10$UzOIw2zsxTpJ8KuFsClhsezDz2hH0QMYSu41a0tvn3WlFgSsucAfm', NULL, '2022-01-20 19:46:31', '2022-01-20 19:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(118, 'malik', 'Malik', '', '', NULL, '$2y$10$NQlly/50O7oLb4jLnxq5lufsHxVTN6Mr9luZwg0B/ScXZekgtyl2u', NULL, '2022-01-20 19:46:31', '2022-01-20 19:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(119, 'ABC', 'XYZ', '', '', NULL, '$2y$10$SwqjDm7iHht0dcl7WDppreO0An0M8FFOL334.1nuUkHRLrF0w5V4i', NULL, '2022-01-20 19:46:32', '2022-01-20 19:46:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(120, 'Arsal', 'Malik', '', '', NULL, '$2y$10$rGoEaNyEwoIS7Sz2PnIt/uiajgSQzcV62mTXQ5yaXg/1xmNIoCu32', NULL, '2022-01-20 19:46:32', '2022-01-20 19:46:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(121, 'Arsal', 'Malik', '', 'atifzakariyan+2@gmail.com', NULL, '$2y$10$Yv.3C8OcqDudgNi3Nm0aJ.mpdBCwLehYf5WJ8XviVSov9jYi/.9N6', NULL, '2022-01-20 21:18:43', '2022-01-20 21:18:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(122, 'malik', 'Malik', '', 'atifzakariyan+3@gmail.com', NULL, '$2y$10$JkTzILQVfAsfXBChl8EWYeoKvHsg00uQem1eVNsdXPUwrDLhGvn4e', NULL, '2022-01-20 21:18:43', '2022-01-20 21:18:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(123, 'ABC', 'XYZ', '', 'atifzakariyan+4@gmail.com', NULL, '$2y$10$TQJkyGPd/Tz8sFS17kJvkeOFCrNkqCQ9CZ//rTIu7f24c2BGhmXo6', NULL, '2022-01-20 21:18:43', '2022-01-20 21:18:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(124, 'Arsal', 'Malik', '', 'atifzakariyan+5@gmail.com', NULL, '$2y$10$eAGN4D.V/xcRIfAP7f8F3uoC3RGm5XG0mFXtdXzzbaQ.pv7L160qi', NULL, '2022-01-20 21:18:43', '2022-01-20 21:18:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(125, 'Arsal', 'Malik', '', 'a1@gmail.com', NULL, '$2y$10$5.hZuqGDhB9dCfIt.5iaDOo0/mPDhcT3/uGM7nMxBsnKQ0VPKoMze', NULL, '2022-01-20 22:01:32', '2022-02-19 04:29:53', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(126, 'malik', 'Malik', '', 'a2@gmail.com', NULL, '$2y$10$MXhQRV9w3FTzV5eu1olISO1lK./YSe3fNzf81UqeVInrLV.c8zJ96', NULL, '2022-01-20 22:01:32', '2022-02-19 04:29:59', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(127, 'ABC', 'XYZ', '', 'a3@gmail.com', NULL, '$2y$10$pxITqaoM3N907W0.CLqcYOnzydnvoS88uVt2n14919v4.4mW9Dwqy', NULL, '2022-01-20 22:01:32', '2022-02-19 04:30:30', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(128, 'Arsal', 'Malik', '', 'a4@gmail.com', NULL, '$2y$10$5Y7XdxsGUvwGPxSu8FNVwO2jcx1HC1z1HZTJ4HLTanx5OEEN7hdrO', NULL, '2022-01-20 22:01:32', '2022-02-19 04:30:12', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(129, 'TANGS GROUP                             ', 'TANGS GROUP                             ', '2392781881', 'store1@teamafricorp.com', NULL, '$2y$10$bhllIIf8MvtiarzO8co58.8hKaCXKm6UZc4LHOhLr0qc//Arcbie2', NULL, '2022-01-22 18:33:10', '2022-01-22 18:33:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(130, 'KAREZI INC                                        ', 'KAREZI INC                                        ', '2399493080', 'store2@teamafricorp.com', NULL, '$2y$10$eqhQAR7WNs6nWImDPBcVveetrcHOCYd7Z9/6h0LNwMCX9qFF1uN9S', NULL, '2022-01-22 18:33:10', '2022-01-22 18:33:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(131, 'SWFRI & GLADIOLUS LTD                             ', 'SWFRI & GLADIOLUS LTD                             ', '2394329500', 'store3@teamafricorp.com', NULL, '$2y$10$cJ.ynPJXxhVexA.Qp5w8V.fl97ywG0Htr23pqrY9JNcNJSNkrShii', NULL, '2022-01-22 18:33:10', '2022-01-22 18:33:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(132, 'FENNELL CHARLOTTE ANNE                            ', 'FENNELL CHARLOTTE ANNE                            ', '2399392144', 'store4@teamafricorp.com', NULL, '$2y$10$AkeUXKSYe5CjZhF2S60PaOJ1hbxoeotoxr1bLis4c0VS7Jg7v6Jg2', NULL, '2022-01-22 18:33:10', '2022-01-22 18:33:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(133, '7 ELEVEN INC & MIGS VENTURE INC                   ', '7 ELEVEN INC & MIGS VENTURE INC                   ', '2399454844', 'store5@teamafricorp.com', NULL, '$2y$10$xtNdOF/ECtAS5e.nk7ZB4O/SJgDlgrgpCr4/g.u7J/jvFDfGND.7q', NULL, '2022-01-22 18:33:11', '2022-01-22 18:33:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(134, 'GULF HARBOUR GOLF AND COUNTRY CLUB                ', 'GULF HARBOUR GOLF AND COUNTRY CLUB                ', '2394335111', 'store6@teamafricorp.com', NULL, '$2y$10$d3LbOvSpNppoG6pX2VhiJeTxN3jkBhc1mhMdw47BTqQocDOEjxE6q', NULL, '2022-01-22 18:33:11', '2022-01-22 18:33:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(135, 'K CORP LEE INC                          ', 'K CORP LEE INC                          ', '2394956599', 'store7@teamafricorp.com', NULL, '$2y$10$fDt9g8XrqBTPmFKu1gWPzu5PvXy93E29A13N2i4E.OwRPJtx1nJOK', NULL, '2022-01-22 18:33:11', '2022-01-22 18:33:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(136, 'SKILLETS INC', 'SKILLETS INC', '2399929333', 'store8@teamafricorp.com', NULL, '$2y$10$TGP.ysCqJLTdzmBOYcnK7.iHyFgbu3zIq2sjqbzXF13NkPpK5q476', NULL, '2022-01-22 18:33:11', '2022-01-22 18:33:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(137, 'LEHMANN ENTERPRISES, LLC                          ', 'LEHMANN ENTERPRISES, LLC                          ', '2394378664', 'store9@teamafricorp.com', NULL, '$2y$10$Hs8sPTLU6EnCyhPglzFugucM.4B64G6WcrGMZ/NFYRvdwGkzWkUmK', NULL, '2022-01-22 18:33:11', '2022-01-22 18:33:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(138, 'TANGS GROUP                             ', 'TANGS GROUP                             ', '2392781881', 'store1@teamafricorp.com', NULL, '$2y$10$Os/lsujBT.VfTGwYVLStVONbK3bd0tY103FA3EK3mEkhBgFNd.fzS', NULL, '2022-01-22 18:39:36', '2022-01-22 18:39:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(139, 'KAREZI INC                                        ', 'KAREZI INC                                        ', '2399493080', 'store2@teamafricorp.com', NULL, '$2y$10$02hbO.dMGRII2mkAbwP6yeXm8aMLYW6fw6ev2NPmxxQ.zAc9ivvj.', NULL, '2022-01-22 18:39:36', '2022-01-22 18:39:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(140, 'SWFRI & GLADIOLUS LTD                             ', 'SWFRI & GLADIOLUS LTD                             ', '2394329500', 'store3@teamafricorp.com', NULL, '$2y$10$grhnH8KA7PHzpZ6Ht6C8sOkrGIALnhiLhRGDih5qo46v0j1hlM65m', NULL, '2022-01-22 18:39:36', '2022-01-22 18:39:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(141, 'FENNELL CHARLOTTE ANNE                            ', 'FENNELL CHARLOTTE ANNE                            ', '2399392144', 'store4@teamafricorp.com', NULL, '$2y$10$n4l6UVSQfxOMO34MFPJu/OV0gC73SYhlrSNOme1cXlof7qWnQJaDC', NULL, '2022-01-22 18:39:36', '2022-01-22 18:39:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(142, '7 ELEVEN INC & MIGS VENTURE INC                   ', '7 ELEVEN INC & MIGS VENTURE INC                   ', '2399454844', 'store5@teamafricorp.com', NULL, '$2y$10$zYHBiQ0eQceAofpcLCvoaObvS5Sgb3N8KpfxgERHfOqi0aKI0IMtq', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(143, 'GULF HARBOUR GOLF AND COUNTRY CLUB                ', 'GULF HARBOUR GOLF AND COUNTRY CLUB                ', '2394335111', 'store6@teamafricorp.com', NULL, '$2y$10$gFxzb2TivFd/4SNgXQCAEeF9Mffhu7fESzlYwTW.5Ho5zOfHDPPsm', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(144, 'K CORP LEE INC                          ', 'K CORP LEE INC                          ', '2394956599', 'store7@teamafricorp.com', NULL, '$2y$10$jMEGmlWGUzTGBkbYXJHCW.FSEFDY/1DNNHPHtvW33cuRLTqfzYAiK', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(145, 'SKILLETS INC', 'SKILLETS INC', '2399929333', 'store8@teamafricorp.com', NULL, '$2y$10$w.IBo.SLecERgf5Ab0T3yeN3zrxoNxQR7yQCwqPXhb4DD43ZJyCE2', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(146, 'LEHMANN ENTERPRISES, LLC                          ', 'LEHMANN ENTERPRISES, LLC                          ', '2394378664', 'store9@teamafricorp.com', NULL, '$2y$10$Lh101KaHflNVJaJU4Sn8qu9tfbrWtE09c4tMpt5ZlXucE7vncoM3S', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(147, '7 ELEVEN INC AND BEACH STEIL INC                  ', '7 ELEVEN INC AND BEACH STEIL INC                  ', '2395613070', 'store10@teamafricorp.com', NULL, '$2y$10$XA46pGBvyFbWZN.8V4Bx0unfm2JlpIISkrdw91NG6U4CFuAlGx24m', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(148, 'CAPE\'S BURGERS & SHAKES INC                       ', 'CAPE\'S BURGERS & SHAKES INC                       ', '2397722357', 'store11@teamafricorp.com', NULL, '$2y$10$OsDHzfB4eS2/iBvOtE6mcOHWsAcvRoDINx4pvE/PQhBuLiD7AaYgK', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(149, 'C G GOLD INVESTMENTS CORP                         ', 'C G GOLD INVESTMENTS CORP                         ', '2399458668', 'store12@teamafricorp.com', NULL, '$2y$10$rNFPWEBJf2Tt0G95i4uND.kT8R2QNAsJia9V1JhrxAkjlmboP/F/i', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(150, 'ESN CAPE INC                            ', 'ESN CAPE INC                            ', '2394154262', 'store13@teamafricorp.com', NULL, '$2y$10$30ATQI5qMFcGMzSQKnhZ4OkrRsWd4eH14tMU1w8rZm85ofwAceotK', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(151, 'TORTILLERIA LA RANCHERITA INC                     ', 'TORTILLERIA LA RANCHERITA INC                     ', '2392535890', 'store14@teamafricorp.com', NULL, '$2y$10$kerEkQk9tLjvkKuOOY9ws.vAKcRKliNRhPseKrXtKcFXJQY7QcQfi', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(152, 'MATHEUS RETAILS OF SWFL INC                       ', 'MATHEUS RETAILS OF SWFL INC                       ', '2392775638', 'store15@teamafricorp.com', NULL, '$2y$10$E4SDZP2KHzUCog.bNb5ORu4pKpg8rjI0JvXePJRsnkffsVo2tNxge', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(153, 'LA VENEZIA CORPORATION                            ', 'LA VENEZIA CORPORATION                            ', '2399450034', 'store16@teamafricorp.com', NULL, '$2y$10$jB9xU.P1oNMahfO1g5PQS.6MZ1Ps9Bb8nFa4MIgDrRNoInJRySzku', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(154, 'QFRM 7 LLC                                        ', 'QFRM 7 LLC                                        ', '4077238103', 'store17@teamafricorp.com', NULL, '$2y$10$bcSqaMV2e4R1LEmZE2b25OY6bGAy2sILYG4LmlRNI9Fks.uIYAqdW', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(155, 'PE CAMINA LLC                                     ', 'PE CAMINA LLC                                     ', '2399395344', 'store18@teamafricorp.com', NULL, '$2y$10$AypdASgMpuNLO5OhVigG9uuGY/KG0BaZm9oMr7SSOH4dxKRwoh.SW', NULL, '2022-01-22 18:39:37', '2022-01-22 18:39:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(156, 'RIB CITY LEHIGH LLC                               ', 'RIB CITY LEHIGH LLC                               ', '2392756700', 'store19@teamafricorp.com', NULL, '$2y$10$.nI2SU3idS4mFDe0tW5hl.Rn1cB8kt2/cAFod9OY0QvzU74PvayHa', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(157, 'THE COMMONS CLUB AT THE BROOKS INC                ', 'THE COMMONS CLUB AT THE BROOKS INC                ', '2394987777', 'store20@teamafricorp.com', NULL, '$2y$10$TZzNxzAg.pL1WrB9rzzlEOsRalcNdB5iXEWmc8DFNULjTzIAVRrVG', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(158, 'WINKLER HOUSE CORP OF SW FL                       ', 'WINKLER HOUSE CORP OF SW FL                       ', '2392781749', 'store21@teamafricorp.com', NULL, '$2y$10$Yk/wjm1CCJNHBDIBT9BdS.lOCXd5RO96PhUsiOjdCjSbHsJojBaKO', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(159, 'LEONIS PIZZERIA 1 LLC                             ', 'LEONIS PIZZERIA 1 LLC                             ', '2394159000', 'store22@teamafricorp.com', NULL, '$2y$10$8W9g1sXRGpgSG2LG1IzeQuIZ.rk.2UIxRPzkgGnDz9W3S0fltMIQ2', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(160, 'TORCHIATI LLC                                     ', 'TORCHIATI LLC                                     ', '2394636139', 'store23@teamafricorp.com', NULL, '$2y$10$qKL6AeWRkNar3Rz5J/w2r.zVjTX4nDsuH0Jb3vB0n02tewL.QfEy6', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(161, 'GULF HARBOUR GOLF AND COUNTRY CLUB                ', 'GULF HARBOUR GOLF AND COUNTRY CLUB                ', '2394335111', 'store24@teamafricorp.com', NULL, '$2y$10$NaDGdPz46G1y8nF0USH51OdU9zFArYRNPlgaYcuiI6zmKLCyJn2Fm', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(162, 'MARIAS PIZZERIA INC                     ', 'MARIAS PIZZERIA INC                     ', '2395409595', 'store25@teamafricorp.com', NULL, '$2y$10$5kOjZC8SuMyykUNgSx4qau5GYiCInqKBRJftl.kOstitDeFEQ98oC', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(163, 'GULF WATERS RV RESORT LLC               ', 'GULF WATERS RV RESORT LLC               ', '2394375888', 'store26@teamafricorp.com', NULL, '$2y$10$j1V7NLnycBW69oKHzU4ArO0AKaplPXClcntSv9zidRROdvwc8eP8a', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(164, 'WILDCAT RUN OF LEE COUNTY INC           ', 'WILDCAT RUN OF LEE COUNTY INC           ', '2399476066', 'store27@teamafricorp.com', NULL, '$2y$10$bUhAZyPSMdGwqc6EuJylxePquv/m2E0xZJ76iiEoYRdm3ON4F7D6O', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(165, 'WILDCAT RUN GOLF & COUNTRY CLUB ASSOCIATION INC   ', 'WILDCAT RUN GOLF & COUNTRY CLUB ASSOCIATION INC   ', '2399476084', 'store28@teamafricorp.com', NULL, '$2y$10$7mXh0mZwAwzH/6tTgUehU.FSKZewMlnzXHTagB.JOE17k23hdR/pm', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(166, 'HERONS GLEN RECREATION DISTRICT                   ', 'HERONS GLEN RECREATION DISTRICT                   ', '2393342722', 'store29@teamafricorp.com', NULL, '$2y$10$uugVTH9b4CfvnMmLAkvwk.J2Mh030ejvBkzBLe/3GugYtCjG/4kSS', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(167, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '8139106800', 'store30@teamafricorp.com', NULL, '$2y$10$8tpvuYbRg7GGZUsrh3lPB.j.Wl5Ec/oFomZwVzayv8gk/vTzBcKvC', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(168, 'FURMANS INC', 'FURMANS INC', '9413657891', 'store31@teamafricorp.com', NULL, '$2y$10$ERnKp5tcJSKtCUyfv/i3HOc.RVUUcIBVX1P1NrSRWhm4PwrVy2LIy', NULL, '2022-01-22 18:39:38', '2022-01-22 18:39:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(169, 'FURMANS INC', 'FURMANS INC', '9413657891', 'store32@teamafricorp.com', NULL, '$2y$10$Tk2FNLw4KgTRWZ4C5.dH9ezvBycCpQR5497r5fYROZtnZNWw9ajoa', NULL, '2022-01-22 18:39:39', '2022-01-22 18:39:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(170, 'OM OF SW FLORIDA LLC                              ', 'OM OF SW FLORIDA LLC                              ', '2399392323', 'store33@teamafricorp.com', NULL, '$2y$10$KRFPnN0dE4BxXknF17DZMugEs2sOx5qjzBDT1vsE2/vODm1dlzlJe', NULL, '2022-01-22 18:39:39', '2022-01-22 18:39:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(171, 'KRAFT HEINZ FOODS INC                             ', 'KRAFT HEINZ FOODS INC                             ', '2396934480', 'store34@teamafricorp.com', NULL, '$2y$10$eaGS2GSmqwo9SoSGA.RtQOUKRdT2fAer/ybShfM8ZRuD3iPe6mZde', NULL, '2022-01-22 18:39:39', '2022-01-22 18:39:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(172, 'BRAVOFLORIDA LLC                                  ', 'BRAVOFLORIDA LLC                                  ', '2393900373', 'store35@teamafricorp.com', NULL, '$2y$10$j64btxVxL0Oyj75Ce.nN7OR8gr6D2DnaMUgQUK7HriU.1jNyU/oiS', NULL, '2022-01-22 18:39:39', '2022-01-22 18:39:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(173, 'STAMATIS FAMILY RESTAURANT INC                    ', 'STAMATIS FAMILY RESTAURANT INC                    ', '2396529999', 'store36@teamafricorp.com', NULL, '$2y$10$QlcOpPT59OiWNqTqH/7FwuWcrGvfK3ypLNdoQ4ORvPD8/SxyVw9xe', NULL, '2022-01-22 18:39:39', '2022-01-22 18:39:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(174, 'SUNSHINE RESTAURANT MERGER SUB LLC                ', 'SUNSHINE RESTAURANT MERGER SUB LLC                ', '9546186300', 'store37@teamafricorp.com', NULL, '$2y$10$m93d1DwZkIMhaflu.weQY.pieMtbT/MGBgJ8REdC6EK4dIinKtJtu', NULL, '2022-01-22 18:39:39', '2022-01-22 18:39:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(175, 'FLORIDA SE INC                                    ', 'FLORIDA SE INC                                    ', '2394549234', 'store38@teamafricorp.com', NULL, '$2y$10$t9WXGa.76psn53yx6n12K.KGlrZ.DO9VGAxPgaDyuZ0Ok.GUousXO', NULL, '2022-01-22 18:39:39', '2022-01-22 18:39:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(176, 'NORTH CAPTIVA ISLAND CLUB INC                     ', 'NORTH CAPTIVA ISLAND CLUB INC                     ', '2393958898', 'store39@teamafricorp.com', NULL, '$2y$10$xcS89u9hjNTPBzzgcRKQaeuhgsEpXns4KPYMgvFNR15pRK1yRDeIe', NULL, '2022-01-22 18:39:39', '2022-01-22 18:39:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(177, 'NORTH CAPTIVA ISLAND CLUB INC                     ', 'NORTH CAPTIVA ISLAND CLUB INC                     ', '2393951500', 'store40@teamafricorp.com', NULL, '$2y$10$v8PtP5F5FgNTBEfS9q3HmeWSwZ/uzXhBwHm2ngdEzjaemFpLgqGee', NULL, '2022-01-22 18:39:39', '2022-01-22 18:39:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(178, 'HERITAGE PALMS GOLF AND COUNTRY CLUB INC          ', 'HERITAGE PALMS GOLF AND COUNTRY CLUB INC          ', '2392781361', 'store41@teamafricorp.com', NULL, '$2y$10$sd4.6bOVBimul/EyT1RRFObdFEDtUW6IEAiO8Stx4wSQ1ZibpQL6y', NULL, '2022-01-22 18:39:39', '2022-01-22 18:39:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(179, 'PUBFMB LLC                                        ', 'PUBFMB LLC                                        ', '2394634644', 'store42@teamafricorp.com', NULL, '$2y$10$p0zZ2Cmuo7mlXIJycSEQ9eOgZmQad8zKD69a1QBSq3hlmIMfjz162', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(180, 'GUENTHER INC OF LEHIGH ACRES            ', 'GUENTHER INC OF LEHIGH ACRES            ', '2393030688', 'store43@teamafricorp.com', NULL, '$2y$10$g9LQoRZYw14kyKCz562bBOl/fNShfE4Z80eAJSYvcC/9Ku4hpbzLi', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(181, 'RSW HOSPITALITY INC                     ', 'RSW HOSPITALITY INC                     ', '2392823232', 'store44@teamafricorp.com', NULL, '$2y$10$NKzf8kLhLsTOU0kwzgsvee7lRnQleFyXCL9JEIadwQmzQU1OqGz/W', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(182, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '8412674660', 'store45@teamafricorp.com', NULL, '$2y$10$zGAlHNypQXYxyaMmft2sCeeid4IieEQOGX/zfWJaciQ1V9C6wDuvW', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(183, 'COLONY GOLF & COUNTRY CLUB INC                    ', 'COLONY GOLF & COUNTRY CLUB INC                    ', '2393904703', 'store46@teamafricorp.com', NULL, '$2y$10$M1iHBfeNIrJwdEHqhhauG.jfeN/Y8Jo5n/pfck9MOyH4Fw/h5.FfG', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(184, 'PELICAN SOUND GOLF AND RIVER CLUB INC   ', 'PELICAN SOUND GOLF AND RIVER CLUB INC   ', '2399484331', 'store47@teamafricorp.com', NULL, '$2y$10$d.Uf7Z0HB25v/J.SKTn9uO4dscJ0r96TGVwWyshUt9OM16GUolFCe', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(185, 'R C OTTERS CAPTIVA LLC                            ', 'R C OTTERS CAPTIVA LLC                            ', '2393951142', 'store48@teamafricorp.com', NULL, '$2y$10$DNeBZ4hwOfwe1Dar7BEwDu7OsXxFZ9c206D414On7bw./OYLvSITS', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(186, 'DOLLYS  PRODUCE PATCH', 'DOLLYS  PRODUCE PATCH', '2399928939', 'store49@teamafricorp.com', NULL, '$2y$10$GPn8zFVFx/VLUB0h61q8CuzmjZtCajgX6U54rUt2hf3UGV20iN2mK', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(187, 'AMBIKA 12 CORP                                    ', 'AMBIKA 12 CORP                                    ', '2396946003', 'store50@teamafricorp.com', NULL, '$2y$10$ulInI8cXHGVgjp32XadpFecMbvuPqeF.QBAbcOVohZ7BaXCZgzK.W', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(188, '7 ELEVEN INC & METRO FOOD CENTERS INC             ', '7 ELEVEN INC & METRO FOOD CENTERS INC             ', '2394988649', 'store51@teamafricorp.com', NULL, '$2y$10$yr3y/fpY3mO1zRasKa44deETi55kjpbOmfe9wtuoTWcsxO15cXmgO', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(189, 'PERKINS LLC                                       ', 'PERKINS LLC                                       ', '7703251306', 'store52@teamafricorp.com', NULL, '$2y$10$KTw.tn88iWjdXElnL29dFeoLuu7mCfQlBQ69bR2HkI.7dL0sh7nnO', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(190, 'PERKINS LLC                                       ', 'PERKINS LLC                                       ', '7073751306', 'store53@teamafricorp.com', NULL, '$2y$10$ATLHfML3DexEDBQoDnVrd.kUgmVbPHh/ebI53/KRxE8n1Ez/4K8GK', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(191, 'CHINA TOWN RESTAURANT INC                         ', 'CHINA TOWN RESTAURANT INC                         ', '2396562980', 'store54@teamafricorp.com', NULL, '$2y$10$62TjIsH252OU9ejiHuhdcev790g5aPOCHOTvXANIJrBINo8dqzZxy', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(192, 'JONES ARON  & LAVERNE                             ', 'JONES ARON  & LAVERNE                             ', '2393342134', 'store55@teamafricorp.com', NULL, '$2y$10$Em1iJeN.HYTrskwxFTVIwegxS0s/jwf8P3/I6d463zqxjpA7H1NYe', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(193, 'FLORIDA DEVELOPMENT PARTNERS LC                   ', 'FLORIDA DEVELOPMENT PARTNERS LC                   ', '2399482900', 'store56@teamafricorp.com', NULL, '$2y$10$8p9di1dSIubvx2FO/s.lMu8wH..z6quKiIEuKOuXwWgVKajCdS3s2', NULL, '2022-01-22 18:39:40', '2022-01-22 18:39:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(194, 'PINK HAUS CORP                                    ', 'PINK HAUS CORP                                    ', '2394637707', 'store57@teamafricorp.com', NULL, '$2y$10$W41XcUsZj5TvQs2RUEwwheAjVNBjws1JrWxw1Sgr/UgzwfahQF1ma', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(195, 'MIXTECO CARNICERIA & MINIMARKET LLC               ', 'MIXTECO CARNICERIA & MINIMARKET LLC               ', '2396769874', 'store58@teamafricorp.com', NULL, '$2y$10$vqeIzLAZP.rZ2pEeYzSK9uW3aLrTCbl0nVINeC1o9WUWx8fI6UICu', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(196, 'VICTORY LANE CAFE INC                             ', 'VICTORY LANE CAFE INC                             ', '2399950340', 'store59@teamafricorp.com', NULL, '$2y$10$Cd/6.C7cS4N4QDqb/3rD8O8hPcyqMNYjJWYLqBMZ5zcUzsgjt3Px6', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(197, 'HEAVENLY BISCUIT INC                              ', 'HEAVENLY BISCUIT INC                              ', '2394637600', 'store60@teamafricorp.com', NULL, '$2y$10$xp9L/QU1U5wr0N0EsjZGPud3T/y7.N9QQYso/6ChLhhaoy66oEQaC', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(198, 'BIG HICKORY SEAFOOD GRILL & DELI LLC              ', 'BIG HICKORY SEAFOOD GRILL & DELI LLC              ', '2399920991', 'store61@teamafricorp.com', NULL, '$2y$10$rzfsFY9G/LGEtwon4FYIlOeYMf5VNZlggx9WprNpWavL4omofUyIq', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(199, 'WEST BAY GOLF CLUB INC                  ', 'WEST BAY GOLF CLUB INC                  ', '2394987770', 'store62@teamafricorp.com', NULL, '$2y$10$EUF2EAj9VBxfcRjYJD4GOuvbJkPGVYaTJXqVDmOZzbGLHCVSNypQK', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(200, 'QFRM 7 LLC                                        ', 'QFRM 7 LLC                                        ', '2399487030', 'store63@teamafricorp.com', NULL, '$2y$10$qYhMm3h35xWTnOTb.qOEV.WEEbHB6ibua6Yss4iiwQo.8i/4mPNo6', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(201, '7 ELEVEN INC & GATEWAY CONVENIENCE INC            ', '7 ELEVEN INC & GATEWAY CONVENIENCE INC            ', '2392953076', 'store64@teamafricorp.com', NULL, '$2y$10$cioPj4bgjzhEK7aSqzB6pevi5DR7vMfHl51Q7y3p7pnlLNHoRi0QS', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(202, 'CHENG FAMILY LLC                                  ', 'CHENG FAMILY LLC                                  ', '2395378811', 'store65@teamafricorp.com', NULL, '$2y$10$jZKy6TDas6Ny5ZdRTyNl3.k5mR5TYhlmP3BQXBE0s7Mc/ejc3h9z2', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(203, 'COPPERLEAF GOLF CLUB COMMUNITY ASSOC INC          ', 'COPPERLEAF GOLF CLUB COMMUNITY ASSOC INC          ', '2393902027', 'store66@teamafricorp.com', NULL, '$2y$10$ersdzroGgR6ugJWxHFRzLOq46swIV8FUGropHjUxMIT3GmGJmItcW', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(204, 'NEW NUMBER 1 WOK INC                    ', 'NEW NUMBER 1 WOK INC                    ', '2394158838', 'store67@teamafricorp.com', NULL, '$2y$10$a2b.GpRQgWS7jo/K268y6.jHvRWLWowKVDrfxmWwSoYHst5oeOwMa', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(205, 'EVERYBODYS BRUNCH PLACE INC             ', 'EVERYBODYS BRUNCH PLACE INC             ', '2395670300', 'store68@teamafricorp.com', NULL, '$2y$10$S5Uux3WQs.sOO3l32YdIruIGTKqZsPhJtXR6ohbIATt/PtJx9Nhtm', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(206, 'WANG YAN LIN                                      ', 'WANG YAN LIN                                      ', '2395745833', 'store69@teamafricorp.com', NULL, '$2y$10$s9iegadtDDczFxtoEh0f0.dgfHKgVERTVg9SzVbcdMKI9U7o0eheC', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(207, 'OZTURK FAMILY INC                       ', 'OZTURK FAMILY INC                       ', '2392672707', 'store70@teamafricorp.com', NULL, '$2y$10$k2LC/hyLoxoJiywGPLqUKuNmX/eJ6eJbdv41iJH9aS0HzneRoLhCK', NULL, '2022-01-22 18:39:41', '2022-01-22 18:39:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(208, 'PELICAN LANDING GOLF RESORT VENT LP               ', 'PELICAN LANDING GOLF RESORT VENT LP               ', '2393904603', 'store71@teamafricorp.com', NULL, '$2y$10$WkTTIO/LGLB8Y7JGNHeEtOYLiILgVfxMW0ZtfE11b6g0nFLYYOBfW', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(209, 'THE COLONY CLUB & COUNTY CLUB INC                 ', 'THE COLONY CLUB & COUNTY CLUB INC                 ', '2393904703', 'store72@teamafricorp.com', NULL, '$2y$10$gcLx4gbJaWKxUpN4am1re.jQVE4LPGkS/cYHwhnRk0murNqyj9W.6', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(210, 'COPPERLEAF GOLF CLUB COMM ASSOC INC               ', 'COPPERLEAF GOLF CLUB COMM ASSOC INC               ', '2393902027', 'store73@teamafricorp.com', NULL, '$2y$10$PH22PII11Q7iyOGRs45dUusUQivx1rZGYJL./tI6/aIvHCIo7B.QS', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(211, 'SUBWAY 24083 LLC                                  ', 'SUBWAY 24083 LLC                                  ', '2394377625', 'store74@teamafricorp.com', NULL, '$2y$10$IqEOc.gWkYGmwS3JBGyWf.0N2eUJp9hMhJcB3szCJ5cYxSp3ckoM6', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(212, 'SALAMA OF DUNCAN ROAD INC                         ', 'SALAMA OF DUNCAN ROAD INC                         ', '2392429780', 'store75@teamafricorp.com', NULL, '$2y$10$LeTqqTBPvoaZwan.ebPPwuTAb03hJl7MyaoF72YmkS0bbVbiM6K4y', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(213, 'BUCKINGHAM OIL INC                      ', 'BUCKINGHAM OIL INC                      ', '2396935411', 'store76@teamafricorp.com', NULL, '$2y$10$DUkrFC7rydpXnUvTceWla.pJ577cpJAAvvy7jFmNEW4FrsFBSS3eG', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(214, 'LA FONTANELLA RISTORANTE INC                      ', 'LA FONTANELLA RISTORANTE INC                      ', '2394986808', 'store77@teamafricorp.com', NULL, '$2y$10$lOtxpMF1A3yYz4IT68yDauEo.am5oDh5GRZkET672gY.8Pbdw/VL6', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(215, 'FIRST WATCH ENTERPRISES INC                       ', 'FIRST WATCH ENTERPRISES INC                       ', '9419079800', 'store78@teamafricorp.com', NULL, '$2y$10$Eeem6tV2pvDK8kkcyZ4ZLejyu28rXtOOwknQOAHrSSNeNbsnnGlMC', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(216, 'WILROCK  FORT MYERS LLC                 ', 'WILROCK  FORT MYERS LLC                 ', '2395909994', 'store79@teamafricorp.com', NULL, '$2y$10$9Ar5tt.SWranJFBRacT8guoOqnqeaUQ4eWcGQNaVty.M9oPmOWZoe', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(217, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '2392785162', 'store80@teamafricorp.com', NULL, '$2y$10$8Yj6Gyr8A1EW1hLeJwsUUOXpml4WttnTCL4QGNIYw/45ypBkZ7NdK', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(218, 'A TOUCH OF ITALY INC                              ', 'A TOUCH OF ITALY INC                              ', '2394337717', 'store81@teamafricorp.com', NULL, '$2y$10$ftoT2cXePxHoiNeosXIPzOq0Sfa4baVqfSzzV6CPCAYZuqL3o9Oky', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(219, 'QUILLEN GREG                                      ', 'QUILLEN GREG                                      ', '2399924677', 'store82@teamafricorp.com', NULL, '$2y$10$qpXlZqO3tmIBQBMaaqRhDOHEg/LkaQuzRnuMHeFJYliEaN6OLErfO', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(220, 'BUON APPETITO CAFE INC                  ', 'BUON APPETITO CAFE INC                  ', '2394330117', 'store83@teamafricorp.com', NULL, '$2y$10$we.9MV2lI3FoabvDMJK3jOX2mj8ZvyEx4xSgKKiORiClgJ0KzK4qy', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(221, 'HE ZHIQI                                          ', 'HE ZHIQI                                          ', '2393320888', 'store84@teamafricorp.com', NULL, '$2y$10$EEdN4vC2K2.pSb6RIpxkGeouRVzNwcyhE1JWbn5pIqpoYN574g9eu', NULL, '2022-01-22 18:39:42', '2022-01-22 18:39:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(222, 'SNSMARIA LLC                                      ', 'SNSMARIA LLC                                      ', '2392749500', 'store85@teamafricorp.com', NULL, '$2y$10$813uJNoxB3.IX4Qz5llgGeOgfuUIqiabMbPpHt00iYcfUUpj7IFgW', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(223, 'MARIAS RESTAURANT INC                             ', 'MARIAS RESTAURANT INC                             ', '2394951868', 'store86@teamafricorp.com', NULL, '$2y$10$DU5V7C0xskt.bj7N0M.xa.lDfIyDwk.RwYo4cQdfAAgDhG/vYk09O', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(224, 'RT TAMPA FRANCHISE LP                             ', 'RT TAMPA FRANCHISE LP                             ', '8653795700', 'store87@teamafricorp.com', NULL, '$2y$10$14Ecyngjs.06TSOiTYtoTekJocWzaNFM354Xyig4DvWiVud33Jnyu', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(225, 'COOPER MOSES                            ', 'COOPER MOSES                            ', '2393320594', 'store88@teamafricorp.com', NULL, '$2y$10$4Kw1SAJQVaYIofZcH354H.7mmKxde.siFW1tB77wauI9EIhziUm8q', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(226, 'MIKE AN DMIKEY ENTERPRISES LLC                    ', 'MIKE AN DMIKEY ENTERPRISES LLC                    ', '2392834668', 'store89@teamafricorp.com', NULL, '$2y$10$IQdOjqdcLWqVtFTPQ9A.jeXX4Ck8w0RcW0E317TvYrsyQYkU14LM.', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(227, 'CABRAL-JORDAN MEDITERANNENA CUISINE CORP          ', 'CABRAL-JORDAN MEDITERANNENA CUISINE CORP          ', '2395603044', 'store90@teamafricorp.com', NULL, '$2y$10$vG9HqlVwaeDtJhnFjfVtTOUhDA36bGzBjGx1WVf/hOoKM3KOXV5nO', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(228, 'LA DELICIAS CAFETERIA & BAKERY INC                ', 'LA DELICIAS CAFETERIA & BAKERY INC                ', '2399970009', 'store91@teamafricorp.com', NULL, '$2y$10$Te1Bn1jdA.5V.L0caot2Ee6gNmK4fmIBe4YEf8tatKsJ4iMgRI.oO', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);
INSERT INTO `vendors` (`id`, `f_name`, `l_name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `bank_name`, `branch`, `holder_name`, `account_no`, `image`, `status`, `firebase_token`, `auth_token`) VALUES
(229, 'CHINA CITY RESTAURANT                             ', 'CHINA CITY RESTAURANT                             ', '2396936688', 'store92@teamafricorp.com', NULL, '$2y$10$3J7UhtpORU8x9OoSqiKItewET0H051gRX4hZp3jTSWnwq.7ijjndC', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(230, 'PSC LLC                                           ', 'PSC LLC                                           ', '2392832255', 'store93@teamafricorp.com', NULL, '$2y$10$4JZk5K7WGQcKqXp5h6V6.uJ87gLPpOoMbuVU7QaLLwe.ibvteuu8u', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(231, '4MOMWTHLUV INC                                    ', '4MOMWTHLUV INC                                    ', '2394726566', 'store94@teamafricorp.com', NULL, '$2y$10$BFF/wHBMBPmoAjsx8kRYYOCcOEXZ5UVtSAPA4YYmzZnKkCWkuy35u', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(232, 'AROONRUNG LLC                                     ', 'AROONRUNG LLC                                     ', '2399396002', 'store95@teamafricorp.com', NULL, '$2y$10$9w5RxzRavz40z.NqT9ppeOJTSf6tm/31.ov2yFyQKNPRYBc4J4WNy', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(233, 'SUBWAY 23358 LLC                                  ', 'SUBWAY 23358 LLC                                  ', '2397722038', 'store96@teamafricorp.com', NULL, '$2y$10$2OWzJqB2q5pj6U5WMK/ut.DRqFUY9FOqzM7ft5owGsSsofYqoSY5O', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(234, 'OUTBACK STEAKHOUSE OF FLORIDA LLC                 ', 'OUTBACK STEAKHOUSE OF FLORIDA LLC                 ', '8132821225', 'store97@teamafricorp.com', NULL, '$2y$10$YD/wx7e/b4AcUQ6H.UR/6.GHvr6bwNXNb/TB2hW8kPahn1XJt.lRK', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(235, 'QFRM 7 LLC                                        ', 'QFRM 7 LLC                                        ', '4077238103', 'store98@teamafricorp.com', NULL, '$2y$10$9Nvy7tsAc7cRmiN4/a5o2e86To84.ut8ng2TZlRbp7VeuMwFrqq0W', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(236, 'DMS HOSPITALITY LLC                               ', 'DMS HOSPITALITY LLC                               ', '2394633257', 'store99@teamafricorp.com', NULL, '$2y$10$OcPhyha65bOycKA6XGOtAOxJnjlqke1JJWRdgqjsNhS.sEBlMxckm', NULL, '2022-01-22 18:39:43', '2022-01-22 18:39:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(237, 'NEW HUAS GARDEN TWO INC                           ', 'NEW HUAS GARDEN TWO INC                           ', '2399977100', 'store100@teamafricorp.com', NULL, '$2y$10$xxkbVkPEjuBaJy9VK5OLS.h3yzXs5bbROHQ.i5gt9n1aTHFahb8AW', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(238, 'BLUE COYOTE BUSINESS & SOCIAL CLUB LLC  ', 'BLUE COYOTE BUSINESS & SOCIAL CLUB LLC  ', '2394329222', 'store101@teamafricorp.com', NULL, '$2y$10$2nxRshtDiYCWYEvXIcuCnuhgHhKQBm/YrJxK1A8H6FfSYbyDCeDfu', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(239, 'CHINA KING 6800 INC                               ', 'CHINA KING 6800 INC                               ', '2394956800', 'store102@teamafricorp.com', NULL, '$2y$10$v0pKgiqK.g6iLSuEt2jIy.r50Hy4VvfxDikTYw4AZVLDszXf3kEkC', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(240, 'SHRIJI II LLC                                     ', 'SHRIJI II LLC                                     ', '2393907109', 'store103@teamafricorp.com', NULL, '$2y$10$3Cc26k0X2LhbE0ClxInlQu1BOsnrcHgsY8K4k4eMJDhimObyxy4j.', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(241, 'ESTERO BEEFS INC                                  ', 'ESTERO BEEFS INC                                  ', '2399494423', 'store104@teamafricorp.com', NULL, '$2y$10$9hEeqxR4029hJFnkQBisUuux6nleOtKBCKmD62rPxx55RRq8zNaAC', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(242, 'CARRABBAS ITALIAN GRILL LLC                       ', 'CARRABBAS ITALIAN GRILL LLC                       ', '2399490981', 'store105@teamafricorp.com', NULL, '$2y$10$IBpxW7luqlayTQfd9hdWQ.CqTcv9bCHU0hhuG1Htjg2XbaB3kMr8a', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(243, 'JOF LLC                                           ', 'JOF LLC                                           ', '2399457377', 'store106@teamafricorp.com', NULL, '$2y$10$ItN3c2oijQ0Jli1qnLALtOaAz9u/RyfSbEuGKy5tpmJRsxNe6Pjgy', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(244, 'CAPTIVA NOOK LLC                        ', 'CAPTIVA NOOK LLC                        ', '2393954000', 'store107@teamafricorp.com', NULL, '$2y$10$erzcpnrXMagmP8/uSdNrCeMK3.BA1yMlOvWfH/1CiKEX0YvL32fV2', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(245, 'THE VILLAGES AT COUNTRY CREEK MASTERS ASSOC INC   ', 'THE VILLAGES AT COUNTRY CREEK MASTERS ASSOC INC   ', '2399474488', 'store108@teamafricorp.com', NULL, '$2y$10$7Tguk7r3RSvED43kczdNW.jADCaC9vsGX3DKvAZr0ORN71Yw8JiAm', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(246, 'LORD JACK INC                                     ', 'LORD JACK INC                                     ', '2396937111', 'store109@teamafricorp.com', NULL, '$2y$10$C2o.l8x5rufG1HaCxFqdAO.2PCMUwrLJSqdYff4ZSrmvBUvvJZkBu', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(247, 'NEW R A LLC                                       ', 'NEW R A LLC                                       ', '2392821131', 'store110@teamafricorp.com', NULL, '$2y$10$it1KNt6fdLGRoB4JwfuYguMprWMc4EXxvm/CYECfTeEv30o8slWWS', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(248, 'JK BONGIORNO INC                                  ', 'JK BONGIORNO INC                                  ', '2394891115', 'store111@teamafricorp.com', NULL, '$2y$10$frTs2X.T3/jV9dEvG1eimecF1X6gLi9ZEfcxsw2ZV8BfZ6IWULzg.', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(249, 'BOYKIN HOSPITALITY PROPERTIES LLP                 ', 'BOYKIN HOSPITALITY PROPERTIES LLP                 ', '2394638607', 'store112@teamafricorp.com', NULL, '$2y$10$a5W.ZjwtkBVxhvKPO0cHrenZ6WuHuX3Uw.wtgs1RsQd1JmaVtqc22', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(250, 'BOYKIN HOSPITALITY PROPERTIES LLP       ', 'BOYKIN HOSPITALITY PROPERTIES LLP       ', '2394636181', 'store113@teamafricorp.com', NULL, '$2y$10$Wi6R3SLGgFnAHG/hJj6F8uU5eGhk8WefGTEDNQvtkmZdzrtQjNw3e', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(251, 'FORT MYERS SUSHI LLC                              ', 'FORT MYERS SUSHI LLC                              ', '2394891500', 'store114@teamafricorp.com', NULL, '$2y$10$66jpjOkJJEmult8s/ED7OO9xx8O0UkmrUvsf0uRmND5ularFw2gMi', NULL, '2022-01-22 18:39:44', '2022-01-22 18:39:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(252, 'VOXEN INC                               ', 'VOXEN INC                               ', '2394667788', 'store115@teamafricorp.com', NULL, '$2y$10$yRS/81YEOIdG3rm4nrIskO76rYSkqVbgnVcooEZ6FzISe.sdJzQS2', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(253, 'ESTERO RESTAURANT LLC                             ', 'ESTERO RESTAURANT LLC                             ', '2394988773', 'store116@teamafricorp.com', NULL, '$2y$10$04Sj7Ah.15PZSODjsmdRFOSXE88/WFbLS9bClnnUuBRxc03dzNOPS', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(254, 'CHINO GOURMET ESTERO INC                          ', 'CHINO GOURMET ESTERO INC                          ', '2399492615', 'store117@teamafricorp.com', NULL, '$2y$10$SsumiRgQPsdvFJEGK2xyW.VgdTmbxF.3s82.8kmCCyzxdCBy1mi0W', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(255, 'RAINCO LLC                              ', 'RAINCO LLC                              ', '2394373499', 'store118@teamafricorp.com', NULL, '$2y$10$997lYiR5J7mxDL53GhTlsO0/ob7KM68ib5QV7uXtP5TVKCL31Wu9W', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(256, 'MARSALA PIZZA OF ESTERO INC             ', 'MARSALA PIZZA OF ESTERO INC             ', '2399488443', 'store119@teamafricorp.com', NULL, '$2y$10$p6YX6EN73e4o/j0QzhgnF.3ofRP.OyhOq/H/m1lnr4QPLDU9/KXaG', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(257, '7 ELEVEN INC  & MATRYDER LLC                      ', '7 ELEVEN INC  & MATRYDER LLC                      ', '4072953076', 'store120@teamafricorp.com', NULL, '$2y$10$oPSqBwKbwJhLL/0iMSJEu.JrrlzFbdi5dNfkFubIKhnt7GFgwulAK', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(258, 'CASA ROJAS CUBAN BAKERY NO III INC                ', 'CASA ROJAS CUBAN BAKERY NO III INC                ', '2395739998', 'store121@teamafricorp.com', NULL, '$2y$10$82dH1.lwWbaXCWxiomBCy.vdquiCRq0.yLa23526pxx2jhpJJv9Iq', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(259, 'MIROMAR LAKES MASTER ASSOCIATION INC              ', 'MIROMAR LAKES MASTER ASSOCIATION INC              ', '2394374745', 'store122@teamafricorp.com', NULL, '$2y$10$.5jKkXPs56h1febII2K8/.4iKT0BgwSLtjzNZTJFnypETcGttmCJW', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(260, 'WCI COMMUNITIES LLC                               ', 'WCI COMMUNITIES LLC                               ', '2399851780', 'store123@teamafricorp.com', NULL, '$2y$10$gNLV3zrJpnPna3c0VgOTA.t/Ux8PncTxsMw8yb1RxWcoHqUZZjNHy', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(261, '7 ELEVEN INC & AILA ENTERPRISE INC                ', '7 ELEVEN INC & AILA ENTERPRISE INC                ', '2392748368', 'store124@teamafricorp.com', NULL, '$2y$10$HSXr4arKZ6KY0zYOVSrDNeKinO/qwXGmW.23gNLOoeOK4HO6GHzCi', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(262, 'GARRATT & LAU FOOD DEVELOPMENT                    ', 'GARRATT & LAU FOOD DEVELOPMENT                    ', '2395731210', 'store125@teamafricorp.com', NULL, '$2y$10$Prt/FqO7ZuoRXO5qTauAFuMZ/Vz.NfQocOdagjGnJPs4U5ZkkCZqe', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(263, '7 ELEVEN INC & NNMK INC                           ', '7 ELEVEN INC & NNMK INC                           ', '2394153463', 'store126@teamafricorp.com', NULL, '$2y$10$7jl1xU5MrCCdXmuo/VwAc.uGiYCX4D7AxpIy3MXNDE2mASfWcLo82', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(264, 'ZOU XIU QI                                        ', 'ZOU XIU QI                                        ', '2399496669', 'store127@teamafricorp.com', NULL, '$2y$10$0tzvIMwGXd2bE6RyunTy7e7KVBzrsCk5/.kGm2gfERBhMrViwKRGm', NULL, '2022-01-22 18:39:45', '2022-01-22 18:39:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(265, 'LIU TIAN JI                             ', 'LIU TIAN JI                             ', '2399958188', 'store128@teamafricorp.com', NULL, '$2y$10$QMAmDMWQNlWZIfC.t77vcumXY8wm6QwuuW4iH432yxyYLIHNdo.CC', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(266, 'PARARONS LLP                                      ', 'PARARONS LLP                                      ', '2394823145', 'store129@teamafricorp.com', NULL, '$2y$10$IcR1K1Kc66ldHyvI43jfqOYW7bKlLcCf389/F.iGrVIGBGBcDarky', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(267, 'REYES CARLOS MARTI                      ', 'REYES CARLOS MARTI                      ', '2397727790', 'store130@teamafricorp.com', NULL, '$2y$10$fnKIhWCC.0bu7NHCgRp57eSQAqngkhz2vxR5Ry6Qy3TKoSBjC0SAC', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(268, 'LANTZOUNIS JANET                                  ', 'LANTZOUNIS JANET                                  ', '2395613777', 'store131@teamafricorp.com', NULL, '$2y$10$HL9WT6j0mb6/BC3V5szC5OOL/RkYXrKIuRNXze/FGFtWNyWHgPpDG', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(269, 'HOGBODYS OF N FT MYERS LLC              ', 'HOGBODYS OF N FT MYERS LLC              ', '2395438800', 'store132@teamafricorp.com', NULL, '$2y$10$mRgUYbPORx.7rSBgrVXQ1OP0rcG0hrIrAC.0dejNpAItEthQXAhca', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(270, 'PRIVATE PLATTER INC                               ', 'PRIVATE PLATTER INC                               ', '2399955800', 'store133@teamafricorp.com', NULL, '$2y$10$UMeOrzDilhkbQ1NrmevW.usoidtAh8FNSBohw1RumQxWEcM0ZOj/2', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(271, 'JIANGS GROUP INC II                     ', 'JIANGS GROUP INC II                     ', '2395739988', 'store134@teamafricorp.com', NULL, '$2y$10$AkWK3V9.Er4VYx2ixJ1qiuJvQY.1rllX4b0v7bEftdtyWlTFk6kF2', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(272, 'SHI RUAN ZHONG                                    ', 'SHI RUAN ZHONG                                    ', '2394891088', 'store135@teamafricorp.com', NULL, '$2y$10$uDsovcj3UW6jkam280fL1.g69eWdTqptkNvMuz/2sOMP43dBnlu9i', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(273, 'L & S RESTAURANT CONCEPTS INC                     ', 'L & S RESTAURANT CONCEPTS INC                     ', '2394154424', 'store136@teamafricorp.com', NULL, '$2y$10$ddyc5HzPL19C4KWkuBrYsemwwEAWRMuqi18nZ7Tzd7yVg0SDzOwYa', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(274, 'KUNTRY KUBBARD INC                      ', 'KUNTRY KUBBARD INC                      ', '2395432751', 'store137@teamafricorp.com', NULL, '$2y$10$tYMiIRxsUXqBxfIS8.23KeAqh4NxfwRYMyAHuYeMLvvtb2CNQ8j2.', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(275, 'NEW TASTY WOK LLC                                 ', 'NEW TASTY WOK LLC                                 ', '2394157882', 'store138@teamafricorp.com', NULL, '$2y$10$DX0JZeN3..mvstSN1zkTVuKjzTiu9tigvIUbldMH1V/3FZnulu95q', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(276, 'SNAPPERS INC                            ', 'SNAPPERS INC                            ', '2395420200', 'store139@teamafricorp.com', NULL, '$2y$10$RDUye9XrTldMe61umMpMgeYlXm.Nll.MvSjurBGAtR6v6pu5v3f/G', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(277, 'PSC LLC                                           ', 'PSC LLC                                           ', '2395737383', 'store140@teamafricorp.com', NULL, '$2y$10$3hhDdT/r6ClpHqHt40l8we/qKhbAwfkduHRm4FIhI.PDcmcIhkaoS', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(278, 'MAINSTREET VENTURES RESTAURANT GROUP LLC          ', 'MAINSTREET VENTURES RESTAURANT GROUP LLC          ', '2399478071', 'store141@teamafricorp.com', NULL, '$2y$10$krEWSEYqnZns7S504f0UDeM5.k6K1RPzkse/nxc1XvnAsxVZ/E3tO', NULL, '2022-01-22 18:39:46', '2022-01-22 18:39:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(279, 'BRUCE DANE ADKINS LLC                             ', 'BRUCE DANE ADKINS LLC                             ', '2399366317', 'store142@teamafricorp.com', NULL, '$2y$10$6Di5t3EPnA/GANm7gNTogOdNSx/ezl5SRtjSPYmYbbmGELzgymPuu', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(280, 'WORTHINGTON OF RENAISSANCE LLC          ', 'WORTHINGTON OF RENAISSANCE LLC          ', '2395614170', 'store143@teamafricorp.com', NULL, '$2y$10$5X3SXerbzFL4HtZw5MLIiuxcB.DQCj4SKr7jbXgR0r9qejoG5.qC.', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(281, 'MOLINOS RISTORANTE LLC                  ', 'MOLINOS RISTORANTE LLC                  ', '2399927025', 'store144@teamafricorp.com', NULL, '$2y$10$wT6Pn7sgD3pxdweHzLc59.K0Ubsjx68bI89NDS/JbQFnFHXCwubQm', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(282, 'CHARLEYS SOUTH BEACH GRILLE OF FT MYERS ', 'CHARLEYS SOUTH BEACH GRILLE OF FT MYERS ', '2394637770', 'store145@teamafricorp.com', NULL, '$2y$10$eM3mSdFZR2m5/RDa3ss1yOsgVqLNxVQl8m8Hxpone2EeUOy4uiTk6', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(283, 'CRACKER BARREL OLD COUNTRY STORES INC             ', 'CRACKER BARREL OLD COUNTRY STORES INC             ', '6154434444', 'store146@teamafricorp.com', NULL, '$2y$10$gU.f2U0cxdsWf7TOFpb6P.JauQMKdZTgX8KhMm.NTB2aYlLHCGOFe', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(284, 'JJ & GRAY VENTURES LLC                  ', 'JJ & GRAY VENTURES LLC                  ', '2395494000', 'store147@teamafricorp.com', NULL, '$2y$10$JDQCj0YYIbWYfit9QMI9w.nJ6uFLizzKlilwUmTUEcbg4yQSedUaq', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(285, 'GARRATT FOOD SERVICES INC                         ', 'GARRATT FOOD SERVICES INC                         ', '2394817415', 'store148@teamafricorp.com', NULL, '$2y$10$sP.0uyeKLNA8uBk4pi5gium1Q4qrrPdasuXnA.A8.tYMMbPQGqvhm', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(286, 'TEH4, INC                                         ', 'TEH4, INC                                         ', '2397652222', 'store149@teamafricorp.com', NULL, '$2y$10$nQnWRzBnpR0H.v7m8lrN8uJtEwjbA8YU/7Rpu0SUhAS6L0SZSFjtK', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(287, 'TACO ARDIENTE CORDOVA INC                         ', 'TACO ARDIENTE CORDOVA INC                         ', '2393689777', 'store150@teamafricorp.com', NULL, '$2y$10$p2nG7gHZ2bxLeOwZiGqbYufcABQEajHnwyM2K1yJg/X.96PkElI4e', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(288, 'CHINA INN USA INC                                 ', 'CHINA INN USA INC                                 ', '2392781668', 'store151@teamafricorp.com', NULL, '$2y$10$BkxmI9oIzFvUCRbWP5GCUeaZ.NGymJ5ZHS5DFabSnjoEvj0ce3.uq', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(289, 'LEWIS SOPHIE                                      ', 'LEWIS SOPHIE                                      ', '2398514685', 'store152@teamafricorp.com', NULL, '$2y$10$TyisGNi3EUfLGXBfkibjd.hJR0sMIsrHm3elVC3LGTamZ9ArRON5K', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(290, 'A BONA FIDE RESTUARANT LLC                        ', 'A BONA FIDE RESTUARANT LLC                        ', '2395426622', 'store153@teamafricorp.com', NULL, '$2y$10$nwdwRJIUUFNZ4WLy0/hzh.ZaWcGkbRQNHUgoe5Gu3BAx10O6wF1WK', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(291, 'LJ FT MYERS LLC                                   ', 'LJ FT MYERS LLC                                   ', '2392748877', 'store154@teamafricorp.com', NULL, '$2y$10$wV.nCIT1oQlzr5JA53dns.oEsR40nlQi.1JFd6dpSlzU9HlX9xZXK', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(292, '3MJ INC                                           ', '3MJ INC                                           ', '2394955044', 'store155@teamafricorp.com', NULL, '$2y$10$Z8ny30ZRZMOFcJIgwUaecO9s0If7yKm2mpOwVKYdniW0JO0hzr1Q.', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(293, 'ESMERALDA CUBAN BAKERY INC                        ', 'ESMERALDA CUBAN BAKERY INC                        ', '2393688090', 'store156@teamafricorp.com', NULL, '$2y$10$XZZ.4.XkCLcD0OJFstTZ0OhtjuZbc5mazykDD1CSoHx1C9DNBbO1.', NULL, '2022-01-22 18:39:47', '2022-01-22 18:39:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(294, 'BACK BONE ROCK WYOMING LLC                        ', 'BACK BONE ROCK WYOMING LLC                        ', '2394339030', 'store157@teamafricorp.com', NULL, '$2y$10$wbjEUuWBsca46hQGcNRd5.PiqH0bTg1t8xmJC6xlSzalUeQ8BIqde', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(295, 'JILLJER INC                                       ', 'JILLJER INC                                       ', '2399953500', 'store158@teamafricorp.com', NULL, '$2y$10$K9iZSPJYtwXi4ZxPWwhubORWjPY44TdOsxnY7qnnAXvL9I3HfuhLi', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(296, 'MUCHO TACO MEXICANO INC                           ', 'MUCHO TACO MEXICANO INC                           ', '2392224226', 'store159@teamafricorp.com', NULL, '$2y$10$tuSpPaI8jrMfumJrPJX4bedLcQmogwHJEWMVHF2IYEFTDRVfdCUIW', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(297, 'STARBUCKS CORPORATION                             ', 'STARBUCKS CORPORATION                             ', '2399478818', 'store160@teamafricorp.com', NULL, '$2y$10$7m26K57Jibs3dx0J7wihP.Du6mIdMLzIMEp.tgwxz1JQOl6.r3lS.', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(298, '7 ELEVEN INC                                      ', '7 ELEVEN INC                                      ', '2394332531', 'store161@teamafricorp.com', NULL, '$2y$10$bq.5cEWcLdXR8kDh/JgLK.5/ygdz.lwJjCfyx8CWVR/5FY9W6dY5W', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(299, 'WILROCK CAPE CORAL LLC                  ', 'WILROCK CAPE CORAL LLC                  ', '2399857215', 'store162@teamafricorp.com', NULL, '$2y$10$THCUCSoWeSS3V4SYHqYNjOVeQZrfB/355WGkVxHanSjDXIWnnKzbC', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(300, 'BONEFISH GRILL LLC                                ', 'BONEFISH GRILL LLC                                ', '2394891240', 'store163@teamafricorp.com', NULL, '$2y$10$5rKixrKoTOg8dxPPAev.3.az2GwKnwE2Jw25EN0MCS7ME6eP.F2xi', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(301, 'RIZZOS PRETZELS INC                               ', 'RIZZOS PRETZELS INC                               ', '2399490833', 'store164@teamafricorp.com', NULL, '$2y$10$03405JdMN2zcBtlCbSgpx.N2nnbUhHK2Jf4VW0QT..NDbhr4/ee/u', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(302, 'COOL TREATS OF BONITA INC                         ', 'COOL TREATS OF BONITA INC                         ', '2399924797', 'store165@teamafricorp.com', NULL, '$2y$10$glG4WwZMcQ25Xg7O/csje.E1TemteDKK.qg.t2Da.XNQ/d4icIsBq', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(303, '7 ELEVEN INC & THE GREENLIGHT ORGANIZATION INC    ', '7 ELEVEN INC & THE GREENLIGHT ORGANIZATION INC    ', '2394985600', 'store166@teamafricorp.com', NULL, '$2y$10$Fqc5h7o1hWhgLpjOyAdnD.zrR9cNgngFg0lbWWNI32tO64LOawFZC', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(304, '7 ELEVEN INC                                      ', '7 ELEVEN INC                                      ', '2394981135', 'store167@teamafricorp.com', NULL, '$2y$10$cfVko.M445tlz5WG4xAQMeAYNjZBgtV8uL9kYYnIJd9JXVRe5J/Fm', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(305, 'AKSHARPATI INC                                    ', 'AKSHARPATI INC                                    ', '2399497752', 'store168@teamafricorp.com', NULL, '$2y$10$8zuk1rJGpV1gK4PCAYeZnOTehXWZGZRhLF3ehQD3PYl9m3Q5QhCBK', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(306, 'CHINA GARDEN INC                                  ', 'CHINA GARDEN INC                                  ', '2394816688', 'store169@teamafricorp.com', NULL, '$2y$10$sR9.S1CAjEHMVZ7nHA2qKes824yX5kYvmHhVr3asqkpDmHNDkhrDy', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(307, 'IL PRIMO PIZZA & WINGS IV INC                     ', 'IL PRIMO PIZZA & WINGS IV INC                     ', '2393444457', 'store170@teamafricorp.com', NULL, '$2y$10$BI9w4w5v9cAszzAmHEtuKeGWv09sZaUli/r0LXYSJa0A209IRIfwC', NULL, '2022-01-22 18:39:48', '2022-01-22 18:39:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(308, 'BONEFISH GRILL LLC                                ', 'BONEFISH GRILL LLC                                ', '2393909208', 'store171@teamafricorp.com', NULL, '$2y$10$tmNo7DzCFm70xg7CZM0O4uCgNxtE9VN3IF04WSTsp.WiHjaXZJv3O', NULL, '2022-01-22 18:39:49', '2022-01-22 18:39:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(309, 'HERON LAURA J                                     ', 'HERON LAURA J                                     ', '2396013022', 'store172@teamafricorp.com', NULL, '$2y$10$hvAvgSED7lszJiwGCesKkenF7j/cDAhavwFDTg3SQoj/um0j4/B8O', NULL, '2022-01-22 18:39:49', '2022-01-22 18:39:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(310, 'SWH MIMIS CAFE LLC                                ', 'SWH MIMIS CAFE LLC                                ', '2395610073', 'store173@teamafricorp.com', NULL, '$2y$10$zWi/XevuydL9LTyC/GK6eetsBWu96xrsBtejHyAghL8ljo9KZngZ6', NULL, '2022-01-22 18:39:49', '2022-01-22 18:39:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(311, 'DONG MEI CHEN ZHEN                                ', 'DONG MEI CHEN ZHEN                                ', '2396938388', 'store174@teamafricorp.com', NULL, '$2y$10$do4VKVgQ4laurcfXyhghiuntKOkkRclVJw1.yPTAi6WwMvg2hxYDG', NULL, '2022-01-22 18:39:49', '2022-01-22 18:39:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(312, 'SHRI JALA 1 LLC                                   ', 'SHRI JALA 1 LLC                                   ', '2399954150', 'store175@teamafricorp.com', NULL, '$2y$10$nNLGdW99qPTjsGAyoAlRpespRZOJ14D/CE1yJu66/oVG3RcMRLv.i', NULL, '2022-01-22 18:39:49', '2022-01-22 18:39:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(313, 'KUMO JAPANESE STEAK HOUSE SANTA INC               ', 'KUMO JAPANESE STEAK HOUSE SANTA INC               ', '2395739866', 'store176@teamafricorp.com', NULL, '$2y$10$nfplpLi5FMG4CataSFbuqeRqm0DmqIke2hbT186wah4ioxP/2rJRy', NULL, '2022-01-22 18:39:49', '2022-01-22 18:39:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(314, 'S32160 LLC                                        ', 'S32160 LLC                                        ', '2394916272', 'store177@teamafricorp.com', NULL, '$2y$10$vrCkrmbvMYyWiTAgGHmGJOfXveYfnOt1wj/GrxcZ07Ph1TCLrMzWS', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(315, 'CARRABBAS ITALIAN GRILL LLC                       ', 'CARRABBAS ITALIAN GRILL LLC                       ', '2392160687', 'store178@teamafricorp.com', NULL, '$2y$10$GL/eJBV/EoD1Yj2BOrc6yOfUbRSajb.KeDdRkDdw/WGAQl0XrCUHO', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(316, 'PINCHERS CRAB SHACK  FT MYERS BEACH INC           ', 'PINCHERS CRAB SHACK  FT MYERS BEACH INC           ', '2394315504', 'store179@teamafricorp.com', NULL, '$2y$10$mjX4s3FrRha5eDdN2sdX8OXTVLOnrdoLdMumvGYwjcRzJ3niK1wZi', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(317, 'THE WEST BAY GOLF CLUB INC              ', 'THE WEST BAY GOLF CLUB INC              ', '2399483486', 'store180@teamafricorp.com', NULL, '$2y$10$f9fHaWcJSwHvsfo2lROLoOPrcFLLvuxJBCBjV8Fc.Px2hLd3H3I6K', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(318, 'THE WEST BAY GOLF CLUB INC                        ', 'THE WEST BAY GOLF CLUB INC                        ', '2399483486', 'store181@teamafricorp.com', NULL, '$2y$10$AeKZCgEZCsshEJNn7liJnejnSW3eW8GYn9OVZy9d/pW1bnOGGzCFu', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(319, 'SSC341662 LLC                                     ', 'SSC341662 LLC                                     ', '2392563442', 'store182@teamafricorp.com', NULL, '$2y$10$eW4PaiFmeR/UJRYQd8u.8ORZRIEmf92IquCe4V1GCcE0fNU4xJ9PS', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(320, '7 ELEVEN INC                                      ', '7 ELEVEN INC                                      ', '4073994630', 'store183@teamafricorp.com', NULL, '$2y$10$8iX02KfOE.D7CIa4H.yHneukf3WElLlKTYiTdrvJ7rG4Te1pn7e1y', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(321, 'QUALITY FRESCA I LLC                              ', 'QUALITY FRESCA I LLC                              ', '9198004940', 'store184@teamafricorp.com', NULL, '$2y$10$pSxj3CPCslT9aRkwO1RZcOu8UOlpvOOqdhzr9WGoQsxokE6gAb7ju', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(322, 'STARBUCKS CORPORATION                             ', 'STARBUCKS CORPORATION                             ', '2063188705', 'store185@teamafricorp.com', NULL, '$2y$10$NTxw8s4hvvhHow1o6gMOnur13d8ZUuLOuFYy.FC/2mMDDWEalPmfW', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(323, 'CHEN MEI LIAN                                     ', 'CHEN MEI LIAN                                     ', '2399498588', 'store186@teamafricorp.com', NULL, '$2y$10$QRL.Lz3EtNKlGqi7XFv4He2H8Gvc2qrKJ72LLzGapuJwRU.0uTxy.', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(324, 'JM DANIELS PKWY LLC                               ', 'JM DANIELS PKWY LLC                               ', '2399317827', 'store187@teamafricorp.com', NULL, '$2y$10$B1jxuaO.1bx48wt9PoU6keBYuVCMPr77EUTPPZ.qW24.cBub0S5Ge', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(325, 'BRUNO CATERING INC                                ', 'BRUNO CATERING INC                                ', '2398871219', 'store188@teamafricorp.com', NULL, '$2y$10$IDntUL2C9dHofvw/iSdxr.yIxR/T06V6dPICxKFU1p3lyphDSBGrm', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(326, 'VERANDAH DEVELOPMENT LLC', 'VERANDAH DEVELOPMENT LLC', '2396947229', 'store189@teamafricorp.com', NULL, '$2y$10$08mAyyF.daUZeffZq.JRSeZziKBQdH.2zznuytUT3s0LtibQnh3qq', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(327, 'DC NOON LLC                             ', 'DC NOON LLC                             ', '2394635544', 'store190@teamafricorp.com', NULL, '$2y$10$PiKPRpWPRwTHvbYQXGd5puqMzYYZGVnuFh706MLyFGeJrT.7Oqbuu', NULL, '2022-01-22 18:39:50', '2022-01-22 18:39:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(328, '7 ELEVEN INC & FSI & ALI INC                      ', '7 ELEVEN INC & FSI & ALI INC                      ', '2393373966', 'store191@teamafricorp.com', NULL, '$2y$10$nqH6iudpU.mAWnktXQjXuOmZbEYDeeGVqoyTLvynXXsN/LtSSQuwe', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(329, 'CORONADO FOODS INC                      ', 'CORONADO FOODS INC                      ', '2394957715', 'store192@teamafricorp.com', NULL, '$2y$10$YWPD56rBfM1fML9twd9Houl/oJOknTOIvIG1y2lCb9ScT6lhptGT2', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(330, 'THAI STAR INC                                     ', 'THAI STAR INC                                     ', '2392084057', 'store193@teamafricorp.com', NULL, '$2y$10$/D60DMX.AHZqdM9h9fNTK.ZSxLtn3vkBswYrWu/3CnzthZqC686PK', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(331, 'DOHERTY FLORIDA CORKSCREW LLC                     ', 'DOHERTY FLORIDA CORKSCREW LLC                     ', '2399921310', 'store194@teamafricorp.com', NULL, '$2y$10$EQjDO3mGU8JnliD.weF5Muoh7SKvUHeLUEtcNCVdhzjesthR.cfwe', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(332, 'LEHIGH HOMESTEAD SHELL LLC                        ', 'LEHIGH HOMESTEAD SHELL LLC                        ', '2393690571', 'store195@teamafricorp.com', NULL, '$2y$10$Dt.CmTtLZCJrU15ILr7DI.tJAO0MMDLqJwfUBhZjRQQtM8QoaO52K', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(333, 'DOHERTY FLORIDA COLONIAL LLC                      ', 'DOHERTY FLORIDA COLONIAL LLC                      ', '2399395569', 'store196@teamafricorp.com', NULL, '$2y$10$EzrJ09o9Wxs4XZVS75AO5OrurTvt7PGr5.wBWE1f45AS.EmhK8dka', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(334, 'CHINA DRAGON WENG INC                             ', 'CHINA DRAGON WENG INC                             ', '2395612095', 'store197@teamafricorp.com', NULL, '$2y$10$C4rHJIRWNxryAZdd8fpNKemqnHZU2rrQ.1g/2Wu1EQGwfkcn8FnuG', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(335, 'RIB CITY N41 LLC                                  ', 'RIB CITY N41 LLC                                  ', '2392756700', 'store198@teamafricorp.com', NULL, '$2y$10$caAC76wjxFZYQGVBpI7VbedzRk2mrmbXcZ/dHIkop7GuzBGDXkgRi', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(336, 'TORTILLERIA Y TAQUERIA LA BAMBA LLC               ', 'TORTILLERIA Y TAQUERIA LA BAMBA LLC               ', '2395672622', 'store199@teamafricorp.com', NULL, '$2y$10$41WBK.AjxSz95ge7ES8A3OFXtFlufg69LQEa5KK07MZ2bvKKYE.7e', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(337, 'ESTERO MALL INVESTMENTS INC                       ', 'ESTERO MALL INVESTMENTS INC                       ', '2393905910', 'store200@teamafricorp.com', NULL, '$2y$10$tU4PWPLtDGv5y.FbNHWVFOFLLhIjSAd3Jgh/Ims71TNL5FjGPP8SO', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(338, 'CHINA GARDEN III INC', 'CHINA GARDEN III INC', '2392838891', 'store201@teamafricorp.com', NULL, '$2y$10$hKTakydjjhNWnIfzo1u1cenJzywE3l0Qq04S/2kVcO8U9xISzo4Fi', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(339, 'BOB 1 INC                                         ', 'BOB 1 INC                                         ', '2395742060', 'store202@teamafricorp.com', NULL, '$2y$10$N2uTO/aCM0/3s9V8wGewyevQirxaVVDEH97Dc7OYFK.Yu6Zd3W/Ge', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(340, '7 ELEVEN INC & NEIGHBORHOOD MARKETS INC           ', '7 ELEVEN INC & NEIGHBORHOOD MARKETS INC           ', '2394669006', 'store203@teamafricorp.com', NULL, '$2y$10$irLW14XpytvKcXz0wRUKP.62CPBiIoV64sYMQe5MFhDKJymUwTFrG', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(341, 'IL PRIMO PIZZA & WINGS V INC                      ', 'IL PRIMO PIZZA & WINGS V INC                      ', '2397779220', 'store204@teamafricorp.com', NULL, '$2y$10$fHq7967gZq3fbeKaY/r7N.MpZZcUvVDT8gkcfgpPd3D0N32YP9UaG', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(342, 'FISHER INVESTMENTS LTD                            ', 'FISHER INVESTMENTS LTD                            ', '2393698415', 'store205@teamafricorp.com', NULL, '$2y$10$FkjNDkLSXuUCed/XdwjdwuMIe89/Q4NjRKxxuV.CktbekKMqCaKx2', NULL, '2022-01-22 18:39:51', '2022-01-22 18:39:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(343, 'SANIBEL HARBOUR YACHT CLUB CONDO ASN INC', 'SANIBEL HARBOUR YACHT CLUB CONDO ASN INC', '2394892969', 'store206@teamafricorp.com', NULL, '$2y$10$L4uoiqUAs86Kodq4Oe/Vau3l.1t3NuEhNgAWqg6RZMdt4JXOHY8Hi', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(344, 'SEELAND ENTERPRISES LLC                           ', 'SEELAND ENTERPRISES LLC                           ', '2399850080', 'store207@teamafricorp.com', NULL, '$2y$10$Uler9Q7QHJE2G2vDBROZzOh00LoIt6d65l3qSWGz4B.KMxJ8vzFHC', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(345, 'TARGET CORPORATION                                ', 'TARGET CORPORATION                                ', '6127618138', 'store208@teamafricorp.com', NULL, '$2y$10$5KoWxAfeAh6aj6ovSwgSUOAZjn0h0TBTzC70ziZRmygWdIVY4R.2a', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(346, 'STEAK N SHAKE OPERATIONS                          ', 'STEAK N SHAKE OPERATIONS                          ', '2399310090', 'store209@teamafricorp.com', NULL, '$2y$10$Cxki/VeoHYk4nnA/MhCe2.ikYEKeDasTmJwMFlRybsvbHDXDlkF9C', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(347, 'STEELE PEGGY OR MCMURRY MARTIN          ', 'STEELE PEGGY OR MCMURRY MARTIN          ', '2399959100', 'store210@teamafricorp.com', NULL, '$2y$10$i53MI2rTRNWaANL.5RKEc.s2JveBrkYVc4XApJkZgeqyeDUsAzUpS', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(348, 'TAMBASCO ERNEST                         ', 'TAMBASCO ERNEST                         ', '9416282429', 'store211@teamafricorp.com', NULL, '$2y$10$hWehEtQ1eOfJtRBUqdXYDuU7juoHiZT1GdQSp8u8YAPFEdWXBIFZ6', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(349, 'UNITED ASIAN PETROLEUM INC              ', 'UNITED ASIAN PETROLEUM INC              ', '2394826908', 'store212@teamafricorp.com', NULL, '$2y$10$9uq4M78GWLTXT5C5FQ2yme8b6MK0Guyk/x0vyI6ATv/e7sUY4pRbG', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(350, 'THREE GIRLS INC                                   ', 'THREE GIRLS INC                                   ', '9416282429', 'store213@teamafricorp.com', NULL, '$2y$10$1oDxjZMPIahVorF0CDS5ve6pAGoDve3KYNOYlY7Ch1dE9hIrqm3Ru', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(351, 'THREE GIRLS INC                                   ', 'THREE GIRLS INC                                   ', '9416282429', 'store214@teamafricorp.com', NULL, '$2y$10$YdGT7BjSuvR7ivjjslX6HuuJaIUJQnHOGzV.SIikPeXULq93wL8Km', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(352, 'POLLO OPERATIONS INC                              ', 'POLLO OPERATIONS INC                              ', '3056707696', 'store215@teamafricorp.com', NULL, '$2y$10$IJj56w.dlY2/40b37jqNEO8J1X0JT/y8WSNAD3Yo8Pc.aa4wkRexm', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(353, 'QUALITY DRIVE-IN I, LLC                           ', 'QUALITY DRIVE-IN I, LLC                           ', '2399955114', 'store216@teamafricorp.com', NULL, '$2y$10$qZaAR4sCJ0OMf48UyC2y2eZQWF131cOTGCZ1LTnr7HK.YDSs/gpii', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(354, 'CHEN XIANG HUA                                    ', 'CHEN XIANG HUA                                    ', '2394158889', 'store217@teamafricorp.com', NULL, '$2y$10$B2Ba.IyvnFOu4tVwC3uD3enSEoUQnWtCWhSADRwFJ1XQCQvMiblwS', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(355, 'MMEP BEEFS OF LEHIGH INC                ', 'MMEP BEEFS OF LEHIGH INC                ', '2393690390', 'store218@teamafricorp.com', NULL, '$2y$10$lCxdPsDO6UHLanNpmQ3uQe2k60NeDLYueHjf1tCYTbqM45Hk3v.Ii', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(356, 'JPS BAR B QUE LLC', 'JPS BAR B QUE LLC', '2399971992', 'store219@teamafricorp.com', NULL, '$2y$10$.4CcOSP5k/b0fpVwkhL.3epu4vbFxCx988REamwu2UO26.CFkhSqO', NULL, '2022-01-22 18:39:52', '2022-01-22 18:39:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(357, 'AZUCAR RESTAURANT & BAKERY INC          ', 'AZUCAR RESTAURANT & BAKERY INC          ', '2395492833', 'store220@teamafricorp.com', NULL, '$2y$10$U/bKmEqVEk821Apodq3qeOmWwYFyqEX8UN3G4bmQHbjLCCWFLSSzm', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(358, 'TMG OF BONITA SPRINGS LLC                         ', 'TMG OF BONITA SPRINGS LLC                         ', '4042661344', 'store221@teamafricorp.com', NULL, '$2y$10$Qb9HSyzyeFRUikBMvw2RTuU/9c3un7uFr53vBDo9TJm69GVsdf9nW', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(359, 'BMT PETROLEUM INC', 'BMT PETROLEUM INC', '2399475013', 'store222@teamafricorp.com', NULL, '$2y$10$kWAFvFc.b0YPm1oDV6AqdeAlC5shMBWY/AGNfEYIN.zfuYTHTGJCC', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(360, 'RNR FLORIDA LLC                                   ', 'RNR FLORIDA LLC                                   ', '2392834447', 'store223@teamafricorp.com', NULL, '$2y$10$yNqDUjhXyBbKLqMC3.XxeepgEp32khcHKH1ujREPpGZYDhD9UCQC.', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(361, 'SHADOW WOOD COUNTRY CLUB INC                      ', 'SHADOW WOOD COUNTRY CLUB INC                      ', '2399926000', 'store224@teamafricorp.com', NULL, '$2y$10$hqgtdrqQGYnmrb8dC1nZlOctn7dPuXGMwfGSEvKTfDE7fmH47Dkq.', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(362, 'SHADOW WOOD COUNTRY CLUB INC                      ', 'SHADOW WOOD COUNTRY CLUB INC                      ', '2399926000', 'store225@teamafricorp.com', NULL, '$2y$10$y8ZAcMGDGNBHgqX3XBlQa.6LRQlu65rPTZnCAmyG4w3SP99iQCQOm', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(363, 'MONKEY GRILL INC', 'MONKEY GRILL INC', '2395498800', 'store226@teamafricorp.com', NULL, '$2y$10$xen3uL8ZHiwv3o159laJaeTlJxZ1QyQG3GlI7u2472D0nMp/PJKPe', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(364, 'QUALITY DRIVE-IN I, LLC                           ', 'QUALITY DRIVE-IN I, LLC                           ', '2392675521', 'store227@teamafricorp.com', NULL, '$2y$10$W6GIGW3LYEyut/639xtB9ORJKrFK6qrL1Cj1TEv9JiVWIcK9V8Vn6', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(365, 'BMT PETROLEUM INC                       ', 'BMT PETROLEUM INC                       ', '2399475013', 'store228@teamafricorp.com', NULL, '$2y$10$b.IEqkB7PobT37yz6feQ5eACaCISopX65ptQ5A5e16.969GDnLfdy', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(366, 'RCSH OPERATIONS LLC                               ', 'RCSH OPERATIONS LLC                               ', '4073337440', 'store229@teamafricorp.com', NULL, '$2y$10$xPHDN9cKShmNpjMl6umKPe4ZiWIBsiTRe0AT4kEtViQ9JlIiTFJ4e', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(367, 'PANERA LLC                                        ', 'PANERA LLC                                        ', '3146337100', 'store230@teamafricorp.com', NULL, '$2y$10$PBsxoOpZYpQYhht4V2OP/O5H6lFDlu1tqHQH6VXS9db1lFbacRQIi', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(368, 'HOFFMAN GROUP HOLDINGS LLC                        ', 'HOFFMAN GROUP HOLDINGS LLC                        ', '2395420123', 'store231@teamafricorp.com', NULL, '$2y$10$iBRgWG8A1t2LVITypb19NuVRGDungA2iPFAKv3ZeZHtvKBO2WDbPK', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(369, 'R D ABUKAF 1 INC                                  ', 'R D ABUKAF 1 INC                                  ', '2393908788', 'store232@teamafricorp.com', NULL, '$2y$10$Et6H8lOhX7Uo.HL0D/i2z.u/LE1FFYWXwwcE9SQzMVyATENBS8rmm', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(370, 'FISHTALE INVESTMENTS INC                          ', 'FISHTALE INVESTMENTS INC                          ', '2399492583', 'store233@teamafricorp.com', NULL, '$2y$10$qi49fNZnx9JkEBcWlHtTNOPe56E2uHniR1YfZM9fUgJTyMcyT4KCW', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(371, 'HOFFMAN GROUP HOLDINGS LLC                        ', 'HOFFMAN GROUP HOLDINGS LLC                        ', '2395420123', 'store234@teamafricorp.com', NULL, '$2y$10$g5WoeT5/9ICtlppOglpp0.fiC.SVuafnW9DPkZhWBZdbNoQwMLEFK', NULL, '2022-01-22 18:39:53', '2022-01-22 18:39:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(372, 'TEREZI ROMEO                                      ', 'TEREZI ROMEO                                      ', '2399498330', 'store235@teamafricorp.com', NULL, '$2y$10$daiaeXeJin/KN4Tk75e19eoAcwbbzcvHiLMJ5rOEyWFgDKWIZEBaq', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(373, 'BOB EVANS RESTAURANTS LLC 550                     ', 'BOB EVANS RESTAURANTS LLC 550                     ', '2392424315', 'store236@teamafricorp.com', NULL, '$2y$10$olH/3l4sbYd.08lYeB.eROfg0cgHaY5JlW094Fa.GW9SL9wjQr7fG', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(374, 'QUALITY FRESCA  I LLC                             ', 'QUALITY FRESCA  I LLC                             ', '9198004940', 'store237@teamafricorp.com', NULL, '$2y$10$3as8SnFP0lg2ERs.zueyKOeMZUBVL68VZEtGfFnO6o0cgiEo1z0V2', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(375, 'AMY D LLC                                         ', 'AMY D LLC                                         ', '2392770611', 'store238@teamafricorp.com', NULL, '$2y$10$IXscYCSFDrwcgeCXu3sukuH/DfQXY2QrMf3MQr1V9CZwnD25upKHW', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(376, 'PEDRO S MEAT PALACE INC                           ', 'PEDRO S MEAT PALACE INC                           ', '2393694080', 'store239@teamafricorp.com', NULL, '$2y$10$.hFqTiAnl.ej8BQ2AuJCX.Cp4gfASc65T6n.QIlKM4GpFmHIBm/A6', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(377, 'PINCHERS BEACH BAR & GRILL INC                    ', 'PINCHERS BEACH BAR & GRILL INC                    ', '2394315504', 'store240@teamafricorp.com', NULL, '$2y$10$s/b4T8JZJHl3DnojcJbE0.7D9SIRGWfdvFLoShdhZF5A1xriN605W', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(378, 'MILLERS ALE HOUSE INC                             ', 'MILLERS ALE HOUSE INC                             ', '5617432299', 'store241@teamafricorp.com', NULL, '$2y$10$wV.WYuBGV/Z1CXGhBMFVCegHDEFc8Og2mOScTp4v93LmPia117RFi', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(379, 'MVP LRS INC                                       ', 'MVP LRS INC                                       ', '2396303287', 'store242@teamafricorp.com', NULL, '$2y$10$Utarmk9IBAZvzqnOiJzio.8Ez6nlSNtmCHe5oEvoF82D01UcZMeQG', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(380, 'COSTCO WHOLESALE 621                              ', 'COSTCO WHOLESALE 621                              ', '2394337242', 'store243@teamafricorp.com', NULL, '$2y$10$ZDclnZk.w7WZHy9kKAhj0OaHpdgo110sCpWS3eCwBBheFidO/kFiq', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(381, 'QUALITY BRAND GROUP FLORIDA LLC                   ', 'QUALITY BRAND GROUP FLORIDA LLC                   ', '2033282130', 'store244@teamafricorp.com', NULL, '$2y$10$6gLDQbGzoxoVA1Mt6mMrPu0hM1/Vmpdv/9pmAVofipTjuhP0onPyy', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(382, 'P F CHANGS CHINA BISTRO INC                       ', 'P F CHANGS CHINA BISTRO INC                       ', '2395909197', 'store245@teamafricorp.com', NULL, '$2y$10$2vFbqOv09vRT0vCfABeilOSM8l17obiG9aDDPG5tHLWxLDIi0Tqdq', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(383, 'VORAVONG PHONEMY                                  ', 'VORAVONG PHONEMY                                  ', '2399955002', 'store246@teamafricorp.com', NULL, '$2y$10$HrfCsQuw/rwpgl.CAx3.VemKP.bAJDn47KG7v2ima6WJLViiE1iyy', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(384, 'YUMS INC', 'YUMS INC', '2394379888', 'store247@teamafricorp.com', NULL, '$2y$10$KRwhOKmFlTfHW5ALTf0YQeUJWDTX0N9p/HZoA5F1814OTdJb8Khie', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);
INSERT INTO `vendors` (`id`, `f_name`, `l_name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `bank_name`, `branch`, `holder_name`, `account_no`, `image`, `status`, `firebase_token`, `auth_token`) VALUES
(385, 'STARBUCKS CORPORATION                             ', 'STARBUCKS CORPORATION                             ', '2063188705', 'store248@teamafricorp.com', NULL, '$2y$10$AAwRnibtXLjcHhNYOH2zXOqE6OnwfomUvMaHMYp/1uEx/aN35fwtG', NULL, '2022-01-22 18:39:54', '2022-01-22 18:39:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(386, 'GHP OF FLORIDA LLC                                ', 'GHP OF FLORIDA LLC                                ', '2394542653', 'store249@teamafricorp.com', NULL, '$2y$10$PS2sRNB8QPz2uoXUkdvjP.zFDzVItbFUB998EOnIyQF4n03dcuiZa', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(387, 'STARBUCKS CORPORATION                             ', 'STARBUCKS CORPORATION                             ', '2063188705', 'store250@teamafricorp.com', NULL, '$2y$10$4wzpXsMrmvk8cFsU9aIChOaura2vA.wHaPz7C33jIPqAQDEl9PS86', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(388, 'RED ROBIN INTERNATIONAL INC                       ', 'RED ROBIN INTERNATIONAL INC                       ', '3038466000', 'store251@teamafricorp.com', NULL, '$2y$10$rk.cjMsAwBJQxDBiynlCZOFJIh.i9WXzc0MMuBn.MguEpADLMB5IG', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(389, 'JM BEACH BONITA LLC                               ', 'JM BEACH BONITA LLC                               ', '7322958891', 'store252@teamafricorp.com', NULL, '$2y$10$XT6qrWHzoEZx/RH9m2D7zuJIZzrGn4SpqwE.1ubwSVUa5Fj0VSS8y', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(390, 'CRAVE OF FT MYERS INC                             ', 'CRAVE OF FT MYERS INC                             ', '2394664663', 'store253@teamafricorp.com', NULL, '$2y$10$xEOnvmJkbWdNlKSa6l4q1eL4Kuzdo5yp4TvaKX.SjBjeQTOMrFCRa', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(391, 'CHARBROILED CONCEPTS INC                          ', 'CHARBROILED CONCEPTS INC                          ', '2395734454', 'store254@teamafricorp.com', NULL, '$2y$10$mQYWI36PYImvRiN93E58XOt6aQY4N4abbcs10adZaQ8MMQww34Plu', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(392, 'WILSON EARL C                                     ', 'WILSON EARL C                                     ', '2392757757', 'store255@teamafricorp.com', NULL, '$2y$10$qp61kaOM9lRCqZXSfyELee1om4kh7dzinoJFmZ0Oi3UHcAV4Hh2A.', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(393, 'VIRGIL L METCALF LLC                              ', 'VIRGIL L METCALF LLC                              ', '2395650691', 'store256@teamafricorp.com', NULL, '$2y$10$T0P/Jw3nWk5myY0mHDEbx.cLyCobiZwc2OlwlmPTpGltbYvj5M9mO', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(394, 'PIECES OF EIGHT PIRATE HOLDINGS LLC               ', 'PIECES OF EIGHT PIRATE HOLDINGS LLC               ', '2397657272', 'store257@teamafricorp.com', NULL, '$2y$10$8z8HMrvaHYljiAFUtyUM.OrYZzuY0zzWdi82c7Jtf7bbnPM/5ZUq6', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(395, 'RAZA A INC                                        ', 'RAZA A INC                                        ', '2399489455', 'store258@teamafricorp.com', NULL, '$2y$10$f4PaKAwvoOJFMXvxznK1LuxMvmqTNol.kmZAwofpmXomHAear2iB2', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(396, 'YELLOW DOGZ LLC                                   ', 'YELLOW DOGZ LLC                                   ', '2393951464', 'store259@teamafricorp.com', NULL, '$2y$10$wwA4w/5l0XBZt5ztBkZh1.1Qp19VAivZfm36iXw6P6N36J4td.jOS', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(397, 'QUALITY FRESCA I LLC                              ', 'QUALITY FRESCA I LLC                              ', '9198004940', 'store260@teamafricorp.com', NULL, '$2y$10$2CJS8xFYi70/VIC.cGqANOUpM.yUzlvIwPt/2mlla0U/hdhPJGhFm', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(398, 'PANERA LLC                                        ', 'PANERA LLC                                        ', '2394584162', 'store261@teamafricorp.com', NULL, '$2y$10$bZ6ynnl35Tp4ZQ3fiDV7VudBVH/PWaZsnThXC9PfR6bua4iu1Ff0y', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(399, 'CLK RESTAURANT LLC                                ', 'CLK RESTAURANT LLC                                ', '2394543700', 'store262@teamafricorp.com', NULL, '$2y$10$kcFT9UUwkkS/ACZax7AOn.UGeJWSL88jFRhRh8BzEBXptx.3BrR96', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(400, 'OLD CORKSCREW GOLF CLUB MANAGEMENT LLC            ', 'OLD CORKSCREW GOLF CLUB MANAGEMENT LLC            ', '2399494700', 'store263@teamafricorp.com', NULL, '$2y$10$5l5wjJak0wVFUFsC3TfBKuQkR7z9EpA.4a5M4XwX0td0rQb06zKpK', NULL, '2022-01-22 18:39:55', '2022-01-22 18:39:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(401, 'BOB 2 INC                                         ', 'BOB 2 INC                                         ', '2395736172', 'store264@teamafricorp.com', NULL, '$2y$10$Lkt/dkMB0S0TmtzKanY1UO7efyQLTRdLOslZGysBcjCweuxPgzTf.', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(402, 'EUROPEAN FOOD MARKET OF FORT MYERS LLC            ', 'EUROPEAN FOOD MARKET OF FORT MYERS LLC            ', '2393327200', 'store265@teamafricorp.com', NULL, '$2y$10$Rdf/KLJ0208JnvORjMlFCuvefg7aQ.Mog/er0cU6.Mzsd4eiJuB8q', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(403, 'LANSDOWNE STREET LLC', 'LANSDOWNE STREET LLC', '2394953800', 'store266@teamafricorp.com', NULL, '$2y$10$5wXJhuvIdDML.xz3I7wHxu6rIF65kfcWsDstj1KDULS4u.SdZNiSS', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(404, 'I RAGAZZI PIZZA INC                               ', 'I RAGAZZI PIZZA INC                               ', '2397729005', 'store267@teamafricorp.com', NULL, '$2y$10$lZbzsj9V7etoJivwELrSi.wtI.H7PBYlsyB7O/bR3RTo40LFLGxuC', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(405, 'BRESOUTH SEAS RESORT OWNER LLC                    ', 'BRESOUTH SEAS RESORT OWNER LLC                    ', '2394725111', 'store268@teamafricorp.com', NULL, '$2y$10$cqOOGjh93xfLC1B.S68AzO/uwQQ.GLGwt2cIH4YVYLykzZ7M.8f1.', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(406, 'DIAMOND WHEELS BILLARDS CORP                      ', 'DIAMOND WHEELS BILLARDS CORP                      ', '2395737665', 'store269@teamafricorp.com', NULL, '$2y$10$kTsy8HP0NGR7T8a/iSYcT.pPELi/kxrzBKXtrPG8CC2IAuTw7Y8Ji', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(407, 'M ASSETS LLC                                      ', 'M ASSETS LLC                                      ', '2392420384', 'store270@teamafricorp.com', NULL, '$2y$10$oeOKihcB4YJNjUfH3HlUe.K1lkbT7xl41TpqRJj4qYnEYZvORsscq', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(408, 'STARBUCKS CORPORATION                             ', 'STARBUCKS CORPORATION                             ', '2063188705', 'store271@teamafricorp.com', NULL, '$2y$10$acvVM9S3iy1ct0p08g.EdOT8EVD1gAiMvJrNpCz1XnUxxwWPvU5qW', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(409, 'OUTBACK STEAKHOUSE OF FLORIDA LLC                 ', 'OUTBACK STEAKHOUSE OF FLORIDA LLC                 ', '4073994630', 'store272@teamafricorp.com', NULL, '$2y$10$IQj6QSaBN3HzTMPiu/6BIOPvIn7nn/jXXniPmJ1Qg2GSZrdeYMsdC', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(410, 'GARRATT DAVID                                     ', 'GARRATT DAVID                                     ', '2399401925', 'store273@teamafricorp.com', NULL, '$2y$10$axYaHNlOqfLqLgKckUJyB.xov1AhDqLqJgVjGSqmSZVo98A.n/H6q', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(411, 'MUNROAST INC                                      ', 'MUNROAST INC                                      ', '2393320077', 'store274@teamafricorp.com', NULL, '$2y$10$mMDqkHDf6UeHSG16HzgJreKQ3yUyr8izuYhscEu3BA3PGkx8kr0ue', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(412, 'TACOS EL TEQUILA INC', 'TACOS EL TEQUILA INC', '2394408311', 'store275@teamafricorp.com', NULL, '$2y$10$/8BjMBM9Hby51Tuhg94x5e6hjFoFvY/VfxRQoOFOil32efW.YD57q', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(413, 'ICE CREAM CLUB OF CAPE CORAL INC', 'ICE CREAM CLUB OF CAPE CORAL INC', '2392822582', 'store276@teamafricorp.com', NULL, '$2y$10$EfgRjKrKKfPWxHLaw/y/Ze33jp9oZ9na9Sz1C/bZYB8ETY//u6R3a', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(414, 'GULF COAST FLATS INC                              ', 'GULF COAST FLATS INC                              ', '2399488820', 'store277@teamafricorp.com', NULL, '$2y$10$EivOPADDEDIfDNet.qQYRO8ko4kCxc4K.TEuDPM/Uhyv9a2FVDW1G', NULL, '2022-01-22 18:39:56', '2022-01-22 18:39:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(415, 'SWEET CENTS INVESTMENTS LLC                       ', 'SWEET CENTS INVESTMENTS LLC                       ', '2395615300', 'store278@teamafricorp.com', NULL, '$2y$10$jzK/MnbgkbvDT5EuI42NFe.Y8olaMcS2WEfCULye.MZ31xRRUavcq', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(416, 'LUKASIK DAVID J', 'LUKASIK DAVID J', '2395432075', 'store279@teamafricorp.com', NULL, '$2y$10$v8J2xkuwK3c8lBGC2S9tx.kuLu47X7C7sZ7hLwr5CvDVbcwuoE//S', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(417, 'MY SWEET ART LLC                                  ', 'MY SWEET ART LLC                                  ', '2394587646', 'store280@teamafricorp.com', NULL, '$2y$10$NnPDwVC5ef/2zXwjmWY2NuFIFNfBJVnqkZZTu/f0DOXv5viccmt42', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(418, 'SWEET MELISSAS CAFE LLC                           ', 'SWEET MELISSAS CAFE LLC                           ', '2394721956', 'store281@teamafricorp.com', NULL, '$2y$10$sTvmCbsmbdXVxc3c2tx.lOa7wypZlWpEOOENkiest.mCgSIbha87m', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(419, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '2395612112', 'store282@teamafricorp.com', NULL, '$2y$10$yZLz91bJm0Ua/ZRKBOuFI.Q/m/LZTjVeLVpWSaXQMwiy/V4zNnDEC', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(420, 'BRINKER FLORIDA INC                               ', 'BRINKER FLORIDA INC                               ', '2392428724', 'store283@teamafricorp.com', NULL, '$2y$10$DDy8SbEx/yh2LQMNHjFeRO1jDjWoQHwCNidvrbtiaZ70QhxqCljMe', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(421, 'CHINA A & B INC                                   ', 'CHINA A & B INC                                   ', '2399479977', 'store284@teamafricorp.com', NULL, '$2y$10$F3i8DQRWWIbAfkChRgy8HuyQH.hzFlTSPEHVBOkMJpseN1o6ojETm', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(422, 'THE LANDINGS YACHT GOLF & TENNIS CLUB INC         ', 'THE LANDINGS YACHT GOLF & TENNIS CLUB INC         ', '2394823211', 'store285@teamafricorp.com', NULL, '$2y$10$zESLzVXVOGSsKimT4JYLWut1NocObMNXXJa68/xC8CfPd8BjIeyEu', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(423, 'CARRABBAS ITALIAN GRILL LLC                       ', 'CARRABBAS ITALIAN GRILL LLC                       ', '8132888286', 'store286@teamafricorp.com', NULL, '$2y$10$zfZBSosRXXCYBrw7CrhSGuKqwaZ3i2dk0FakImvWnHs9U27dvSDum', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(424, 'ISLAND COW LLC', 'ISLAND COW LLC', '2394720606', 'store287@teamafricorp.com', NULL, '$2y$10$5gew8ta9rI.QFB7Tqo.WteGAvU8eB4wU9G31tX/.8dV3gPPSAiYbq', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(425, 'PASEO MASTER HOMEOWNERS ASSOCIATION INC           ', 'PASEO MASTER HOMEOWNERS ASSOCIATION INC           ', '2395927344', 'store288@teamafricorp.com', NULL, '$2y$10$e88Do6xPl2mzF.bbKiY5Wei1reaMX0kwwKC1gIfJLtYEvVdUnxQ6S', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(426, 'TSC FL 147 INC                                    ', 'TSC FL 147 INC                                    ', '2399922008', 'store289@teamafricorp.com', NULL, '$2y$10$SoRIXbnhpONDgFwn03E20O154jFOkdEFSccjb.8.qVW4qAbgnF.ZK', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(427, 'FLORIDA SE LLC                                    ', 'FLORIDA SE LLC                                    ', '8002484918', 'store290@teamafricorp.com', NULL, '$2y$10$7j5E5L2QkKN9vqtWGr30WOISWNOOQ8U2T.FkQwJWDhlPT.NybAJt.', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(428, 'NPNY CORP                                         ', 'NPNY CORP                                         ', '2392746004', 'store291@teamafricorp.com', NULL, '$2y$10$Djf5TaB1G4HYBM79PH7azulwfTafnFv1ikoX.gIJBKz8rw5.sDFYi', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(429, 'JIMMY JOHNS OF ESTERO INC                         ', 'JIMMY JOHNS OF ESTERO INC                         ', '2399921152', 'store292@teamafricorp.com', NULL, '$2y$10$2PJ6DmC8TdS7./B8cPDeSe7AeerAp3e0CLmouWzcLGVWkwPbp2ESW', NULL, '2022-01-22 18:39:57', '2022-01-22 18:39:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(430, 'ESMERALDA CUBAN BAKERY INC                        ', 'ESMERALDA CUBAN BAKERY INC                        ', '2392001742', 'store293@teamafricorp.com', NULL, '$2y$10$RyN33hYFuGIXn6oiZ0Zm4Owh2Iys3QTn5WXRDjOhI.okG/WraqLEW', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(431, 'LUCKY CHINA WOK INC                               ', 'LUCKY CHINA WOK INC                               ', '2394823788', 'store294@teamafricorp.com', NULL, '$2y$10$n2zgTl9DhDYACIWgsxDghesh9lt08YrdXnmsPukHSnC7g7DUUuvza', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(432, 'JOF LLC                                           ', 'JOF LLC                                           ', '2393379425', 'store295@teamafricorp.com', NULL, '$2y$10$tGm84zWKknGwuXYFfBA6Ku606RSCtoMnRcXXlaS/qiI7bENv2BMEG', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(433, 'M ASSETS LLC                                      ', 'M ASSETS LLC                                      ', '2392426620', 'store296@teamafricorp.com', NULL, '$2y$10$TLn69o4fYlCqPEMOz4hv/O2dEVVpIyNMFIxSYKMEPkCXTCEv3sr4.', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(434, '1 WOK CHEN INC                                    ', '1 WOK CHEN INC                                    ', '2395738589', 'store297@teamafricorp.com', NULL, '$2y$10$RSzL.8djSCqeQlxCTzAZLulBbeAcm8xXCI2a0MGYeydlijRattkSu', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(435, 'LOWELL GENERAL SERVICE CORP', 'LOWELL GENERAL SERVICE CORP', '2393689715', 'store298@teamafricorp.com', NULL, '$2y$10$NJ39TTB7/Xf5VH6lt7EcO.tATk.bcuqq4xcZoq/FFTLNtiUzcysEe', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(436, 'PANDA EXPRESS                                     ', 'PANDA EXPRESS                                     ', '3059670024', 'store299@teamafricorp.com', NULL, '$2y$10$JF2cBwSCtOyCOBxQMM35Q.QfkCcoYfevt9V3P7w.jMC/VNUgg387W', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(437, 'STINGRAYS RAW BAR INC                             ', 'STINGRAYS RAW BAR INC                             ', '2393334386', 'store300@teamafricorp.com', NULL, '$2y$10$UexJp29B16GjZQ0f759HneelwiP4h7YmJNRLj3fzw3c4wce27BAl.', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(438, 'FUTURE ENERGY FLORIDA, INC.                       ', 'FUTURE ENERGY FLORIDA, INC.                       ', '2393698476', 'store301@teamafricorp.com', NULL, '$2y$10$MclgdsvF37byh.CYZ9xwjeMSDm.udpTzNX5eQk/JU0P4tntayb/o6', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(439, 'BURNT STORE GOLF & ACTIVITY CLUB INC', 'BURNT STORE GOLF & ACTIVITY CLUB INC', '9416394151', 'store302@teamafricorp.com', NULL, '$2y$10$SATpvVn61zoD2dvJFF7mluc2xEyA8PwBS.KgWrw09e8xC07.hfBiW', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(440, 'CHINA TOWN INC', 'CHINA TOWN INC', '2394953637', 'store303@teamafricorp.com', NULL, '$2y$10$fXP5v3.aghLmpXSQJ3JeQ./RDUWvt0LT4PXijeEdqyO8B3hAxJBdG', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(441, 'STARBUCKS CORPORATION                             ', 'STARBUCKS CORPORATION                             ', '2393322142', 'store304@teamafricorp.com', NULL, '$2y$10$RYJdp3U.DClLf2lGW5XcveQj6mmySnjgA.I3UTUSiNS3FTX/o0L2G', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(442, 'ULLOA-DIAZ   YAKELIN                              ', 'ULLOA-DIAZ   YAKELIN                              ', '2393037775', 'store305@teamafricorp.com', NULL, '$2y$10$gcYNRRt/c1gUnOyuRojT2OXuetD2HTW4oO1wL5b3WRmdobaKX7XCW', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(443, 'CEC ENTERTAINMENT LLC                             ', 'CEC ENTERTAINMENT LLC                             ', '2392775629', 'store306@teamafricorp.com', NULL, '$2y$10$PTyWf4hC4a9u4i.ju4ysz.UfcjQ4ont/K4SO9ZhGCyelTWmT0QoSa', NULL, '2022-01-22 18:39:58', '2022-01-22 18:39:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(444, 'WABBY GROUP LLC THE                               ', 'WABBY GROUP LLC THE                               ', '2399486697', 'store307@teamafricorp.com', NULL, '$2y$10$ygnJdiu2OAHKEWEEnQX6e.gTKVLhgMTFbjxFZruszRzcOW9MHWlWm', NULL, '2022-01-22 18:39:59', '2022-01-22 18:39:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(445, '1217 DEL PRADO BLVD LLC                           ', '1217 DEL PRADO BLVD LLC                           ', '2396738614', 'store308@teamafricorp.com', NULL, '$2y$10$pJyCYXRXyYM7i0jWR6g.xO4pdInl.v1Z2HZoKp81G7MP8VFKmf5we', NULL, '2022-01-22 18:39:59', '2022-01-22 18:39:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(446, 'PANERA LLC                                        ', 'PANERA LLC                                        ', '2392740294', 'store309@teamafricorp.com', NULL, '$2y$10$YPfVEDd7tN6koszbbZoQ4u4AHPkQiUs/qxyp0ztaAJJpuraJgjJHi', NULL, '2022-01-22 18:39:59', '2022-01-22 18:39:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(447, 'SSC344273 LLC                                     ', 'SSC344273 LLC                                     ', '2392563442', 'store310@teamafricorp.com', NULL, '$2y$10$hBykYhRqCO/ZHpRXw6cevOlhRTw9NmGuoyHL7UMy00gv40ff4Sdzq', NULL, '2022-01-22 18:39:59', '2022-01-22 18:39:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(448, 'CROSSROADS GRILL & LOUNGE INC                     ', 'CROSSROADS GRILL & LOUNGE INC                     ', '2395739253', 'store311@teamafricorp.com', NULL, '$2y$10$0/tHYoR5JDrL7XcmJ2DnpOGLOt51d8gPIinL61ab6TsyN4JblCypS', NULL, '2022-01-22 18:39:59', '2022-01-22 18:39:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(449, 'JESARECC INC                                      ', 'JESARECC INC                                      ', '2394494722', 'store312@teamafricorp.com', NULL, '$2y$10$.lAOBmLoD7UPzt.0TQ9iyuvGKBpquqXCIhVDhkqqgvPsVrAuCCKiq', NULL, '2022-01-22 18:39:59', '2022-01-22 18:39:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(450, 'BONEFISH GRILL LLC                                ', 'BONEFISH GRILL LLC                                ', '8132821225', 'store313@teamafricorp.com', NULL, '$2y$10$tP/UtLpJ82nk9PJwhbPB4OtXVgjOPiy2u3vs.us/zudJ9KbfuJAyG', NULL, '2022-01-22 18:39:59', '2022-01-22 18:39:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(451, 'JEB HOLDINGS LLC                                  ', 'JEB HOLDINGS LLC                                  ', '2395747070', 'store314@teamafricorp.com', NULL, '$2y$10$glA8qBYUPKs5MISrRUz9RuqwIVZQpEgy900nQFf6NRrpgfegf3YNC', NULL, '2022-01-22 18:39:59', '2022-01-22 18:39:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(452, 'ORTESE INC                                        ', 'ORTESE INC                                        ', '2399925000', 'store315@teamafricorp.com', NULL, '$2y$10$234DyA3dnuzzEHixAyVATOUvv6M0n1gaX08KmkLC.21/4LJPQ7CgC', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(453, 'M ASSETS SOUTHWEST FLORIDA LLC', 'M ASSETS SOUTHWEST FLORIDA LLC', '2179354915', 'store316@teamafricorp.com', NULL, '$2y$10$AIy7Oonr6W4BWuYVe/sPoeyCSaBKgIxmWNcJZHs98rBlL0ln64J4W', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(454, 'LEONE PROVISIONS LLC', 'LEONE PROVISIONS LLC', '2394580013', 'store317@teamafricorp.com', NULL, '$2y$10$HDPBKxolYP74uWdwKIzUtejb/25CX93wzTYXK2G74h1hgdT4HNFyy', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(455, 'QUALITY BRAND GROUP FLORIDA LLC                   ', 'QUALITY BRAND GROUP FLORIDA LLC                   ', '2033282130', 'store318@teamafricorp.com', NULL, '$2y$10$Crmqo/nLxpTvsNtvUaHGgOG.3WiRfq0U80Tl8TX4ZIp33HRjiiFXm', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(456, 'ALLEN ANNE MARIE                                  ', 'ALLEN ANNE MARIE                                  ', '2393336264', 'store319@teamafricorp.com', NULL, '$2y$10$r8KkUzmPxHDgZXSOMOPt1O5jMo2Jmw1/m5dC.3t0hJ38Nb1Ln1SKm', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(457, 'OSAKA JAPANESE STEAKHOUSE INC                     ', 'OSAKA JAPANESE STEAKHOUSE INC                     ', '2394892414', 'store320@teamafricorp.com', NULL, '$2y$10$I1BKPXXeo6nDCTz1rdgIDelvlkk9W9b4ySfWmMD5weTfczeLcJ8na', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(458, 'THREE STAR VENTURES LLC                           ', 'THREE STAR VENTURES LLC                           ', '6035148241', 'store321@teamafricorp.com', NULL, '$2y$10$p.oWX8CtqCf/cyhIk3KiWOvvaqV1z6WSipFLFfVcNIwtWP/44YUP.', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(459, 'LA BELLE GOURMANDISE, LLC                         ', 'LA BELLE GOURMANDISE, LLC                         ', '2399922233', 'store322@teamafricorp.com', NULL, '$2y$10$Q7lEPOb2Wg8FNtxVm/FX9eONwFjHUTwsaX2o1HGKkW2k94WcIb0Ve', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(460, 'BRADBURN HOSPITALITY LLC                          ', 'BRADBURN HOSPITALITY LLC                          ', '2394988700', 'store323@teamafricorp.com', NULL, '$2y$10$z24GllXtI1pyTkxkI.1.bukhzq3gp9kCicP0wQPtp/75eYiWZo.ZK', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(461, 'JB MATTIA ENTERPRISE INC                          ', 'JB MATTIA ENTERPRISE INC                          ', '2392825502', 'store324@teamafricorp.com', NULL, '$2y$10$XeLafgHBUag2f0kITz0abugS/P3e3KileXS5QFzFntKdYD6rcyc9S', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(462, 'STH INC OF SWFL                                   ', 'STH INC OF SWFL                                   ', '2393901428', 'store325@teamafricorp.com', NULL, '$2y$10$eYtPx2UKjhP1ps0lQeXcpOnvuEW5tXx8UTE6/0PhTXu/dUN9E4a7m', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(463, 'FISHER DARYL                                      ', 'FISHER DARYL                                      ', '2392756940', 'store326@teamafricorp.com', NULL, '$2y$10$XDDHnpyMigQ7xh2pmid9z.6C8bGRARc.hKOl9inL3tZh18BisB2WS', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(464, 'JAMA FOOD SERVICES INC                            ', 'JAMA FOOD SERVICES INC                            ', '2393699800', 'store327@teamafricorp.com', NULL, '$2y$10$PqJ0xUIJZIRxmSZuuq88lO6JUL7C/8jEG2p4zGaGDrgyb3R.x6NvW', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(465, 'CHEF BROOKES LLC', 'CHEF BROOKES LLC', '2394649659', 'store328@teamafricorp.com', NULL, '$2y$10$kTaWDsuK0OxaQDbJ6rkPauYnRCyhwdy2FsSJzLK0mquoLeGJqBq5q', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(466, 'NGUYEN LIEM VAN                                   ', 'NGUYEN LIEM VAN                                   ', '2398290343', 'store329@teamafricorp.com', NULL, '$2y$10$VoJFBwBkgqOh4RFMfotRqu04izeiZOFQ3s7y1rXfTrLoMVK1Vl5Si', NULL, '2022-01-22 18:40:00', '2022-01-22 18:40:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(467, 'VAN DER KOOY KEVIN                                ', 'VAN DER KOOY KEVIN                                ', '2394374800', 'store330@teamafricorp.com', NULL, '$2y$10$pKn/B33fc1k5EAx.31uWjucSysHDebn9nWWN1Jt5wmY7IcYyGZIga', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(468, 'WEBSTERS GRILL INC                                ', 'WEBSTERS GRILL INC                                ', '2392457674', 'store331@teamafricorp.com', NULL, '$2y$10$Fb/kZeSGJrJtZEtqZIgEpeQF5zi3zYOxurvwahGLOb1oqqVyIBTiC', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(469, 'M ASSETS SOUTHWEST FLORIDA LLC', 'M ASSETS SOUTHWEST FLORIDA LLC', '2392672813', 'store332@teamafricorp.com', NULL, '$2y$10$TBTUdPSoLMoHITvrEyLLE.yfqPZ1xijCbgJcN8PhI41Xv34Pb72FC', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(470, 'HARRITTY MARTY J                                  ', 'HARRITTY MARTY J                                  ', '2397659660', 'store333@teamafricorp.com', NULL, '$2y$10$ji1v2ejI3H8XCzAyfCdnUuXWD.Fh6.o/2fwHi9pXkvmvTZHI6QWe6', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(471, 'CAFE LUPITA CAFE LLC', 'CAFE LUPITA CAFE LLC', '2394795244', 'store334@teamafricorp.com', NULL, '$2y$10$zJfHG3iDfm68COfyaFO/Vu2oyl02qOw9wOBSJQO8v/7O8MwL/SNrW', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(472, '7 ELEVEN INC & GLORELYN ENTERPRISES INC           ', '7 ELEVEN INC & GLORELYN ENTERPRISES INC           ', '2392420018', 'store335@teamafricorp.com', NULL, '$2y$10$cIi1JRnK/5G5gIMrTaZwzuPm8EFHiRhneDTd2IHGs5d8.bbQGOdny', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(473, 'OAN FOOD MART INC', 'OAN FOOD MART INC', '2395952572', 'store336@teamafricorp.com', NULL, '$2y$10$gfytfZ3fgiyeZsmpYhzqGukhbwRek3TmCXB3NFWuhieMIdXphHXaG', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(474, 'COSSETTE  LLC                                     ', 'COSSETTE  LLC                                     ', '2392428748', 'store337@teamafricorp.com', NULL, '$2y$10$pckcwfqyCOOGTWguPPHzvuCVDAl2hcfjuDEsRsiWsVHYbuegNlfHK', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(475, 'GOOD THING ALLIANCE LLC A                         ', 'GOOD THING ALLIANCE LLC A                         ', '2399853013', 'store338@teamafricorp.com', NULL, '$2y$10$YnS3e9UBTBCh75bQGD3ate1asYbDoNYNAi3gfDAFVnInYdvzJqX3a', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(476, 'EL MAMBO RESTAURANT INC                           ', 'EL MAMBO RESTAURANT INC                           ', '2395429995', 'store339@teamafricorp.com', NULL, '$2y$10$wQjK8YkGnPySfRyHgJgxGuO5cMrG3UHSwISvp30idiy7X/fwKSQNy', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(477, 'TABER JOSHUA AND MICHELLE                         ', 'TABER JOSHUA AND MICHELLE                         ', '2399496822', 'store340@teamafricorp.com', NULL, '$2y$10$8BtGE73u.IKVX3.cXNmPZOXMKvCaOez90vFtin1hgPdRMnZQmtqU6', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(478, 'FUTURE ENERGY FLORIDA, INC.                       ', 'FUTURE ENERGY FLORIDA, INC.                       ', '2395619633', 'store341@teamafricorp.com', NULL, '$2y$10$xf3Y8Sa4F27GigESeR9SvOKZEr6a5zV8g.5E4ZRjhMIJ49eXbVYKy', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(479, 'VIVET CHRISTIAN C                                 ', 'VIVET CHRISTIAN C                                 ', '2395651608', 'store342@teamafricorp.com', NULL, '$2y$10$s79KoxSsLpiAAOrYzt3J2eslxDHD8gsLrNAVYFQ8p2oBhd0vA5FY2', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(480, 'SOF VENTURES LLC                                  ', 'SOF VENTURES LLC                                  ', '2393341651', 'store343@teamafricorp.com', NULL, '$2y$10$.lHPsQi5ngDFgT2a5eHJYey.lCUIplOYw1EFQyK0nJAhBl.Eo0Jk6', NULL, '2022-01-22 18:40:01', '2022-01-22 18:40:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(481, '7 ELEVEN INC & ALICO BAY ENTERPRISES INC          ', '7 ELEVEN INC & ALICO BAY ENTERPRISES INC          ', '2394371205', 'store344@teamafricorp.com', NULL, '$2y$10$sxUfw/FFuPZydif/otQnbO/D/PfRtbptFm9tzRAFEcyHQo6rRE13O', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(482, 'JHS KUBERRA17 LLC                                 ', 'JHS KUBERRA17 LLC                                 ', '2393694835', 'store345@teamafricorp.com', NULL, '$2y$10$GZL2gUA3BCTpAEWbR6BH1OdeHlTyClL656W2AP5I7KSAIT/9CTOZS', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(483, 'SLATE 08 LLC                                      ', 'SLATE 08 LLC                                      ', '9419640155', 'store346@teamafricorp.com', NULL, '$2y$10$XHp8KPi3hwK9TcAJGqMOs.yoT/BZlRAaIQn2ZdCwg/P9UxHAzFfZG', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(484, 'EUROPEAN BAKERY & DELI INC', 'EUROPEAN BAKERY & DELI INC', '2393031822', 'store347@teamafricorp.com', NULL, '$2y$10$uge3Nfk7cEQ0R.P/7PTbne6NK8aMFMFWS8olIDJSS6Fii1FOzPQai', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(485, 'JAMA FOOD SERVICES INC                            ', 'JAMA FOOD SERVICES INC                            ', '2395909800', 'store348@teamafricorp.com', NULL, '$2y$10$EDb/65qyvQYIvdTLvyknLujr52AK6Fw8CYdx0YONo08jfKQHDh36m', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(486, 'DIEUNER DORLUSCA', 'DIEUNER DORLUSCA', '2398789074', 'store349@teamafricorp.com', NULL, '$2y$10$V4D25co1Mhs2f3N1qLTygekAZmajcp9dSibOeNsnqGajoYAczrcDe', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(487, 'SAIBABA LLC                                       ', 'SAIBABA LLC                                       ', '2393136344', 'store350@teamafricorp.com', NULL, '$2y$10$h.PIHBtiM46UY5G35qAHrucIwSLelaLI9.ydmSsfFmfNnOhhzxzO2', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(488, 'J AND E TIKI LLC                                  ', 'J AND E TIKI LLC                                  ', '2392828454', 'store351@teamafricorp.com', NULL, '$2y$10$P8nnAYZaAttl2rALIQRar.LhzOqKze1VmuspKoQ1.72nn49fncEv6', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(489, 'RESTAURANTE LA BENDICION INC                      ', 'RESTAURANTE LA BENDICION INC                      ', '2392565232', 'store352@teamafricorp.com', NULL, '$2y$10$HvnE7FczSu20/CqkkTHpiudjtCdal.yCmqRiY99CT0UCwYhZyfEqa', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(490, 'NAPLES FLATBREAD ESTERO LLC', 'NAPLES FLATBREAD ESTERO LLC', '2394953528', 'store353@teamafricorp.com', NULL, '$2y$10$i6cW0H3a76W.StPGyHBd1uCGo7VUkrnvn5F4GYO0CX5W9p/ALv3xe', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(491, 'CLOWNFISH RESTAURANT HOLDINGS LLC                 ', 'CLOWNFISH RESTAURANT HOLDINGS LLC                 ', '2392338224', 'store354@teamafricorp.com', NULL, '$2y$10$iD2m5o5.smywlO4t7Kxr6OBD1l1a7o9PwnmNLKWsmuYJjoFv46aOG', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(492, 'TRE AND AMY INC                                   ', 'TRE AND AMY INC                                   ', '2394635398', 'store355@teamafricorp.com', NULL, '$2y$10$w/CIIYTyz9WADsPs2m2L5.LIiMUB5WCocDjpk6QLwMNV8fQdFFnDi', NULL, '2022-01-22 18:40:02', '2022-01-22 18:40:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(493, 'VEGANEERS LLC                                     ', 'VEGANEERS LLC                                     ', '2394248433', 'store356@teamafricorp.com', NULL, '$2y$10$.iOAmts9ETGzQzrckXzbLeTbqHsRayF3iU3rlK0F2AB5GRMwS0nZK', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(494, 'M & M PETRO GROUP INC                             ', 'M & M PETRO GROUP INC                             ', '2395903973', 'store357@teamafricorp.com', NULL, '$2y$10$yc2wv2gyxaPNtPnKUO.dteVlvFoDrg6XJ5eYySOOf56fFtt4Md/yK', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(495, '7 ELEVEN INC & RC & B HOLDINGS CORP               ', '7 ELEVEN INC & RC & B HOLDINGS CORP               ', '2395742110', 'store358@teamafricorp.com', NULL, '$2y$10$cv9pwiWbBxeyol.KN2aiOer3lh9UpzwjpfkT4dMM.TEPK2LeP0NHK', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(496, 'LUCKY FAMILY 888 INC                              ', 'LUCKY FAMILY 888 INC                              ', '2394581818', 'store359@teamafricorp.com', NULL, '$2y$10$Mb3iXL3ksK4hO2VFQJ.EWuT0CxDijQCgOayc3KtjlJq8lcx8hkKXS', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(497, 'PU THAI LLC                                       ', 'PU THAI LLC                                       ', '2395994639', 'store360@teamafricorp.com', NULL, '$2y$10$fwuE05Lf6U1M6gIISHixY.DUI.QYuhmgs76FhyiLxbY7K5Xgc1Hd6', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(498, 'EL MAMBO RESTAURANT II INC                        ', 'EL MAMBO RESTAURANT II INC                        ', '2399452587', 'store361@teamafricorp.com', NULL, '$2y$10$4/5F6aiu9T5DfuZU25mvnu.g1EmOh0wfygrXskl5pQBldiD.KEo9.', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(499, 'M ASSETS FIVE LLC', 'M ASSETS FIVE LLC', '2399487106', 'store362@teamafricorp.com', NULL, '$2y$10$LWoPlDSqntt1ZElM3ThWvO6QBQqTStJujfYNR311YiXLepcg.DbW.', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(500, 'BLT EATS LLC                                      ', 'BLT EATS LLC                                      ', '2399452262', 'store363@teamafricorp.com', NULL, '$2y$10$8Tuyg./LYfKdeK9sw4eIHOtiVzXHQpc51AtzyTx11oCa0Jg2eM8dC', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(501, 'MINERVAS GRILL INC                                ', 'MINERVAS GRILL INC                                ', '2394150202', 'store364@teamafricorp.com', NULL, '$2y$10$5F7xzAmtlqbgLVwbQAC8le0P17ZjvwWnN7n0CdoIKBfgKJVv/nJle', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(502, 'AZUCAR CAFE INC                                   ', 'AZUCAR CAFE INC                                   ', '2396747444', 'store365@teamafricorp.com', NULL, '$2y$10$8kdAAVPlefX.8ScLsc2gCeLhFswKZvBqvFQxvB4oBvZV7Jwcqg/Ae', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(503, 'JAMES M THOMPSON TWO LLC                          ', 'JAMES M THOMPSON TWO LLC                          ', '2393900123', 'store366@teamafricorp.com', NULL, '$2y$10$r15EJ7sMj9U734VX1Sh60ueXY0J7A9IM2Jje3S3ttbABZobHwBSX.', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(504, 'KENWOOD LANE GRILLE                               ', 'KENWOOD LANE GRILLE                               ', '2397285400', 'store367@teamafricorp.com', NULL, '$2y$10$XQHoRoyu14aWxSy4xEzBp.3SEmoYzbXeNf83vwJFbcZrB7eZ3.Pq2', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(505, 'KASSEK ENTERPRISE INC                             ', 'KASSEK ENTERPRISE INC                             ', '2395402000', 'store368@teamafricorp.com', NULL, '$2y$10$whqI170T7rQrpWDnw37AYeKGhzYVZ9DJCGtnMOQZBFE5wrCygv8Ny', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(506, 'AHMAD CORPORATION                                 ', 'AHMAD CORPORATION                                 ', '9549932867', 'store369@teamafricorp.com', NULL, '$2y$10$epS2jj8c7D3.sc3Aq3y3V.Ov1lzak7/WZ/PH6ZocYXAcnjk7Ho89u', NULL, '2022-01-22 18:40:03', '2022-01-22 18:40:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(507, 'CAPTIVA PIZZA YOGURT AND GIFT EMPORIUM LLC        ', 'CAPTIVA PIZZA YOGURT AND GIFT EMPORIUM LLC        ', '2393950823', 'store370@teamafricorp.com', NULL, '$2y$10$3/zaRHeZxfIejxC7KJyxhuMp98u.zd5c3/EgGEFwxOS8GBrknNstu', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(508, 'SENOR TEQUILAS INC                                ', 'SENOR TEQUILAS INC                                ', '2399489700', 'store371@teamafricorp.com', NULL, '$2y$10$ni/5L7yfGbiiHX0ZDAIK5eNtrF2OnVtcWtb7W8Z7pPY2/GsnVBgbe', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(509, 'JR RESTAURANT GROUP LLC                           ', 'JR RESTAURANT GROUP LLC                           ', '2396898775', 'store372@teamafricorp.com', NULL, '$2y$10$m2fLgz7AatbTRIYhLuy.duJCf/Ql4CZI0u343uQAZT3825dY33c7q', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(510, 'PINCHERS CRAB SHACK OF GCTC INC                   ', 'PINCHERS CRAB SHACK OF GCTC INC                   ', '2394315504', 'store373@teamafricorp.com', NULL, '$2y$10$r59GHSNH3RVO5unEQcl.aeIFZl8EI5XS5mzN7lSoYnOpGmORtH.TK', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(511, 'SOUTHERN SNO BALLS LLC', 'SOUTHERN SNO BALLS LLC', '2399807875', 'store374@teamafricorp.com', NULL, '$2y$10$t4dEc83N18N6/UQvXWIpce42kOEeqBZnrcDY164588..w5coEw36G', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(512, 'NJV CORPORATION                                   ', 'NJV CORPORATION                                   ', '2394950991', 'store375@teamafricorp.com', NULL, '$2y$10$XBB661TvcZHGDC8P1l7EYu01cg.Y7za1DO6oYyznOkO/GE21y5MeG', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(513, 'ZHENG XIU HUI', 'ZHENG XIU HUI', '2395903996', 'store376@teamafricorp.com', NULL, '$2y$10$ZGV1qjeUScnQ3beQI4qcCuAb26N7AUwNuq1MAPQBot5fRmExXkYh.', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(514, 'RENAISSANCE CENTER AT PALMIRA INC                 ', 'RENAISSANCE CENTER AT PALMIRA INC                 ', '2399494466', 'store377@teamafricorp.com', NULL, '$2y$10$hE0YqOSRAhjIJWjpa3uTB./WINwJ5oqgP8qpivGfg03n36y8lPLMy', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(515, 'KSL SW INC                                        ', 'KSL SW INC                                        ', '2396895660', 'store378@teamafricorp.com', NULL, '$2y$10$lOj/bEDgjeNOuteWp5.hIe5Wbue6Wk.RHIIEYiFBMDWJOnp6jyBpW', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(516, 'JOE DADDYS PIZZA LLC                              ', 'JOE DADDYS PIZZA LLC                              ', '2395736600', 'store379@teamafricorp.com', NULL, '$2y$10$F1nHIMP73iM3ruHivbVuF.SWv.YED0n9wvfvgP/3DzdF79V0wwBH6', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(517, '7 ELEVEN INC & JP SQUAD ENTERPRIZE INC            ', '7 ELEVEN INC & JP SQUAD ENTERPRIZE INC            ', '2393347207', 'store380@teamafricorp.com', NULL, '$2y$10$aar08llxZDFZ0RDcTt9OceJyDm7RmaZAYC1EbOkK1uJcoyUblLdl6', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(518, 'BELL TOWER PIZZERIA INC                           ', 'BELL TOWER PIZZERIA INC                           ', '2399477100', 'store381@teamafricorp.com', NULL, '$2y$10$7TRSxVwFRjc5.U8NujdNQuNbK1A8ESOcdK0LX0T2CfEkYk7zUUnn2', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(519, 'RIB CITY SAN CARLOS INC                           ', 'RIB CITY SAN CARLOS INC                           ', '2392756700', 'store382@teamafricorp.com', NULL, '$2y$10$ZbScV0f2vKewjaNX50fdxO4QEqRtDRrO.myjgkAXp09K7QMfn8l8G', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(520, 'MEYER PROPERTIES OF THE SOUTH INC                 ', 'MEYER PROPERTIES OF THE SOUTH INC                 ', '2397918554', 'store383@teamafricorp.com', NULL, '$2y$10$ipwoohMfrssb8f.z0yA8Vu4.QpmZXd4e2EV407osJy/ocO2fQyfzO', NULL, '2022-01-22 18:40:04', '2022-01-22 18:40:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(521, 'BLAZIN WINGS INC                                  ', 'BLAZIN WINGS INC                                  ', '9525168175', 'store384@teamafricorp.com', NULL, '$2y$10$kU0kWiKSjiMkDWFb1NOOduYnlRidV37kH5sF/AVcbHx330H1vCTpu', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(522, 'MOBILE NOSH LLC                                   ', 'MOBILE NOSH LLC                                   ', '2392480715', 'store385@teamafricorp.com', NULL, '$2y$10$3I3faGodsU8BILDf2wMN7.kVyT60tC9QWP4mPGAItFswTe/ID7H4q', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(523, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2392250326', 'store386@teamafricorp.com', NULL, '$2y$10$hUW87hxSe/2pxCTMlqTFAOmPcdmD7bLfAdyWXEkTx3Xj8keVPncyO', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(524, 'CHANG HSIN TING', 'CHANG HSIN TING', '2393440037', 'store387@teamafricorp.com', NULL, '$2y$10$f5QBqYmV7OBM7WOYLsVOpO6OzyqtuHGdhGN6vGkPoyqEyO94LYPPy', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(525, 'CICCIO BELLO FM LLC                               ', 'CICCIO BELLO FM LLC                               ', '2394891111', 'store388@teamafricorp.com', NULL, '$2y$10$zxdcAPkNUxInGK.tmVua7e0V2x5A8e7UfHrCBv2GRAlsvj4QgLH/C', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(526, 'RHONDAS DELI INC                                 ', 'RHONDAS DELI INC                                 ', '2396904123', 'store389@teamafricorp.com', NULL, '$2y$10$WZjyv3cfiiqsWIUeOOjKDORxbjzknznR/2Ndr5s4fdGDfKzrjJMoG', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(527, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2392422573', 'store390@teamafricorp.com', NULL, '$2y$10$X17hYiYfpcW4LzZ0eG/VAe88RvOsExUjqi4zgwIHeb9mjmCbhkc3u', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(528, '7 ELEVEN INC & FAIZA ENTERPRISES INC              ', '7 ELEVEN INC & FAIZA ENTERPRISES INC              ', '2393690262', 'store391@teamafricorp.com', NULL, '$2y$10$vc55gYwKrJgBVFqFpmoeX.yMBC2PLhU2X0YmQXTtT4MuG5dGdNe.S', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(529, 'MARTIAN MANAGEMENT INC                            ', 'MARTIAN MANAGEMENT INC                            ', '2392671317', 'store392@teamafricorp.com', NULL, '$2y$10$wGC4UUjlEwmlhEDwpMkFwe6glr7Kn7/VHZID2MuumCjbzufrVNxBW', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(530, 'FROZEN PARADISE INC                               ', 'FROZEN PARADISE INC                               ', '2394958582', 'store393@teamafricorp.com', NULL, '$2y$10$UIZEiU5NogLUUV6pwp1dROvkrnOOTP98Z2e2DAu9TMq2znKBFipDm', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(531, 'COASTAL QSR LLC                                   ', 'COASTAL QSR LLC                                   ', '7068556395', 'store394@teamafricorp.com', NULL, '$2y$10$zYseaooeQZgwQ2gVwM/kU.wLlP0IHjr3pmn8QP1iKONkCfCWNlxeu', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(532, 'THREE FISHERMAN SEAFOOD NORTH LLC', 'THREE FISHERMAN SEAFOOD NORTH LLC', '2395998568', 'store395@teamafricorp.com', NULL, '$2y$10$nj7D/fD/U1urVHHYyiLHI.i/JWuAd69dj75filIZQEiH.rI4IMDo6', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(533, 'CARIBBEAN DELIGHTS BESTRO INC                     ', 'CARIBBEAN DELIGHTS BESTRO INC                     ', '2393683265', 'store396@teamafricorp.com', NULL, '$2y$10$aSRBgtcbJXwQmLkHba7mceu5IAvCrkcOWEqvRmzuQyE.g6U3EUjnG', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(534, 'MOSAIC RBFL LLC                                   ', 'MOSAIC RBFL LLC                                   ', '2393901702', 'store397@teamafricorp.com', NULL, '$2y$10$3Qi4nLDP3PusxAHWj5Eok.7KFtL0F0yHznSm58Xqort720NR.eTZq', NULL, '2022-01-22 18:40:05', '2022-01-22 18:40:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(535, '7 ELEVEN INC & NEIGHBORHOOD MARKETS INC           ', '7 ELEVEN INC & NEIGHBORHOOD MARKETS INC           ', '2395429260', 'store398@teamafricorp.com', NULL, '$2y$10$fEKt71aXiddvqCpNegUaA.8x7R3ARrAAK44gOGCgTykuOC07cYwTy', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(536, 'COCONUT JACKS WATERFRONT GRILLE LLC               ', 'COCONUT JACKS WATERFRONT GRILLE LLC               ', '2396767777', 'store399@teamafricorp.com', NULL, '$2y$10$n6S7Io9KfzYc0e0g9aV.EudWiz/EwkvVkaTXxVbsCeLVl6u1QTtKC', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(537, 'BURGERQUE LLC', 'BURGERQUE LLC', '2392775700', 'store400@teamafricorp.com', NULL, '$2y$10$eFpiKsqmt3SUL67kvT/goe9NgVxexnn3wHwTuq/N0RWvjF3lU.byW', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(538, 'TERMINATOR OUTDOOR LASER TAG LLC                  ', 'TERMINATOR OUTDOOR LASER TAG LLC                  ', '7342163323', 'store401@teamafricorp.com', NULL, '$2y$10$id5hrgfK0MH7EH48LPiLD.QH1g6UuhgYBLme/wQCBimX02gMgN.cK', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(539, 'FANG TANG GROUP INC', 'FANG TANG GROUP INC', '9175472848', 'store402@teamafricorp.com', NULL, '$2y$10$/b0jPawf66lp01jpJ/9RH.GWMl6K4UzsfSqzWBjdRqKhIQ9mcsGtK', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(540, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2393320775', 'store403@teamafricorp.com', NULL, '$2y$10$fY6lfq3o1ss2klBtFcs5peotMJ5urGkiflvujp9YC9CgAPtcdzbHK', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(541, 'ZUSHI ZUSHI LLC', 'ZUSHI ZUSHI LLC', '2394639874', 'store404@teamafricorp.com', NULL, '$2y$10$htVjKUT50uLZt7ytSXM8fO2mxDxfEWLpx8.QAWPedRXh8hu5rs4Vm', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(542, 'LCT RESTAURANT PARTNERS 4 LLC                     ', 'LCT RESTAURANT PARTNERS 4 LLC                     ', '2394769000', 'store405@teamafricorp.com', NULL, '$2y$10$SEwU1nWZ9GDhQ8wKzyE7g.WaicfoeI/.Evms3O/9wYRi9SfTu6G9m', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);
INSERT INTO `vendors` (`id`, `f_name`, `l_name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `bank_name`, `branch`, `holder_name`, `account_no`, `image`, `status`, `firebase_token`, `auth_token`) VALUES
(543, 'SUSHI THAI TEAM LLC                               ', 'SUSHI THAI TEAM LLC                               ', '2399925600', 'store406@teamafricorp.com', NULL, '$2y$10$CAnvO8Y4absDQ7zi30XpqewDHEVM3U7X66MpGsyYVNGxZrWVuW5rW', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(544, 'RIB CITY ESTERO INC                               ', 'RIB CITY ESTERO INC                               ', '2392756700', 'store407@teamafricorp.com', NULL, '$2y$10$GNex.WPuojMIAC4t0D8PHerfepaolhGNfdoBrdFZ1BV/uyeiLrzrS', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(545, 'CIAO WOOD FIRED PIZZA & TRATTORIA INC', 'CIAO WOOD FIRED PIZZA & TRATTORIA INC', '2394710033', 'store408@teamafricorp.com', NULL, '$2y$10$eHsSy8rE84yHAnkX6BVFc.d0eD0y4ntTzAFhuKJ8kLRWoCGsiLli.', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(546, '7 ELEVEN INC & KESAV ENTERPRISES INC              ', '7 ELEVEN INC & KESAV ENTERPRISES INC              ', '2394376152', 'store409@teamafricorp.com', NULL, '$2y$10$vwfZBxD9hYRqJzj6j54knOykt/908Ql7scVOqzsiFYGO5m6YG98.2', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(547, 'THE SUMMIT GROUP (SE) LLC                         ', 'THE SUMMIT GROUP (SE) LLC                         ', '2392751110', 'store410@teamafricorp.com', NULL, '$2y$10$/lQr/OERkAC9moFy6sXrAugj78KIiEtPPpHNkYy5KlnbjhuQDDxWO', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(548, 'CITROLAS ON COLLEGE INC                           ', 'CITROLAS ON COLLEGE INC                           ', '2394661113', 'store411@teamafricorp.com', NULL, '$2y$10$9VzxveUK34cKMGlirBAScOiBCt5sblqjvfRM2eFKld1/TTHZxxUom', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(549, 'BREAD PETE LLC                                    ', 'BREAD PETE LLC                                    ', '2394716933', 'store412@teamafricorp.com', NULL, '$2y$10$wGbqWgWDVi09/mCZgxzUD.nnGgmf/MEUputWSsP22XZyKXD.nH7di', NULL, '2022-01-22 18:40:06', '2022-01-22 18:40:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(550, 'KAM WAI MAN', 'KAM WAI MAN', '2392260868', 'store413@teamafricorp.com', NULL, '$2y$10$K.dM0UXXqk395BDNsRPtn.d990l3lRWsXKI28YsdJ.qYmFI8d1d/W', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(551, '7 ELEVEN INC                                      ', '7 ELEVEN INC                                      ', '2399317140', 'store414@teamafricorp.com', NULL, '$2y$10$VWy/FrXe9eN6QwwLK32RSu93TpUW8Iby3K6jFbX.XjKBTnePHhfBe', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(552, 'BLACK SEA PETROLEUM INC                           ', 'BLACK SEA PETROLEUM INC                           ', '2393320600', 'store415@teamafricorp.com', NULL, '$2y$10$QNXIc8PBWCYUraZlgUsDVODJdBnZ.DDhRKdesls.mp2M8Uo3nwOMC', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(553, 'DJA ENTERPRISES LLC', 'DJA ENTERPRISES LLC', '2394728686', 'store416@teamafricorp.com', NULL, '$2y$10$x2oPJ0W3ltqezHo0KjKOcuaRFfg4/4pJOUoJrn9ecIIFifZ51FhoG', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(554, 'OCONNOR BRIAN J                                   ', 'OCONNOR BRIAN J                                   ', '2398265121', 'store417@teamafricorp.com', NULL, '$2y$10$TI/vS7T0BHBOs058vAymxuOrVPoVZ2BtQmoJwZ00U0R.hNFHJ1f3i', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(555, 'TRACKSIDE LLC', 'TRACKSIDE LLC', '2392950002', 'store418@teamafricorp.com', NULL, '$2y$10$FYvJ93GrLOxrEdyfuVAo.Odsy6ZBhgWw3PAHCE89S94EY/.PzXeuq', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(556, 'CHOP CHOP CHOP LLC                                ', 'CHOP CHOP CHOP LLC                                ', '2395431015', 'store419@teamafricorp.com', NULL, '$2y$10$/469t7jDGFzf.GB5B7GTUe5I8ZQLeJvKAFdBZSciuZKTc1c61eiXG', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(557, 'LOPEZ SUAREZ CORP                                 ', 'LOPEZ SUAREZ CORP                                 ', '9548024468', 'store420@teamafricorp.com', NULL, '$2y$10$wqMGwaMVOnuO6iIPdIix3utEUeUwqarwLtrufIcEaCI9rgy29IJRu', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(558, 'JESAREFM INC                                      ', 'JESAREFM INC                                      ', '2399397211', 'store421@teamafricorp.com', NULL, '$2y$10$18/ND2HUQ5OPpVdtXlI67uggGM.q/Q0RCUQudsXQwR4p57yL1WwiC', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(559, 'FIGS BISTRO INC', 'FIGS BISTRO INC', '2393901700', 'store422@teamafricorp.com', NULL, '$2y$10$tlJGAOmx/ccYfd4/rCZW5uW/TMZVWefsMLoShr/O5T9GBHySvB1cu', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(560, 'FLORIDA SE LLC                                    ', 'FLORIDA SE LLC                                    ', '4072454000', 'store423@teamafricorp.com', NULL, '$2y$10$li79xbMT50xHfK3R8G.DXePteSWg8FOhwrn3j2UP4EJfWStvxCUfG', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(561, 'LAU & TONGS MANAGEMENT LLC', 'LAU & TONGS MANAGEMENT LLC', '2394376880', 'store424@teamafricorp.com', NULL, '$2y$10$dd8SnRi5K2hoY6E5gEinFe6mvXrDw3LPPRt1haVuQVHSYRgcJGTUi', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(562, 'HOLLISTER BISTROS LLC', 'HOLLISTER BISTROS LLC', '2392261687', 'store425@teamafricorp.com', NULL, '$2y$10$csvmVcxl2zE/q819lyVYBehz.SnPtIavD4vpxpKdm7Y/ysCmjD0TC', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(563, 'CRISTOFS ON MCGREGOR                              ', 'CRISTOFS ON MCGREGOR                              ', '2397918473', 'store426@teamafricorp.com', NULL, '$2y$10$LWHDZHSBxGCbSHssuYTPGusV8M3yYfgxBR5dQtQxSyB3q2oar2UEi', NULL, '2022-01-22 18:40:07', '2022-01-22 18:40:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(564, 'MATARRESE ENTERPRISES LLC', 'MATARRESE ENTERPRISES LLC', '2395431971', 'store427@teamafricorp.com', NULL, '$2y$10$bqncPZV.B875wH4Wd7TiZePlcrp.9rOQXswHXDgRuP02vAJJPb/Z6', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(565, '7 ELEVEN STORE 36660                              ', '7 ELEVEN STORE 36660                              ', '4073994630', 'store428@teamafricorp.com', NULL, '$2y$10$/MRVgH5watx1Soc2x2dCYutNFS1n2mKrrXv1MdKLnxOz7sLt7rx4S', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(566, 'TARGET CORP                                       ', 'TARGET CORP                                       ', '6127612282', 'store429@teamafricorp.com', NULL, '$2y$10$.IUo3wemkNoXGpq4pWPHW.6xVSgILH00Izr/wFeMmMKt.q.AJpAq6', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(567, 'TARGET CORP                                       ', 'TARGET CORP                                       ', '6127612282', 'store430@teamafricorp.com', NULL, '$2y$10$yZxIcqIl9O/.SdM5zEvdROveuqu7.0fURDID4ETbKZQYc4rIur912', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(568, 'GASPARILLA INN INC                                ', 'GASPARILLA INN INC                                ', '9419644516', 'store431@teamafricorp.com', NULL, '$2y$10$p6s1v6nQwK7TpWFOx731KeMG.Wf5KIw.fAtKqYkLdTguzXgrNZ0GG', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(569, 'MANHATTAN STEAK HOUSE LLC', 'MANHATTAN STEAK HOUSE LLC', '2396768687', 'store432@teamafricorp.com', NULL, '$2y$10$8qT7xk8/viHznVvwLjFgD.L8sNJppD9J3qjBm4rmzNi7Wfe.vlGQS', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(570, 'LA ROCA RESTAURANT CORP                           ', 'LA ROCA RESTAURANT CORP                           ', '2392420334', 'store433@teamafricorp.com', NULL, '$2y$10$W0zptKWZOsCZ.OG5WbizSOC.1O6kqH.f9qeFsuCuXIv0G.dL7qY6S', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(571, 'BAWA & PREETI INC', 'BAWA & PREETI INC', '2399850888', 'store434@teamafricorp.com', NULL, '$2y$10$8VdjEWqLthKb.qRjHroRvOUdu0mqQLaZBLXNlC9MP9FbDv7GYt0HO', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(572, 'IL CIELO LLC                                      ', 'IL CIELO LLC                                      ', '2394725555', 'store435@teamafricorp.com', NULL, '$2y$10$djxsujCrgRAvLVLe7r8qZemqzBVmquw1YPFy3c9/epwkJZb8ACILS', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(573, 'HAPPY SUN ICE CREAM INC                           ', 'HAPPY SUN ICE CREAM INC                           ', '2396728260', 'store436@teamafricorp.com', NULL, '$2y$10$VnJiP/iitwxHjtADaHf/e.cqj4YZ.A2gEb1ZN1GhQlqo2l27sOsRO', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(574, 'PATEL PRADIP GANESHBHAI                           ', 'PATEL PRADIP GANESHBHAI                           ', '2399485556', 'store437@teamafricorp.com', NULL, '$2y$10$PLC80DeHzQezx.9s01fk7eIoaYHXy7Mn7x6Co2LPRpLhqSkfSIZkq', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(575, 'AUSTIN POWERS LLC                                 ', 'AUSTIN POWERS LLC                                 ', '2397657437', 'store438@teamafricorp.com', NULL, '$2y$10$i/mPkMLl8qi4xzvufF5s5uOdo23/q0tVtRomM34nB6oJ9WS4xwBWa', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(576, 'FORDS GARAGE LLC                                  ', 'FORDS GARAGE LLC                                  ', '2393323673', 'store439@teamafricorp.com', NULL, '$2y$10$6dclXfZd3SLp/K1ftXGHg.fgzt9hXfdtcokD2XfwVkEVaPS48Gixm', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(577, 'JAMA FOOD SERVICES INC                            ', 'JAMA FOOD SERVICES INC                            ', '2399971400', 'store440@teamafricorp.com', NULL, '$2y$10$tlqWHyeMSAmZULsIDPm1pOJEhIqBxsFHZVWPXe6vAeT/l2gtneefi', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(578, 'MARKO FRANGIAS', 'MARKO FRANGIAS', '2392049172', 'store441@teamafricorp.com', NULL, '$2y$10$.0zNwhhsSXxBtpZ87XzywO1G5djbDbmEcVxeUaQ27lTgA5DFvZ4rm', NULL, '2022-01-22 18:40:08', '2022-01-22 18:40:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(579, 'SWF FOOD & BEVERAGE LLC                           ', 'SWF FOOD & BEVERAGE LLC                           ', '2392572183', 'store442@teamafricorp.com', NULL, '$2y$10$fXVNKSPaE2aaVemoXxBQV.b0Lr1nsHah6KUqU49h9L/MvdvqwiEt2', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(580, 'ASIAN BUFFET OF LEHIGH ACRES INC', 'ASIAN BUFFET OF LEHIGH ACRES INC', '2393039978', 'store443@teamafricorp.com', NULL, '$2y$10$RpqzbSXKsDyyCS4bVCtCse50lwVZyh/kUY.zGKjEpzOPekVx0oVeS', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(581, 'FLORIDA SE LLC                                    ', 'FLORIDA SE LLC                                    ', '4072455378', 'store444@teamafricorp.com', NULL, '$2y$10$xRVN4XeF5IYEnB4ls9vUEem/OOcdBK.hoeEgzXJYonZlyVYMqlmHG', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(582, 'JFG BAGELS LLC                                    ', 'JFG BAGELS LLC                                    ', '2393214610', 'store445@teamafricorp.com', NULL, '$2y$10$MHgkOpcooC0T9GQ0EC0M/eVwmAw0B2/ji2MeZecD9oeWMbFDEE2ly', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(583, 'CAPE CORAL COFFEE ROASTING LLC                    ', 'CAPE CORAL COFFEE ROASTING LLC                    ', '2397721212', 'store446@teamafricorp.com', NULL, '$2y$10$QfUFMyFdxzJRz6jRelyeluJPgGVfoQdm.n.dWWZ94nQ8UMUIiT1Iy', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(584, 'STEVE B WATERFRONT CAFE LLC                       ', 'STEVE B WATERFRONT CAFE LLC                       ', '2398783032', 'store447@teamafricorp.com', NULL, '$2y$10$yHRpCYQRud1crO/noiOnTOJZ49KMMIfnYAASSBR9VQ/tvJTflffZC', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(585, 'HIAX LLC', 'HIAX LLC', '2397658844', 'store448@teamafricorp.com', NULL, '$2y$10$MwHyveCjzvibC9kncXBEmOgHyJGSMs5WhvUrsvS3tbvQ9/.uFzkve', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(586, '7ELEVEN INC & GREEN LIGHT ORGANIZATION INC        ', '7ELEVEN INC & GREEN LIGHT ORGANIZATION INC        ', '2394634011', 'store449@teamafricorp.com', NULL, '$2y$10$Ov2BLgA1Db8YOLlu8/iBQ.qUt5kfE6xFoO9f1aYmVM4PQqv..o6I.', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(587, 'FBF LLC', 'FBF LLC', '2394581940', 'store450@teamafricorp.com', NULL, '$2y$10$rz7ERogQp7Lr8dGaLPER5eU9xxQm80Lg2wMoQQGcNFdNSODBSuXN2', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(588, 'M Z FOOD TO GO INC', 'M Z FOOD TO GO INC', '2394610050', 'store451@teamafricorp.com', NULL, '$2y$10$CEG9nNSly7EUsiIr0AHEJeztoKfWsYflxZrpNlTCRZQqhsB/37BJO', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(589, 'FRESH MEX FOODS LLC                               ', 'FRESH MEX FOODS LLC                               ', '2393692121', 'store452@teamafricorp.com', NULL, '$2y$10$nPYKbPOmawsp8oaO9cy.IOG8wS8JA/0D0Cz80z760SKnT46TY.SY6', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(590, 'FAT KATZ SPORTS BISTRO', 'FAT KATZ SPORTS BISTRO', '2397683541', 'store453@teamafricorp.com', NULL, '$2y$10$nsP5Pqls8/d9ySUW1QlMFur86vnJTs/1dZqk/w.sbtOc1Wge6cdM.', NULL, '2022-01-22 18:40:09', '2022-01-22 18:40:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(591, 'THE HUT AT THE PEACE TROPICAL GARDENS LLC', 'THE HUT AT THE PEACE TROPICAL GARDENS LLC', '2392250907', 'store454@teamafricorp.com', NULL, '$2y$10$l.Wt.Exj2IetvOrwbDAyqOnmjFFAxunbvvOb9Cyoyvur4hkcDJOj2', NULL, '2022-01-22 18:40:10', '2022-01-22 18:40:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(592, 'BIGGYS INC                                        ', 'BIGGYS INC                                        ', '2392770064', 'store455@teamafricorp.com', NULL, '$2y$10$OjTDg88gx6HqMlYgEV42j.FYMpw..vRSMGM6fcWhnCkoUVis//y4u', NULL, '2022-01-22 18:40:10', '2022-01-22 18:40:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(593, 'RARE HOSPITALITY MANAGEMENT LLC                   ', 'RARE HOSPITALITY MANAGEMENT LLC                   ', '2394330286', 'store456@teamafricorp.com', NULL, '$2y$10$ZrDCiivYNDyGOmwoctEkpeHX5V4BsDqzOPTV3XNP7QpHfznsPkaZO', NULL, '2022-01-22 18:40:10', '2022-01-22 18:40:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(594, 'FANCYS SOUTHERN CAFE LLC                          ', 'FANCYS SOUTHERN CAFE LLC                          ', '2395612988', 'store457@teamafricorp.com', NULL, '$2y$10$tnoUQYBfXjGGkFMotd4kIuwo1hRdARcIiB9.95gTEnh3coxSqWkxS', NULL, '2022-01-22 18:40:10', '2022-01-22 18:40:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(595, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '9516847393', 'store458@teamafricorp.com', NULL, '$2y$10$y0qRr06Jn6kxUAHdLWJm5e7kFQUhqnAeKhN1riAo5gJdmrXkV/K7u', NULL, '2022-01-22 18:40:10', '2022-01-22 18:40:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(596, 'LA VALENTINA MEXICAN RESTAURANT LLC               ', 'LA VALENTINA MEXICAN RESTAURANT LLC               ', '2393366800', 'store459@teamafricorp.com', NULL, '$2y$10$TV/gfOqML3KTIDGZ4oW/7OnlLOIRitauXyKdvBJWGwOtqYfbXCCG6', NULL, '2022-01-22 18:40:10', '2022-01-22 18:40:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(597, 'M ASSETS SIX LLC', 'M ASSETS SIX LLC', '2179354915', 'store460@teamafricorp.com', NULL, '$2y$10$wQGrp7D4Yam0r5IuuuDap.2ufpNgpt8ZyFAvvjBfKi8.pPLCNTsyS', NULL, '2022-01-22 18:40:10', '2022-01-22 18:40:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(598, 'TSC FL 189, INC                                   ', 'TSC FL 189, INC                                   ', '2395616220', 'store461@teamafricorp.com', NULL, '$2y$10$GbYdwflkiXulLMS/6ndcTuhcL6mdyvNIwvfQnvtY5eiao5A6NIe3q', NULL, '2022-01-22 18:40:10', '2022-01-22 18:40:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(599, 'JIMMY JOHNS OF ESTERO INC                         ', 'JIMMY JOHNS OF ESTERO INC                         ', '2398232707', 'store462@teamafricorp.com', NULL, '$2y$10$3/9STmwsUHVx9K5qkP4TPeqG/qjOVIFkUkI5RWC3VDDHUVe0je1Hy', NULL, '2022-01-22 18:40:10', '2022-01-22 18:40:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(600, 'JP FORT MYERS LLC                                 ', 'JP FORT MYERS LLC                                 ', '2392457019', 'store463@teamafricorp.com', NULL, '$2y$10$ScK3CoDHWh58f8LP1GOr5Or90J0cvwfT1VnC7BBXLTuGOmGGqG0RW', NULL, '2022-01-22 18:40:10', '2022-01-22 18:40:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(601, 'ND SOLUTIONS INC                                  ', 'ND SOLUTIONS INC                                  ', '2395914877', 'store464@teamafricorp.com', NULL, '$2y$10$ZZPiXB80Ocf3QVQP1pr9eelp.wBrHm0/WJtCUyNmCcdNe9macE3XC', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(602, 'TOAST OF BONITA LLC', 'TOAST OF BONITA LLC', '2392218256', 'store465@teamafricorp.com', NULL, '$2y$10$3uDfADQxsGnpRx5AzMtZaem9jZGIQ5Ge5CWHpDkkrQPSIChRos7R6', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(603, 'CABO CANTINA DOWNTOWN LLC                         ', 'CABO CANTINA DOWNTOWN LLC                         ', '2393322226', 'store466@teamafricorp.com', NULL, '$2y$10$8byqW6GRpMe4N4Behn2UQ.EKi4uuj3nDpRiFbbhPvphSiKJ/0X/gm', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(604, 'CHEDDARS CASUAL CAFE INC                          ', 'CHEDDARS CASUAL CAFE INC                          ', '2395613618', 'store467@teamafricorp.com', NULL, '$2y$10$HPZiqw.WvM54dhMMfUpI8OyA9DdpriUZZCpP8qYmtBW7Ki9lw2h1G', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(605, 'NEVERMIND US LLC                                  ', 'NEVERMIND US LLC                                  ', '2394710295', 'store468@teamafricorp.com', NULL, '$2y$10$PkWs5ZvQ0JiIkat7d86uB.YajPIEBKtJt15T4j62lIvwmq0z6XhFq', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(606, '7 ELEVEN INC & FSI & ALI INC                      ', '7 ELEVEN INC & FSI & ALI INC                      ', '2399317658', 'store469@teamafricorp.com', NULL, '$2y$10$paPnYiMb.WG.U68OAyIHL.ymc7Wol8aktLfs4/yJx5bHqrPC2zC3q', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(607, 'LIUS CHINA KING LLC                               ', 'LIUS CHINA KING LLC                               ', '2395434888', 'store470@teamafricorp.com', NULL, '$2y$10$HsWaXQAEHb/z5pdMlRYwmeUTOumvcj4AK0k1tGHpu6SoBzBow8WOG', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(608, 'CHEROKEE HILLS TWELVE INC                         ', 'CHEROKEE HILLS TWELVE INC                         ', '2394375504', 'store471@teamafricorp.com', NULL, '$2y$10$kqBhgpRWbEdxUfmeP2kbreI2RXkrqS5P5ZfJbpcee76jsYYSXjrQ.', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(609, 'ZARAGOZAS ICE CREAM SHOP LLC', 'ZARAGOZAS ICE CREAM SHOP LLC', '2392331024', 'store472@teamafricorp.com', NULL, '$2y$10$KkmqYBr1ILvn1dXIApuGe.lg40Jbf7xPHMDlzIdsOZi5J8UsCeWJ2', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(610, 'TIJUANA FLATS 180 LLC                             ', 'TIJUANA FLATS 180 LLC                             ', '4073392222', 'store473@teamafricorp.com', NULL, '$2y$10$9wknchn65RLIxQXRGkT.tuilUWFer.30Np0bxEAY5pOZIx9tZb7eW', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(611, 'SENOR TACO INC', 'SENOR TACO INC', '2396769271', 'store474@teamafricorp.com', NULL, '$2y$10$ib1aJiuFc0gmK6DSZTCzueLYsQzV3g19WltrOM3FkvRtLOgwVfZaW', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(612, 'KRAUS COMPANY INC                                 ', 'KRAUS COMPANY INC                                 ', '2393332403', 'store475@teamafricorp.com', NULL, '$2y$10$0aSXldT3L17vTYO1G153weABmK5ST1oGCxjOD138Pbl.DNQoVsATO', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(613, 'FIRESTONES RESTAURANT GROUP LLC                   ', 'FIRESTONES RESTAURANT GROUP LLC                   ', '2393343473', 'store476@teamafricorp.com', NULL, '$2y$10$ne6kl/tODLXvS0sIN5LeGud6pJYkNILQk69020RFRY6dAlSyt0a06', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(614, '7 ELEVIN INC & NKNM INC                           ', '7 ELEVIN INC & NKNM INC                           ', '4073994630', 'store477@teamafricorp.com', NULL, '$2y$10$0N4.YdpJskhw1mfFIQdRMOFNrc6gknhoI8JxWOvn6MhRHDA7YWUsW', NULL, '2022-01-22 18:40:11', '2022-01-22 18:40:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(615, 'SHRIJI 21 LLC', 'SHRIJI 21 LLC', '2393578268', 'store478@teamafricorp.com', NULL, '$2y$10$lixI/rYTYqYtu6jGElC0ZukyyARpi3c4/Har0tuyRBQovBIJwSfUO', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(616, 'EL MICHOACANO LLC                                 ', 'EL MICHOACANO LLC                                 ', '2396736371', 'store479@teamafricorp.com', NULL, '$2y$10$eyKnOkxl8C/mW2fvW74XP.eB6gYWNXhear3hQt21e68SiLmv4KGEW', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(617, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2393362249', 'store480@teamafricorp.com', NULL, '$2y$10$zcFOdLbtGc50jRptOL6VYOY0tSX85nAhqWg6msxk.9bhZ8HUQpVSu', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(618, 'HOUSE OF OMELETS INC                              ', 'HOUSE OF OMELETS INC                              ', '2396737545', 'store481@teamafricorp.com', NULL, '$2y$10$fgeOkztTgLU968DQLE8Oq.ibpVf8LUIozru0cr18AzUGVoDwqV1Y.', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(619, 'LATINOS MARKETPLACE INC                           ', 'LATINOS MARKETPLACE INC                           ', '2394371471', 'store482@teamafricorp.com', NULL, '$2y$10$r/tdv2MNzh4XwXnFh3w2.uw27MmFs.cZyWM2iqJm0tHU96Gk/DOE2', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(620, 'JINGDU INC                                        ', 'JINGDU INC                                        ', '2399858518', 'store483@teamafricorp.com', NULL, '$2y$10$qf1o5VTcrenu1yHgz38FcOftNJaJsMZ8wAGbEueGhD/1YnMUJbnAO', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(621, 'COURTNEYS ON SANIBEL INC                          ', 'COURTNEYS ON SANIBEL INC                          ', '2394664646', 'store484@teamafricorp.com', NULL, '$2y$10$DyKMiTg01auv/i0ewNuuPe65D/XaM2LRhmXPTuX7xtjoL3Xwq17WC', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(622, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2394791287', 'store485@teamafricorp.com', NULL, '$2y$10$WnXXVABmr86Q0twxy0P9YeHRWsm3IIHYAyQVbqhrtBRhwuFTBp/Wq', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(623, 'CONSOLIDATED BURGER B LLC                         ', 'CONSOLIDATED BURGER B LLC                         ', '5612424907', 'store486@teamafricorp.com', NULL, '$2y$10$iYm3fqtHMB1dEWbbqz.zCeNiFUx3jt0fmPo/xx3TquDQTQvuZ6ad2', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(624, 'POLLO OPERATIONS INC                              ', 'POLLO OPERATIONS INC                              ', '3056711258', 'store487@teamafricorp.com', NULL, '$2y$10$zAbI4mXejz.7dvf6P4B5euJsCdRFbnrWyjHn.yS8QiAtIwSraYahS', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(625, 'DMR FOODS III LLC                                 ', 'DMR FOODS III LLC                                 ', '2393347827', 'store488@teamafricorp.com', NULL, '$2y$10$O527AwOAuohS3SG6zvlgSu5F561tsm7hAfQpcVQgUjlDzJMgknlAe', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(626, 'NICE GUYS PINTS AND PIES LLC                      ', 'NICE GUYS PINTS AND PIES LLC                      ', '2395497542', 'store489@teamafricorp.com', NULL, '$2y$10$sdKRT0DEJaXCJacPXwxv1O/Xq6aHSvfo9HMel/iKcUm1YEGAwAx12', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(627, 'CUBAN RESTAURANT EL TROPICAL INC                  ', 'CUBAN RESTAURANT EL TROPICAL INC                  ', '2397728858', 'store490@teamafricorp.com', NULL, '$2y$10$BQr8Ld7QlXncx2LG1pM9Guq9qP7RU0TMfwpeLHxZVDboz1Ig.AqSC', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(628, 'CENOGRILLE LLC', 'CENOGRILLE LLC', '2395492366', 'store491@teamafricorp.com', NULL, '$2y$10$Bz454mHxHCTzVhk/MYabqulCn95kA5d.sDfg5GmIzdTVHNuPjV12G', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(629, 'AYALA  CONRADO', 'AYALA  CONRADO', '2393693294', 'store492@teamafricorp.com', NULL, '$2y$10$4q6RkwV9Xmeb/4QCsLhZr.oB06trTxJWWjvnhE5D8fzRao0P40nky', NULL, '2022-01-22 18:40:12', '2022-01-22 18:40:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(630, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2394581161', 'store493@teamafricorp.com', NULL, '$2y$10$8BC/NtgRSd/grXbPrVnHA.q5DtnRlpc/e.4xg1OkSy8n5le6w/Uiy', NULL, '2022-01-22 18:40:13', '2022-01-22 18:40:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(631, 'GARCIA  DAVID  J                                  ', 'GARCIA  DAVID  J                                  ', '2393692722', 'store494@teamafricorp.com', NULL, '$2y$10$EoIyW0eWPAbcLV4N2.Mjnug4T1xUYrAJsJWnGIr9d8OcQeipHCL9m', NULL, '2022-01-22 18:40:13', '2022-01-22 18:40:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(632, 'FORDS GARAGE CAPE CORAL LLC                       ', 'FORDS GARAGE CAPE CORAL LLC                       ', '2395403673', 'store495@teamafricorp.com', NULL, '$2y$10$iW0isfkKRJ.nt8SZYXHPNe9KrGxVY9ue6LkXRp/3taSzxYGw/Vybq', NULL, '2022-01-22 18:40:13', '2022-01-22 18:40:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(633, 'CROSSFIRE RESTAURANT GROUP LLC                    ', 'CROSSFIRE RESTAURANT GROUP LLC                    ', '2393148226', 'store496@teamafricorp.com', NULL, '$2y$10$asIvZKMPHiNJ5Ww7Ju5kIOq1CgnDbz9HWeBvBMMDun4N2LZHW46q6', NULL, '2022-01-22 18:40:13', '2022-01-22 18:40:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(634, 'THE TRADING POST AT BURNT STORE MARINA LLC        ', 'THE TRADING POST AT BURNT STORE MARINA LLC        ', '9416773137', 'store497@teamafricorp.com', NULL, '$2y$10$8WQEkoHOcWIga..Zrbc8R.sdnvJpPCEosNVLIkNeCBgSS4XJEIbH2', NULL, '2022-01-22 18:40:13', '2022-01-22 18:40:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(635, 'ADRIANZEN PAUL C', 'ADRIANZEN PAUL C', '2399484663', 'store498@teamafricorp.com', NULL, '$2y$10$yL6EkVHIbqzeUPaHVM61m.WTntEijKBnOKpmQPzcEHvsv.Z57ZGSO', NULL, '2022-01-22 18:40:13', '2022-01-22 18:40:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(636, 'FLORIDA CULINARY INNOVATIONS INC', 'FLORIDA CULINARY INNOVATIONS INC', '2395655034', 'store499@teamafricorp.com', NULL, '$2y$10$RrxytUibNA7yen.UKN1OUecaILqiExtZzy6WPZEE4E60g8/kjpc76', NULL, '2022-01-22 18:40:13', '2022-01-22 18:40:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(637, 'TROPIC FOOD & BEVERAGE INC                        ', 'TROPIC FOOD & BEVERAGE INC                        ', '2396941010', 'store500@teamafricorp.com', NULL, '$2y$10$Ly51ZSW9sb/HCMx1M1S34e7pBHOSSDOeBF6q5H/UeSaJAfB6LUPWq', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(638, 'THE CHARROS BROTHERS INC                          ', 'THE CHARROS BROTHERS INC                          ', '2397650160', 'store501@teamafricorp.com', NULL, '$2y$10$S3RrtYzNOkjme3boSBzXMe1ykV8o3XqCyqnbz268rniEn0Zz7bm0O', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(639, 'SUB59303 LLC                                      ', 'SUB59303 LLC                                      ', '2393578268', 'store502@teamafricorp.com', NULL, '$2y$10$r5pmMuMgPOezx8Fke3J2Weo.APL9SsDwJztGVzEi7t3vzj3.qWEzi', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(640, 'FARINA JOSEPH', 'FARINA JOSEPH', '2393136462', 'store503@teamafricorp.com', NULL, '$2y$10$t4CjoVVucA.fLB17hw7qu.JoinZOypRNpNzwkH0i59kUEvcRM4AzK', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(641, 'OUTBACK STEAKHOUSE OF FLORIDA LLC                 ', 'OUTBACK STEAKHOUSE OF FLORIDA LLC                 ', '2397725454', 'store504@teamafricorp.com', NULL, '$2y$10$yRRvz4GXa8S8IWgyGzbTFudrGnP8R9MlbSFm5xTmWxKie5W.UQx8a', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(642, 'OS PACIFIC LLC', 'OS PACIFIC LLC', '2394987697', 'store505@teamafricorp.com', NULL, '$2y$10$AVRWU3y.llkLAkgOdm5LQuttzaT3NvWl.8bC5QPTiUcJ6px7vuR5a', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(643, 'THE GRIND LLC                                     ', 'THE GRIND LLC                                     ', '2393620735', 'store506@teamafricorp.com', NULL, '$2y$10$4u9rS.p3Iv9fnyhEU4aeROhjKKyjFPP.on.PG9LAyQG.lulkpz9mS', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(644, 'FORDS GARAGE ESTERO LLC                           ', 'FORDS GARAGE ESTERO LLC                           ', '2394953673', 'store507@teamafricorp.com', NULL, '$2y$10$6Z/8.oW2sjAcpn10E4w.meihOBdfjbpKyiKgCWiQC5b8y/22SR7am', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(645, 'COASTAL CUISINE AND CATERING LLC', 'COASTAL CUISINE AND CATERING LLC', '2394052620', 'store508@teamafricorp.com', NULL, '$2y$10$U13iFXRaB8olh/gv.C1wTeLqO2/3qxpcAssTT.7xu/a2YGG.VzIdq', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(646, 'S&S FOODS OF SWFL INC', 'S&S FOODS OF SWFL INC', '2396768047', 'store509@teamafricorp.com', NULL, '$2y$10$v85OtH60QAnldHeRL2ZxH.3aXZg6cyjYiZt1sg5uYuubwqIu9C79y', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(647, 'GAB PJB RSW LLC                                   ', 'GAB PJB RSW LLC                                   ', '2394107101', 'store510@teamafricorp.com', NULL, '$2y$10$SvuEC8TvLq5qS3uUTu3zzOagtodNdPirK0BJxqmP7CbHVxXPMAnPW', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(648, 'GAB PJB RSW LLC', 'GAB PJB RSW LLC', '2394107101', 'store511@teamafricorp.com', NULL, '$2y$10$6zEUYz8GDiypjGow9f.yZeshbYYnf949CYg2FQMirEaNTWVFg5tLW', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(649, 'GAB PJB RSW LLC', 'GAB PJB RSW LLC', '2394107101', 'store512@teamafricorp.com', NULL, '$2y$10$qE55DiHFRCNiY9wFPWA2DO/.m8WaSFLrV6jN9SAYf1bLS/A93lH7W', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(650, 'BATEMAN FAMILY LLC', 'BATEMAN FAMILY LLC', '2392258636', 'store513@teamafricorp.com', NULL, '$2y$10$9eBBBiz4aTS0sP7IbcYWpuiHdZb0ony7qG0OBiYrIjtmv386QWJfC', NULL, '2022-01-22 18:44:57', '2022-01-22 18:44:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(651, 'MERRICK SEAFOOD COM                               ', 'MERRICK SEAFOOD COM                               ', '2395428080', 'store514@teamafricorp.com', NULL, '$2y$10$Gywlb/3mD9US0Ana27TRdOoKkstMCxFcZuW76lWL6VeereklBZHRi', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(652, '7 ELEVEN INC', '7 ELEVEN INC', '2393698749', 'store515@teamafricorp.com', NULL, '$2y$10$csm.8DZ1lPY46iRBGa7AAeyr1xl/7vVIZQDJNC.Em4mDIt2wpACo2', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(653, 'PINCHERS CRAB SHACK OF TARPON PT INC              ', 'PINCHERS CRAB SHACK OF TARPON PT INC              ', '2394315504', 'store516@teamafricorp.com', NULL, '$2y$10$00uwVE2EylchGl6vOt3Xger0kjaqJ0h180.I8BDcly4ksZHymQgIy', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(654, 'STARBUCKS CORPORATION                             ', 'STARBUCKS CORPORATION                             ', '2063185009', 'store517@teamafricorp.com', NULL, '$2y$10$BIlYeB9O1JlKST6s6g/BIe/xrdoRNHgSmrbzEF7TC1gvOL1gJz8Aa', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(655, '7 ELEVEN INC & AARYAN SHREYA INC                  ', '7 ELEVEN INC & AARYAN SHREYA INC                  ', '2392822615', 'store518@teamafricorp.com', NULL, '$2y$10$wgdVJkdxqmSxRZ/2rBBayOQcWDXN7sa02knXfK2rAQhFGgQO5yJTi', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(656, 'BEELUX LLC', 'BEELUX LLC', '2392783589', 'store519@teamafricorp.com', NULL, '$2y$10$dF.qfM.AjV3Si05Aq5U2KOMbYJ.EXb0QMYlyfF02pDxMpL2M0LVLa', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(657, 'CUSCALTAN RESTAURANT LLC                          ', 'CUSCALTAN RESTAURANT LLC                          ', '2393686831', 'store520@teamafricorp.com', NULL, '$2y$10$vHjvQq6K9Amle.V8rFJkVuHujYL5bhMNaxszK3kQ0TEGY20Q9J8YC', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(658, 'JOSEPH JOSEPHUS                                   ', 'JOSEPH JOSEPHUS                                   ', '2398781636', 'store521@teamafricorp.com', NULL, '$2y$10$CqFqlV/gyhZuDjRB4NR4cusCYrGoPGNIGv8j9XgCrdHkqjjNP2CDK', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(659, 'REAL MONARCA INC                                  ', 'REAL MONARCA INC                                  ', '2395409533', 'store522@teamafricorp.com', NULL, '$2y$10$xQdRrQ/atSZT1fWMsOscnebc7F7CxiUqU2ucUuLA9r9TcY9qvXXoG', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(660, 'AYALA CONRADO                                     ', 'AYALA CONRADO                                     ', '2399396992', 'store523@teamafricorp.com', NULL, '$2y$10$4HT3zsCQLTvYRFwuQRG4Iem4TNv0s3TrB3wOwH0NuIWZam5e57Ipi', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(661, 'DERYNDA FOODS FOUR LLC                            ', 'DERYNDA FOODS FOUR LLC                            ', '2394378572', 'store524@teamafricorp.com', NULL, '$2y$10$aP8JMuBDM8Udrku6NUaNHe60ZSu/y56o1FD8IZm.vzjbipKhWw64K', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(662, 'CAFFE TOSCANO INC', 'CAFFE TOSCANO INC', '2394158466', 'store525@teamafricorp.com', NULL, '$2y$10$ddnQyHkRWIaENKRFTGHs1.ZfMyS/2tQ3dmahXWer3f/.7XTuseCVi', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(663, 'BEMOC LLC, DBA MORETTI ITALIAN GRILL              ', 'BEMOC LLC, DBA MORETTI ITALIAN GRILL              ', '2397857184', 'store526@teamafricorp.com', NULL, '$2y$10$p1dPmWVDwh6mYCz9VtzDP.11.127tWVYnRot2IHsxWxspX4OtKakS', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(664, 'SHAWN & TONY S KITCHEN LLC                        ', 'SHAWN & TONY S KITCHEN LLC                        ', '2394252626', 'store527@teamafricorp.com', NULL, '$2y$10$FHiAFJRHij/ebSq3bOCVvuzR8pvW7KMaJ13P4/3eXM4XvXS7svmoq', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(665, 'FAZZOLA GEORGE A', 'FAZZOLA GEORGE A', '2397315500', 'store528@teamafricorp.com', NULL, '$2y$10$ArCNLFOtCaINGVVJUVftlOe4T00QWcEj2GYf0YEaWwe/rqU1/RsZ2', NULL, '2022-01-22 18:44:58', '2022-01-22 18:44:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(666, 'JS ONE STOP CARRIBBEAN RESTAURANT & GROCERY LLC   ', 'JS ONE STOP CARRIBBEAN RESTAURANT & GROCERY LLC   ', '2393321455', 'store529@teamafricorp.com', NULL, '$2y$10$x3bix9WI5zasj270yQHG2eFVo722BVpEl8icm71XvSnf7RYfrdALe', NULL, '2022-01-22 18:44:59', '2022-01-22 18:44:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(667, 'CHIPOTLE MEXICAN GRILL OF COLORADO LLC            ', 'CHIPOTLE MEXICAN GRILL OF COLORADO LLC            ', '3032222524', 'store530@teamafricorp.com', NULL, '$2y$10$ntzZnflKZmztWWmibTvVpOy0AgMJ7BdU9CClxc.y6r37IfEaNvXcC', NULL, '2022-01-22 18:44:59', '2022-01-22 18:44:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(668, 'DMR FOODS 1 LLC', 'DMR FOODS 1 LLC', '2392457587', 'store531@teamafricorp.com', NULL, '$2y$10$FlFW/8eQT2RQviwYeW9uv.24Ytqgp5YV8wA/e7w5FQYD6GtFGEUXe', NULL, '2022-01-22 18:44:59', '2022-01-22 18:44:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(669, 'TORTILLERIA LA GUERA LLC                          ', 'TORTILLERIA LA GUERA LLC                          ', '2398871245', 'store532@teamafricorp.com', NULL, '$2y$10$qLPLdZAkPla65fHCvweDF.FCT7eCXghaR6zRxzCtQQufxaT4O/fW.', NULL, '2022-01-22 18:44:59', '2022-01-22 18:44:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(670, 'PINCHERS CRAB SHACK OF DOWNTOWN FT MYERS INC      ', 'PINCHERS CRAB SHACK OF DOWNTOWN FT MYERS INC      ', '2394315504', 'store533@teamafricorp.com', NULL, '$2y$10$84j0ppo42zLzP4P3JkzOGuuIM.M4UVdxShZ2khRZOcUhFgU6XC74e', NULL, '2022-01-22 18:44:59', '2022-01-22 18:44:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(671, 'GIRLS5DAD1 CHARTERS LLC', 'GIRLS5DAD1 CHARTERS LLC', '2392828811', 'store534@teamafricorp.com', NULL, '$2y$10$WEf2xZRW/mwOF7z8LjBySeGWkIes/Ink3ZG3LyZqXUACEGe8mGXLC', NULL, '2022-01-22 18:44:59', '2022-01-22 18:44:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(672, 'J&J ISLAND DREAMS LLC                             ', 'J&J ISLAND DREAMS LLC                             ', '2392338261', 'store535@teamafricorp.com', NULL, '$2y$10$kmLsMPnFOtXk5pJIPwAGcOvds6.XIaW9IyujVfG7.jV0dXtHCDk3y', NULL, '2022-01-22 18:44:59', '2022-01-22 18:44:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(673, 'BUON APPETITO LLC', 'BUON APPETITO LLC', '2395585711', 'store536@teamafricorp.com', NULL, '$2y$10$/9RJwYFh08Ns7VQoDQJCpuiRySp3XZvoda6pIAXkr95Bigpm8dOiu', NULL, '2022-01-22 18:44:59', '2022-01-22 18:44:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(674, 'STARBUCKS CORPORATION                             ', 'STARBUCKS CORPORATION                             ', '2063185009', 'store537@teamafricorp.com', NULL, '$2y$10$3GVr.ghEVQAKOKMaSmIssuxpVDmQwMqZz9/EXXdH.Tjik9zGuTApC', NULL, '2022-01-22 18:44:59', '2022-01-22 18:44:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(675, 'THE OTHER SIDE BISTRO INC                         ', 'THE OTHER SIDE BISTRO INC                         ', '2399927433', 'store538@teamafricorp.com', NULL, '$2y$10$N41z/iIgISHZjprj2b5TauMyO5wyxy3a1.E.DGM9/RCFn/ZSHCENW', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(676, 'LOVES TRAVEL STOPS & COUNTRY STORES INC           ', 'LOVES TRAVEL STOPS & COUNTRY STORES INC           ', '4057519000', 'store539@teamafricorp.com', NULL, '$2y$10$2XsGUCUmdDfkToI7kxHsx.voyQhAWKEDoU/LnSAdkecX3RGPmyLW6', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(677, 'DJ CHINESE RESTAURANT INC                         ', 'DJ CHINESE RESTAURANT INC                         ', '2393136913', 'store540@teamafricorp.com', NULL, '$2y$10$T1bNL2HlSU6XCw3RbBLnK.am.ErJFjkjquiw4T6FO6GB/mSUv9v1i', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(678, 'DOS SABORES LLC                                   ', 'DOS SABORES LLC                                   ', '2392621775', 'store541@teamafricorp.com', NULL, '$2y$10$1RvccAVzyf9s7axHa7JbV.JfHEdEliDHtsD97cpRqCwfZUWDWeuZi', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(679, 'MBDS OPERATIONS 1 LLC                             ', 'MBDS OPERATIONS 1 LLC                             ', '6038128455', 'store542@teamafricorp.com', NULL, '$2y$10$ST3vcYBcoU.CSjtXdw7Ci.KH7oL8d9X0XkAaT9.TCFOsL6d6bNniW', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(680, 'LOVES TRAVEL STOPS & COUNTRY STORES INC           ', 'LOVES TRAVEL STOPS & COUNTRY STORES INC           ', '4057519000', 'store543@teamafricorp.com', NULL, '$2y$10$hUPQRs0WtJdBc2tGyTaJTOlioGBc5wY1TnZH1/4uhGgZewswNxIbK', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(681, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '2395672737', 'store544@teamafricorp.com', NULL, '$2y$10$mRLpDJF8Xb2kTnYoeL5U2O7uPXdY8aBCzgZJKWTd8thJxkXbnFMTi', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(682, 'ARNETT VALLEE J', 'ARNETT VALLEE J', '2396451903', 'store545@teamafricorp.com', NULL, '$2y$10$Tp02Dhy6j3Jbprxw.6zdC.y4vTIPR0qGtwaGQaFeG6OYJXzriJly.', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(683, 'ZAWODNY ANDREW                                    ', 'ZAWODNY ANDREW                                    ', '2398224091', 'store546@teamafricorp.com', NULL, '$2y$10$/wfE0gSHx3HH5mLT6Il4cuIirkYoamWgQ3Gx9YkSbWnS7t2SICC1C', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(684, 'COLOSSEUM LLC', 'COLOSSEUM LLC', '2395417900', 'store547@teamafricorp.com', NULL, '$2y$10$gkngRVarJQrbVy52V5wy1e70SzUYd4hULeFe0xZngYbhVwv3tDFOC', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(685, 'POLLO OPERATIONS INC                              ', 'POLLO OPERATIONS INC                              ', '3056711258', 'store548@teamafricorp.com', NULL, '$2y$10$PLnmC97eVBIi2AeH.W4frO2ngeXZR6igbpZg.IsJQmN907x2CsyFK', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(686, 'SODEXOMAGIC LLC                                   ', 'SODEXOMAGIC LLC                                   ', '8035137257', 'store549@teamafricorp.com', NULL, '$2y$10$Qxoj81TYuUs9BUc2P8Jt/uffNTZnAA40.cp6NM8TlM9iaMvhRxKFu', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(687, 'CAPE WINGS INC                                    ', 'CAPE WINGS INC                                    ', '2398003141', 'store550@teamafricorp.com', NULL, '$2y$10$4YSMmVEgO3H/1QI8xG2Y5.khc8oHcVGp3QAQp1YRJrebnNK5E9P6a', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(688, 'BOATHOUSE TIKI BAR & GRILL LLC                    ', 'BOATHOUSE TIKI BAR & GRILL LLC                    ', '2399452628', 'store551@teamafricorp.com', NULL, '$2y$10$SvTRSh/4VoG4ZBbbvIffg.xOxtCbuHKqm2zSlubzwXp9yCT.d7/Wi', NULL, '2022-01-22 18:45:00', '2022-01-22 18:45:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(689, 'GEORGE AND WENDYS TROPICAL GRILL LLC', 'GEORGE AND WENDYS TROPICAL GRILL LLC', '2393951263', 'store552@teamafricorp.com', NULL, '$2y$10$iCur.ZgBGuCIBssaxUQIJunnEr.odp5q7AyUG448mlYQz.dPunzFm', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(690, '7 ELEVEN INC & PMG AIRPORT PLAZAS DEVELOPERS LLC  ', '7 ELEVEN INC & PMG AIRPORT PLAZAS DEVELOPERS LLC  ', '2392451371', 'store553@teamafricorp.com', NULL, '$2y$10$C8tKtO5.8LP7428rb0H8X.PtAI..anird.vSNBg.ojGRnPmtpYWFW', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(691, 'S & L PROPERTIES FORT MYERS LLC', 'S & L PROPERTIES FORT MYERS LLC', '2396893955', 'store554@teamafricorp.com', NULL, '$2y$10$bfxphSfiNWmSfsBcLbrBa.kjgm4Qw07ZcdLp5M/Cfh4Knb.pPmf8C', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(692, 'WOLOVLEK DEBRA K                                  ', 'WOLOVLEK DEBRA K                                  ', '2396017721', 'store555@teamafricorp.com', NULL, '$2y$10$RP.AhRd9QWf202F1IVUzYutk7DuPfPpor6T.f5WwucBeEnbE.z6eO', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(693, 'POLLO OPERATIONS INC                              ', 'POLLO OPERATIONS INC                              ', '4079480839', 'store556@teamafricorp.com', NULL, '$2y$10$Zv24qSANJsDnGvy5Ism.Q.qDzWdDClVS133/qYic8naFQt2Cht5U2', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(694, 'QUALITY BRAND GROUP FLORIDA LLC                   ', 'QUALITY BRAND GROUP FLORIDA LLC                   ', '2033282130', 'store557@teamafricorp.com', NULL, '$2y$10$7lWugZEDdNFK3EkjTANLROpo9S1u4dOV70TI0UFczYycjRIEmSKPy', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(695, 'QUALITY BRAND GROUP FLORIDA LLC                   ', 'QUALITY BRAND GROUP FLORIDA LLC                   ', '2033282130', 'store558@teamafricorp.com', NULL, '$2y$10$9TZYcjzAb.Btcf0UNBiC4O2o8J0CMv4IPS.uzYnGDK0QZxGDq4Ife', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(696, 'QUALITY BRAND GROUP FLORIDA LLC                   ', 'QUALITY BRAND GROUP FLORIDA LLC                   ', '2033282130', 'store559@teamafricorp.com', NULL, '$2y$10$dr4yUNQRJbStW7H/G/kQSeyLCZikq/65u98iWzIwFTHOJVql1hrOm', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(697, 'SSC342328 LLC                                     ', 'SSC342328 LLC                                     ', '2395497656', 'store560@teamafricorp.com', NULL, '$2y$10$I6hnYVd9B/cWLFpl3eXbyeEoubWJIIuKypAJhyzkayHRzm9DZl5bG', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(698, 'QUALITY BRAND GROUP FLORIDA LLC                   ', 'QUALITY BRAND GROUP FLORIDA LLC                   ', '2033282130', 'store561@teamafricorp.com', NULL, '$2y$10$.CktZi5dffqNBoChimbJkuJn5A7xBo31bEQgTyxnqnYONUPRY2l4O', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(699, 'QUALITY BRAND GROUP FLORIDA LLC                   ', 'QUALITY BRAND GROUP FLORIDA LLC                   ', '2033282130', 'store562@teamafricorp.com', NULL, '$2y$10$4pv5zrnZLMtks3nuC.ux5uJ48azjdCO28XACk9w.Msq61tGmjmr5y', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(700, 'QUALITY BRAND GROUP FLORIDA LLC                   ', 'QUALITY BRAND GROUP FLORIDA LLC                   ', '2033282130', 'store563@teamafricorp.com', NULL, '$2y$10$VhCW11ul0yLtLmMffe2oxejJbrOFMqdihr/fZKo/3ddo4XEBe/hPm', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(701, 'SSC349365 LLC                                     ', 'SSC349365 LLC                                     ', '2392422638', 'store564@teamafricorp.com', NULL, '$2y$10$HWcAOYfg5lDjHIe96Yzmt.loxEJ5m15F/uwBM94J.552rmRLR/oTa', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(702, 'SSC344826 LLC                                     ', 'SSC344826 LLC                                     ', '2396902326', 'store565@teamafricorp.com', NULL, '$2y$10$hAFl0HqJRkwDJr.0vznDIe.a0NB7HHOLq15jR52qDPuA1DgXD6xWC', NULL, '2022-01-22 18:45:01', '2022-01-22 18:45:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(703, 'SSC351221 LLC                                     ', 'SSC351221 LLC                                     ', '7322563442', 'store566@teamafricorp.com', NULL, '$2y$10$vxp.WMkoc3w7h54LhFvCFe5IUVoaIDt10vtqW5jt12.b97iMccdTe', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(704, 'SSC300469 LLC                                     ', 'SSC300469 LLC                                     ', '2395407070', 'store567@teamafricorp.com', NULL, '$2y$10$IV.ytTnszXwYVNtbgYTGPeiRsxnNrdskxegNy7SRTi7irXjXaS7gS', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);
INSERT INTO `vendors` (`id`, `f_name`, `l_name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `bank_name`, `branch`, `holder_name`, `account_no`, `image`, `status`, `firebase_token`, `auth_token`) VALUES
(705, 'CHIPOTLE MEXICAN GRILLE OF DENVER', 'CHIPOTLE MEXICAN GRILLE OF DENVER', '3032222524', 'store568@teamafricorp.com', NULL, '$2y$10$5GFSgR5JnYgrc8n.MQvGcu4dZdzufYb/tI/QD4lpr25TEl57YkWJ6', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(706, 'LELULOS PIZZERIA LLC', 'LELULOS PIZZERIA LLC', '2392056935', 'store569@teamafricorp.com', NULL, '$2y$10$vId5XW5hb9EUVjNQzQO4Uuf9GiJ/FgjQpBA2svU7TYLGtLiDKeBPG', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(707, 'CRAVE MARKET & WICKED SANDWICH CO', 'CRAVE MARKET & WICKED SANDWICH CO', '2394664663', 'store570@teamafricorp.com', NULL, '$2y$10$ZnHKuM0yg3qugpdvj16p1eSrQQqkhl.EqawmL8RQ2q6jCxDxWblwS', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(708, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2394828883', 'store571@teamafricorp.com', NULL, '$2y$10$zGxqkFYpZeIiL98L3cTupO2hw7.f938iNm4bnRa0o.Nu.Fr2jMv1G', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(709, 'REIS BAKERY CORP                                  ', 'REIS BAKERY CORP                                  ', '2392420216', 'store572@teamafricorp.com', NULL, '$2y$10$XqjTTz8efF2Ic44pAqNUGeeMMiPdIdoYaeHA2Bd38R1.kaYUSoa/2', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(710, 'RACETRAC PETROLEUM INC 584', 'RACETRAC PETROLEUM INC 584', '2394950395', 'store573@teamafricorp.com', NULL, '$2y$10$MgZBCJI/h80UFXOi0iwBjOLjd/qS1V1DOzIuGxxYcG2NQAXO4/0F2', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(711, '7 ELEVEN INC & J & J MIGS INC                     ', '7 ELEVEN INC & J & J MIGS INC                     ', '2395741629', 'store574@teamafricorp.com', NULL, '$2y$10$wjUv49CliJS0ZlHE9rKgkOBeSasH43cZPRwg3f6CEHgYnejiGqfCy', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(712, 'ZIRILLIS CHILLY TREATS LLC', 'ZIRILLIS CHILLY TREATS LLC', '2395731590', 'store575@teamafricorp.com', NULL, '$2y$10$Lill/TYB87j8/OA0mebDvOFvNPH5rEOZWSIXS3ASHqQtK07PVMncm', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(713, 'LADYCAKES LLC', 'LADYCAKES LLC', '2395492253', 'store576@teamafricorp.com', NULL, '$2y$10$4V4QEBLvOFJ.abs0v4VcRugRJndVyziEIimJ1Mb4jD8k7ommzVCsO', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(714, 'FRASER ROGER A', 'FRASER ROGER A', '2398955141', 'store577@teamafricorp.com', NULL, '$2y$10$VBVko4PxXHfnuAA53c2WuO2TWoea16XOhpyMJUR2oHRWu4F5JAvy2', NULL, '2022-01-22 18:45:02', '2022-01-22 18:45:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(715, 'KOTTENBROCK & SONS LLC                            ', 'KOTTENBROCK & SONS LLC                            ', '2399100818', 'store578@teamafricorp.com', NULL, '$2y$10$eD8nDADkFTgZoFlcZXRO2.UZweUPp4xXyH20klYhwnTthQ89qB9R.', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(716, 'BE HAPPY CAKES LLC                                ', 'BE HAPPY CAKES LLC                                ', '8888455003', 'store579@teamafricorp.com', NULL, '$2y$10$CEjS2ynwm8KK/R2fc0DNZOAcDIrdVWcss.Kj1xBIYDkw3k642zlVG', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(717, 'STEVENS  MARIA  D', 'STEVENS  MARIA  D', '2394669666', 'store580@teamafricorp.com', NULL, '$2y$10$hd6AGG.zw0V69743Yzxb8..Op2l7LMI2DFDbb.a3hJ2gaq/WfOGSi', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(718, 'JSMD BAGELS LLC', 'JSMD BAGELS LLC', '2393213046', 'store581@teamafricorp.com', NULL, '$2y$10$khZ1xGCip1Zs1ES1dD4H0u2n4jIEhx/Rajv/U59k5MYMwL7GzZLne', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(719, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2392754046', 'store582@teamafricorp.com', NULL, '$2y$10$Cn2Ucj7l8igF/ugg/gmOd.hrxSWdZSnfAifAAnweDesKbi.Mb7ZBy', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(720, 'SOUTHWEST FLORIDA RESTAURANT MANAGEMENT LLC       ', 'SOUTHWEST FLORIDA RESTAURANT MANAGEMENT LLC       ', '2394817311', 'store583@teamafricorp.com', NULL, '$2y$10$BWIiklLj94BaUmoZ24xFQ.a0maDatNca7V.C0weExxaXjWrHnmBua', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(721, 'STARBUCKS CORPORATION                             ', 'STARBUCKS CORPORATION                             ', '2399453839', 'store584@teamafricorp.com', NULL, '$2y$10$AkCuCA1fEopkMdhR5a8sRucPHK3lWRLAe2JxOvBszYDaURq/rlbey', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(722, 'BRUNOS OF BROOKLYN ITALIAN EATERY                 ', 'BRUNOS OF BROOKLYN ITALIAN EATERY                 ', '2392780211', 'store585@teamafricorp.com', NULL, '$2y$10$Xt7.gqMVCeI3.9BB7GE4.eA5Wji9DbQEhHoW6hRrDEBkjvPcu7QiG', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(723, '26795 MARKET LLC                                  ', '26795 MARKET LLC                                  ', '2393253583', 'store586@teamafricorp.com', NULL, '$2y$10$zonrQUEylI99ALtKx/MZNOLCzXLE3F6JWRPryrJtmJPr2zehc3qrm', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(724, 'STARBUCKS CORPORATION                             ', 'STARBUCKS CORPORATION                             ', '2063185009', 'store587@teamafricorp.com', NULL, '$2y$10$JzMc6OPlK7.5RfjUsVnjtOe6OkfuFZAAKNNULC45rWfqMlqRgtR0O', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(725, 'ARTICHOKE CATERING INC                            ', 'ARTICHOKE CATERING INC                            ', '2392636970', 'store588@teamafricorp.com', NULL, '$2y$10$9vW7Ezre7p8kuxalpas0e.5oEGsfkiumpCuyOc6VVkLBjfgsygH2S', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(726, 'RESTAURANTE LA BENDICION INC', 'RESTAURANTE LA BENDICION INC', '2392049184', 'store589@teamafricorp.com', NULL, '$2y$10$BQp8otu2Moq7TaQ.BsoyS.pnhFtc.TFUkjGLxpOYWnR5P1Rh0SHzu', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(727, 'S & L PROPERTIES  CAPE CORAL LLC                  ', 'S & L PROPERTIES  CAPE CORAL LLC                  ', '2392573841', 'store590@teamafricorp.com', NULL, '$2y$10$1AYuo.c.m9g9BtW2ehVYd.K2IR8c2f4PCp7JJlwSouhhyjOli15iK', NULL, '2022-01-22 18:45:03', '2022-01-22 18:45:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(728, 'CAPONES COAL FIRED PIZZA LLC', 'CAPONES COAL FIRED PIZZA LLC', '2393372625', 'store591@teamafricorp.com', NULL, '$2y$10$pSNCoz9/c/0WFlCKvL1fX.2VrB1Wbf2pFl0//0a8hgOOcl5d3KZly', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(729, 'LAPAS COSTA RICAN BISTRO INC                      ', 'LAPAS COSTA RICAN BISTRO INC                      ', '2392217016', 'store592@teamafricorp.com', NULL, '$2y$10$49n9ZkjXpZYVWyvWn7dzwO6OY1BFnkR69SFUnxP9KhfNd/ZMuTkK2', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(730, 'SINCHI EDGAR                                      ', 'SINCHI EDGAR                                      ', '3054172148', 'store593@teamafricorp.com', NULL, '$2y$10$dsT1TK46NbrPBvXBh./6aOkaoBvplImlAFD74UbFiuuVtzCVBpWb6', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(731, 'BJS RESTAURANT OPERATIONS COMPANY                 ', 'BJS RESTAURANT OPERATIONS COMPANY                 ', '7145002400', 'store594@teamafricorp.com', NULL, '$2y$10$Q13TrturTJFeuaOHYxLoBe29fdMOheoVeOBsTE6cvpo6Rds7lrmXW', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(732, 'BRINKER FLORIDA INC                               ', 'BRINKER FLORIDA INC                               ', '9727705929', 'store595@teamafricorp.com', NULL, '$2y$10$6ojAFEnm6ZFce.SJWiC7Geh6V1OjdZDte4rJ2RiSEvcGf.KsC2kee', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(733, 'THAI NAWA CUISINE LLC', 'THAI NAWA CUISINE LLC', '2395742610', 'store596@teamafricorp.com', NULL, '$2y$10$2u3c5LIe4E2Z31ufMAeB9epUDxUUhHbszgrxeydsxQbI0U6KWa.fm', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(734, 'MR. TEQUILA INC                                   ', 'MR. TEQUILA INC                                   ', '6783649441', 'store597@teamafricorp.com', NULL, '$2y$10$.c5WVQ3PI3sUi5oLiwhBC.KFBBzvR2YzOd/LoQtfOME6swMpm.bMi', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(735, 'GARCIA ISABEL                                     ', 'GARCIA ISABEL                                     ', '2392172265', 'store598@teamafricorp.com', NULL, '$2y$10$fI5E0O/QERKUP2tixCglsOCDlKcG8w0axWLlEp1u0GiDF1heClDMS', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(736, 'TERIS DINER INC                                   ', 'TERIS DINER INC                                   ', '2399923300', 'store599@teamafricorp.com', NULL, '$2y$10$c4lbNP6uafKNrYQQsFThiu/tVnHclDXzP7CTvPZdn5yifC0.PEknK', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(737, 'SUNS CHINA AJ INC                                 ', 'SUNS CHINA AJ INC                                 ', '2399493288', 'store600@teamafricorp.com', NULL, '$2y$10$UeoslBoDXkx4CRP7YvWVDOov4jvN5izeTRaNaJbEv9kdY/cTSby5.', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(738, '7 ELEVEN INC & SABAL PALMS HEIGHTS INC            ', '7 ELEVEN INC & SABAL PALMS HEIGHTS INC            ', '2394334181', 'store601@teamafricorp.com', NULL, '$2y$10$tt7LYyMh6S4nVDKM/Rhneue6ZeNYUB3Ur9qHGYMdhPF85MGWxAJTC', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(739, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2399951060', 'store602@teamafricorp.com', NULL, '$2y$10$0O8SZALmks2z9idUiGhTGeJWevDnUwXem.njN2.SVamPcdYygA7Gy', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(740, 'UMI SUSHI HOUSE LLC', 'UMI SUSHI HOUSE LLC', '2397721609', 'store603@teamafricorp.com', NULL, '$2y$10$jEoQTpe9Ea7BkGyqLzDCcOZtzuhgKkDliAabZdwB4KgGeijnJpJ3m', NULL, '2022-01-22 18:45:04', '2022-01-22 18:45:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(741, 'NGUYEN VAN T                                      ', 'NGUYEN VAN T                                      ', '9412585689', 'store604@teamafricorp.com', NULL, '$2y$10$E94XZBb5MtR2Py9BOo92O.68bpp5Eye/J71xXOMK4/f2vA2pE.eoS', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(742, 'A & A CENTRAL AMERICAN FOOD INC                   ', 'A & A CENTRAL AMERICAN FOOD INC                   ', '2392049521', 'store605@teamafricorp.com', NULL, '$2y$10$.zatrJd9t4Yb0Y8YMpdvRupel3r9Xc4o2yjkdfa5BCvhm8KdX5HQK', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(743, 'NAUTI PARROT TIKI HUT INC', 'NAUTI PARROT TIKI HUT INC', '2393497907', 'store606@teamafricorp.com', NULL, '$2y$10$TJTaiBBcs.6aCg6aXjbcNejUZniwmgUD8FRl/1xs0VaGLsODDfRam', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(744, '4200 JSL MANAGEMENT LLC                           ', '4200 JSL MANAGEMENT LLC                           ', '2395403463', 'store607@teamafricorp.com', NULL, '$2y$10$LpfuFVY9VqM447xDDGamc.rmNKD5ZEI7zng6dSP5caTCRpyjFCn0G', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(745, 'TSC FL 196 INC                                    ', 'TSC FL 196 INC                                    ', '2395730035', 'store608@teamafricorp.com', NULL, '$2y$10$p7KcymVQexwdiMqxEZlOreAm2YiXHIwqNoSavwT.8vPm38qSe3akK', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(746, 'TSC FL 180 INC', 'TSC FL 180 INC', '2399313100', 'store609@teamafricorp.com', NULL, '$2y$10$BnIfqXn6m7Vw05nNiAvFE.ksrOB4HaQNN5NkVibDSWGTgb5bASvEO', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(747, 'MON PARIS CAFE LLC                                ', 'MON PARIS CAFE LLC                                ', '2394371988', 'store610@teamafricorp.com', NULL, '$2y$10$3qkhAhoJSOBcPSLgiirZ1OUjbyjcv1b9qN6BRU0uRgmzDoAr5Ydo.', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(748, 'TRANSCEND FRESH CONCEPTS INC                      ', 'TRANSCEND FRESH CONCEPTS INC                      ', '2392754745', 'store611@teamafricorp.com', NULL, '$2y$10$iHNctwPANTyZnf2JlAkr5uzdGwvhyO/A27f3kANoUtC.gmX6f8.Dq', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(749, 'LINS CHINA EXPRESS LLC                            ', 'LINS CHINA EXPRESS LLC                            ', '2392740561', 'store612@teamafricorp.com', NULL, '$2y$10$6WqCUm6eqmPwO82nzkpLueVq.U3rHRv7AqCEPFxmkqX65YmB1eW1S', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(750, 'SWEET LIFE 6 LLC', 'SWEET LIFE 6 LLC', '2393124356', 'store613@teamafricorp.com', NULL, '$2y$10$eU/jbTT/n9ccuxZ2FCWUp..7gGFj/5EGU/HgWTtxb.qT8EQ6jjIVa', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(751, 'WAWA FLORIDA LLC                                  ', 'WAWA FLORIDA LLC                                  ', '6103588029', 'store614@teamafricorp.com', NULL, '$2y$10$bip9UgqqHfQpZwZGUEkP/ehjKyG4elb1R26sT7FsTFooJhvrXagrW', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(752, 'P & R SICKMILLER INC', 'P & R SICKMILLER INC', '2393012865', 'store615@teamafricorp.com', NULL, '$2y$10$5BS9M3w2BfEqL71amtJUQeYmlodKiyVVIdR5.BfRL1oz7UQJECxfa', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(753, 'JP CAPE SOUTH LLC', 'JP CAPE SOUTH LLC', '2392573270', 'store616@teamafricorp.com', NULL, '$2y$10$m88Io3bIPKHBz.q1ywETkObkIfpznjGGLwLKcl8fzFDj.4maPw.U.', NULL, '2022-01-22 18:45:05', '2022-01-22 18:45:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(754, 'PANAERIA LAS DELICIAS LLC                         ', 'PANAERIA LAS DELICIAS LLC                         ', '2393335980', 'store617@teamafricorp.com', NULL, '$2y$10$/YpAKRsKOgvGqZEp3fHtTO//e5JAcS3o2Cqfslr75tGwRklp4cylS', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(755, 'GATOR JOHNS BBQ LLC                               ', 'GATOR JOHNS BBQ LLC                               ', '2398233547', 'store618@teamafricorp.com', NULL, '$2y$10$5qlTGyAoI2ewb/Dw75O20uULGSIoQ3sx5HEmGzmEi93rmokhSdUG.', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(756, 'JUSTICES JAMAICAN RESTAURANT INC                  ', 'JUSTICES JAMAICAN RESTAURANT INC                  ', '2393037775', 'store619@teamafricorp.com', NULL, '$2y$10$h59ObsyZ6DE0k43nQU3F/OSvzEeZhSpGpkN0J58qQUgBH7YHAFQDC', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(757, 'POLLO OPERATIONS INC                              ', 'POLLO OPERATIONS INC                              ', '3056711258', 'store620@teamafricorp.com', NULL, '$2y$10$ha5nEv5NVYEdWo3eUKfYoeYP5UL3kSkquibsfWk3VJ7n3VrnwxIJG', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(758, 'MARISQUERIA GUANAJUATO RESTAURANT INC', 'MARISQUERIA GUANAJUATO RESTAURANT INC', '2396903339', 'store621@teamafricorp.com', NULL, '$2y$10$gD9wUT583r7vOvEegUCAYeJe3MqgUGzpnXaDBlnhia/tQ0/EPiaj.', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(759, 'MISSION BBQ FORT MYERS FL                         ', 'MISSION BBQ FORT MYERS FL                         ', '2396036700', 'store622@teamafricorp.com', NULL, '$2y$10$dBX/EydHJAxtFBfZWwjT1.hYatMTj11vHi2/JasH14twdVTAoSZO6', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(760, 'STEVE & JAN LLC                                   ', 'STEVE & JAN LLC                                   ', '2394912203', 'store623@teamafricorp.com', NULL, '$2y$10$gDAK/Y4m8A.zN/3yiVMZIO/GXMdB2N9leu43Zh3xOkk.0o91PE4FG', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(761, 'FUTURE ENERGY FLORIDA INC                         ', 'FUTURE ENERGY FLORIDA INC                         ', '2395438148', 'store624@teamafricorp.com', NULL, '$2y$10$CwPfEpPI4WNx7LgwQgQgSOfuWUYD.kf.OG28b6CsXMT3WF2JkH0Py', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(762, 'FIRST WATCH RESTAURANT INC                        ', 'FIRST WATCH RESTAURANT INC                        ', '9419079800', 'store625@teamafricorp.com', NULL, '$2y$10$V1aTO9UsYtkY/HVs87JOs.btiYUrj4.DjkVe9a4zQdcUcmn2w0Irm', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(763, 'STRAND HAUS INC                                   ', 'STRAND HAUS INC                                   ', '2394811110', 'store626@teamafricorp.com', NULL, '$2y$10$31ZH5ohSl6nt09mHolNl5edFEDAE5i8RFzNTztiYh8zUgvcodLp3i', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(764, 'RIB CITY PLANTATION LLC                           ', 'RIB CITY PLANTATION LLC                           ', '2392756700', 'store627@teamafricorp.com', NULL, '$2y$10$RjIU04OBn8noLIQpgWAehuJwB7z/BZkCOg864xWZjvEb5O.mJ4jxO', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(765, 'OK UK BRITISH FISH AND CHIPS  LLC', 'OK UK BRITISH FISH AND CHIPS  LLC', '2395992328', 'store628@teamafricorp.com', NULL, '$2y$10$D8fKQW.B3LTRC1/Ik6cugu41pjrONPZ.UuJUd/MBxvLAuPw3Uj1Yq', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(766, 'OPS SERVICES LLC                                  ', 'OPS SERVICES LLC                                  ', '2396338844', 'store629@teamafricorp.com', NULL, '$2y$10$qyHfVbe4fG/WCq4enpSuqevwJVBok/Nr5KaGa9FzDlUMNlLmrOMvW', NULL, '2022-01-22 18:45:06', '2022-01-22 18:45:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(767, 'OVERTIME PIZZERIA & SPORTS PUB INC                ', 'OVERTIME PIZZERIA & SPORTS PUB INC                ', '2395412663', 'store630@teamafricorp.com', NULL, '$2y$10$soXv135dWvat3SvZzvo8DOHaELBU7elpyfopvAPiA0sMIxBVo.pOC', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(768, 'QFRM 5 LLC                                        ', 'QFRM 5 LLC                                        ', '4077238103', 'store631@teamafricorp.com', NULL, '$2y$10$3WtotJzweGdwkJXWP.hE5e4hlLA9X/peMUe1AFEjtMfGioHc4s3nO', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(769, '2 GUYS IN A HUT                                   ', '2 GUYS IN A HUT                                   ', '2399401043', 'store632@teamafricorp.com', NULL, '$2y$10$a8lA8TXsfGDQhkuEydgmje5mB4VxoWVaxPyopp9cT5HRzuqc4avj.', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(770, 'S & L PROPERTIES PINE ISLAND LLC', 'S & L PROPERTIES PINE ISLAND LLC', '2396739835', 'store633@teamafricorp.com', NULL, '$2y$10$L89WBKFlKYRIJUoK04igluYN1ssrJfLaKwATZfdeHrCfjIvLhfzJm', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(771, 'COCO BAKERY INC', 'COCO BAKERY INC', '2396336398', 'store634@teamafricorp.com', NULL, '$2y$10$EpzrVEsPy6z0R1jrKEHFZuOl7.5NmfPsPpMUKXDeW1VJI2e..Qd4u', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(772, 'EMJAYS TAVERN & GRILL LLC', 'EMJAYS TAVERN & GRILL LLC', '2393682398', 'store635@teamafricorp.com', NULL, '$2y$10$fk3akJfBlfH6yzEjw9I40ee90Ylikm9QOirkpQiMB8KouBRS3IXqm', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(773, 'SOPHIA OF GATEWAY LLC', 'SOPHIA OF GATEWAY LLC', '2392196799', 'store636@teamafricorp.com', NULL, '$2y$10$I2qMXZAFo77pYN9aUFtOBuCTBJFyWoCieJ0WdTL4/sXOm5gBnMHi2', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(774, 'UNCLE Z LLC', 'UNCLE Z LLC', '2395419100', 'store637@teamafricorp.com', NULL, '$2y$10$ZKQvnn2QcvPjqrTw1kwlS.7EZSvGg6bkaU5CVMAydThrtCeN3aNiK', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(775, 'DMR FOODS II LLC', 'DMR FOODS II LLC', '2398002884', 'store638@teamafricorp.com', NULL, '$2y$10$aiCgSA4ja6/o636Vh0VeHeBtxzLWYUWoQCt9kUoZwl4iZf0VNgq3O', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(776, 'PINE ISLAND PIZZA LLC                             ', 'PINE ISLAND PIZZA LLC                             ', '2394718253', 'store639@teamafricorp.com', NULL, '$2y$10$QL628RppdIfKvf0YiQbTluca71fE08E4B6wCSRSBvVQuBC.6zthWS', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(777, 'AHANA & DELENA LLC                                ', 'AHANA & DELENA LLC                                ', '2393012539', 'store640@teamafricorp.com', NULL, '$2y$10$gTu91dcfHC4w7JHk3wCJye9gve.v3Y/OdPT7ydKvdsLYRS3pc2ZN.', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(778, 'LASALLE, CARA L                                   ', 'LASALLE, CARA L                                   ', '2394726882', 'store641@teamafricorp.com', NULL, '$2y$10$KdAPzQ9.S8ypwyT/lAIDeO5eNQxruF4wQvzw64mSuIseSNysbJ6uq', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(779, 'RUBY TREE LLC                                     ', 'RUBY TREE LLC                                     ', '2395426080', 'store642@teamafricorp.com', NULL, '$2y$10$6C24tqXREfnWJClMSfo1.ehIXmAfyjbWu4RmkSruqEz/..pMWqGMm', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(780, 'UNION 2 LLC                                       ', 'UNION 2 LLC                                       ', '2392196463', 'store643@teamafricorp.com', NULL, '$2y$10$UCs7gQI9TXvANeNiZ.htX.nY2QjKniyfGBblb1Fx1wR69uKBH/wOC', NULL, '2022-01-22 18:45:07', '2022-01-22 18:45:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(781, 'DIXIE WHARF LLC', 'DIXIE WHARF LLC', '2392338837', 'store644@teamafricorp.com', NULL, '$2y$10$L.j09G.3suNKfaznHfCU0.Z9EgLNI8pWqrGqMg7un7005ejVEDzjm', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(782, 'DF CAPTIVA ISLAND LLC', 'DF CAPTIVA ISLAND LLC', '2393124274', 'store645@teamafricorp.com', NULL, '$2y$10$1sGNnLboPPvIIBYyuCJYhe2i4jGyUZQdgV6nDmUuKGOpFQtPXTRb2', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(783, 'PANERA LLC                                        ', 'PANERA LLC                                        ', '1239999999', 'store646@teamafricorp.com', NULL, '$2y$10$SMryb7HrG7H1DC.3LGV0ce6psFFMo3zT2etsKR/EnTnPr5Vjntn9e', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(784, 'RESTAURANT INVESTMENT AT BONITA LLC               ', 'RESTAURANT INVESTMENT AT BONITA LLC               ', '2393902868', 'store647@teamafricorp.com', NULL, '$2y$10$234Tf2wRaXAj/oijtiMb7OVCD8ylQq.kviTa2YNxqBCMA0ao2GwXK', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(785, 'HABANEROS MEXICAN GRILL FT MYERS INC              ', 'HABANEROS MEXICAN GRILL FT MYERS INC              ', '2393497949', 'store648@teamafricorp.com', NULL, '$2y$10$eWBr0UzuMcfJ1qPd0hMo4uVKMaumcslaaxQ9shruS1atVhxEMoGwC', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(786, 'DUFFYS OF CAPE CORAL INC                          ', 'DUFFYS OF CAPE CORAL INC                          ', '2392056771', 'store649@teamafricorp.com', NULL, '$2y$10$EoR3kExd8DssRHdHVkkF3Oj3gKkVBlBakxic27oj6CbI6J7uD3nGa', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(787, 'MAX BUSINESS GROUP LLC                            ', 'MAX BUSINESS GROUP LLC                            ', '2392884296', 'store650@teamafricorp.com', NULL, '$2y$10$4NoCQWofkx908J6xe6AUQuSgboP0UuIyqHw8FKQ3IGvV4VCXscDFK', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(788, 'FINE FOLK PIZZA LLC', 'FINE FOLK PIZZA LLC', '2393135155', 'store651@teamafricorp.com', NULL, '$2y$10$HF0iQcWd1MgEwdte.NVhVO8EbaksY7zinu3AfT5cvElI.MMPZN79i', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(789, 'SSC353982LLC                                      ', 'SSC353982LLC                                      ', '7322563442', 'store652@teamafricorp.com', NULL, '$2y$10$2en2ZEdKh7oO8ljzTeZAce7yLKvca9mKfXswRdg0Adb.hQw9G0o.G', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(790, 'QUALITY BRAND GROUP FLORIDA LLC                   ', 'QUALITY BRAND GROUP FLORIDA LLC                   ', '2033282130', 'store653@teamafricorp.com', NULL, '$2y$10$it5M.hEjOuQPEJKJYqqx2OhIkbqR3TdJa6fbjXMNyU1RX1iXrRrM2', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(791, 'GOLDEN OLIVE RESTAURANT INC                       ', 'GOLDEN OLIVE RESTAURANT INC                       ', '2392458496', 'store654@teamafricorp.com', NULL, '$2y$10$LAitEGkuJEDH/p40h.nV8Oe.zqM3hWiJYJrBihZT5KZouEWrWzpUa', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(792, 'PERSUD PROPERTIES FL INVESTMENTS LLC              ', 'PERSUD PROPERTIES FL INVESTMENTS LLC              ', '2394631028', 'store655@teamafricorp.com', NULL, '$2y$10$6qAizAL6oEE9DUMQBX43hu0et1d9tpwoZu8v/rt0wLGSl3U1rqT0e', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(793, 'GV FT MYERS LLC                                   ', 'GV FT MYERS LLC                                   ', '2398294066', 'store656@teamafricorp.com', NULL, '$2y$10$XOfwqXQmYBh7vXpLisf2BusdKNV/amgKNTZt6jn.q1Vnij1UUvsue', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(794, 'DOWNTOWN PUBLIC HOUSE LLC                         ', 'DOWNTOWN PUBLIC HOUSE LLC                         ', '2394332739', 'store657@teamafricorp.com', NULL, '$2y$10$OCQPOlrBFqcMa/.RuvUsL.IxUoNQp.ZzA8ALqUa6k6sclcckeiFtq', NULL, '2022-01-22 18:45:08', '2022-01-22 18:45:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(795, 'PETAR A ALKURDI', 'PETAR A ALKURDI', '2394941343', 'store658@teamafricorp.com', NULL, '$2y$10$PWmKtUaA/wHqqFpG8vLUIuO5dAKI.5vYJI4zh3bvZj8Lk4mMUoDam', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(796, 'BLU SUSHI DOWNTOWN LLC                            ', 'BLU SUSHI DOWNTOWN LLC                            ', '2393622843', 'store659@teamafricorp.com', NULL, '$2y$10$mclJuG964B6sbCKuGzR7quV4XSJXUeO5P3o6dwwlJCI1Pf/.LUgHi', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(797, 'WILROCK GULF COAST LANDINGS LLC', 'WILROCK GULF COAST LANDINGS LLC', '2399857215', 'store660@teamafricorp.com', NULL, '$2y$10$wtkWAequrL2tx.7sksKJCer5jmDav6OMMG8lQ8ECXc8eb5rwD.GYK', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(798, 'TSC FL 197 INC', 'TSC FL 197 INC', '2393620574', 'store661@teamafricorp.com', NULL, '$2y$10$VioI3h05MW3fqSXQqQbtOO2Nbph67OepgYu2LZKxrN8wTlN2tbjhi', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(799, 'TC BROWN INC                                      ', 'TC BROWN INC                                      ', '2397311029', 'store662@teamafricorp.com', NULL, '$2y$10$YyX7AxmFDNqXl5J1mY/3geSpoTrqLhZmV7a8.bu3aBbk7h72EFHzO', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(800, 'OM MARARI LLC', 'OM MARARI LLC', '9413911243', 'store663@teamafricorp.com', NULL, '$2y$10$szFwqI3j4FzeazVq9k42sezu4Tnv1RkR8sG1jQ6cMTmka74NdVpI.', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(801, 'S&L PROPERTIES COLONIAL LLC', 'S&L PROPERTIES COLONIAL LLC', '2392082130', 'store664@teamafricorp.com', NULL, '$2y$10$e9odpnbIbLyQXfi/q/KrFeh57su85vWPQwhoKOhGS8r2RKAf3gG7i', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(802, 'CHESTNUT ACQUISITIONS LLC', 'CHESTNUT ACQUISITIONS LLC', '2392452850', 'store665@teamafricorp.com', NULL, '$2y$10$SssyeSyGoymgcBpYc1Iku.TfIjaUyNVD0fgfamwKLxhUxNb54kImu', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(803, 'DMD FLORIDA RESTAURANT GROUP F LLC                ', 'DMD FLORIDA RESTAURANT GROUP F LLC                ', '2394376599', 'store666@teamafricorp.com', NULL, '$2y$10$tgMM0.on237CsmJ9ibo6muXOLAatPJCp5m2kIv53cxd8LeQMcWhkC', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(804, 'A&E ADVENTURES LLC                                ', 'A&E ADVENTURES LLC                                ', '2392045964', 'store667@teamafricorp.com', NULL, '$2y$10$uVYVw1ZrU0mmd7AHq9eEmOPdQUhV2uqba1rzNiWFUf6jDTiJlUoBO', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(805, 'COLLEONI INC                                      ', 'COLLEONI INC                                      ', '2172203609', 'store668@teamafricorp.com', NULL, '$2y$10$.5Mc2T0U3zxRD7jnLt3Y0uFkZhFYEaK9ZqUbFofCQed11t8r3yxky', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(806, 'LENARD LAURA', 'LENARD LAURA', '8108146366', 'store669@teamafricorp.com', NULL, '$2y$10$OEsNAbalcPR0fHV/H44pouI64FdXxStEU6qX/qmv/utMusR8Ke0Fa', NULL, '2022-01-22 18:45:09', '2022-01-22 18:45:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(807, 'TAQUERIA JIMENEZ SERVICES INC                     ', 'TAQUERIA JIMENEZ SERVICES INC                     ', '2396034088', 'store670@teamafricorp.com', NULL, '$2y$10$vaPn4ZvNAjhzPBTIXCTV7.15QV/vAlSJQULXsc9Xk7ZQ0AYT0u55S', NULL, '2022-01-22 18:45:10', '2022-01-22 18:45:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(808, 'DUFFYS OF FORT MYERS INC                          ', 'DUFFYS OF FORT MYERS INC                          ', '2395908631', 'store671@teamafricorp.com', NULL, '$2y$10$CsTgMAn6Lo89IH80IsoSReD7.ol7wJQOc2VwTT10Rp7DZzMbLqZQi', NULL, '2022-01-22 18:45:10', '2022-01-22 18:45:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(809, 'FV EIGHT LLC                                      ', 'FV EIGHT LLC                                      ', '3057892776', 'store672@teamafricorp.com', NULL, '$2y$10$0Uk21X.wnG1elvhQ3l/qnuEQh84CBRcV5G1AvJJ6ReJl5AEEUU/KO', NULL, '2022-01-22 18:45:10', '2022-01-22 18:45:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(810, 'KIERAS KETTLE KORN LLC                            ', 'KIERAS KETTLE KORN LLC                            ', '2398783903', 'store673@teamafricorp.com', NULL, '$2y$10$v9JnO82bG2jb1q4oB1FCouL2PEm6nXoCiU9mTqHJHcheavlqbwioO', NULL, '2022-01-22 18:45:10', '2022-01-22 18:45:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(811, '7 ELEVEN INC                                      ', '7 ELEVEN INC                                      ', '2398103651', 'store674@teamafricorp.com', NULL, '$2y$10$Pbm4izL/7UlsLl3qtRbkDO1GLSwBvdZ9KHtXKiwZJK0JQAmWeLd0W', NULL, '2022-01-22 18:45:10', '2022-01-22 18:45:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(812, 'EAST COAST WAFFLES INC                            ', 'EAST COAST WAFFLES INC                            ', '7707295700', 'store675@teamafricorp.com', NULL, '$2y$10$xz/DhkHA7Wg2ARVi8b1yxuKaAhLKhdkjtU7CSAY6VaTg3/BCXV4da', NULL, '2022-01-22 18:45:10', '2022-01-22 18:45:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(813, 'MCCARTER MICHELLE N                               ', 'MCCARTER MICHELLE N                               ', '2394403951', 'store676@teamafricorp.com', NULL, '$2y$10$YuwZM/b3H1slo3d9DVNXXOduweLE5lYOhn0NM96AwK2C6V/BNPUM.', NULL, '2022-01-22 18:45:10', '2022-01-22 18:45:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(814, 'FIRST WATCH RESTAURANTS INC                       ', 'FIRST WATCH RESTAURANTS INC                       ', '9419079800', 'store677@teamafricorp.com', NULL, '$2y$10$TPDE70MdkNqDQdDFM.rarutGo4S/hz3R9UVqHaQYx0FT6askTpvRy', NULL, '2022-01-22 18:45:10', '2022-01-22 18:45:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(815, 'FUNNY FRIENDS LLC                                 ', 'FUNNY FRIENDS LLC                                 ', '2394795233', 'store678@teamafricorp.com', NULL, '$2y$10$rVGqdCsfrJdttdP/I4cAoeZQ69hncYMKfbZQKdrI4iOT6SbmqKLnK', NULL, '2022-01-22 18:45:10', '2022-01-22 18:45:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(816, '7 ELEVEN INC & AUM INC                            ', '7 ELEVEN INC & AUM INC                            ', '2394151407', 'store679@teamafricorp.com', NULL, '$2y$10$eK5h0ClzBzZE.sY3lJQ3RemAg93DWoMGjZ3m0o08ji3rKmGOaxJ0y', NULL, '2022-01-22 18:45:10', '2022-01-22 18:45:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(817, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2395619839', 'store680@teamafricorp.com', NULL, '$2y$10$bRAvtl5Ybq8ydY17ts1KruEx7HZz0ZOePkE2K2Cq3MAi4cEWSqMfS', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(818, 'CHIPOTLE MEXICAN GRILL OF COLORADO LLC            ', 'CHIPOTLE MEXICAN GRILL OF COLORADO LLC            ', '3032222524', 'store681@teamafricorp.com', NULL, '$2y$10$wBZOJPcOqF7KXxNts9F1tOUOJFv0oVuZ4RiKCnNzxhh1xiwLt5Rgm', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(819, 'CHICAGO BOYS LLC                                  ', 'CHICAGO BOYS LLC                                  ', '7082596204', 'store682@teamafricorp.com', NULL, '$2y$10$mU1xqEzZNb4CFcqAcBHP3uhaRW6LkED3Khi3wDyoJMaOe5JRArkZa', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(820, 'MAYAN CAFE INC                                    ', 'MAYAN CAFE INC                                    ', '2392217502', 'store683@teamafricorp.com', NULL, '$2y$10$SW9l.3qPUd8EwuXPO0HNX.sKz1aWvSA06pfqtB4vpY9h9fnuAIX22', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(821, 'WAWA FLORIDA LLC                                  ', 'WAWA FLORIDA LLC                                  ', '6103588029', 'store684@teamafricorp.com', NULL, '$2y$10$vodJPaM0M05DNQWeUfNh6uCddbcfPJeNAW.SGaRmZCRsMCi5wDFry', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(822, 'TIPTON AMANDA D                                   ', 'TIPTON AMANDA D                                   ', '2393576198', 'store685@teamafricorp.com', NULL, '$2y$10$vuW6XrdBvKKBD8NsRauda.OS4Iyj6D/WF/5.o28znCRsj.iNjc1CO', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(823, 'TSC FL 198 INC', 'TSC FL 198 INC', '2397718078', 'store686@teamafricorp.com', NULL, '$2y$10$712XP65fRDmouQ8k2ORTc.t5vjYQaKsJaLDHqZLUELCIw7y7BkgKi', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(824, 'QUALITY BRAND GROUP FLORIDA LLC                   ', 'QUALITY BRAND GROUP FLORIDA LLC                   ', '2033282130', 'store687@teamafricorp.com', NULL, '$2y$10$san/FwOh/CWU5p46sbERgeaIpn3EUqN2dazS.wGNqgkFTUb2zkmhW', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(825, 'GATEWAY QUICK MART INC                            ', 'GATEWAY QUICK MART INC                            ', '2396282178', 'store688@teamafricorp.com', NULL, '$2y$10$AXBQgSb5wJjYpqkeB01MbuiNDVaTPW.3GLaIjOb74ShobJhk4MYG6', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(826, 'LAS BRISAS RESTAURANT MEXICANO CORP               ', 'LAS BRISAS RESTAURANT MEXICANO CORP               ', '2392343802', 'store689@teamafricorp.com', NULL, '$2y$10$IcrmlDvhN9EwCC00ZETPy.tG/o/Shfc5wfeF9wHMN03lHJdZA/IXS', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(827, 'BLAZIN WINGS INC                                  ', 'BLAZIN WINGS INC                                  ', '9525168175', 'store690@teamafricorp.com', NULL, '$2y$10$khWgBEqHsoMGsCSK3Ao8DeCXlscaG/00fzTOMyHCT0BbH9aVTTAmu', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(828, 'DOC FORDS SANIBEL LLC                             ', 'DOC FORDS SANIBEL LLC                             ', '2394728311', 'store691@teamafricorp.com', NULL, '$2y$10$3Oahz99ZQDQR/u3KYjJ1NebQk8UzOr0NLuPfgqg6X3zBKRwqimbPS', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(829, 'KOTO CAPE CORAL LLC', 'KOTO CAPE CORAL LLC', '2397721965', 'store692@teamafricorp.com', NULL, '$2y$10$9SPLbi6HzIPoW1anzrCbU./5.DVyFQqwfm5EJyPs2Ng//3nwRAAvK', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(830, 'LYONS DONUTS LLC                                  ', 'LYONS DONUTS LLC                                  ', '3057663723', 'store693@teamafricorp.com', NULL, '$2y$10$BqwBsVuzwJeQYYDnioN8seCoHhnaeWVEk161miTOE4zGhmnyhjK3q', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(831, 'STARBUCKS CORPORATION', 'STARBUCKS CORPORATION', '2392831357', 'store694@teamafricorp.com', NULL, '$2y$10$aGyQKPVaqrGbJutliulKM.4xRgFOnNWR8EDW6rSd7inUeIBCVjfve', NULL, '2022-01-22 18:45:11', '2022-01-22 18:45:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(832, 'EAST COAST WAFFLES INC                            ', 'EAST COAST WAFFLES INC                            ', '2395419050', 'store695@teamafricorp.com', NULL, '$2y$10$9Jq4uGmmqEJh.yzF3eSrGOj2aN9A.CCe9hKFiraVbs94DLaOqN2rO', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(833, '7 ELEVEN INC & INA INC                            ', '7 ELEVEN INC & INA INC                            ', '2392672047', 'store696@teamafricorp.com', NULL, '$2y$10$kdAR6GAhDbTDaZSanO8/AuwEpy8xoKbfWncBQ3.jhYq5vv0EGjEWm', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(834, 'ISLAND PHO AND GRILL RESTAURANT LLC               ', 'ISLAND PHO AND GRILL RESTAURANT LLC               ', '2395584007', 'store697@teamafricorp.com', NULL, '$2y$10$xLvl.FOJ8h8Q8YPzKdXNK.1.NyhRC7s4wiYUNxaMdN2Ailrid82Qa', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(835, 'FLEGY INC', 'FLEGY INC', '2392083878', 'store698@teamafricorp.com', NULL, '$2y$10$qHtkJZX787Ol2vlNx1mokOCj4DVFXQFcTg4nMTGZex2nXehSEgX5C', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(836, 'SS GREY LLC                                       ', 'SS GREY LLC                                       ', '2398290407', 'store699@teamafricorp.com', NULL, '$2y$10$7nNB4Kf.EYOrPMa/TSIbPexXzkCIv/I7P9IbnLimRs0i3U9R3BELC', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(837, 'TACO VAZQUEZ INC', 'TACO VAZQUEZ INC', '2394408282', 'store700@teamafricorp.com', NULL, '$2y$10$0dAKLzktKlg.FDxwqB4r9u4y8h3J.U2FprfilH6AibKr3A8XBQy/e', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(838, 'LES EAT LLC                                       ', 'LES EAT LLC                                       ', '2398233388', 'store701@teamafricorp.com', NULL, '$2y$10$IQtK0Y9F.iI59AGexkfWy.oac3/y0oAa5JtqrdBXUsMIToIrLYvE2', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(839, 'ONE ALVAEREZ INC                                  ', 'ONE ALVAEREZ INC                                  ', '2399452003', 'store702@teamafricorp.com', NULL, '$2y$10$X4lWLNinb10UbGIbF3vxCeveFeK58iMdXOPXznQJowkx90fHdcG0u', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(840, 'LIGDANOS & NIC LLC                                ', 'LIGDANOS & NIC LLC                                ', '2394632328', 'store703@teamafricorp.com', NULL, '$2y$10$J0eXh.a8X6i7ty7j19TCrOupEFt6jAMwCU.uQUNSh4k2aHg4AzJ7a', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(841, 'BIG BLUE BREWING LLC', 'BIG BLUE BREWING LLC', '2394712777', 'store704@teamafricorp.com', NULL, '$2y$10$TJT3JXCJrQQgN5wze5gCYeTcR1GuiZ./K4Ju9bARz7HmU/01rgcWO', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(842, 'HAVANA BAKERY AND CAFE INC                        ', 'HAVANA BAKERY AND CAFE INC                        ', '2394913894', 'store705@teamafricorp.com', NULL, '$2y$10$emv1ISoowWMq0gAv6gKb4.zj/22rYArRfO2totOF.jSMvH.5uUvHO', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(843, 'MC SCHLEWER LLC', 'MC SCHLEWER LLC', '2393198460', 'store706@teamafricorp.com', NULL, '$2y$10$ZhzK0SqBURCmFhaZc077YONP4fpFO5/zyvYwdXuAwSwqvZVYWLnM.', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(844, 'CHEN XIE HIBACHI & SUSHI LLC', 'CHEN XIE HIBACHI & SUSHI LLC', '2395584830', 'store707@teamafricorp.com', NULL, '$2y$10$DCrNUQMFbC/bGXLd25mb6OXDOvUywd3VTGTMnrN41EM7FtOOmp3Ca', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(845, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2394953274', 'store708@teamafricorp.com', NULL, '$2y$10$p/DTEPlYq6VO9zbKjbv1sOgsynQ/Sy2jXpLCcMr/We8JkiB7LHIVm', NULL, '2022-01-22 18:45:12', '2022-01-22 18:45:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(846, 'CARDOOS CATERING WITH DISTINCTION                 ', 'CARDOOS CATERING WITH DISTINCTION                 ', '2394246200', 'store709@teamafricorp.com', NULL, '$2y$10$wX54e/OLCjJlo4kefpuEE.R/prUTw7JwIuH6Wxmi7ypt5W00FQfK.', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(847, 'VET CHERIE', 'VET CHERIE', '6162920339', 'store710@teamafricorp.com', NULL, '$2y$10$t5YigbzEUJs16OsEc2tSbupbxB7CO8Cw4nRwhTbFoqZ7QCTpDDcKO', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(848, 'FIRST WATCH RESTAURANT INC                        ', 'FIRST WATCH RESTAURANT INC                        ', '9419079800', 'store711@teamafricorp.com', NULL, '$2y$10$JTNLUW5BcWJVSWE9vwqPZuiF8CeSOSFM6NLxp181DgP0jYY2XfvOG', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(849, 'ESTES AMANDA                                      ', 'ESTES AMANDA                                      ', '2393128132', 'store712@teamafricorp.com', NULL, '$2y$10$GS/wJGulp/7oM8jY8H3cz.Obrdts0Sh23z2CxuT0W9Plgc9GJhxi2', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(850, 'REDFISH POINT LLC                                 ', 'REDFISH POINT LLC                                 ', '2395422224', 'store713@teamafricorp.com', NULL, '$2y$10$9qPy9STfXgHC.qtYhbYZ1.xNs.di6kJT5RCfB9KuagaCygxzvpAvy', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(851, 'KIELY MICHELLE', 'KIELY MICHELLE', '2394051933', 'store714@teamafricorp.com', NULL, '$2y$10$n2d1pVpC0ta2u9mkxCg12uOmnKU.3JUVi8Sqck4w5wreW77Fqo0Ki', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(852, 'SSTARBUCKS COFFEE COMPANY', 'SSTARBUCKS COFFEE COMPANY', '2063185009', 'store715@teamafricorp.com', NULL, '$2y$10$Iop5tXOrzPjwDbBZvEhc8ebhFg2kBZ6BmPmb7ZGs2SqQUiA3UAr0G', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(853, 'TSC CAPE CORAL SB INC                             ', 'TSC CAPE CORAL SB INC                             ', '2398005362', 'store716@teamafricorp.com', NULL, '$2y$10$Nb53sIO9CjzC18/oiS3SkOtPz8xJGN0JliNq3iuhZFs0fnj4zemyW', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(854, 'AIWS LLC                                          ', 'AIWS LLC                                          ', '2397659647', 'store717@teamafricorp.com', NULL, '$2y$10$c/SloSFF9QjHEPRQZlBwCOIDRweB5nMuct/l43VYW4.6bnRA48RaG', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(855, 'NAPLES BAY ENTERPRISES LLC                        ', 'NAPLES BAY ENTERPRISES LLC                        ', '2399926600', 'store718@teamafricorp.com', NULL, '$2y$10$IvMl0EiizzkgVM/eoc8DD.HgFegL3dqMw6yRMwpyFabpqBYt0cnzW', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(856, 'PHO FRESH LLC                                     ', 'PHO FRESH LLC                                     ', '2396896022', 'store719@teamafricorp.com', NULL, '$2y$10$wg99paV5wetIK0qjWm3QF.PWEnblcupoN.Jye/3uznq6HaALzGwem', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(857, 'BONITA BRUNCH INC', 'BONITA BRUNCH INC', '2394057415', 'store720@teamafricorp.com', NULL, '$2y$10$WcNGs357ofAyk8VsQ5m37eMPzKDWbLJyx0VV.A9N.JQ26lVvd8m5a', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(858, '7 ELEVEN INC', '7 ELEVEN INC', '2397311017', 'store721@teamafricorp.com', NULL, '$2y$10$zRfX4ntLptZrIiMX3ozj5eH37rV6x3wvJ4.OsWez9QjMT9eajCFrq', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(859, 'COUPLE OF BREWS 1 INC                             ', 'COUPLE OF BREWS 1 INC                             ', '2395585001', 'store722@teamafricorp.com', NULL, '$2y$10$Xyyitgw8ljssXBTDoHSCsOk80kufufKGEo.oPZUSW6nSULCc3..TO', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(860, 'LETENDRE ENTERPRISES INC                          ', 'LETENDRE ENTERPRISES INC                          ', '2394722525', 'store723@teamafricorp.com', NULL, '$2y$10$Ket9iQOE1AUGCyZ4UhpHx.pZMaI77nqxcZh24K7VRrrGhEjOGIxje', NULL, '2022-01-22 18:45:13', '2022-01-22 18:45:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(861, 'MBBS OPERATIONS LLC                               ', 'MBBS OPERATIONS LLC                               ', '2399083502', 'store724@teamafricorp.com', NULL, '$2y$10$76bx31mOe4RInz4zUwEmB.EaZjC5AYIaYSUL/Qq2d9SgucRXBBIXC', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(862, 'MORA RODRIGUEZ JONATHAN                           ', 'MORA RODRIGUEZ JONATHAN                           ', '2397916751', 'store725@teamafricorp.com', NULL, '$2y$10$YKmRv6MhwdQgvBHvX1X49eHRgO4XdxZwmFEmfG10s/81hrgy2t2Yy', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(863, 'DAIRY QUICK A LICIOUS INC', 'DAIRY QUICK A LICIOUS INC', '2393132479', 'store726@teamafricorp.com', NULL, '$2y$10$W7sCqvw5byNfyBnNN8.GDei4srpKtIOAFGYtNt1u2RlJ6CxyArbOe', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(864, 'A ONE FOOD STORE INC', 'A ONE FOOD STORE INC', '2392047659', 'store727@teamafricorp.com', NULL, '$2y$10$.uMTssojwKwBIlfXRY2v1.RHK2sgx0CKHPSG1SFeQ8gFXwWgDIveK', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(865, 'CHIPOTLE MEXICAN GRILL OF COLORADO LLC', 'CHIPOTLE MEXICAN GRILL OF COLORADO LLC', '2394953165', 'store728@teamafricorp.com', NULL, '$2y$10$aJZcJJqLG.m5JNqzItKCkeTTkdhHOqZX1N3/EFjjJAlNF8v4qz4JG', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(866, 'CHIPOTLE MEXICAN GRILL OF COLORADO LLC', 'CHIPOTLE MEXICAN GRILL OF COLORADO LLC', '2394583944', 'store729@teamafricorp.com', NULL, '$2y$10$traC6HYExUbxHRtSsYpBXeSHe8jWLkfBPN5fktNtygioqxcoNI0uC', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(867, 'DELI OF SWFL INC                                  ', 'DELI OF SWFL INC                                  ', '2399973354', 'store730@teamafricorp.com', NULL, '$2y$10$P5CyhW82q7W1SXCHg2WDW.pAAEknaE1DxmNKnzMppPJoCAy6mHZ0.', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);
INSERT INTO `vendors` (`id`, `f_name`, `l_name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `bank_name`, `branch`, `holder_name`, `account_no`, `image`, `status`, `firebase_token`, `auth_token`) VALUES
(868, 'PEI WEI ASIAN DINER LLC', 'PEI WEI ASIAN DINER LLC', '4808883000', 'store731@teamafricorp.com', NULL, '$2y$10$oH5p3bzRJ7MRm0bF00bGX.DCRAzMHA8EKLz9sTg.Kue5roIDrp6Ii', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(869, 'JASITA BUSINESSES INC', 'JASITA BUSINESSES INC', '2394824128', 'store732@teamafricorp.com', NULL, '$2y$10$Aj92leCigcPlUAyqIxZ1SukIzrpr9BuJ4TnDPXCdCmkqri39JAvCq', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(870, 'DOWDS PUB & GRILL LLC', 'DOWDS PUB & GRILL LLC', '2394378162', 'store733@teamafricorp.com', NULL, '$2y$10$hSUb7ABaK3RX4ys9w2M3AeDeI7bbr.FQO//ikgT2/Gp3vchVDlnee', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(871, 'BUCHA TOWN LLC                                    ', 'BUCHA TOWN LLC                                    ', '8607480226', 'store734@teamafricorp.com', NULL, '$2y$10$eWYhbo9O843/9d5jfbIDnuDRJQDFTm.lY4.URF7OQTug2wVW8iCvu', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(872, 'TIPSY COW LLC', 'TIPSY COW LLC', '2399497172', 'store735@teamafricorp.com', NULL, '$2y$10$jaMa3wZ4sd83GzxSLJLwCeHsr2tM5t.6PsuWy/IRVxtHREXheW8aG', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(873, 'CHINMI ASIAN DINER & SUSHI INC.', 'CHINMI ASIAN DINER & SUSHI INC.', '2392082612', 'store736@teamafricorp.com', NULL, '$2y$10$GPtqHl2TiEjAMmYvyju6Lef5QCNzhpCw6rycZK5IBzWc35256utam', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(874, 'S&L PROPERTIES LEHIGH ACRES LLC', 'S&L PROPERTIES LEHIGH ACRES LLC', '2394919552', 'store737@teamafricorp.com', NULL, '$2y$10$eKL56eELal5dQIK9rREW3entlZJWjUwbNLX/6XnvJZ3yu5TdU86qa', NULL, '2022-01-22 18:45:14', '2022-01-22 18:45:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(875, 'HIBBERT CURTIS P AND HIBBERT CRYSTAL T', 'HIBBERT CURTIS P AND HIBBERT CRYSTAL T', '2399384477', 'store738@teamafricorp.com', NULL, '$2y$10$/TsB0ea2ariRhxc.omFVDOQD8CcYML2LSzlbchYHug3YYxO3h5Cha', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(876, 'BEGONIAS RESTAURANT & PIZZERIA INC', 'BEGONIAS RESTAURANT & PIZZERIA INC', '2392088243', 'store739@teamafricorp.com', NULL, '$2y$10$C2v/nMTRFmi3HgafPCGg7eJcJWeVPPl3kt4EX2sX.l1ADQ8Rkcmue', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(877, 'SUPER TACOS LLC', 'SUPER TACOS LLC', '2396250351', 'store740@teamafricorp.com', NULL, '$2y$10$Kw5BDfUzBtwDbcnfzVqgcOmT2wJpT4SP.iLMEt.uVM.rcLTKP90Vq', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(878, 'HASAN HASAN A', 'HASAN HASAN A', '7548027631', 'store741@teamafricorp.com', NULL, '$2y$10$aJmBRgA3gOTkey7YhZZinu5McFdMkFX9xGAWdZv33kJzTpZqMyfjS', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(879, 'TBD22 LLC                                         ', 'TBD22 LLC                                         ', '2395730888', 'store742@teamafricorp.com', NULL, '$2y$10$yoFj2wMV5VZbhZNkPLLvI.sCqqsdi3AJI4zvoQ6RzGGsocUdZvWjG', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(880, 'JP BONITA SPRINGS LLC                             ', 'JP BONITA SPRINGS LLC                             ', '2393014800', 'store743@teamafricorp.com', NULL, '$2y$10$brsaQqeeqzrGHD4nFgnDJeQ1YZTrLIGGdW2xLcsOhA9yfldiJqwt6', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(881, 'GRAHAM WILLIAM D                                  ', 'GRAHAM WILLIAM D                                  ', '2399190725', 'store744@teamafricorp.com', NULL, '$2y$10$KJO9gQwMGnMlUlL5aHuWcefS3aMnHc6y1z/WHFSq6HXw0gEQHnhOK', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(882, 'GUSTO CUCINA ITALIANA LLC', 'GUSTO CUCINA ITALIANA LLC', '2394585900', 'store745@teamafricorp.com', NULL, '$2y$10$H5CPacrPPz2.qQU6MCrGzOl7.fvvAhF1b8cT9HulM/mfn9RUKqFC6', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(883, 'FRIEZE RACHEL  HAHN MICHAEL                       ', 'FRIEZE RACHEL  HAHN MICHAEL                       ', '2394705296', 'store746@teamafricorp.com', NULL, '$2y$10$bdlmSrg19LBjWqCQDdub5OoG6pxmWk6Wo5Ntj.Jo7lglXP5hqIfDq', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(884, 'BF FORT MYERS LLC                                 ', 'BF FORT MYERS LLC                                 ', '2397037851', 'store747@teamafricorp.com', NULL, '$2y$10$2aD3MAWZmRW3utybxLSzauvCi8/X0HTiG4hEuu7uaOLdEQrawnWSm', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(885, 'SALZMANN ENTERPRISES LLC                          ', 'SALZMANN ENTERPRISES LLC                          ', '2392338305', 'store748@teamafricorp.com', NULL, '$2y$10$mh1Cc0ezzNGC2tJEZbiVN.I1IfbN6KdNZV1pVhAq41TG63HKcWWz2', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(886, 'P57 CAPE CORAL LLC                                ', 'P57 CAPE CORAL LLC                                ', '2394717785', 'store749@teamafricorp.com', NULL, '$2y$10$Khr6lCPGZEB2HHfqzIWcze3RnMWwbVeiQP35Tc/ydc6rU84zQwyH6', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(887, 'TROPIC FOOD INC', 'TROPIC FOOD INC', '2395908095', 'store750@teamafricorp.com', NULL, '$2y$10$jZvbqOklUOysyZiAC0mWUut05er8AT2bscMbxR.Iqt2Bb0ZatCc0O', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(888, 'FDR WINGS I LLC                                   ', 'FDR WINGS I LLC                                   ', '2392705905', 'store751@teamafricorp.com', NULL, '$2y$10$/o6EWOlHX8Fiw.OPzkFyOeWSDcv49Ll/F3iBnkj4gdaoEFOAOFMra', NULL, '2022-01-22 18:45:15', '2022-01-22 18:45:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(889, 'LUCIANOS PIZZA LLC', 'LUCIANOS PIZZA LLC', '2393608112', 'store752@teamafricorp.com', NULL, '$2y$10$d8A0BMLNBAZ3r9joQ6T/3.5MwlHRRJAKekuRgLQToIMSTWDbgLZdG', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(890, 'SREE VINAYAK LLC                                  ', 'SREE VINAYAK LLC                                  ', '2394545400', 'store753@teamafricorp.com', NULL, '$2y$10$v7I1pHb0H8tADogQpLWp8.XClLKbP7TMQ.ZSTfSFI4.Tdyfsn4gwy', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(891, 'DON PERROS CAFE AND BAKERY INC                    ', 'DON PERROS CAFE AND BAKERY INC                    ', '2398004100', 'store754@teamafricorp.com', NULL, '$2y$10$8RC6rGGa05sFngB3tOa4XOE4nkmdetqNNWmSZGcpQNObl7Qd8VNpy', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(892, 'SWEET LIFE 6 LLC                                  ', 'SWEET LIFE 6 LLC                                  ', '2394667707', 'store755@teamafricorp.com', NULL, '$2y$10$ZcBSiu1ZwP7TXkQFn6APTOMs149QR6sozqhTYwrvEtz5jf0k/cBBe', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(893, 'TAQUERIA JIMENEZ SERVICES INC', 'TAQUERIA JIMENEZ SERVICES INC', '2396034088', 'store756@teamafricorp.com', NULL, '$2y$10$CaloJ8sCuGtVgI8Pl3xILOt0/Ygrd3UhOs0K5sDxsYPmKw/CMKpfa', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(894, 'REDBONES OUT EAST LLC', 'REDBONES OUT EAST LLC', '2398393651', 'store757@teamafricorp.com', NULL, '$2y$10$RPPmduXH7iR56pkDj0b89.nI6UPSXjrNTpHn6Q56cDWj0GB63qZTS', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(895, 'BETTERSTEAMING INC                                ', 'BETTERSTEAMING INC                                ', '2392370707', 'store758@teamafricorp.com', NULL, '$2y$10$FChozblpPOmDrvOc0H77S.7zvBnR/1iTKio3qmv.r4FZ7sIQrAtva', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(896, 'GEIB INC                                          ', 'GEIB INC                                          ', '2393145667', 'store759@teamafricorp.com', NULL, '$2y$10$.365GAaN6JCiJrBv8DMBtOISBPvhrhGcs0UhymSkRKc1.b3qi5Xqu', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(897, 'LEHIGH HH PIZZA INC                               ', 'LEHIGH HH PIZZA INC                               ', '2393685225', 'store760@teamafricorp.com', NULL, '$2y$10$KMtMTr6/V8k.U1a7l5ra6ORJsIIf8EITGtra/qgN2piyTplYc2gse', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(898, 'CALAMONDIN COTTAGE LLC', 'CALAMONDIN COTTAGE LLC', '2393211894', 'store761@teamafricorp.com', NULL, '$2y$10$SpuLbZVAlgKxaA1ov9wf6OIQwsszadxL68qKjy6iXYis0RdeSJDAC', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(899, 'PRD SAI LLC                                       ', 'PRD SAI LLC                                       ', '2394919825', 'store762@teamafricorp.com', NULL, '$2y$10$Xdc.5DtQZ51oi9dwcMS.O.ADdhbE/AX85R6qRl58uqnealyZkJfjy', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(900, 'LOL HOLDINGS LLC                                  ', 'LOL HOLDINGS LLC                                  ', '2396420873', 'store763@teamafricorp.com', NULL, '$2y$10$JQzP.pyNgkN7mnzWkeELA.vY2EJsEXo5q21ZEI6zCOaQQtTeL5ySy', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(901, 'COX COOKIES AND CAKES LLC', 'COX COOKIES AND CAKES LLC', '2397380838', 'store764@teamafricorp.com', NULL, '$2y$10$oHb2jK3T/AUVXD2Lh1o9gOrCBlLh6LGmjE6TAmXQrooK36MXmZ2RC', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(902, 'LEOS FRENCH TOAST HOUSE LLC                       ', 'LEOS FRENCH TOAST HOUSE LLC                       ', '7654616903', 'store765@teamafricorp.com', NULL, '$2y$10$00iMh3THd/NO.ij.sXr3Ke7JrxXWrp5EbuYBlyblyxXEsBXS89zKC', NULL, '2022-01-22 18:45:16', '2022-01-22 18:45:16', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(903, 'ANTHONYS ON THE BLVD INC', 'ANTHONYS ON THE BLVD INC', '2397725900', 'store766@teamafricorp.com', NULL, '$2y$10$8B3f2iOTJYFiFG.Ifm7Y3eYOFuRHbOQBRVxw6O8yGnfoornowfn7q', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(904, '2282 FIRST STREET HOSPITALTY LLC', '2282 FIRST STREET HOSPITALTY LLC', '2393374997', 'store767@teamafricorp.com', NULL, '$2y$10$5Eu7wWj/UjTiytA/zg1bCuvD4fHusglPwqKxLeE87e79SigTwL8Bi', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(905, 'VEULVE A LA VIDA SEAFOOD LLC                      ', 'VEULVE A LA VIDA SEAFOOD LLC                      ', '2396004884', 'store768@teamafricorp.com', NULL, '$2y$10$XkMsj2VNViUrrXOgWtN8ue70MK6VVjpYwStUdseb9Av9EHzQaX22.', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(906, 'NOLAN  EVE B                                      ', 'NOLAN  EVE B                                      ', '2392874159', 'store769@teamafricorp.com', NULL, '$2y$10$8DhuEpcThGPKJKZ2Nfa2ye6xnepUeLEJSXGFM/0JeplbV/BwKFeyS', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(907, 'NEW EL TORO MEXICAN BAR & GRILL LLC               ', 'NEW EL TORO MEXICAN BAR & GRILL LLC               ', '2395585181', 'store770@teamafricorp.com', NULL, '$2y$10$IF4bs3v8OB3mYOGK/n1T9.lZhPd3Xf0OapR0c5qtJP4oWQIVhfTTy', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(908, 'BIG G S ICE TEA', 'BIG G S ICE TEA', '2397705343', 'store771@teamafricorp.com', NULL, '$2y$10$qedxPl01WQu5bV7jpGKW3OncYujAnwkUmfR88VrrEVp2fU70x.Wny', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(909, 'THE FROZEN CHOSEN LLC                             ', 'THE FROZEN CHOSEN LLC                             ', '2396770686', 'store772@teamafricorp.com', NULL, '$2y$10$XSGwtqIrTnZoWmg022fRru08QnEDGET36Q0141EuagJICA9GleEwi', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(910, 'KAPUA KAVA INC                                    ', 'KAPUA KAVA INC                                    ', '2392926567', 'store773@teamafricorp.com', NULL, '$2y$10$iDb1wxUu60ZShtMUI1JltO337OHl1wXdIffrGvK8IgEcvJB3Ugba2', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(911, 'ZOES FLORIDA LLC', 'ZOES FLORIDA LLC', '5133946161', 'store774@teamafricorp.com', NULL, '$2y$10$Kl10ZbFv9D1FZxidFI/OAuQpX/zs92sRaFt.oae586Gllox8O/.q.', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(912, '1406 HENDRY HOSPITALITY LLC                       ', '1406 HENDRY HOSPITALITY LLC                       ', '2393373673', 'store775@teamafricorp.com', NULL, '$2y$10$8bIXwYdHGDQ5pud0bhFAKuvJYavcP0taLid93trbt3o0ZxWU92NBi', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(913, 'RACOE TRAC PETROLEUM INC                          ', 'RACOE TRAC PETROLEUM INC                          ', '2399950325', 'store776@teamafricorp.com', NULL, '$2y$10$wBJylW0nybK9S6rEw4hNRODziUwBUPiln7G1J.7EI9kz4ZzzT5JTC', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(914, 'RACETRAC PETROLEUM INC', 'RACETRAC PETROLEUM INC', '2399950325', 'store777@teamafricorp.com', NULL, '$2y$10$UnqHJZ3RUkpLsdy.RTrV4OODze2NSSWcE2P0rPbAIHql2NpnhEpR.', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(915, 'QUALITY BRAND GROUP FLORIDA LLC                   ', 'QUALITY BRAND GROUP FLORIDA LLC                   ', '2033282130', 'store778@teamafricorp.com', NULL, '$2y$10$sPddGtgxoYKR5ESeyp.jV.tJULNwjAIOywQgu1cEyI/9fBKA8k2Y6', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(916, 'BRAVOFLORIDA LLC', 'BRAVOFLORIDA LLC', '2394248939', 'store779@teamafricorp.com', NULL, '$2y$10$D8A6kTWUznnyn6YLobgk4umCjnEeNLcpT1Ot7dV.uOZE62XwZzlqS', NULL, '2022-01-22 18:45:17', '2022-01-22 18:45:17', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(917, 'MIX FLORIDA SERVICES INC                          ', 'MIX FLORIDA SERVICES INC                          ', '7867693999', 'store780@teamafricorp.com', NULL, '$2y$10$EUZMRVkIU5ckdnzIQkHGEeLNdPsOmuEM8Vc2H00/4BqHQtQCqkUG.', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(918, 'KREIPS & JUICES INC', 'KREIPS & JUICES INC', '2395748085', 'store781@teamafricorp.com', NULL, '$2y$10$i9gauymbb0rS2kXroW2bze/UDkp436ItDA3FzasJfYYvfzNjna3o2', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(919, 'BRAVOFLORIDA LLC                                  ', 'BRAVOFLORIDA LLC                                  ', '2393607900', 'store782@teamafricorp.com', NULL, '$2y$10$BH3SkzSoK59S72ynkPKF3OEqM.jumenRVOHuyxE7wJ.SZ4rT530Zm', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(920, 'UNCLE MIKEYS FOOD TRUCK LLC                       ', 'UNCLE MIKEYS FOOD TRUCK LLC                       ', '2399088806', 'store783@teamafricorp.com', NULL, '$2y$10$mtwOOs0j5GseqUkG4dL2vuuMZRQt.hBSFFy3aevmElbUvk/np2t8m', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(921, 'FLORIDA POP LLC', 'FLORIDA POP LLC', '9722322118', 'store784@teamafricorp.com', NULL, '$2y$10$LWzFIygtq9ZHebJEVdTzwehp.tDYqQVwNUeLr4QwqMrh.54I1LupC', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(922, 'WILLIAMS JUSTIN E', 'WILLIAMS JUSTIN E', '9416212481', 'store785@teamafricorp.com', NULL, '$2y$10$xON0RUg8CaGndlnYEyYD0ekUhHhCBzKjSxHKQMPPiYktjnWmJvo2m', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(923, 'RACETRAC PETROLEUM INC', 'RACETRAC PETROLEUM INC', '2397688160', 'store786@teamafricorp.com', NULL, '$2y$10$dYRn8E7PVW7nsB05RU6SP.u2Dl.iBjdY9dRvLDXZmgYCf/ImPNuAG', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(924, 'TSC FL 218 INC                                    ', 'TSC FL 218 INC                                    ', '2397891210', 'store787@teamafricorp.com', NULL, '$2y$10$8PtUhLI9he4AK7qY1mfEEuiYxlUXrLuCbSPDdFbxtr2Y1l45yX3Ca', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(925, 'CHIPOLTE MEXICAN GRILL OF COLORADO LLC', 'CHIPOLTE MEXICAN GRILL OF COLORADO LLC', '2394246451', 'store788@teamafricorp.com', NULL, '$2y$10$lkLeA2/7pQc1s93qqY90ZOFOBk3z0vaUZkLQUTpwO0U3wJUc669KO', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(926, 'VOHO RESTAURANT GROUP LLC                         ', 'VOHO RESTAURANT GROUP LLC                         ', '2396739939', 'store789@teamafricorp.com', NULL, '$2y$10$xwVUr3agikoKuj8WIMjCReJVgzft6gpl4xtD9GzefosXlgL75ziQ6', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(927, 'PLR INVESTMENTS LLC', 'PLR INVESTMENTS LLC', '9205791434', 'store790@teamafricorp.com', NULL, '$2y$10$wcD1PY7UVJDMPUS2trTiY.hMrk976x1rzHFXkoxQR1a/qznyI./z.', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(928, 'BALFOUR MICHELE                                   ', 'BALFOUR MICHELE                                   ', '2392895986', 'store791@teamafricorp.com', NULL, '$2y$10$HFfOI/z.qamKOQRJghu/MO0C0xPPTbIEtcbAYrPpzgjZoK6Gm1VA2', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(929, 'TAGS WHISKEY BENT BBQ LLC', 'TAGS WHISKEY BENT BBQ LLC', '2394405543', 'store792@teamafricorp.com', NULL, '$2y$10$vkTIWRX8VGEEwLwlSfHQxubQgfmA7O0zB5zcBAz.ClY.ueBU2JNUO', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(930, 'MOJOES COFFEE BAR LLC', 'MOJOES COFFEE BAR LLC', '2392732477', 'store793@teamafricorp.com', NULL, '$2y$10$75mWB/9HI94cLQt.7OivaOrIgekZzkVxPnKvjnhiZYJA7j16SxTzm', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(931, 'FDR WINGS II LLC                                  ', 'FDR WINGS II LLC                                  ', '2392219464', 'store794@teamafricorp.com', NULL, '$2y$10$2IUMmiE5WYNUupOEUboFzuPxEOtxixP03yuuRjii4HoiaClIHozQy', NULL, '2022-01-22 18:45:18', '2022-01-22 18:45:18', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(932, 'GREEN GOLF PARTNERS LLC', 'GREEN GOLF PARTNERS LLC', '2392835522', 'store795@teamafricorp.com', NULL, '$2y$10$qr9puGhNqRU7UH6dTcUrIuQ9rPB836KM0VPFhWLBBRXEpftowMZ5O', NULL, '2022-01-22 18:45:19', '2022-01-22 18:45:19', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(933, 'HAVEN FORT MYERS LLC                              ', 'HAVEN FORT MYERS LLC                              ', '2393340900', 'store796@teamafricorp.com', NULL, '$2y$10$mXerRyvFA2A2aasHG0ZfIeX8Lj7tnGNSQ91iEkbE7iMEcgbM6NReC', NULL, '2022-01-22 18:45:19', '2022-01-22 18:45:19', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(934, 'ARTISAN EATERY LLC', 'ARTISAN EATERY LLC', '2398874844', 'store797@teamafricorp.com', NULL, '$2y$10$LlfELMbwVFwHBViUrkOdJu1wMSn0wlFIgWB9ZyfOXGxXm4AW2ZGea', NULL, '2022-01-22 18:45:19', '2022-01-22 18:45:19', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(935, 'RINALDI\'S ITALIAN KITCHEN INC                     ', 'RINALDI\'S ITALIAN KITCHEN INC                     ', '2399497770', 'store798@teamafricorp.com', NULL, '$2y$10$V6av.XFYPeo1fV9hsz1dmOfzXHlwKyznMXVBNzzGRr2ZD/GCQvrOK', NULL, '2022-01-22 18:45:19', '2022-01-22 18:45:19', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(936, 'PIERRE LEONCE                                     ', 'PIERRE LEONCE                                     ', '2395654224', 'store799@teamafricorp.com', NULL, '$2y$10$s/xBcnqh2ypkEsWh0h5lYufkxKUDDY3iNY7fF/wCbHlunWc1l6bme', NULL, '2022-01-22 18:45:19', '2022-01-22 18:45:19', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(937, 'TORTILLERIA SAN JULIAN INC', 'TORTILLERIA SAN JULIAN INC', '2392884123', 'store800@teamafricorp.com', NULL, '$2y$10$X/pZYWox6sQLFQTp8qN5b.CKXG0zqnUY.IfbjscCM4HH826o0SRhm', NULL, '2022-01-22 18:45:19', '2022-01-22 18:45:19', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(938, 'FISH TALE MARINA RESTAURANT LLC', 'FISH TALE MARINA RESTAURANT LLC', '2397476500', 'store801@teamafricorp.com', NULL, '$2y$10$tg5ZdovGGkvlo81KdNKPPObLFNnJ7axd8xZTXr008o5p/wbH3RISu', NULL, '2022-01-22 18:45:19', '2022-01-22 18:45:19', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(939, 'CAPE ICE CREAM LLC', 'CAPE ICE CREAM LLC', '2392402323', 'store802@teamafricorp.com', NULL, '$2y$10$X1Q.JOeRYxnRbh1sM9egR.JVrI.tv/0mVeI9D7omGYvDfi8dwzoX6', NULL, '2022-01-22 18:45:19', '2022-01-22 18:45:19', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(940, 'ISHA ZAIN ENTERPRISES LLC                         ', 'ISHA ZAIN ENTERPRISES LLC                         ', '', 'store803@teamafricorp.com', NULL, '$2y$10$kd23pq6MfEAe1UFcqKEEKeHmvr8jDdToYPTgrQkOML3N4mGRtycBq', NULL, '2022-01-22 18:45:19', '2022-01-22 18:45:19', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(941, 'MEATBALLS ITALIAN KITCHEN LLC                     ', 'MEATBALLS ITALIAN KITCHEN LLC                     ', '2398007172', 'store804@teamafricorp.com', NULL, '$2y$10$CuLofQhD0AlunkTLrAQmMOv996CMgy6MFDbZXhMtWYa7bYZPj4myO', NULL, '2022-01-22 18:45:19', '2022-01-22 18:45:19', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(942, 'TACOS SAN MIGUEL INC                              ', 'TACOS SAN MIGUEL INC                              ', '2396451993', 'store805@teamafricorp.com', NULL, '$2y$10$gCrR8NVXcRz7.1N.mNuxseD1sixxzF4N5skzdLQeS3Y0OdBF1IBwy', NULL, '2022-01-22 18:45:19', '2022-01-22 18:45:19', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(943, 'MMRNS INC', 'MMRNS INC', '2397918036', 'store806@teamafricorp.com', NULL, '$2y$10$hw0ssA4ceebShTPXiveEV.zwBLVjjWPUBZGbzNlNeQXHcjunKtVDa', NULL, '2022-01-22 18:45:20', '2022-01-22 18:45:20', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(944, 'SILK ROAD LLC', 'SILK ROAD LLC', '2396894845', 'store807@teamafricorp.com', NULL, '$2y$10$1IlXoZBzbWaZw7MZurUnRO8N69xo1Igi6QWUEqM/isPqdomMDmSk.', NULL, '2022-01-22 18:45:20', '2022-01-22 18:45:20', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(945, 'TRADERS VILLAGE LLC', 'TRADERS VILLAGE LLC', '5129648089', 'store808@teamafricorp.com', NULL, '$2y$10$U8VF9YMlWKu1u.RwTRhdq.FIek/ZyaAeXPEF402i7gDcW5SohElLa', NULL, '2022-01-22 18:45:20', '2022-01-22 18:45:20', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(946, 'B2U INC                                           ', 'B2U INC                                           ', '3039085130', 'store809@teamafricorp.com', NULL, '$2y$10$nMYZoebC3JAk.Tk5F3YD/eEcKAJkqxoZ3.NYi2MLlkvKYUIna0g9y', NULL, '2022-01-22 18:45:20', '2022-01-22 18:45:20', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(947, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2394953001', 'store810@teamafricorp.com', NULL, '$2y$10$mcP2zASRBPoM4MxCGZqFnuwBdudYbyc2CTFn1K5yJSiXkXZAuHeK6', NULL, '2022-01-22 18:45:20', '2022-01-22 18:45:20', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(948, 'MILSEAIN BELLE LLC', 'MILSEAIN BELLE LLC', '2393401147', 'store811@teamafricorp.com', NULL, '$2y$10$qAwyEG6AZT.p5mmgfTYeFuqN7p51q8vRBh4vWODc5eNpOjSQQ3g76', NULL, '2022-01-22 18:45:20', '2022-01-22 18:45:20', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(949, 'KYC GLOBAL ENTERPRISE INC                         ', 'KYC GLOBAL ENTERPRISE INC                         ', '2397683388', 'store812@teamafricorp.com', NULL, '$2y$10$DvpgABu9oGcy6q7afAWfnu8LL4kPuE7qbX3Zy2XBxLRLli6DGtFmy', NULL, '2022-01-22 18:45:20', '2022-01-22 18:45:20', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(950, 'TINSLEYBRIDGEMAN LLC                              ', 'TINSLEYBRIDGEMAN LLC                              ', '5022547130', 'store813@teamafricorp.com', NULL, '$2y$10$LG9Q97gjph17SD.wuzTAYu7ZpSgQUSSwwL.HJprQeDN/H72pCptKS', NULL, '2022-01-22 18:45:20', '2022-01-22 18:45:20', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(951, '7 ELEVEN INC & TOOMBS INC                         ', '7 ELEVEN INC & TOOMBS INC                         ', '2394587150', 'store814@teamafricorp.com', NULL, '$2y$10$6rBVx2IfSBDa33ssbZ9iSuOiYRKv1e4qHGzsH34XxksLmcAzIO.jy', NULL, '2022-01-22 18:45:20', '2022-01-22 18:45:20', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(952, 'PANADERIA LA VICTORIA CORP                        ', 'PANADERIA LA VICTORIA CORP                        ', '2397284946', 'store815@teamafricorp.com', NULL, '$2y$10$PGIaI8HfZkW9s3Cbalks5.tqG/f2v6KkAeRfUWvxYu6S2DqQOwgha', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(953, 'SABOR A MEXICO NFM INC                            ', 'SABOR A MEXICO NFM INC                            ', '2399979995', 'store816@teamafricorp.com', NULL, '$2y$10$YVIXMr.wEVBEZml8Nw/fX.Jx2Oo2GyhcbSjncxxhNq2mFl1zmvfaS', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(954, 'AMORE ITALIAN MARKET & BAKERY LLC                 ', 'AMORE ITALIAN MARKET & BAKERY LLC                 ', '2398003938', 'store817@teamafricorp.com', NULL, '$2y$10$ZbwWARVCGmnqyQ/ST5POP.GqPtgYShOefEHdnNd0/rXyDjvnc41aC', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(955, 'LUCKY CHINA GARDEN', 'LUCKY CHINA GARDEN', '2399458866', 'store818@teamafricorp.com', NULL, '$2y$10$ESvPLNVPyVFkoCpOa9f7JuyOSSJG8rWhj5t/7KOBduRr64UnBoryi', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(956, 'L D  MANANGEMENT INC', 'L D  MANANGEMENT INC', '2396566622', 'store819@teamafricorp.com', NULL, '$2y$10$f45PTcnjrgKsmbBrUwE7f.UKzTQcT8CXP.HmotWTDrRms7sdW6wDm', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(957, 'CARBELLOS FAMILY CATERING LLC                     ', 'CARBELLOS FAMILY CATERING LLC                     ', '2392810104', 'store820@teamafricorp.com', NULL, '$2y$10$zk031wFPOQj6nfcU.BVaDeL8tVDN9gdRsDXhH0Oc3nSbQK.Ff4b4.', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(958, 'MACKIEGLO INC', 'MACKIEGLO INC', '2394581672', 'store821@teamafricorp.com', NULL, '$2y$10$SHUAatFCpqHLc71C7vYdAua9sAIcYeCmo0A5FE9IrFcOBE75lIRRS', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(959, 'JAMES M THOMPSON THREE LLC', 'JAMES M THOMPSON THREE LLC', '2394721771', 'store822@teamafricorp.com', NULL, '$2y$10$y5FXcUhqPqItA9AL85Wti.Zw9Ff0vgQKNAYVIQwfzr1VfYOQq/Fi2', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(960, 'STAY TRUE & BE ME LLC                             ', 'STAY TRUE & BE ME LLC                             ', '4076259331', 'store823@teamafricorp.com', NULL, '$2y$10$d1rb9FgTxrbB70hUoxgCJu2.RAzxwCsGp04Is3xVry71RAY7BFZDm', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(961, 'TARGET CORPORATION                                ', 'TARGET CORPORATION                                ', '2394585868', 'store824@teamafricorp.com', NULL, '$2y$10$W2.WZBzhoo7zpu.4VskP8OfYfrKOhQMZl3/3ZRHLR0dMjIAuRfvCq', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(962, 'TARGET CORPORATION                                ', 'TARGET CORPORATION                                ', '2392659002', 'store825@teamafricorp.com', NULL, '$2y$10$VFRTgrSq/SxHmTnH0FLwl.TDsH9iOzQEEQNDEe0nhu4/ZuLTHx2lS', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(963, 'TARGET CORPORATION                                ', 'TARGET CORPORATION                                ', '2398292639', 'store826@teamafricorp.com', NULL, '$2y$10$cnTcgXVd/b51gWYdi/f0VuSkb36hJM7vuiX4qXfPL78//Jcurt.fi', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(964, 'BRAVOFLORIDA LLC                                  ', 'BRAVOFLORIDA LLC                                  ', '3524604444', 'store827@teamafricorp.com', NULL, '$2y$10$dd0kq1oxBUzCAtWyr9KAJ.Tn40UnFWHKecUHTM5MR9lXCp2UdGEq.', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(965, 'HIBACHI OF JAPAN 3 LLC', 'HIBACHI OF JAPAN 3 LLC', '2393137879', 'store828@teamafricorp.com', NULL, '$2y$10$6mNY/pYKQBnoGdSNCPuINuRXd/EzOisDH8PRaTQepxZ/oDngl8Zha', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(966, 'SIX MILE DONUTS LLC', 'SIX MILE DONUTS LLC', '3057663723', 'store829@teamafricorp.com', NULL, '$2y$10$Q/Tdi1Er0S8LfsHwt/KV3utAhHz3a47BHGMK6lt07N5LYOdvelJSW', NULL, '2022-01-22 18:45:21', '2022-01-22 18:45:21', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(967, 'FAIRVIEW DONUTS LLC                               ', 'FAIRVIEW DONUTS LLC                               ', '3057663723', 'store830@teamafricorp.com', NULL, '$2y$10$zh4PD/Hgz0UCiVJyDjy1e.okfpIjyy59Z0itLzm0g/WILQkph3l0q', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(968, 'VILLAGE WALK BONITA INC                           ', 'VILLAGE WALK BONITA INC                           ', '2398509451', 'store831@teamafricorp.com', NULL, '$2y$10$yk3GcuMveCzIJ6k7Ne72buyENMcUcrl4rTxXUPVGg8OYmWDN36EKe', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(969, 'CUCKOO DADDYS LLC                                 ', 'CUCKOO DADDYS LLC                                 ', '7867662256', 'store832@teamafricorp.com', NULL, '$2y$10$IUISXLG1dSjFv7ElEIjBVuwC9vLpjaZRl3FdzMgdHd6KJGtjmcxRS', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(970, 'PILARKSIBROTHERS LLC', 'PILARKSIBROTHERS LLC', '2399366622', 'store833@teamafricorp.com', NULL, '$2y$10$rr58wpGg0726uNvjTn.4iew2HFO14.23hBFv9T3YOowCG/rlJWkZi', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(971, 'HAYWOOD HEATHER                                   ', 'HAYWOOD HEATHER                                   ', '2392090707', 'store834@teamafricorp.com', NULL, '$2y$10$nqIuFaFl2o1pGokFnuv3WuA.5X5sYn6wlNileC5w5M27CtUW5w1Kq', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(972, 'PFP ENTRUST EATERY LLC', 'PFP ENTRUST EATERY LLC', '2392170519', 'store835@teamafricorp.com', NULL, '$2y$10$xOJRNFIFd2T2ijdop0kNfec41M7XX/UMAlAQu0nozi8weIyVwBz/q', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(973, 'CHINA WOK 3 INC                                   ', 'CHINA WOK 3 INC                                   ', '2392420921', 'store836@teamafricorp.com', NULL, '$2y$10$6sEfL/LcFBkkQDoEO/0Al.F.cyYUXfsDjTRzixovbqfGnauYPOy0W', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(974, 'RDC FOOD GROUP LLC', 'RDC FOOD GROUP LLC', '2392458068', 'store837@teamafricorp.com', NULL, '$2y$10$o8yCxls059J0fJYAakr8quwLcpuvi5p4rs7/gGsa/ScNYv3K9kdTG', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(975, 'ICHIBAN FOOD INC', 'ICHIBAN FOOD INC', '2393346991', 'store838@teamafricorp.com', NULL, '$2y$10$H7eXii2O3rWttEwh1skBH.6WOduPFjNljzCSHHMGhBUQ00Y8N89B6', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(976, 'MESON CAMAGUEYANO LLC', 'MESON CAMAGUEYANO LLC', '2398508597', 'store839@teamafricorp.com', NULL, '$2y$10$Zxs9jERUnnFWitjKxjGUVOtZDGfBOUxdLp1iVcSTc6HDberdIM9W2', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(977, 'QUALITYBRAND GROUP FLORIDA LLC                    ', 'QUALITYBRAND GROUP FLORIDA LLC                    ', '2033282130', 'store840@teamafricorp.com', NULL, '$2y$10$ce6U7UbeDH6V.aKzqG0e4OhiXw8nCHB4hcAgJosAVHD40g5ZHnk/S', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(978, 'EL MERCADO DE SAN CARLOS INC                      ', 'EL MERCADO DE SAN CARLOS INC                      ', '2394370668', 'store841@teamafricorp.com', NULL, '$2y$10$CX6G5VdPNTlEW0TqpG/MDOZyCNyYSDKsbZCXWsPjHBje7xEm0eLTa', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(979, 'AGALAS LLC                                        ', 'AGALAS LLC                                        ', '2397918227', 'store842@teamafricorp.com', NULL, '$2y$10$bqGABpZhFpsPJITnCGnGAuV/TnxGqy9H4K022cHQtuJQCMR79uK9a', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(980, 'SMOKIN RS BAR B Q LLC', 'SMOKIN RS BAR B Q LLC', '2393489555', 'store843@teamafricorp.com', NULL, '$2y$10$mwiqOo4dS5.lMR3MQifha.O0MlAnoEIpENpJBt89xEQzhp9kt/2wS', NULL, '2022-01-22 18:45:22', '2022-01-22 18:45:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(981, 'JONESEZ BBQ INC                                   ', 'JONESEZ BBQ INC                                   ', '2392266262', 'store844@teamafricorp.com', NULL, '$2y$10$nvPdJXb24EfD9tDKF2raguufidCr710egRmueBxdkwVq0Aa3y64Oi', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(982, 'STARZ ACQUISITION LLC', 'STARZ ACQUISITION LLC', '2394827827', 'store845@teamafricorp.com', NULL, '$2y$10$P4xOB38jFkUH5tq4Zz5Hg.P7akY6NshreV7yTW30M1mKUIUIElsF.', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(983, 'STARZ ACQUISITIONS LLC', 'STARZ ACQUISITIONS LLC', '2394823105', 'store846@teamafricorp.com', NULL, '$2y$10$uGNoHbE5gqaqhbcCwxc/2eIU.bHjjvp2NdoIqakSX9GePtr0fpgj2', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(984, 'M C BUSINESS MANAGEMENT LLC                       ', 'M C BUSINESS MANAGEMENT LLC                       ', '2393477115', 'store847@teamafricorp.com', NULL, '$2y$10$hXYfzc/CpqMNo1.qfPjkBOE/AZsxEIX4B0EftlhLcMZxTOLJsix9.', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(985, 'JAC ISLAND BAR AND GRILLE LLC                     ', 'JAC ISLAND BAR AND GRILLE LLC                     ', '2394721771', 'store848@teamafricorp.com', NULL, '$2y$10$v4Wf5MZTDUiBrTfiwy6Ut.Eu4EWsF9qDBYN9nT2L4.SJKb61OOrJ.', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(986, 'BIMINI BAIT SHACK LLC', 'BIMINI BAIT SHACK LLC', '2393602248', 'store849@teamafricorp.com', NULL, '$2y$10$MBNtphd6FHSpkpL2P9oxb.vpKX1CBD7X8qtQulAqBWDGve14e5BGO', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(987, 'THREE RESCH KIDS INC', 'THREE RESCH KIDS INC', '2393308226', 'store850@teamafricorp.com', NULL, '$2y$10$Ho9S3oigtkjGzFIcYT8g0edmtPXuU3gfL.bAZebKQc4ZmiwcX/BRq', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(988, 'ANTOJITOS VENEZUELA CORP                          ', 'ANTOJITOS VENEZUELA CORP                          ', '2392366444', 'store851@teamafricorp.com', NULL, '$2y$10$rxQp5gCbOwliKj7h9rZY3OajOLHPCs5TUSTYj3iRvAuiv7YcrsTjy', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(989, 'ORIGINAL ENGLUNDS DELI LLC', 'ORIGINAL ENGLUNDS DELI LLC', '2393323444', 'store852@teamafricorp.com', NULL, '$2y$10$vBeWaoVM1Ubnw8k74CWmDuFnHqKxVf/0CL6x2ja3ztOUrj545iY1K', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(990, 'HOLE IN 1 BAGELS & DELI CORP', 'HOLE IN 1 BAGELS & DELI CORP', '3107790492', 'store853@teamafricorp.com', NULL, '$2y$10$9oR8qhvyA3Jl2yvsYR2EWu8HoPb3BzNlMFQRGLDsrdukoKAq5bp.i', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(991, 'DANIELS BROOKSHIRE FORT MYERS LP                  ', 'DANIELS BROOKSHIRE FORT MYERS LP                  ', '2144368765', 'store854@teamafricorp.com', NULL, '$2y$10$.nhuFkLC6giSgTJEAaLn2uw1.suHv.W0eEYwgEMrmdahmEQMdmCXu', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(992, 'NISBET ENTERPRISES OF SIX MILE CYPRESS LLC        ', 'NISBET ENTERPRISES OF SIX MILE CYPRESS LLC        ', '8636120333', 'store855@teamafricorp.com', NULL, '$2y$10$TBYtT1jiTqMR6YeuP78pruwnv3cVAVw1UgOoBR9Xhtq7JlJ7EzBIS', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(993, 'DEEP LAGOON FT MYERS LLC', 'DEEP LAGOON FT MYERS LLC', '2396316266', 'store856@teamafricorp.com', NULL, '$2y$10$84FUZvpefdV69OjEq44houqse9I.T4L8fM3MOU2CjzsvmuwKOOQ2G', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(994, 'JNY OM INC', 'JNY OM INC', '5163841251', 'store857@teamafricorp.com', NULL, '$2y$10$QpfHujsoECDaVNCI7Jjj/esG1rjfl2Fsii34mYao0nhg.p79xLZre', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(995, 'MYSTIC JADE LLC', 'MYSTIC JADE LLC', '7867778105', 'store858@teamafricorp.com', NULL, '$2y$10$0jyggOPqUj4PhCaDW3MboeDsXXweSTHIztxr5lQRvDSTMmSR9E6se', NULL, '2022-01-22 18:45:23', '2022-01-22 18:45:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(996, 'DIPRIMA KENNETH                                   ', 'DIPRIMA KENNETH                                   ', '8434247423', 'store859@teamafricorp.com', NULL, '$2y$10$0Y7qgy.8CmB5kWtFDWr1Tu5/bhCgnSJPOAesDXUfneuT7MZrtWLrS', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(997, 'VINTAGE REAL ESTATE LLC', 'VINTAGE REAL ESTATE LLC', '2395410800', 'store860@teamafricorp.com', NULL, '$2y$10$8bDbyBcOQ01h1vw1P.oPyu8MblGmqUeCFA4gLliJvHRFLItk8GllS', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(998, 'FAVI CAKES LLC', 'FAVI CAKES LLC', '2393131429', 'store861@teamafricorp.com', NULL, '$2y$10$sLgfqIpyg3sGyB3Le5quV.P8jBrrEuJo73jQc64sZbW7RvVCAel.S', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(999, 'WALKER DEBRA D', 'WALKER DEBRA D', '2392710552', 'store862@teamafricorp.com', NULL, '$2y$10$KJfMEEcgJ6TBdi06alXv8ODVvUlMWQCqRK6kXhZW2jO2TDjQwvSPK', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1000, 'ADIL ALI ENTERPRISES LLC                          ', 'ADIL ALI ENTERPRISES LLC                          ', '4073994630', 'store863@teamafricorp.com', NULL, '$2y$10$HEeopPxTOIFYODJdO8dwvuyFX96NF4Iz5Qr.WLpacsXXvqXii7Sdi', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1001, 'HIBBS SANDRA J', 'HIBBS SANDRA J', '2394371311', 'store864@teamafricorp.com', NULL, '$2y$10$UGn0xXyauvV1znNc.sxeyOB94Z1Y5RwbXVR/yv8VQ/inngwylmgWS', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1002, 'PANERA LLC', 'PANERA LLC', '2393407983', 'store865@teamafricorp.com', NULL, '$2y$10$DelEL4GxOSvyzHmAl3DJjeco6T2CU5ufcwcEwpAlGmpU10kf9FvNm', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1003, 'BOATHOUSE FORT MYERS LLC', 'BOATHOUSE FORT MYERS LLC', '2393322628', 'store866@teamafricorp.com', NULL, '$2y$10$cMfY4wewyf4rEfL6NBEpteiSUP2lUWX9EnoPNaVmO5P03N/U4K/8C', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1004, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '2393033692', 'store867@teamafricorp.com', NULL, '$2y$10$ZxVBu8p3bejDI5zGUljWOuM8/eCoEJAAyJng728BN4z1oW.LaGMUa', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1005, 'CCLLF INC                                         ', 'CCLLF INC                                         ', '2393014727', 'store868@teamafricorp.com', NULL, '$2y$10$iE4nvgCW9W.p0rasElTGCeAnOdL0SSq1f04ZdNTCBaJaErN0P81C6', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1006, 'BRAVOFLORIDA LLC                                  ', 'BRAVOFLORIDA LLC                                  ', '2392750324', 'store869@teamafricorp.com', NULL, '$2y$10$rBUJisl1nTRoedu/FvxSLejbf.CqkjfODUHzFmjpf7eJG51BL0qBK', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1007, 'GINGER GROUP LLC', 'GINGER GROUP LLC', '2395588801', 'store870@teamafricorp.com', NULL, '$2y$10$cIgWfTp5X1VUOCIPAlya6eNfg3EiLXopwv1R5Pyu6wKvQSOLpX2wS', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1008, 'QUALITY FRESCA LLC                                ', 'QUALITY FRESCA LLC                                ', '2392082474', 'store871@teamafricorp.com', NULL, '$2y$10$XVm9V4kpNJLou2MzDIZquuark/tE2OqTIa7UbwjKrug9C0w1uKtRG', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1009, 'EVER AFTER ICE CREAM INC                          ', 'EVER AFTER ICE CREAM INC                          ', '2396894542', 'store872@teamafricorp.com', NULL, '$2y$10$U/NfjFYNjQwPFPz.X3eldeHgmoCB1iLOzYJlad7kemCf7nC27s49K', NULL, '2022-01-22 18:45:24', '2022-01-22 18:45:24', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1010, 'SUNSET SLUSH OF FORT MYERS LLC', 'SUNSET SLUSH OF FORT MYERS LLC', '2398518104', 'store873@teamafricorp.com', NULL, '$2y$10$xd5MoJp7zalASm0n9F2z3OsRe0upxWGZfyAwpIIJH4o0miZ7POOn.', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1011, 'SMALLCAKES PAGE FIELD LLC', 'SMALLCAKES PAGE FIELD LLC', '2032172114', 'store874@teamafricorp.com', NULL, '$2y$10$Go39XMgQNOu19oAKks4MTOWKGBDdlSshY.ELyy08GiiPCIUjhgxyG', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1012, 'COPBAY HOLDINGS LLC', 'COPBAY HOLDINGS LLC', '2392822738', 'store875@teamafricorp.com', NULL, '$2y$10$L3FFZORq8gnOP26do3XUte9Uk.OYHKdhVdpi6Sbpckd7GTNWj39kS', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1013, 'MURPHYS OIL USA INC                               ', 'MURPHYS OIL USA INC                               ', '8708757751', 'store876@teamafricorp.com', NULL, '$2y$10$rgD4qZ8hSJdIJANAE0gEi.4Wyc3byv67lG1zIxiGHvMVc/l7g4GJu', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1014, 'MOFFA ROBERT', 'MOFFA ROBERT', '2488773939', 'store877@teamafricorp.com', NULL, '$2y$10$dq5/DKQJ3Zsyh42Qw/kiZuBMoVzXmcNDP0zyEwP3.FPaHkM6oj4Tu', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1015, 'ELDRIDGE AMY                                      ', 'ELDRIDGE AMY                                      ', '4195430207', 'store878@teamafricorp.com', NULL, '$2y$10$eYlm5AyIuQ1NX11uuL9Vku6einoGThPTOkNGYBr1XNYuHDZucGOB.', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1016, 'LONG PHAM', 'LONG PHAM', '2394001115', 'store879@teamafricorp.com', NULL, '$2y$10$eYklcS7YHbeB8Jns7Jxg1u17WDTjfvMa4YGugTeY1XwT6NEEkHkSm', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1017, 'BLUE FLAME GRILL INC                              ', 'BLUE FLAME GRILL INC                              ', '2397452317', 'store880@teamafricorp.com', NULL, '$2y$10$rIK1Yhh8wmR/0B2S8Io4yOkqSwvwJElEDUpXkBaU7ivNxVuaLtpbW', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1018, 'BLUE CORN BY ELI INC', 'BLUE CORN BY ELI INC', '2398988360', 'store881@teamafricorp.com', NULL, '$2y$10$suxXbwvNU2Blhr/YP9RIWuUFxm5032ypYckj8bvT.enZonEYX8Hj.', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1019, 'ANNIES PLACE INC                                  ', 'ANNIES PLACE INC                                  ', '2392885367', 'store882@teamafricorp.com', NULL, '$2y$10$VCZ3WI6euadaaBRuhRsAhuRiYK94oFngSI7dZVYQ/4vtZPKRN/xDS', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1020, 'MANATEAM INC                                      ', 'MANATEAM INC                                      ', '2397283366', 'store883@teamafricorp.com', NULL, '$2y$10$8eJtlIRyOpjJz1iqew6cWOuKB3s8CxsYYPqjtiCGxlLKV/4Gju6oW', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1021, 'GABRIELLE CHOCOLATES AND CONFECTIONS INC', 'GABRIELLE CHOCOLATES AND CONFECTIONS INC', '2399893576', 'store884@teamafricorp.com', NULL, '$2y$10$WZkD0P/kocxGk90PbPv58.NVnAWDC4LrU2OJ4j9LXrUqKTSFGMrsO', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1022, 'JOHNSON VERONICA', 'JOHNSON VERONICA', '2396911311', 'store885@teamafricorp.com', NULL, '$2y$10$Olh2RZ5S6ns75t0DRI9Y2OYtFHGOpPhpnzdmUuxE3uM8Bl0e92l7e', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1023, 'KINGS TACOS & BURRITOS CO.                        ', 'KINGS TACOS & BURRITOS CO.                        ', '2392706866', 'store886@teamafricorp.com', NULL, '$2y$10$aJX2d6X.UzEE.kS7IggriOoKb7N5ZzAE0r8uhKbySBkDqJZWluCI.', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1024, 'CHLOES COOKIES LLC', 'CHLOES COOKIES LLC', '2392061030', 'store887@teamafricorp.com', NULL, '$2y$10$euWUK5AwFX6JWZk.TQvDX.kWQG0QWT3kAIeZNEKBwdb3XJXC7I.yu', NULL, '2022-01-22 18:45:25', '2022-01-22 18:45:25', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1025, 'MARY CAKES LLC', 'MARY CAKES LLC', '9193535629', 'store888@teamafricorp.com', NULL, '$2y$10$3EqPgHZ3gtxyLPoAUPgl0etbZyyAFNiZVAGJd4.0zdzVVd8Bv2eG2', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1026, 'STARBUCKS CORPORATION                             ', 'STARBUCKS CORPORATION                             ', '2399362210', 'store889@teamafricorp.com', NULL, '$2y$10$L8P7zW/k8kY3JELgmzAUue3ztMsL6RyeSSFSbkTXU/j8itC5sgpdC', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1027, 'FT. MYERS DOUGHNUT OPERATIONS LLC                 ', 'FT. MYERS DOUGHNUT OPERATIONS LLC                 ', '2399319926', 'store890@teamafricorp.com', NULL, '$2y$10$dLcQcs0EIVO7sy0M674bTOOKVrLmzMEsjmECRzjdGHAc.wTQsh/zq', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1028, 'FILLIN THE FLAVOR LLC                             ', 'FILLIN THE FLAVOR LLC                             ', '2392401867', 'store891@teamafricorp.com', NULL, '$2y$10$RUmvDuS5isUMdNFvj3VQ0eiwsKTcN282OPvmbwJXmQ5qTlma0xqyq', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1029, 'BENT HOOK LLC                                     ', 'BENT HOOK LLC                                     ', '2396720282', 'store892@teamafricorp.com', NULL, '$2y$10$f1UobM9yojm2t6IIBTblUucK.47vXbYkeOlqVKPPGX0N.3C2eQbay', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1030, 'POKE BOWL CAFE INC                                ', 'POKE BOWL CAFE INC                                ', '7189028555', 'store893@teamafricorp.com', NULL, '$2y$10$D6wFM0ruyB9SgIYgNxNss.AcQsgEjGxtp5MqdGjMFVjkSZ.wVoJnC', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1031, 'CUBA COFFEE 2 INC', 'CUBA COFFEE 2 INC', '2398493460', 'store894@teamafricorp.com', NULL, '$2y$10$AeL1muBHq4auBg0qIMY/hO8z.b9tTmzh5KSqinkTGzpdMnL2f5mYa', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1032, 'CASEUS SIX MILE LLC', 'CASEUS SIX MILE LLC', '2396728444', 'store895@teamafricorp.com', NULL, '$2y$10$o1bcQWGbU6nSwyNELTsznOxcVDn5LcbGuqL28irJbHrgQVa0pCaBi', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1033, 'FENIX NAPLES LLC                                  ', 'FENIX NAPLES LLC                                  ', '2394980018', 'store896@teamafricorp.com', NULL, '$2y$10$LjFKlQO8fhmrWdgvcSYGfOLQeu1EWL4rsBrsWlHVG/AdfgvtTZIBK', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1034, 'UHMAZE BOWLS LLC', 'UHMAZE BOWLS LLC', '9546732517', 'store897@teamafricorp.com', NULL, '$2y$10$303lNEUp5xodQa/1IeGFnet008PuPg4r/x3rZf4EY6B6iT7g8x372', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1035, 'CARDIX CORP                                       ', 'CARDIX CORP                                       ', '2397721497', 'store898@teamafricorp.com', NULL, '$2y$10$iB0GUrV.BHzLga8uQfzJa.eEvbUv3wZgNz.wYXq34eOHxhjDuBH1e', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);
INSERT INTO `vendors` (`id`, `f_name`, `l_name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `bank_name`, `branch`, `holder_name`, `account_no`, `image`, `status`, `firebase_token`, `auth_token`) VALUES
(1036, 'RACETRAC PERTROLEUM INC', 'RACETRAC PERTROLEUM INC', '9547896103', 'store899@teamafricorp.com', NULL, '$2y$10$5kf4wh2RxFBM60VovuUtlugUzkd0CmfSC4rV27LDi0maoPhByEhSy', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1037, 'HAVANA CUBAN RESTAURANT INC', 'HAVANA CUBAN RESTAURANT INC', '2396737863', 'store900@teamafricorp.com', NULL, '$2y$10$T5RT5s1SsWqlMc5OlIYYPekygIPA4O5uEKvBBnWpiOOfsHy27zwKG', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1038, 'LEOPARDIS ITALIAN RESTAURANT INC', 'LEOPARDIS ITALIAN RESTAURANT INC', '2398874940', 'store901@teamafricorp.com', NULL, '$2y$10$gEy.fBaJJi66x2MCGYuIou0Q9cs82KKMxHRSsHBBb6hnDA7GIHzue', NULL, '2022-01-22 18:45:26', '2022-01-22 18:45:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1039, 'STONE BALLOON LLC', 'STONE BALLOON LLC', '2396768178', 'store902@teamafricorp.com', NULL, '$2y$10$A.nY4MiU3MseNG58ZbNGcuWqOEIQ7fn.AZVaohDBprtLS68aG2GNi', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1040, 'NOBLES EDWARD', 'NOBLES EDWARD', '2396728390', 'store903@teamafricorp.com', NULL, '$2y$10$OpTDs.gYr3/8jKzc5EfaCOYa1L4nvKPbCWy7j8PeEEkX6/vtp53EC', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1041, 'WE COAST VENTURES LLC                             ', 'WE COAST VENTURES LLC                             ', '7863677515', 'store904@teamafricorp.com', NULL, '$2y$10$TTZ/zRcTEVuE9gZ2DsP8SOAM76f0OedBVeKUQRxBKfUhduMcyMorO', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1042, 'BRAVOFLORIDA LLC                                  ', 'BRAVOFLORIDA LLC                                  ', '5742436383', 'store905@teamafricorp.com', NULL, '$2y$10$BTdLBfpklLC5olLAF5YiKOgDW3EUeKDUx5.3KY2FNRFs3bgUdfroO', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1043, 'JAMES M THOMPSON FOUR LLC                         ', 'JAMES M THOMPSON FOUR LLC                         ', '2393315080', 'store906@teamafricorp.com', NULL, '$2y$10$m3nwbyrNEBAgRvqNskApOu.WZTfq3aIOKR3c8o3CzL9zVsxKu6I/C', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1044, 'LATINOS MARKETPLACE INC                           ', 'LATINOS MARKETPLACE INC                           ', '2394371471', 'store907@teamafricorp.com', NULL, '$2y$10$DDSlM9p56.OCtAO9kDuhOOYAbJD2a4L28g61n893oMGFIwZHS6pbm', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1045, 'KONKEL CORPORATION', 'KONKEL CORPORATION', '4073994630', 'store908@teamafricorp.com', NULL, '$2y$10$B7o19bu1J8VwhJOqrxj8GufDFOr52vbjhwEs5fclFJhrj0DV4crbS', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1046, 'SIVA SHAKTI INC                                   ', 'SIVA SHAKTI INC                                   ', '2399317849', 'store909@teamafricorp.com', NULL, '$2y$10$W53XglSwzvImXF7i3tmTIOTkcSmB3AjlhWrcK9/tmcqBRD.hln69u', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1047, 'MATTYMIGS INC', 'MATTYMIGS INC', '2392036985', 'store910@teamafricorp.com', NULL, '$2y$10$nfLNsjzITf7wbLwCAMUFSONbt2hxeC49TIExNig6ZYDuhYhkbN7qS', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1048, 'REED PATRICIA AND JOAN                            ', 'REED PATRICIA AND JOAN                            ', '6072407710', 'store911@teamafricorp.com', NULL, '$2y$10$0x4WHbfeZxN5huGCsG3O2uYwBruMgzqBME7LCUQ8qzaRTIT44YPn6', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1049, 'KAVA CULTURE FMB CO.                              ', 'KAVA CULTURE FMB CO.                              ', '2395908933', 'store912@teamafricorp.com', NULL, '$2y$10$DNDm09/WXzlzuNUnkrUbyuXVr/bxFJvqCXbxJ0QYXAoKWGmVt9yRu', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1050, 'SS GREY II LLC                                    ', 'SS GREY II LLC                                    ', '2392086903', 'store913@teamafricorp.com', NULL, '$2y$10$ZlhriovpVb750opHzV5dhe.vYoqurpIgsjcpCyIc5OCn5wPY3xkXq', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1051, 'THE DRY COMPANY                                   ', 'THE DRY COMPANY                                   ', '2393135521', 'store914@teamafricorp.com', NULL, '$2y$10$6pYDa1yBdheXp0Ict1DLoepXKCyUafrlIWxbyosdZuFcklAFW/Hsq', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1052, 'HUNGARIAN KITCHEN LLC                             ', 'HUNGARIAN KITCHEN LLC                             ', '2394041646', 'store915@teamafricorp.com', NULL, '$2y$10$6m6c9NmL2MRb6Ec8MIF/M.LpW6ZlIzXfGGqv5621U5EP55Kn6iQYe', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1053, 'DYNAMITE STREET EATZ INC                          ', 'DYNAMITE STREET EATZ INC                          ', '3053046545', 'store916@teamafricorp.com', NULL, '$2y$10$eh5QqvITU7EUPDh7x2FjyuciLSgyKqTmFtpyCOUm1aY5KYNY0CRxS', NULL, '2022-01-22 18:45:27', '2022-01-22 18:45:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1054, 'NICEGUYSNEVERMIND LLC                             ', 'NICEGUYSNEVERMIND LLC                             ', '2394705169', 'store917@teamafricorp.com', NULL, '$2y$10$NWVF26xIseBI9oVRIzN37eY.bBbZT9aTikBJYTbcS/Db1ZS1WRWUC', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1055, 'WANFU BEFFET LLC', 'WANFU BEFFET LLC', '2393383666', 'store918@teamafricorp.com', NULL, '$2y$10$RSbA6ar3h4y468rao4mu/.vI6miBw6suPCcUmjw9nYkCtpfHl.dZ.', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1056, 'LU LUS CATERING LLC', 'LU LUS CATERING LLC', '2397037820', 'store919@teamafricorp.com', NULL, '$2y$10$d5U.TTubmAY8d8bXCncF2uehbFCvQvRu3x9Oc3cmO/VfI17UMdb4m', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1057, 'THE HUNGRY CHEF RESTAURANT GROUP LLC              ', 'THE HUNGRY CHEF RESTAURANT GROUP LLC              ', '9546391650', 'store920@teamafricorp.com', NULL, '$2y$10$HTLXVuUkbQToebmDqA20m.sbLBZLPZ7ZC48AMjnvG69/r.jArQd/6', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1058, 'SYLWIAS ICE CREAM LLC', 'SYLWIAS ICE CREAM LLC', '2398882225', 'store921@teamafricorp.com', NULL, '$2y$10$8Z.LbMijhCxKLYQF99q/Fuwir9YopUwYuar4V8Dji4Zwt5kvKCxcO', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1059, 'M ASSETS BONITA LLC', 'M ASSETS BONITA LLC', '2179354915', 'store922@teamafricorp.com', NULL, '$2y$10$JLKee0wFnJkn4tPDdO/RFOks6dRiSbHngSWmQm3r7f52RhsTsz.o2', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1060, 'JIMMY PS CHARRED NORTH LLC', 'JIMMY PS CHARRED NORTH LLC', '2392217428', 'store923@teamafricorp.com', NULL, '$2y$10$7ZbrwzlkviWb/VYlN4LHYeal79E9JP6CcplSlcGtz4NfNa1UTZj92', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1061, 'EIGHT FOOT BREWING LLC                            ', 'EIGHT FOOT BREWING LLC                            ', '2399842655', 'store924@teamafricorp.com', NULL, '$2y$10$kP0XgRaK.kWDoTlqLRe77uFZA1ORANDo8RmNevpXGar5Lmiy5A9jC', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1062, 'SUMMERTIME CONCESSIONS LLC                        ', 'SUMMERTIME CONCESSIONS LLC                        ', '2397684210', 'store925@teamafricorp.com', NULL, '$2y$10$tlGej5tO7bPI7Xyi279Hguts9dQbAOXPNJ8DamYVIpl9K7tw.gPSi', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1063, 'SIX MEATBALLS INC                                 ', 'SIX MEATBALLS INC                                 ', '2399909901', 'store926@teamafricorp.com', NULL, '$2y$10$MfyPuaxV1MlqaOoHHSOe1u0j/SdvKJKs8CyG93lBwID4cj0Me/s4i', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1064, 'LA ISLA DEL SABOR RESTAURANT LLC                  ', 'LA ISLA DEL SABOR RESTAURANT LLC                  ', '2392457838', 'store927@teamafricorp.com', NULL, '$2y$10$KJWyu.Rf9U5TkksEjT6un.eBRnSbkRM9WN5QQw5xW50b0cPXbVgM6', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1065, 'LMFLORIDA2 LLC                                    ', 'LMFLORIDA2 LLC                                    ', '2397891155', 'store928@teamafricorp.com', NULL, '$2y$10$Z5CQVm1ycH21UZu.8MnzIukU673bUdhM0VT03ho24qVAGb7XXs7cS', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1066, 'CHE TITOS STEAK HOUSE INC', 'CHE TITOS STEAK HOUSE INC', '2392444520', 'store929@teamafricorp.com', NULL, '$2y$10$.B9ZzXqPz3TyYERNuq9CkOt27jvj/OReDwRNBle1gzftL4Qsb0t9m', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1067, 'SKILLETS HOLDINGS LLC', 'SKILLETS HOLDINGS LLC', '2393195583', 'store930@teamafricorp.com', NULL, '$2y$10$JY0eMpMM8CQyr.d4UWz7Tu8YS8XNxvWM.ibj8zOVNjwAeHWkfa1IS', NULL, '2022-01-22 18:45:28', '2022-01-22 18:45:28', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1068, 'SKILLETS HOLDINGS LLC', 'SKILLETS HOLDINGS LLC', '2393195583', 'store931@teamafricorp.com', NULL, '$2y$10$pYOePznghkNMH/6A2s6KPu0AO5g6vgXRQXrjkpV2ETlft5w535q0S', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1069, 'PARAISO TROPICAL LLC                              ', 'PARAISO TROPICAL LLC                              ', '2393579252', 'store932@teamafricorp.com', NULL, '$2y$10$4Ii/9aw1z19JuQJmeYm9jONkdRXOhNlN9BwAGrPFwp6T/ZxCjiBjG', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1070, 'PANERA LLC                                        ', 'PANERA LLC                                        ', '2398006223', 'store933@teamafricorp.com', NULL, '$2y$10$6mdY8SFCU/uNhSSqd7/syuu5MlWMQ9rh07FC1PHK.eYf1dZaTs38u', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1071, 'P THOMAS ENTERPRISES LLC                          ', 'P THOMAS ENTERPRISES LLC                          ', '4026301907', 'store934@teamafricorp.com', NULL, '$2y$10$9A/S.6MQVaryPXl6NPTq4.gBGMHgBGoz9sYiPeW7htUQ8T9EHKMHW', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1072, 'OUTREACH COMMUNITY TREATS LLC                     ', 'OUTREACH COMMUNITY TREATS LLC                     ', '8884242779', 'store935@teamafricorp.com', NULL, '$2y$10$Kn69HReRDUphz6TfqK3VMugFF0p4RX4QXwnD6OX/f1Ls310j7MlfG', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1073, 'CHEFS CORNER EATERY LLC                           ', 'CHEFS CORNER EATERY LLC                           ', '9417402928', 'store936@teamafricorp.com', NULL, '$2y$10$bxqeKACdfWFoMDkF.dZA2.tfiLxfxqGY54JnfrzpCdtq0w.J4Xcou', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1074, 'STARBUCKS COFFEE COMPANY', 'STARBUCKS COFFEE COMPANY', '2063189762', 'store937@teamafricorp.com', NULL, '$2y$10$BI/Bb4f2HotEjRm4denyOOQMpdB0nG1LIzHlj5glSGuNrHk6b0kyC', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1075, 'TEXAS TONYS OF CAPE CORAL LLC', 'TEXAS TONYS OF CAPE CORAL LLC', '2393477033', 'store938@teamafricorp.com', NULL, '$2y$10$KaViUqCJVfTFXlprFMdyTewrZQ5lNeXkXT5kPxu7xo9IBRKSEXnqK', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1076, '7 ELEVEN INC', '7 ELEVEN INC', '4073994630', 'store939@teamafricorp.com', NULL, '$2y$10$2Ji7G5K6cUeTey8UDy5CquyqYCqJjd6eLyicGyPjyqGGZ3.B7DXWy', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1077, 'DAVE & BUSTERS OF FLORIDA LP                      ', 'DAVE & BUSTERS OF FLORIDA LP                      ', '2149042257', 'store940@teamafricorp.com', NULL, '$2y$10$HZQsoANXee1iGcD3dFWgBOS9xOlPkJCsuqAVdVvfLc4ivTOwFI4oa', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1078, 'P THOMAS ENTERPRISES LLC                          ', 'P THOMAS ENTERPRISES LLC                          ', '4026301907', 'store941@teamafricorp.com', NULL, '$2y$10$FVfxfIhag/MPIdM1QH6JyufzmlKVvlPaX7R/fy64VCQQweidUaaaa', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1079, 'P THOMAS ENTERPRISES LLC                          ', 'P THOMAS ENTERPRISES LLC                          ', '4026301907', 'store942@teamafricorp.com', NULL, '$2y$10$2tSaeQ/wzOpOvU2cxEc6x.dWE2dfCFTJ4Ly0/jEi8HAXKuT4NK26G', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1080, 'CARIBBEAN UNION RESTAURANT AND BAKERY LLC', 'CARIBBEAN UNION RESTAURANT AND BAKERY LLC', '2396747154', 'store943@teamafricorp.com', NULL, '$2y$10$NwKhnJb6ChfxXMrz6Z/V3Of0zuB8ywiQ5svLxenun5GjPRx.inuae', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1081, 'DONA JUANA GUATEMALAN RESTAURANT INC', 'DONA JUANA GUATEMALAN RESTAURANT INC', '2397918910', 'store944@teamafricorp.com', NULL, '$2y$10$44RJOltlZ1lxU3xxqIIhlOmP55wnlmvsQ2qKpcVu2I3JsO4ZARbFC', NULL, '2022-01-22 18:45:29', '2022-01-22 18:45:29', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1082, 'TAQUERIA LAS AMERICAS INC', 'TAQUERIA LAS AMERICAS INC', '2398780760', 'store945@teamafricorp.com', NULL, '$2y$10$p7/oeIiaDudnh6htx/CJE.GviDu3eu22qIWuKiQat831v.aHEyQU.', NULL, '2022-01-22 18:45:30', '2022-01-22 18:45:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1083, 'COASTAL CITY PIZZA LLC                            ', 'COASTAL CITY PIZZA LLC                            ', '4074762208', 'store946@teamafricorp.com', NULL, '$2y$10$iiDNluA7S63Q.UCiVOMUzeLb/4vPd/Ln62I3XUQtZhGdBe/1hb1ua', NULL, '2022-01-22 18:45:30', '2022-01-22 18:45:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1084, 'THE BEAR DOZEN LLC                                ', 'THE BEAR DOZEN LLC                                ', '3525091295', 'store947@teamafricorp.com', NULL, '$2y$10$d9DA.P0M6cqAFY7t/3aHU.cw3qJWvUPrhHEAg5XG0iwqmHOn8ODO6', NULL, '2022-01-22 18:45:30', '2022-01-22 18:45:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1085, 'ISLAND JUICES LLC', 'ISLAND JUICES LLC', '2393689441', 'store948@teamafricorp.com', NULL, '$2y$10$b2G.DmUFq/RCDL9MPyDEAePNCjEH7tKYgqQQ3silGm4EhQ8LpqMMi', NULL, '2022-01-22 18:45:30', '2022-01-22 18:45:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1086, 'LAS GORDITAS MEXICAN TREATS LLC', 'LAS GORDITAS MEXICAN TREATS LLC', '8635998717', 'store949@teamafricorp.com', NULL, '$2y$10$oG3U2RgJNoj.DR9KQAtp3.ch/7ZpevSDe78se1UlkYTsBRhp3.5Ne', NULL, '2022-01-22 18:45:30', '2022-01-22 18:45:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1087, 'CJS CES CAPE VENTURES LLC                         ', 'CJS CES CAPE VENTURES LLC                         ', '2395744386', 'store950@teamafricorp.com', NULL, '$2y$10$C2RR4exG3CqUtXfSF.2nsupNfn2mr0l3n7QCxMBZR2oHgHopzHDzO', NULL, '2022-01-22 18:45:30', '2022-01-22 18:45:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1088, 'CHICAGO BOYS 2 LLC', 'CHICAGO BOYS 2 LLC', '7082586204', 'store951@teamafricorp.com', NULL, '$2y$10$TfiaYVg4PELdmlXi09ZnF.cuMuT71AeBg/hyp9oujyxxdXFkeYUNe', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1089, 'P THOMAS ENTERPRISES LLC', 'P THOMAS ENTERPRISES LLC', '4026301907', 'store952@teamafricorp.com', NULL, '$2y$10$etPwjp7gRDxG6Sad889x1OCSkknxkwk1Jc44msjKaGnJomOFDMww6', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1090, 'BUBBLE TEA TIME II LLC', 'BUBBLE TEA TIME II LLC', '2395418502', 'store953@teamafricorp.com', NULL, '$2y$10$cfE0Osj6lG0NXQG16Nl2weDxCakThT7pd.QHJS7M8jeqrSYT6ZrA2', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1091, 'PRD SAI LLC', 'PRD SAI LLC', '9416286295', 'store954@teamafricorp.com', NULL, '$2y$10$sX9VLkyR1JfX9roTQIf5qu90xDNJyZQKJPUeLQ7d2.lDpTMi2alAS', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1092, 'ROOTS TO FRUITS ORGANIC FARM FOOD TRUCK LLC', 'ROOTS TO FRUITS ORGANIC FARM FOOD TRUCK LLC', '2399804341', 'store955@teamafricorp.com', NULL, '$2y$10$wJgba2geO69XipMx/5ViJu.qQxeMTcYvsdZsytyeYo2hStt0WMA2a', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1093, 'OUTLET VENTURES LLC', 'OUTLET VENTURES LLC', '2399708797', 'store956@teamafricorp.com', NULL, '$2y$10$HbTXCP2EltEMnfSM48zpt.3ZAlze/1dyioCGJLyT9NXzUGvX6RkoS', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1094, 'JOE DADDYS PIZZA LLC', 'JOE DADDYS PIZZA LLC', '2395736600', 'store957@teamafricorp.com', NULL, '$2y$10$DOV93RbBWtYkARAKJgT50.mMG8PM8G/.4acf4yrF4WTIOyANwa6dC', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1095, 'MOKEH GROUP LLC                                   ', 'MOKEH GROUP LLC                                   ', '2393082339', 'store958@teamafricorp.com', NULL, '$2y$10$3gCiAIe6hk5NUNVkdlPWWuzXoVg0lLxS0UgZeFvps22loChvV9SOe', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1096, 'CEVICHE POINT INC', 'CEVICHE POINT INC', '2396726191', 'store959@teamafricorp.com', NULL, '$2y$10$g7lQgk0iPhJdS7XsPjMvheR3Sw.LW7.rKIrKV0dv79k6QsL.3tsXS', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1097, 'ADIL ALI ENTERPRISES LLC                          ', 'ADIL ALI ENTERPRISES LLC                          ', '4073994630', 'store960@teamafricorp.com', NULL, '$2y$10$UReIq3Y2pij0.ihiD3eb8eejum3J7Hpz7j/2iZAse2mXzRZdQGr6u', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1098, 'LA PARILLA BORICUA LLC', 'LA PARILLA BORICUA LLC', '2397718678', 'store961@teamafricorp.com', NULL, '$2y$10$TpSxzgyhsy21ftvweTDfYOOXDmzCK1aFFOGcEd4YH.E6bj0xJgWAa', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1099, 'CHEF CASEY LLC', 'CHEF CASEY LLC', '2395662371', 'store962@teamafricorp.com', NULL, '$2y$10$Doq0j3QQXQDNF8x/GJd8tu7ZLhljKXdyWSpgPhySeOG4axGnEtjV2', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1100, 'SWEET FLORET CAKERY LLC', 'SWEET FLORET CAKERY LLC', '2396771985', 'store963@teamafricorp.com', NULL, '$2y$10$lFtApM5O9IidBJPBjnNZM.5C/gO2VOx9rQjPZROtzuB2h9pwS39TK', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1101, 'AREKIE LLC                                        ', 'AREKIE LLC                                        ', '7325704396', 'store964@teamafricorp.com', NULL, '$2y$10$MOW5s710eOOSNql7OP3cAugMJpOsAYtepqKpWVxu1GE28Y89H0Nva', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1102, 'H ANGER MANAGEMENT LLC                            ', 'H ANGER MANAGEMENT LLC                            ', '2314200561', 'store965@teamafricorp.com', NULL, '$2y$10$PmnmFHR4KvOppG0zBNljNeCxucIe9pLhIZDBr77/OCr/FyauufC2y', NULL, '2022-01-22 18:45:31', '2022-01-22 18:45:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1103, 'MAYALAYNA LLC', 'MAYALAYNA LLC', '3058792842', 'store966@teamafricorp.com', NULL, '$2y$10$x6FOOYU/WRhjjpMflEFKAuY/M1FmrQOo5ZbniTO0B/mhFfqAG/2u2', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1104, '7 ELEVEN INC & ZAIN ALI ENTERPRISES LLC', '7 ELEVEN INC & ZAIN ALI ENTERPRISES LLC', '4073994630', 'store967@teamafricorp.com', NULL, '$2y$10$PW4pzDvTd/6TmM6uGq3tpuY3e7A10lKdvwsHv84XJl1HJoZCTVttK', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1105, 'THINK BIG FISH LLC', 'THINK BIG FISH LLC', '2394582447', 'store968@teamafricorp.com', NULL, '$2y$10$351YtiQ8/Y7LWVbEU.tGeePIHCg6OtongmCRYM/eGoieqH/4Vs8zq', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1106, 'EL MESON LATIN CUISINE INC', 'EL MESON LATIN CUISINE INC', '2394717881', 'store969@teamafricorp.com', NULL, '$2y$10$5G6L7VEqirtUMJ5LBVBgBei9hbyAcAcyUwmChRUlTgUQkKVxuoAxG', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1107, 'HAPPY SUN ICE CREAM INC                           ', 'HAPPY SUN ICE CREAM INC                           ', '2395994282', 'store970@teamafricorp.com', NULL, '$2y$10$r.IAuWqcdNmdrv82zzioS.wrP9wXzKRPHGKxczFPQTOJh5u55fQxm', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1108, 'CLEVENGER NANCY M                                 ', 'CLEVENGER NANCY M                                 ', '6108882544', 'store971@teamafricorp.com', NULL, '$2y$10$QfnQcPxs1WuCtp3fBtp/TeFnj0DHYmYQEoeoEMlNBKXC5Yaoa0cq6', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1109, 'LIRICH INC.                                       ', 'LIRICH INC.                                       ', '2395992616', 'store972@teamafricorp.com', NULL, '$2y$10$mbP0/PO1ftBVCjcBWNcHoOre50fg3RC8wvhS5G.f1/kYsnRd4TUbm', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1110, 'THE PLACE MASTER ASSOCIATION INC', 'THE PLACE MASTER ASSOCIATION INC', '2395611444', 'store973@teamafricorp.com', NULL, '$2y$10$In2pYDzzYjqhBCQU7Pr3cOe22RI3BgReyzRFlbzM6RuLc5y8suZPS', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1111, 'LOS REYES DEL TAXO 1 LLC', 'LOS REYES DEL TAXO 1 LLC', '2392291357', 'store974@teamafricorp.com', NULL, '$2y$10$QT0SI.wZTk3amlOyadLsl.Gz7WlsJnGzJfXtKvnI2xZVtv/H6xZn.', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1112, 'FANTEL BARBARA', 'FANTEL BARBARA', '7728340742', 'store975@teamafricorp.com', NULL, '$2y$10$sQapcKHRlQolRkWJKJWg2OY1AGSC7WYtlv5Ch/UIyr44UqfNzI8gu', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1113, '2SSS LLC', '2SSS LLC', '2399489466', 'store976@teamafricorp.com', NULL, '$2y$10$.ksMnkOn5VcXsADJgzEJB.GCZnDHHQNk2RM5Ip77bZ7I5i/WyHu8m', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1114, 'MAK INVESTMENTS LLC                               ', 'MAK INVESTMENTS LLC                               ', '2399859632', 'store977@teamafricorp.com', NULL, '$2y$10$Sc7fxvfifYMUcZ3ds4fWgOtNGMMLiiEtDQ8iStBzjg2d4YaIcqZa.', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1115, 'TLAYUDAS OAXACA INC', 'TLAYUDAS OAXACA INC', '2398399272', 'store978@teamafricorp.com', NULL, '$2y$10$qEiNvSWKBvH4CU3jYFWie.UfJPmIy.A3vY.IeoKDG8ZdlDHU4Upv2', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1116, 'WONDERLAND COOKIE DOUGH OF SWFL LLC               ', 'WONDERLAND COOKIE DOUGH OF SWFL LLC               ', '2398501876', 'store979@teamafricorp.com', NULL, '$2y$10$n7BM6Z1aiASeBmsuwDFySusv6K2CSJIY5qhLY5GGlDxVd.avxFpTW', NULL, '2022-01-22 18:45:32', '2022-01-22 18:45:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1117, 'WMD DASH INC                                      ', 'WMD DASH INC                                      ', '2395790807', 'store980@teamafricorp.com', NULL, '$2y$10$vN0iAQFCvmKSFwci7y7RLu8neCv.OVK/3dkMGy/g1WbdY9P/nVIUC', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1118, 'EAT BOLD LLC                                      ', 'EAT BOLD LLC                                      ', '6145370806', 'store981@teamafricorp.com', NULL, '$2y$10$8iTzhudFMcIIXF.RtbFiLOGQ.UxY7AsnO3K32WbiMVVRCDF0SW7Wy', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1119, 'CONNOR DINER INC', 'CONNOR DINER INC', '8657772677', 'store982@teamafricorp.com', NULL, '$2y$10$mFUqnaNBMByv03wc1g2oQO9A/.xIITWAwiHkb9GkWCsvXMs5FPo5u', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1120, 'PINCHOS KABOBS RESTAURANT INC', 'PINCHOS KABOBS RESTAURANT INC', '2396893875', 'store983@teamafricorp.com', NULL, '$2y$10$7hiZ4rYW5QdLuO9CNWzRAedJK.AetabPM7y0GnafXBzlMDWjwPhES', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1121, 'COLONIAL DONUTS LLC                               ', 'COLONIAL DONUTS LLC                               ', '3057663723', 'store984@teamafricorp.com', NULL, '$2y$10$aNb2UDiVeWAkNX9xi5PXNucEXQElviMf36s2HvguYJKowKTq8zhuu', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1122, 'DOWNTOWN COFFEE AND WINE COMPANY LLC              ', 'DOWNTOWN COFFEE AND WINE COMPANY LLC              ', '2396417069', 'store985@teamafricorp.com', NULL, '$2y$10$G4OdUyFMzriH4k84J3Aec.kw54yaCtbXtL9GRDudRf.wzTmG1ev8q', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1123, 'SSC 355718 LLC                                    ', 'SSC 355718 LLC                                    ', '8553366887', 'store986@teamafricorp.com', NULL, '$2y$10$lP/9GHrWw0nKoFbvwTzgfep/j/sJJuRTu79hUqPXHTKs6De7qeILm', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1124, 'THE HAVANAS GUSTO LLC', 'THE HAVANAS GUSTO LLC', '2393210115', 'store987@teamafricorp.com', NULL, '$2y$10$3XES9qBTKnx4fJ3Ti12Ey.r5aX7aWJ8hlXPV1cA5511BZfJmlTiRC', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1125, 'NUESTRO SABOR LATINO CORP', 'NUESTRO SABOR LATINO CORP', '2395491040', 'store988@teamafricorp.com', NULL, '$2y$10$N7Oqt99llFbXob8YOJMBSew3wDm5fxlQwKuMBD9H5iSAEkvC4rhyy', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1126, 'MR & MRS CRAB CAPE CORAL INC                      ', 'MR & MRS CRAB CAPE CORAL INC                      ', '2399842867', 'store989@teamafricorp.com', NULL, '$2y$10$wCRyQcRCO5MbH3zFKC0FGO4VRhEX4DHhJpvKEJdiAEtkQjGgJmEgK', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1127, 'MAKING DOUGH INC', 'MAKING DOUGH INC', '2399317991', 'store990@teamafricorp.com', NULL, '$2y$10$jslYrkVLE/hmhso18CfeOu5NJdkL6Wlt0hQLJfa/49gGmJyu1i9zi', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1128, 'PEDRORUPERTO MARIA', 'PEDRORUPERTO MARIA', '2398489817', 'store991@teamafricorp.com', NULL, '$2y$10$KeDTBMq5oBy/iElKESkx8uHRSHcB8iSBuH6fjAYy7oOKBZxpz1lea', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1129, '199LLC                                            ', '199LLC                                            ', '2393622363', 'store992@teamafricorp.com', NULL, '$2y$10$NDzNFbPmZEfsEq7YhW7LGeX4Cf3Pp/4ZxHTNkw1r.kqi.qS5cFTm2', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1130, 'TACOS Y CEVICHES INC', 'TACOS Y CEVICHES INC', '2398873092', 'store993@teamafricorp.com', NULL, '$2y$10$q2y1h6q.VcgbBhW44n/hxudkdDmmg5KHqLjMq0G0tr/tUYHa//gMa', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1131, 'LOPEZ GRISELLE', 'LOPEZ GRISELLE', '2392004766', 'store994@teamafricorp.com', NULL, '$2y$10$PG9Dpp4oshVTM.Ci8LAQRupKwkbmdaUDmGlv0XWIupyx7rFaVdY6u', NULL, '2022-01-22 18:45:33', '2022-01-22 18:45:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1132, 'SCOOPS AND TREATS LLC', 'SCOOPS AND TREATS LLC', '2395602410', 'store995@teamafricorp.com', NULL, '$2y$10$Fd5X0lXNGzv2cqdjd5Q4i.ocyV8p2N9h8oMGTb1m.mX8eWvtw/vFS', NULL, '2022-01-22 18:45:34', '2022-01-22 18:45:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1133, 'ISHA ALI ENTERPRISES', 'ISHA ALI ENTERPRISES', '2398985890', 'store996@teamafricorp.com', NULL, '$2y$10$ce8fQopRRZWns189hJ1LBOMTCt5FyomX7XGMlTA/pJRRPoPnfIYOC', NULL, '2022-01-22 18:45:34', '2022-01-22 18:45:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1134, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '8139106800', 'store997@teamafricorp.com', NULL, '$2y$10$huOFyB/okfBCqlJgLGO1o.1ysEGDSW.josSJ3xEnz2xkWjt030Z6G', NULL, '2022-01-22 18:45:34', '2022-01-22 18:45:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1135, 'EL PARAISO FRUTAL LLC', 'EL PARAISO FRUTAL LLC', '8636126235', 'store998@teamafricorp.com', NULL, '$2y$10$mW18rza7x/xzsn2QIFnNLezaYsSdYXbswXd8hv8zKEe9fQ77yNh.C', NULL, '2022-01-22 18:46:30', '2022-01-22 18:46:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1136, 'ICESPOT LLC                                      ', 'ICESPOT LLC                                      ', '2394370194', 'store999@teamafricorp.com', NULL, '$2y$10$6eNfadVttbQDkt/.42fMVO9ti9EA14cgtDmfHC54nashmUKOmGwte', NULL, '2022-01-22 18:46:30', '2022-01-22 18:46:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1137, 'NEVERMIND US LLC', 'NEVERMIND US LLC', '2394705169', 'store1000@teamafricorp.com', NULL, '$2y$10$dtXFfh2ZrynFeY9tf1OS8uUxTXrvcHYHPYRsUNulyQfrqUb7bB9ay', NULL, '2022-01-22 18:46:30', '2022-01-22 18:46:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1138, 'KLEIN HOLLAND LLC                                 ', 'KLEIN HOLLAND LLC                                 ', '2397772157', 'store1001@teamafricorp.com', NULL, '$2y$10$3NQHiLUel7u4DaFvSwjNn.EwOhCSk//O58UjaCj6Epc9p6zooXkaS', NULL, '2022-01-22 18:46:30', '2022-01-22 18:46:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1139, 'KEKES BREAKFAST CAFE INC.                         ', 'KEKES BREAKFAST CAFE INC.                         ', '2392252249', 'store1002@teamafricorp.com', NULL, '$2y$10$cp3vg60RCxuLHYcPrcu.uu6Tm9wwdO5qbizQd4eAWnWsPp3tW5eGq', NULL, '2022-01-22 18:46:30', '2022-01-22 18:46:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1140, 'STARBUCKS COFFEE COMPANY                          ', 'STARBUCKS COFFEE COMPANY                          ', '2392071618', 'store1003@teamafricorp.com', NULL, '$2y$10$g6I5azWlBLuCC6S8R1yHIu5i7j97M1KOya5PdYi.1BjykK1loT1KK', NULL, '2022-01-22 18:46:30', '2022-01-22 18:46:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1141, 'NICKEL CITY RED HOTS LLC', 'NICKEL CITY RED HOTS LLC', '2398965175', 'store1004@teamafricorp.com', NULL, '$2y$10$GsxeWOsh1b0R6NlmNmRPjuc5oio3jK52ErEWt1/v7ak9lnj2jOfoO', NULL, '2022-01-22 18:46:30', '2022-01-22 18:46:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1142, 'WICKED GOOD DELI LLC                              ', 'WICKED GOOD DELI LLC                              ', '2398874652', 'store1005@teamafricorp.com', NULL, '$2y$10$PVqs7cn41q2LnSe6hsjeqe0kCHudoUdeKux5zHh6mVqrA5V577Apa', NULL, '2022-01-22 18:46:30', '2022-01-22 18:46:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1143, 'TEXAS ROADHOUSE HOLDING LLC', 'TEXAS ROADHOUSE HOLDING LLC', '2392562290', 'store1006@teamafricorp.com', NULL, '$2y$10$BcGfalzcswVEsVnRobr/jus8LF0WR.RuY.CS9D9.C3bZyF80CUKtK', NULL, '2022-01-22 18:46:30', '2022-01-22 18:46:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1144, 'BRITTS NUT HUT LLC', 'BRITTS NUT HUT LLC', '2397383212', 'store1007@teamafricorp.com', NULL, '$2y$10$0aZ5egdfSrOfY16HnPZsD.T8EVGtd83qn0PF6y4LpHAG2AJYKAg5a', NULL, '2022-01-22 18:46:30', '2022-01-22 18:46:30', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1145, 'MASALA MANTRA THE INDIAN BISTRO LLC', 'MASALA MANTRA THE INDIAN BISTRO LLC', '2395406300', 'store1008@teamafricorp.com', NULL, '$2y$10$9J8JQEdlrv4xTPa4UGgyLOFkB8GNaSVEv2OGcGyiEeRukJoZahg9y', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1146, 'PANOLIO FOODS LLC', 'PANOLIO FOODS LLC', '2394710516', 'store1009@teamafricorp.com', NULL, '$2y$10$EMkTZFhIkIno4e4bdJlXTuQnjzqkSOGvzIrzYDfJ5.Bysc9seyuCe', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1147, 'WOODYS WATERSIDE LLC', 'WOODYS WATERSIDE LLC', '2392829166', 'store1010@teamafricorp.com', NULL, '$2y$10$9tMZcWqm4rLc774IIno9sO7FO/yoUL1wk6DZfLPc4EfbIwrhdkAau', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1148, 'DELEONE CYNTHIA', 'DELEONE CYNTHIA', '2034008787', 'store1011@teamafricorp.com', NULL, '$2y$10$YEDkAO1JSR4rHIanrFrVnukQrUAQOVt8/.Ch7CGqjS.JAorYlsmXi', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1149, 'MOLON LABE EMPIRE LLC', 'MOLON LABE EMPIRE LLC', '9173719455', 'store1012@teamafricorp.com', NULL, '$2y$10$A6rcwuVVGZF8Ng9A6G0ex.LICWBP/TUJwz5quBUdONkJxhooEiK9y', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1150, 'BUEN PROVECHO LLC', 'BUEN PROVECHO LLC', '2392056089', 'store1013@teamafricorp.com', NULL, '$2y$10$Nwfu2FrIMHQ0spQuw22E1.bh.2iEulIvH4vnR27tSnvSi1QEFyTyC', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1151, 'LES EAT TOO LLC', 'LES EAT TOO LLC', '2393136163', 'store1014@teamafricorp.com', NULL, '$2y$10$eMiimNJ/FUnMzlsTRDXoXOGDrxz3Rx0dpPof0vao3S4QKzHH7hZWe', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1152, 'TROPICAL TIKI BAR & GRILL INC                     ', 'TROPICAL TIKI BAR & GRILL INC                     ', '2395992942', 'store1015@teamafricorp.com', NULL, '$2y$10$ayYmnXQeezL4s6utZinkMea1xnq/50kz2P8wQ3/cKYvRXHuQpK2NG', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1153, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '8139106800', 'store1016@teamafricorp.com', NULL, '$2y$10$85E9cfH9h.1ZqJpo0L06oOTofDqfYOsthKFZkgKLxa6U3awCUyKdq', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1154, 'TRAN    AMY    N', 'TRAN    AMY    N', '2393089999', 'store1017@teamafricorp.com', NULL, '$2y$10$E8chX8We1vesvI8VziFcgeBh7x5l7FbagnNb9F.bVPiGzKQlFnoqC', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1155, 'TEN 123 IN                                        ', 'TEN 123 IN                                        ', '2394154262', 'store1018@teamafricorp.com', NULL, '$2y$10$pkIH83LrQrctzgPEBVdY9.0VhtQv7Ftu5I50OOIQT5wGZevuq18hW', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1156, 'BOTANICA LA FUENTE INC', 'BOTANICA LA FUENTE INC', '7869854104', 'store1019@teamafricorp.com', NULL, '$2y$10$Ro1bQheWr./TkXbGKC1wyeknWVDigcH1eTaG.pYKx9e9j78u4akG.', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1157, 'LEE TONI M', 'LEE TONI M', '2398983437', 'store1020@teamafricorp.com', NULL, '$2y$10$23WiW0uNsUUu6uG05dio/.d3hTvmJUlPJHYD.Me5yhvITrSzLLLGa', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1158, 'FREDERIC CALI UV LLC                              ', 'FREDERIC CALI UV LLC                              ', '2398222728', 'store1021@teamafricorp.com', NULL, '$2y$10$Ez4rBiBfOL1XbFn7nnqVZeZ4/OduCwICKkKr0LMmiXgdzkDKESRJq', NULL, '2022-01-22 18:46:31', '2022-01-22 18:46:31', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1159, 'PRIME HOUSE LLC', 'PRIME HOUSE LLC', '2392854459', 'store1022@teamafricorp.com', NULL, '$2y$10$/0Y/2baQ2CTy.TMa1q1PZeF.mRUvGI4SddAHry49pPKRVxNwAuYd.', NULL, '2022-01-22 18:46:32', '2022-01-22 18:46:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1160, 'MRHFT INC', 'MRHFT INC', '2397918036', 'store1023@teamafricorp.com', NULL, '$2y$10$6XCD6hJw89iNGg506mwGROrry4A2dYPNwSVxZd3vLoxddYsdcop/6', NULL, '2022-01-22 18:46:32', '2022-01-22 18:46:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1161, 'ETTER LAURA A                                     ', 'ETTER LAURA A                                     ', '4434164688', 'store1024@teamafricorp.com', NULL, '$2y$10$0QzjdcMafP2JClZaZlbwe.MYatUeJU9TxpU5pRkT4H425umn7mKJu', NULL, '2022-01-22 18:46:32', '2022-01-22 18:46:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1162, 'TRUCKIN DELICIOUS LLC', 'TRUCKIN DELICIOUS LLC', '2392037982', 'store1025@teamafricorp.com', NULL, '$2y$10$E8mSO5OeR81aJwTd71a87Oqne9njecb37mX3fVb7ofROvnSVUIcPK', NULL, '2022-01-22 18:46:32', '2022-01-22 18:46:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1163, '3442 MOLLY LLC', '3442 MOLLY LLC', '2392573111', 'store1026@teamafricorp.com', NULL, '$2y$10$FVV7YPbyKn3xGB2Hr/ECJuxFomBNMHIQ1EGiM2WyBWC.azFaKXGKK', NULL, '2022-01-22 18:46:32', '2022-01-22 18:46:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1164, 'CHURRICO FACTORY LLC                              ', 'CHURRICO FACTORY LLC                              ', '2399897616', 'store1027@teamafricorp.com', NULL, '$2y$10$v21arTgYYj2febtT8M2yNegStr9.JhICRAdoqehvo6SreDLlvjwFC', NULL, '2022-01-22 18:46:32', '2022-01-22 18:46:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1165, 'BOLD AND TASTY LLC                                ', 'BOLD AND TASTY LLC                                ', '8633937761', 'store1028@teamafricorp.com', NULL, '$2y$10$/kXM1MHw/ajqFYz4Exy2jukr2suiWypdiHA8B.A6FLfMgJA1rbv0i', NULL, '2022-01-22 18:46:32', '2022-01-22 18:46:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1166, 'VIET YUM LLC                                      ', 'VIET YUM LLC                                      ', '2398397156', 'store1029@teamafricorp.com', NULL, '$2y$10$FYWz4xS0HiEJKCUzoUZyKudA/DmZQfX9bwkIaWxMToucwhW9L4cxy', NULL, '2022-01-22 18:46:32', '2022-01-22 18:46:32', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1167, 'BRAHM ENTERPRIZE INC', 'BRAHM ENTERPRIZE INC', '2393690200', 'store1030@teamafricorp.com', NULL, '$2y$10$I6UKyDK29Q7jSDbG7KgCd.yg8vZfZ/5FEoWBRh56gWalXky8BpUZG', NULL, '2022-01-22 18:46:33', '2022-01-22 18:46:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1168, 'ROMERO ALAN ISAIAH', 'ROMERO ALAN ISAIAH', '2392738063', 'store1031@teamafricorp.com', NULL, '$2y$10$G3mEUVxCzGTguLU8IbLGoePeb9ko3aL0pgX54GpA7BoJZglmxRYMa', NULL, '2022-01-22 18:46:33', '2022-01-22 18:46:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1169, 'MELENDEZ VAZQUEZ MIGUEL', 'MELENDEZ VAZQUEZ MIGUEL', '2394913810', 'store1032@teamafricorp.com', NULL, '$2y$10$M7G3hFVcaypUCefwuWBdHeUg.WMOYKc6VFRWlp/0qCMqRgaaU91Ya', NULL, '2022-01-22 18:46:33', '2022-01-22 18:46:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1170, 'BETTERSTREAMING INC', 'BETTERSTREAMING INC', '2392370707', 'store1033@teamafricorp.com', NULL, '$2y$10$VC2kGN0Rxy8OZ91ouWaw8uhwuEFBD/cZs1UGgIb1llGUF7N2Eyf96', NULL, '2022-01-22 18:46:33', '2022-01-22 18:46:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1171, 'JAVA LABS LLC                                     ', 'JAVA LABS LLC                                     ', '9542327539', 'store1034@teamafricorp.com', NULL, '$2y$10$DeJfE1CKIeUyroaLMB19Lukoy/c9BBcSUZc.JDeijYEXDEmPfCH7m', NULL, '2022-01-22 18:46:33', '2022-01-22 18:46:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1172, 'SCHWABROW  PERI A', 'SCHWABROW  PERI A', '5183326623', 'store1035@teamafricorp.com', NULL, '$2y$10$e8A33q2ufheKLXyfHbwRwu50xM4kEK/.eZcCXCfuuW.AgNC29oFXW', NULL, '2022-01-22 18:46:33', '2022-01-22 18:46:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1173, 'MARIKAMI LLC', 'MARIKAMI LLC', '2394612600', 'store1036@teamafricorp.com', NULL, '$2y$10$7dmnAsc4iUXeP5iTluCgpu6GM.57DLPR4Bc7jFvHzm1R7yOOVqtLq', NULL, '2022-01-22 18:46:33', '2022-01-22 18:46:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1174, 'HP HOSPITALITY LLC', 'HP HOSPITALITY LLC', '2399902446', 'store1037@teamafricorp.com', NULL, '$2y$10$SAltF8T./jNo/7LRdcuiIeOsFiLpU4j91WeT8Ww/XF3aS7HAnn6Ve', NULL, '2022-01-22 18:46:33', '2022-01-22 18:46:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1175, 'SANTIAGO BETSY', 'SANTIAGO BETSY', '2398785028', 'store1038@teamafricorp.com', NULL, '$2y$10$pQ/KD1iBHYx4nBfV.jq0CeTKLJTXsfKa.oXOmTsPaMoAM1K5ZJ7ku', NULL, '2022-01-22 18:46:33', '2022-01-22 18:46:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1176, 'AROMA ITALIANO RESTAURANTE LLC', 'AROMA ITALIANO RESTAURANTE LLC', '2395908133', 'store1039@teamafricorp.com', NULL, '$2y$10$s1Dz4N8uhXP1Cc0JXm7F4.JG5sRe18RrhRrb5QkHdsxWmg86eHGLq', NULL, '2022-01-22 18:46:33', '2022-01-22 18:46:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1177, 'LIN      MAO YOUNG', 'LIN      MAO YOUNG', '2394630890', 'store1040@teamafricorp.com', NULL, '$2y$10$b7R8GRaHF.OWqX4RS7oycOeHfzS3pgk9XheQQ9PHRJ.2vgl2SfM82', NULL, '2022-01-22 18:46:33', '2022-01-22 18:46:33', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1178, '3 D BBQ LLC', '3 D BBQ LLC', '2396717072', 'store1041@teamafricorp.com', NULL, '$2y$10$izOSBAa1RQnv.PXleuzM4uB2zmTwJVQ32Gp1nCK1yQngOo9Wwz.Ou', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1179, 'COVER GRUDIN LORRIE', 'COVER GRUDIN LORRIE', '2398487611', 'store1042@teamafricorp.com', NULL, '$2y$10$494oYz01toqvPo8NCJaDWuWny6t221HL71ttUP7oeIbJmmPjpIRZ.', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1180, 'GALLEGO GEOVANA', 'GALLEGO GEOVANA', '2392655358', 'store1043@teamafricorp.com', NULL, '$2y$10$56QwJV9h4rbdLP22S3iScuUunftgVLJslVjZGif8NZArSZa2ivXdu', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1181, 'MORRIS QUINTIN', 'MORRIS QUINTIN', '9414659767', 'store1044@teamafricorp.com', NULL, '$2y$10$hr195tjxdaufmgFAA7N91ey.w2j83Hypxh/nl6rYshI6YIyqhE2vS', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1182, 'CHASE YOUR DREAMS INC', 'CHASE YOUR DREAMS INC', '2392869975', 'store1045@teamafricorp.com', NULL, '$2y$10$erDlLtJ/.K90hbwZ6g46iO9OF4D3pnrU8EBANC9dpkTKfRNUYQ8BW', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1183, 'CORNER STOP OF LEHIGH ACRES LLC', 'CORNER STOP OF LEHIGH ACRES LLC', '2393699309', 'store1046@teamafricorp.com', NULL, '$2y$10$ixLyDElIZHUGwXu5PSSrduwR48n/r3DK87LdfKCfTyZCzUpbKpvE2', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1184, 'RINCON LATINO DOMINICANO INC', 'RINCON LATINO DOMINICANO INC', '2396893875', 'store1047@teamafricorp.com', NULL, '$2y$10$1mHmIwcDsuDd0mF0LzlxhuIWvbO1MHrRsXQ6m/h.aP0/RiEvsSuO.', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1185, 'KULYNYCH CRISTINA', 'KULYNYCH CRISTINA', '2392017751', 'store1048@teamafricorp.com', NULL, '$2y$10$NLoaHGqJSAR74mAs0N7Ab.WMkJsubJ5P3VScJKy3BT3qlcf/mf4zq', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1186, 'LANDRIGAN ZUZANA                                  ', 'LANDRIGAN ZUZANA                                  ', '2392577581', 'store1049@teamafricorp.com', NULL, '$2y$10$Hcn3CFGP5AthIAfL5S3Yd.lOCIfIGLbwLoekuDtb4SAhsXTbmPk7W', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1187, 'HOPKINS RUSHELL B', 'HOPKINS RUSHELL B', '2392007488', 'store1050@teamafricorp.com', NULL, '$2y$10$OBhITE3TIYh98KlCSfTKLO52x5A4ZH3B1ja3bar5DdZwT/TUfIw8S', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1188, '9 DBN LLC                                         ', '9 DBN LLC                                         ', '2396765461', 'store1051@teamafricorp.com', NULL, '$2y$10$YWzo9izghu6N7X3a7RKRwuZ8qunu88l5DI3zL.ne6BjWCi7jVgkji', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1189, 'CHINA WOK CAPE CORAL INC', 'CHINA WOK CAPE CORAL INC', '2392420921', 'store1052@teamafricorp.com', NULL, '$2y$10$xuml7O65gybbLB0fGi6YkeBtbdInqYf2d2EYudJ5a5x3Wqi1.q4ya', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1190, 'CRUSIN CUISINE LLC', 'CRUSIN CUISINE LLC', '2398480448', 'store1053@teamafricorp.com', NULL, '$2y$10$6j4mz8SQKt/yZ4hr5kMMKOfsWvmZCV2kTzwHtfE9xv34eLFSEzOii', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1191, 'KING YUMMY INC', 'KING YUMMY INC', '2394912203', 'store1054@teamafricorp.com', NULL, '$2y$10$Udv1pGA9wlavJK7oqYKiQu0qmFwK/fKYrNQZF6OBGrGUc0aZETAf2', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1192, 'TWISTED HOOK SEAFOOD  LLC                         ', 'TWISTED HOOK SEAFOOD  LLC                         ', '2394509831', 'store1055@teamafricorp.com', NULL, '$2y$10$NzX9fnh7mo2d5dFakGtK5Of.ByhcQOWvn6H8Dzijv7azGmLimwLRC', NULL, '2022-01-22 18:46:34', '2022-01-22 18:46:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1193, 'ARZOO & JAY LLC                                   ', 'ARZOO & JAY LLC                                   ', '2393003531', 'store1056@teamafricorp.com', NULL, '$2y$10$MS9R6STYgdpCddCzLde7b.nKyUOeghnbqHezm11aZACJZe3txVt/K', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1194, 'TOTO TOTA CORPORATION', 'TOTO TOTA CORPORATION', '2395418491', 'store1057@teamafricorp.com', NULL, '$2y$10$wvqXqj9o5ucqTQB85Pg2F.4tp3pTrpm8l4KE8Q8BxvLpjqIUBDTiq', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1195, 'MARRONES PIZZERIA LLC', 'MARRONES PIZZERIA LLC', '2395673113', 'store1058@teamafricorp.com', NULL, '$2y$10$XIsLtx3oBlomBNy3OQQG4uWC5jcn6bpFw2n5uxJCdLRuMF165wmri', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1196, 'BUDDYZ II LLC', 'BUDDYZ II LLC', '2392757777', 'store1059@teamafricorp.com', NULL, '$2y$10$LaIrBnMldqS/hJKiw414r.AIhAcQd0mdkzpqiwWJKjaaH8aX57d5m', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1197, 'MURPHY OIL USA INC.', 'MURPHY OIL USA INC.', '2394630001', 'store1060@teamafricorp.com', NULL, '$2y$10$v7vlNjDLVrMagd6D0XQBZuGz.JOY345yHujqzlugOylDK5en3vEmS', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1198, '50S CUBAN CAFE LLC', '50S CUBAN CAFE LLC', '7864691295', 'store1061@teamafricorp.com', NULL, '$2y$10$BdUA4ugt7BoYMeibeicxnOxu8nWBzDqN2wtZX4O.8iSjnq2bd/iMG', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1199, 'STREET VENDOR LLC', 'STREET VENDOR LLC', '2396876661', 'store1062@teamafricorp.com', NULL, '$2y$10$zot7FdJO4SB4PUQlvgaCr.iGhZJxISrIhV7xuhqzu4iebLLlf/BZq', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1200, 'BURNTWOOD TAVERN GULF COAST LLC', 'BURNTWOOD TAVERN GULF COAST LLC', '2392884068', 'store1063@teamafricorp.com', NULL, '$2y$10$OQbU0xIsXakVMAuZ502H9u8Nq9dnTAMFBITc2ENeJ4UVKlERfWno2', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1201, 'T BOBA LLC', 'T BOBA LLC', '2398005965', 'store1064@teamafricorp.com', NULL, '$2y$10$Mm6Y8dPusKLlgk1vOT3FxOyUN3Iy.N2i3FYCimUBD51sajWNf48OG', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1202, 'HABLE LAUREN', 'HABLE LAUREN', '3134077474', 'store1065@teamafricorp.com', NULL, '$2y$10$MD.laKhtps02VKjCJrZS/O/tGac55mohTZuyh5MDsUL3UbwVc4one', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1203, 'BIG NICKS BARBEQUE LLC', 'BIG NICKS BARBEQUE LLC', '8283618766', 'store1066@teamafricorp.com', NULL, '$2y$10$lFTGULpl9Yg5Q5b4vE2hdOPRtjGLiQLStPr2oV29kZ36NzifA6ICy', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1204, 'MD SNOBALLS LLC', 'MD SNOBALLS LLC', '2396015699', 'store1067@teamafricorp.com', NULL, '$2y$10$1S955KUpAzEIS4f4yWIwV.JQvblK6u3.mYQhmxVmRSs4aWvehEWlm', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1205, 'FL MASONS CORPORATE LLC                           ', 'FL MASONS CORPORATE LLC                           ', '2392087271', 'store1068@teamafricorp.com', NULL, '$2y$10$fjPCAgUFUjhT52q1KR9uwe8IaY6ceJKbGhIfANS7TxMXZTSMFvbMG', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1206, 'BEAUS BBQ LLC', 'BEAUS BBQ LLC', '2392401377', 'store1069@teamafricorp.com', NULL, '$2y$10$wa3NYCO/GuGgBfS/Q/3/G.NDk5zLdsVsuJig4MmlkCMyJ00F1OM/W', NULL, '2022-01-22 18:46:35', '2022-01-22 18:46:35', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1207, 'KINGS KITCHEN AND BAR LLC', 'KINGS KITCHEN AND BAR LLC', '2392088518', 'store1070@teamafricorp.com', NULL, '$2y$10$qHIFz5kEt1/rD6UoQBJoWuovNwcemKrjXM22BqSjsRXirpNG8Sy..', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1208, 'KAVA NIRVANA LLC', 'KAVA NIRVANA LLC', '2396008699', 'store1071@teamafricorp.com', NULL, '$2y$10$7B9i7WQCwi21ZVQ6CKugqOObhd620fpA/ojGDoAo1AhIeL8K6iflO', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);
INSERT INTO `vendors` (`id`, `f_name`, `l_name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `bank_name`, `branch`, `holder_name`, `account_no`, `image`, `status`, `firebase_token`, `auth_token`) VALUES
(1209, 'MAMMA ANNA LLC                                    ', 'MAMMA ANNA LLC                                    ', '2399924500', 'store1072@teamafricorp.com', NULL, '$2y$10$SUcn//9mpl8QjRN75gMaPepnhpfO0/w3LVRiOQlN5K1/Jbz9lIRQy', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1210, 'DIXON JENNIFER', 'DIXON JENNIFER', '5134311047', 'store1073@teamafricorp.com', NULL, '$2y$10$wYbo8p8qlWI5/BJrtaM3dOjbyvJQjJsQHBFoa.ZvL8f1atEzFCJZe', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1211, 'MALLOUS KONSTANTINIA                              ', 'MALLOUS KONSTANTINIA                              ', '2392108015', 'store1074@teamafricorp.com', NULL, '$2y$10$J.IOpl5yrmSJSv7ws/oSLO4mQjwZS3DveQ5ol37d9YHEdSUI8PmJS', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1212, 'TROPICAL ISLAND SNOW LLC                          ', 'TROPICAL ISLAND SNOW LLC                          ', '2398412479', 'store1075@teamafricorp.com', NULL, '$2y$10$wvNm4mVT/FyVt6b/grbhIOy3ihqLW2DRSelq/.FHhpW4SuXNubkCW', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1213, 'COYAS UN ANTOJO NATURAL LLC', 'COYAS UN ANTOJO NATURAL LLC', '2394257480', 'store1076@teamafricorp.com', NULL, '$2y$10$c.L9XWOHeQHy..TTgd3IC.u/re/1PvVVwz8IiaFL7ieEDbTFiV81i', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1214, 'QUALITY FRESCA I LLC                              ', 'QUALITY FRESCA I LLC                              ', '9198004940', 'store1077@teamafricorp.com', NULL, '$2y$10$72BH73TffhQ8MlzdPJUjAeEtEYfHnGxLVD6UmCbj3/4Sf2aMKjt1i', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1215, 'YOWELL KATHERINE M', 'YOWELL KATHERINE M', '7274015194', 'store1078@teamafricorp.com', NULL, '$2y$10$giYo3GIJQ11tO.6ISwfISeUKpG7RcjlDMHFMeeMbEBv50DKD6S3h.', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1216, 'CSC FMBEACH LLC', 'CSC FMBEACH LLC', '2399385943', 'store1079@teamafricorp.com', NULL, '$2y$10$xsYYX5mleQylCah3dOaZAu5FCgB1z4U8n5eknb8FGKu6zDiswWjIu', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1217, 'PIERCY CAROLYN  JAY', 'PIERCY CAROLYN  JAY', '2519303937', 'store1080@teamafricorp.com', NULL, '$2y$10$QU/NJWQbmIn3nP/HnoPMKOirln8I7qspyAa58kSqneY2kNbjnm6Oq', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1218, 'LBVW LLC', 'LBVW LLC', '2397718285', 'store1081@teamafricorp.com', NULL, '$2y$10$okSPAolbN1MgM7fvV9j73OIrZA2MgnUc3RikQyspZ36hDKO.RtAGq', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1219, 'QUALITY FRESCA I LLC                              ', 'QUALITY FRESCA I LLC                              ', '9198004940', 'store1082@teamafricorp.com', NULL, '$2y$10$HzEmQ/5dnVjsd/IYwzTOAOkjuf0tvWupFXayf1wVvD2b2COx2lZ7e', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1220, 'YUMMYYUMMIES4YOU LLC                              ', 'YUMMYYUMMIES4YOU LLC                              ', '2392500385', 'store1083@teamafricorp.com', NULL, '$2y$10$2pFaw.87vjbehTC.5AlHa.3pi9DxQr76UnhTceyJ6s3lH0HiIPbta', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1221, 'CHOCOLATTES COFFEE & ROASTING LLC', 'CHOCOLATTES COFFEE & ROASTING LLC', '2393314443', 'store1084@teamafricorp.com', NULL, '$2y$10$KGFFHmgJmQ.PoVBcxnCuzOxoC6W5vogS3ji1Q3pSxZs1jTBxp6C.u', NULL, '2022-01-22 18:46:36', '2022-01-22 18:46:36', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1222, 'SBARRO LLC', 'SBARRO LLC', '2399316015', 'store1085@teamafricorp.com', NULL, '$2y$10$Jx/9B8.jjiCcfO1bgCoMf.5uyF./Bm9hTnC39TXI.cNwYIj4Uv/N6', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1223, 'THE DOG LLC                                       ', 'THE DOG LLC                                       ', '9787719795', 'store1086@teamafricorp.com', NULL, '$2y$10$UYuq9BoOK16PR2yKLLodp.DxGhf7xj.HayOqj2TRdzmMcrAJr0rEi', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1224, 'TORTILLERIA JALISCO INC                           ', 'TORTILLERIA JALISCO INC                           ', '2396288743', 'store1087@teamafricorp.com', NULL, '$2y$10$vC/8wpUiPnULQgYQTfp2tujLCeaEJA3sKyGI6dpZj//cybHgjzpfC', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1225, 'DANIELS PIZZERIA INC', 'DANIELS PIZZERIA INC', '3862640290', 'store1088@teamafricorp.com', NULL, '$2y$10$HHQg2hvIKDtftUpY/sbbquU4TvcpCxyEJ9KB5iX/Wt/jJmjq./goq', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1226, 'EL NUEVO MAGUEY BAR AND GRILL                     ', 'EL NUEVO MAGUEY BAR AND GRILL                     ', '2392816243', 'store1089@teamafricorp.com', NULL, '$2y$10$X4lSGYcD1jPSB0rHKw0ZGem/oP8VO6TgcZ4f5gpN/Q.7jcM4OW71u', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1227, 'HOLLWAY ASSOCIATES INC                            ', 'HOLLWAY ASSOCIATES INC                            ', '2398501228', 'store1090@teamafricorp.com', NULL, '$2y$10$kOWduES5PQGccPi0KMd4xe8QOgS27ljFjEVWB1R5IrZ8ky5jQLlJS', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1228, 'THE BEST AROUND INC                               ', 'THE BEST AROUND INC                               ', '2398721838', 'store1091@teamafricorp.com', NULL, '$2y$10$LcSlPXIN.eZnQwg4S6INDeAfI5oz4EBEvVE8aInmKFql3qFXFJAf.', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1229, 'JAVA HOUSE LLC                                    ', 'JAVA HOUSE LLC                                    ', '2394005282', 'store1092@teamafricorp.com', NULL, '$2y$10$2RyyuAftSzVIsW066FpXtekoLLyH6D.J4zStijul8Urslm9/4JNwW', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1230, 'PINE ISLAND GETAWAY CAFE LLC', 'PINE ISLAND GETAWAY CAFE LLC', '2392833602', 'store1093@teamafricorp.com', NULL, '$2y$10$yHXXc3POMnVZpFGK/znRHudputP3OHTEKZmsP4s1SKxADqlz1hdQy', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1231, 'BOUTIQUE OF SWEETS LLC', 'BOUTIQUE OF SWEETS LLC', '2393098506', 'store1094@teamafricorp.com', NULL, '$2y$10$Vc00QonFOcvlFjG4uBj55.vB4mWH8ujjjSQYBiIlNdTYIuihpMxT.', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1232, 'CATTYSHACK CAFE LLC', 'CATTYSHACK CAFE LLC', '9526078835', 'store1095@teamafricorp.com', NULL, '$2y$10$9O0oXRhdZClTE8W/V2Wa0uOnZZkTjjcTtqdCAAWjyF7d4J.4xXYJC', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1233, 'WAWA FLORIDA LLC', 'WAWA FLORIDA LLC', '6103588029', 'store1096@teamafricorp.com', NULL, '$2y$10$L0Rq98lIj0mi4uEYTW8OH..ThNym7U15rkJdCVygJmt3nNvD98mm6', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1234, 'RACETRAC PETROLEUM INC                            ', 'RACETRAC PETROLEUM INC                            ', '7704317600', 'store1097@teamafricorp.com', NULL, '$2y$10$wVa2jL6RzZhER/GxPdze.euyIfob5Xt7LHlnfaIkXTNMPG9ia.q1m', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1235, 'CASTRO SANDRA IVETTE', 'CASTRO SANDRA IVETTE', '3479049269', 'store1098@teamafricorp.com', NULL, '$2y$10$AFlCTQGTEsqxYzaintgTKelhRkJDXzDdZfARj4gSbJ..wyACcrS.G', NULL, '2022-01-22 18:46:37', '2022-01-22 18:46:37', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1236, 'SUMMERLIN CAFE INC', 'SUMMERLIN CAFE INC', '2395659568', 'store1099@teamafricorp.com', NULL, '$2y$10$Bv10WV40g04HgWNDnppgNu.1h9hxpNrQ0VwLW7DU4nuriD9or8Hsa', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1237, 'NINJA THAI & SUSHI BAR LLC', 'NINJA THAI & SUSHI BAR LLC', '2394330508', 'store1100@teamafricorp.com', NULL, '$2y$10$pSmVnNKQEqw2MaT3q6dtI.c3SAjRJDRIBMJ4ZXYPIUjD2EGO9OKCq', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1238, 'SCOOP ME UP INC', 'SCOOP ME UP INC', '9413911970', 'store1101@teamafricorp.com', NULL, '$2y$10$Fw4fua3ydrF9bbqVs410EOvfrBddwlFZqljyxhoqK.n14bRegRdBK', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1239, 'JUDAH MEALS LLC', 'JUDAH MEALS LLC', '9048947567', 'store1102@teamafricorp.com', NULL, '$2y$10$TDLvpacc.7XKPoaap7gnsOAog2gMASYqttVJV1wb1dTwtzdblRfcW', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1240, 'CORMACAST LLC', 'CORMACAST LLC', '2392014078', 'store1103@teamafricorp.com', NULL, '$2y$10$ScxmGVZxqo./Xu3nyTGKWuuAX3lQay3DR5OYb/4oVAv9BqbQI0LTi', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1241, 'MANGIAMO LLC', 'MANGIAMO LLC', '9164024445', 'store1104@teamafricorp.com', NULL, '$2y$10$hiRNB7IoYGBqMZmx8Z5Jg.SKOOZCCKAyCWUAKM84FX9CBMI7pT1jG', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1242, 'EATON RYAN', 'EATON RYAN', '2396779891', 'store1105@teamafricorp.com', NULL, '$2y$10$RvmhO8CLoG2Skz9/D1MihukffshI8B44U8XUyXx2/pd2/oFXB6DE2', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1243, 'TACOS MECICAN RESTAURANT INC                      ', 'TACOS MECICAN RESTAURANT INC                      ', '8138460922', 'store1106@teamafricorp.com', NULL, '$2y$10$GyXDLA9XGjwsDbpYtDcqWekNUazCAkxR1JqGUJ8lUMS0/Fh8B8wg.', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1244, 'DK MOBILE ENTERPRISES LLC                         ', 'DK MOBILE ENTERPRISES LLC                         ', '8133857914', 'store1107@teamafricorp.com', NULL, '$2y$10$71p31op2plA/eviYv3SZQ.qib4nMqgU2wrC9VE9Ewfb/S.pAsfn1m', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1245, 'SWEENEYS WEENEYS KEY WEST LLC', 'SWEENEYS WEENEYS KEY WEST LLC', '3055877155', 'store1108@teamafricorp.com', NULL, '$2y$10$NXz8L9EgOR3jB1wB9cPw9uMhhEaVFT5oz3jSh6TbOkg3PdassrzFy', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1246, 'STICKY LICKY ICE CREAM LLC                        ', 'STICKY LICKY ICE CREAM LLC                        ', '2397037279', 'store1109@teamafricorp.com', NULL, '$2y$10$MLCgfk/8pjCXFJEPM5oZIuBHXTfvLohtKz1N.H8DrOBOcW4rXFQD.', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1247, 'TWO MEATBALLS CAPE CORAL LLC', 'TWO MEATBALLS CAPE CORAL LLC', '2393473013', 'store1110@teamafricorp.com', NULL, '$2y$10$lu6SSQkRphHihLnFAtqOMe05fjxs4FcpEFYl0riNhCSbu11xqN.U.', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1248, 'COONEY EDWARD K', 'COONEY EDWARD K', '2397706724', 'store1111@teamafricorp.com', NULL, '$2y$10$m41F6gO7cCBrUd1qvSBNRuuwKiNgan80pkxDcjMAXN9FQD3o/XlXG', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1249, 'THE STAGE ENTERTAINMENT CENTER LLC                ', 'THE STAGE ENTERTAINMENT CENTER LLC                ', '2394058566', 'store1112@teamafricorp.com', NULL, '$2y$10$HhqmM4AlwZYWvg1r.uwoROQc0BKFtBOAMyn0fpAg.NjtT2RVmwl4q', NULL, '2022-01-22 18:46:38', '2022-01-22 18:46:38', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1250, 'GIAQUINTO JOHN                                    ', 'GIAQUINTO JOHN                                    ', '2395420185', 'store1113@teamafricorp.com', NULL, '$2y$10$jFBo8h0d/WcEbAUI4Q4Nv.pKbkIXbNJq5mECDVJiSFCYuMVz7QtAi', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1251, 'MEDITERRANEAN PARADISE LLC', 'MEDITERRANEAN PARADISE LLC', '2396769855', 'store1114@teamafricorp.com', NULL, '$2y$10$asQdjhNGQDxZUcosjbmlc.ntO/IDNI3HFDGKhveTcglRbV6C6RiwG', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1252, 'MINAS BISTRO INC', 'MINAS BISTRO INC', '2392251139', 'store1115@teamafricorp.com', NULL, '$2y$10$pnvehezGI8dpSb3eehVb0.QY7JieppJNcjBqcDBjwMr9qKU7IFUFK', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1253, 'PHILLIPS WYNN', 'PHILLIPS WYNN', '8636730920', 'store1116@teamafricorp.com', NULL, '$2y$10$9CkGzlGX6jHIXNuw8cFY3.oj4XXGclpg7/b2KeDg2IIo5czl/ic/a', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1254, 'MEXICAN BOTANAS & FRUTAS LOCAS LLC', 'MEXICAN BOTANAS & FRUTAS LOCAS LLC', '5618562992', 'store1117@teamafricorp.com', NULL, '$2y$10$44IAxql84U/FsHyJXbMMqOn2z0rQw6Ekc5vW8VPeePxsdsEp315f6', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1255, 'REJ LLC', 'REJ LLC', '2392008679', 'store1118@teamafricorp.com', NULL, '$2y$10$nifVrHq9kwQlwxIAxyqSI.LQu4RY22Q6VsnVNbQdPQxNEIfl8ZHei', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1256, 'SCHMIDT PAMELA J                                  ', 'SCHMIDT PAMELA J                                  ', '2399139900', 'store1119@teamafricorp.com', NULL, '$2y$10$I.23/TsIW1LI4BP4d3y.kOnS5R.lhKKj6x8UaCZMBwMA9U126zdVi', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1257, 'PEPES TROPICAL LLC', 'PEPES TROPICAL LLC', '2398785035', 'store1120@teamafricorp.com', NULL, '$2y$10$/T4yFUhJEk4P26PfMg25BeZhO4wvN2zK9U4LwaWpX8o8zrPZzfe4S', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1258, 'BCB KITCHEN LLC', 'BCB KITCHEN LLC', '9177216379', 'store1121@teamafricorp.com', NULL, '$2y$10$WsBm9s75vtVWkdx5TZGIOe2qJQXxFDgW7S88NrzvD/gB0kZ7Q9SHW', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1259, 'SWEETS EMPIRE LLC', 'SWEETS EMPIRE LLC', '2396993227', 'store1122@teamafricorp.com', NULL, '$2y$10$7XIRLafQr1xAHXGE5dR/GOnkZvnchXlfbVs0kWgqg./amnXUb95ju', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1260, 'NAUTI TIKI SEASONINGS LLC                         ', 'NAUTI TIKI SEASONINGS LLC                         ', '2393086121', 'store1123@teamafricorp.com', NULL, '$2y$10$cFbYBixEP0sq3AdIQmVEV.6UAK1D7ZkmRLUsK6tgea/pAQLdYVmQi', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1261, 'PFISTER    MARC    A', 'PFISTER    MARC    A', '2392223100', 'store1124@teamafricorp.com', NULL, '$2y$10$n/NrGtXwNFq0IOeCCD7FSeyAvsfVRXARpk.U6h/asvuv58FWTQ/.u', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1262, 'T MOBILE USA INC                                  ', 'T MOBILE USA INC                                  ', '6308572106', 'store1125@teamafricorp.com', NULL, '$2y$10$gsejEL9SHi8ymlnEKKtz8.vxMPMgSq3aYufUvx6NzHAT6D42p5/bC', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1263, 'T MOBILE USA INC                                  ', 'T MOBILE USA INC                                  ', '6308572106', 'store1126@teamafricorp.com', NULL, '$2y$10$UOFWq236hOG3aKvWdzXBtu7lhwuPiQTkgcLPtq.RS2hKBPW2mjC0a', NULL, '2022-01-22 18:46:39', '2022-01-22 18:46:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1264, 'RODRIGUEZ DANIEL E', 'RODRIGUEZ DANIEL E', '7867400018', 'store1127@teamafricorp.com', NULL, '$2y$10$DCZ5rfpqoHLFPVMz8AIx6ORfzM9/sxrtmboJ0JUiRH05Dl7kuu1ni', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1265, 'EMD ENTERPRISES FORT MYERS INC                    ', 'EMD ENTERPRISES FORT MYERS INC                    ', '2544238139', 'store1128@teamafricorp.com', NULL, '$2y$10$TldvMX0g5mNImJ4kWs4ad.nq.ms2Jxpmcju1XuLUTe7OvAPZ3Jxcy', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1266, 'BAXTER RESTAURANTS OF LEE COUNTY INC', 'BAXTER RESTAURANTS OF LEE COUNTY INC', '2398005051', 'store1129@teamafricorp.com', NULL, '$2y$10$Alr0zH6AOAcoFytoRcyCr.F1pCqwuIUuPlCQsIpvR0hyazlMqRp7S', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1267, 'THE PIZZA CUTTER INC', 'THE PIZZA CUTTER INC', '2399003003', 'store1130@teamafricorp.com', NULL, '$2y$10$FvRSmurrN6vYnKdfjUaKk.wXnY.tksxDdH0qcGUvnC8scE.llMsm2', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1268, 'FIREBREAD LLC', 'FIREBREAD LLC', '2394103909', 'store1131@teamafricorp.com', NULL, '$2y$10$3pbg6rv5BVhHtZnM5x1z.e7j8YRHbmTJ868IUYCW2CZL/bwub7m5C', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1269, 'MAI MY Q', 'MAI MY Q', '2392088368', 'store1132@teamafricorp.com', NULL, '$2y$10$JLwaZA/De4pobQwkGI7TfuaMYOPWgs/Mxk/lNTvDg6cuLYpcqUt3K', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1270, '7 ELEVEN STORE 38285A                             ', '7 ELEVEN STORE 38285A                             ', '4073994630', 'store1133@teamafricorp.com', NULL, '$2y$10$EqeKY73s1CGAYciAFWcXTe4UONB19.0vQPib20HvdG6lP.gOludVa', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1271, 'C & N II LLC', 'C & N II LLC', '2394720305', 'store1134@teamafricorp.com', NULL, '$2y$10$19rARhU/fM2pQRt/esZ0su.X0dgBPC/J0gCD7U8ll68QSR0QHkpVu', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1272, 'THE TRADING POST AT BURNT STORE MARINA LLC        ', 'THE TRADING POST AT BURNT STORE MARINA LLC        ', '9416773137', 'store1135@teamafricorp.com', NULL, '$2y$10$FC12YYDO3Hwfty0sQEZ21uZvr.JojPTOJXeXBL3f8kIenw7c8kq4C', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1273, 'FRITANGA 123 INC', 'FRITANGA 123 INC', '3054171825', 'store1136@teamafricorp.com', NULL, '$2y$10$/a0Gx1BqZvlR3QpfZ8pZSeGrcfTSVesHdw2YGs0b28wDjwMgu8fkK', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1274, 'CATALINAS KITCHEN AND TRUCK INC                   ', 'CATALINAS KITCHEN AND TRUCK INC                   ', '7869305264', 'store1137@teamafricorp.com', NULL, '$2y$10$hPIsbtzOZlWTcuB3u4fotu4/AEu5fuYYFnRL3kPmi9UnvyiwnPzbK', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1275, 'CAFETERIABAKERY SABOR CUBANO INC                  ', 'CAFETERIABAKERY SABOR CUBANO INC                  ', '2392056451', 'store1138@teamafricorp.com', NULL, '$2y$10$eXSG/uMYmgLVJ94jrY6N.O1TuQ9UYXTHA8jZ/XqV/6ST78I/UiM4a', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1276, 'JAENVEGA MICHAEL', 'JAENVEGA MICHAEL', '2393004777', 'store1139@teamafricorp.com', NULL, '$2y$10$E0ihVlsYNkx2uGKr1byAh..S3GnGRbVfFlxWARTcdd2ovn13MOzd6', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1277, 'FARMERS CORN LLC', 'FARMERS CORN LLC', '3057289813', 'store1140@teamafricorp.com', NULL, '$2y$10$YmVLyC47zLuErmFIo.l3T.Sx1QVtoyjG/cgf1L8j9T8TDB1fgCk3y', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1278, 'AMERICAN ONCOLOGY PARTNERS PA                     ', 'AMERICAN ONCOLOGY PARTNERS PA                     ', '2392748200', 'store1141@teamafricorp.com', NULL, '$2y$10$jPZU8HfpokwOpXUH5YCguODv5MrrAivXmtbLE418.NIXywBbgZL/C', NULL, '2022-01-22 18:46:40', '2022-01-22 18:46:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1279, 'XIN QI CHEONG', 'XIN QI CHEONG', '8609903993', 'store1142@teamafricorp.com', NULL, '$2y$10$Isvknjkyif09iExLdfw2sOIXJNoizNsHxxRLOQPFNDw2h7.M0H.Ga', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1280, 'BLUECOTTER LLC', 'BLUECOTTER LLC', '2395406800', 'store1143@teamafricorp.com', NULL, '$2y$10$sRrwQSGykwCknbyranUbJe9Djnb47nXJejR4jbxwWVmscOVFP6B9K', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1281, 'PANDA EXPRESS INC                                 ', 'PANDA EXPRESS INC                                 ', '2397667906', 'store1144@teamafricorp.com', NULL, '$2y$10$NdZ.29vj3H/w2N8VttPAA.LZzJCP0RW0GoAeQ5skXnTHfxtOEe2dS', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1282, 'BEACH BROTHERS BBQ LLC', 'BEACH BROTHERS BBQ LLC', '6155799852', 'store1145@teamafricorp.com', NULL, '$2y$10$1VEMC4xkz/NwC1i5Bncw7uDZO4dr3QcLAlKdJvloxte72r4Z3H31.', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1283, 'A & JAY CATERS LLC', 'A & JAY CATERS LLC', '2394330047', 'store1146@teamafricorp.com', NULL, '$2y$10$iAB/hVIyVbKmHxMsLfJF/e3myk/f9kj0FkhM9vm58vHfVQoa7iWFy', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1284, 'RONLMZ INC', 'RONLMZ INC', '2396738138', 'store1147@teamafricorp.com', NULL, '$2y$10$oNG8BZUz87sBxGi9X69HLe8Y1c0vsjevtXg0LZST32CXsyJpzX9rK', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1285, 'MARGE WONG                                        ', 'MARGE WONG                                        ', '9179022289', 'store1148@teamafricorp.com', NULL, '$2y$10$R84MxuXpjuETVk38PALvqO.wZ1KB/BpLFx3JHheiS5xygX28N89dK', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1286, 'BIG STORM PINELLAS LLC                            ', 'BIG STORM PINELLAS LLC                            ', '7274970666', 'store1149@teamafricorp.com', NULL, '$2y$10$X0YovEQda8mnc8VY5H0o0OtAFJP.XsuMKwPasipPprMN6cU3R6Rra', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1287, 'POLEWSKI CHRISTINA M', 'POLEWSKI CHRISTINA M', '5043465168', 'store1150@teamafricorp.com', NULL, '$2y$10$VgIihAFS1morzElXMCQAJ.wnEvbrpK72wyvI7qHxgKLCdmxM6wqp.', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1288, 'BOODLES RESTAURANT GROUP LLC', 'BOODLES RESTAURANT GROUP LLC', '2394637770', 'store1151@teamafricorp.com', NULL, '$2y$10$lxhiMWbfAiXRpv48Nb1YruynsNR8OYB9qNJQ6F53VQI8Bzj6gBrfO', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1289, 'PETERSON III JESSE                                ', 'PETERSON III JESSE                                ', '2398506124', 'store1152@teamafricorp.com', NULL, '$2y$10$5e1qDRmE5.QvcRhVYiuwYuw2.lIJRPuF2HcZeq7i.qQKwE6YZzLoW', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1290, 'WALLYS CHOCOLATE WORKS LLC                        ', 'WALLYS CHOCOLATE WORKS LLC                        ', '2394637744', 'store1153@teamafricorp.com', NULL, '$2y$10$0GcSLyjKkvNOJp4pvfcQ0e3HCn73PyNv5pNJJRNqrqA1LcMcsHbji', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1291, 'QFRM6 LLC', 'QFRM6 LLC', '9419531808', 'store1154@teamafricorp.com', NULL, '$2y$10$xgXTUhdPWRmz6fHXeB0yMO9tHyKVs2DNwDd7GL8pw6k6.vsejIuVO', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1292, 'MICHELE CHIUPPO INC', 'MICHELE CHIUPPO INC', '4078305338', 'store1155@teamafricorp.com', NULL, '$2y$10$tNG3u7ghscs5ip0FMIskQOrBTWY1C/2RB7JkbS6R9TnSssuOMaUA2', NULL, '2022-01-22 18:46:41', '2022-01-22 18:46:41', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1293, 'MICHELE CHIUPPO INC', 'MICHELE CHIUPPO INC', '4078305338', 'store1156@teamafricorp.com', NULL, '$2y$10$xQzq6jqxi5FOwHENpwsJ7OsQQT3vmKZR8.9/mJo30HPQhCdqRZTf2', NULL, '2022-01-22 18:46:42', '2022-01-22 18:46:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1294, 'BROOKES NUGGET WAGON INC                          ', 'BROOKES NUGGET WAGON INC                          ', '2399951900', 'store1157@teamafricorp.com', NULL, '$2y$10$G.MC5qOZWiwmtY1msIWPU.AlgM82pluZQpyazxi3hECuA/I8qlc6e', NULL, '2022-01-22 18:46:42', '2022-01-22 18:46:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1295, 'SKINNY DOGZ INC                                   ', 'SKINNY DOGZ INC                                   ', '2393622693', 'store1158@teamafricorp.com', NULL, '$2y$10$v/X9VpcuDqvgOXO0yUcu1O7ru4uyTpe8AjmXXci.G/7EXL/vTdNbS', NULL, '2022-01-22 18:46:42', '2022-01-22 18:46:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1296, 'CUBAN LATIN MIX CUISINE LLC', 'CUBAN LATIN MIX CUISINE LLC', '2392740591', 'store1159@teamafricorp.com', NULL, '$2y$10$oS0jPyGKtJjYIEmi3NPZBeLz4GB7xnvwxDMoJpvRf79cWxOEnHquW', NULL, '2022-01-22 18:46:42', '2022-01-22 18:46:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1297, 'WOODYS CONVENIENT STORE FAST FOOD LLC             ', 'WOODYS CONVENIENT STORE FAST FOOD LLC             ', '2392236012', 'store1160@teamafricorp.com', NULL, '$2y$10$fmn/SGTBytsWjwopw1S95Oy8.KaRZtWg3Ayy3luUg6RaENvgmwQjq', NULL, '2022-01-22 18:46:42', '2022-01-22 18:46:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1298, 'DE ARMOND CHELSEA', 'DE ARMOND CHELSEA', '2393627223', 'store1161@teamafricorp.com', NULL, '$2y$10$ef98PsHVMWk0D2p3bJ3R.euKqQ4DkEQrpPK2DWuWqh6NiMtrRg9da', NULL, '2022-01-22 18:46:42', '2022-01-22 18:46:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1299, 'STEHLY JUSTIN', 'STEHLY JUSTIN', '6105540724', 'store1162@teamafricorp.com', NULL, '$2y$10$E3ZpAdvGlh/8QI8VfS6jpOiPbDja8LQ/wrggqA19h0PfC4im.DKha', NULL, '2022-01-22 18:46:42', '2022-01-22 18:46:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1300, 'EL PATRON RESTAURANTE INC', 'EL PATRON RESTAURANTE INC', '2392572896', 'store1163@teamafricorp.com', NULL, '$2y$10$EmlR2Fy/u2uqa7/CApdOMuIwcQR2GI3QF3qLwDtdlLw86eogi1NDO', NULL, '2022-01-22 18:46:42', '2022-01-22 18:46:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1301, 'BURNTWOOD TAVERN BELL TOWER LLC                   ', 'BURNTWOOD TAVERN BELL TOWER LLC                   ', '2392675107', 'store1164@teamafricorp.com', NULL, '$2y$10$1icLfVArJmG/pNSMJUHB4.3MepNOBF44chnCbYtG5EraUYbh5oBeW', NULL, '2022-01-22 18:46:42', '2022-01-22 18:46:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1302, 'DOUBLE DEES MUNCHIES LLC', 'DOUBLE DEES MUNCHIES LLC', '2396746169', 'store1165@teamafricorp.com', NULL, '$2y$10$lrtHgHahafMpkIfwOulCj.zbXrXkQ.SC.Yu2tx4BbJGeLjtH8vnzC', NULL, '2022-01-22 18:46:42', '2022-01-22 18:46:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1303, 'CACCIATORE VINCENZO', 'CACCIATORE VINCENZO', '2395908147', 'store1166@teamafricorp.com', NULL, '$2y$10$Z7oCzt3LziF6axK6w5.ypOGkoNgMegFVYT2LWk4WpY3bs3zQXYD7i', NULL, '2022-01-22 18:46:43', '2022-01-22 18:46:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1304, 'MOMENTUM MEDICAL HOLDINGS GROUP LLC', 'MOMENTUM MEDICAL HOLDINGS GROUP LLC', '2398777069', 'store1167@teamafricorp.com', NULL, '$2y$10$xdPqUfVltzjC0LuwrJ0OC.TW4AhhzHrkH7CbiLPImCnFwwFp/9lsO', NULL, '2022-01-22 18:46:43', '2022-01-22 18:46:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1305, 'DELICIAS LATINA SNOW COFFEE LLC                   ', 'DELICIAS LATINA SNOW COFFEE LLC                   ', '2396661843', 'store1168@teamafricorp.com', NULL, '$2y$10$DF9vS7ZaIZU5Gr1q3KYyGeNrzvj3UPTLk9SV4wwsUeINd/tMSM9.e', NULL, '2022-01-22 18:46:43', '2022-01-22 18:46:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1306, 'GRANDMA PENNYS PIZZA LLC                          ', 'GRANDMA PENNYS PIZZA LLC                          ', '2392170584', 'store1169@teamafricorp.com', NULL, '$2y$10$7rJ0g3aqC.k9OiWvUN.sR.a.IGWygatiNETIQ1XddTxFsmWYFT8Iu', NULL, '2022-01-22 18:46:43', '2022-01-22 18:46:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1307, 'CUBA MEX AMERICAN INC', 'CUBA MEX AMERICAN INC', '2398677904', 'store1170@teamafricorp.com', NULL, '$2y$10$qj6Cacij5Bn5RRrrF0yCSO7B2n7SQl/HjmYw1EA7ewfuRYNPG0PFe', NULL, '2022-01-22 18:46:43', '2022-01-22 18:46:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1308, 'THE BOWL UV LLC                                   ', 'THE BOWL UV LLC                                   ', '2392886487', 'store1171@teamafricorp.com', NULL, '$2y$10$0KO54XJWo.frGkwNptIWju6qN1uvmLhXm7QYU695YmDc5VXlKovVO', NULL, '2022-01-22 18:46:43', '2022-01-22 18:46:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1309, 'SEASIDE BAR AND GRILL BONITA LLC                  ', 'SEASIDE BAR AND GRILL BONITA LLC                  ', '2392881470', 'store1172@teamafricorp.com', NULL, '$2y$10$kSgKzAAtINZMRJpM6enIo.DPlyFewzAg5URk76Ix/4cnMm6ouqIoC', NULL, '2022-01-22 18:46:43', '2022-01-22 18:46:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1310, 'FOOD SERVICES INC', 'FOOD SERVICES INC', '2397918562', 'store1173@teamafricorp.com', NULL, '$2y$10$MRDShgTeGGvV.XmzOqIYs.mAGow.0HHEatvHbTF.sXfZbMRtYkoZe', NULL, '2022-01-22 18:46:43', '2022-01-22 18:46:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1311, 'CAMACHO MARTINEZ MARCO A', 'CAMACHO MARTINEZ MARCO A', '2398239148', 'store1174@teamafricorp.com', NULL, '$2y$10$SbwnqousQkEuEQd6FyQpVesXxKcke.Hv0zKc6YIqy7jrtVx80113G', NULL, '2022-01-22 18:46:43', '2022-01-22 18:46:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1312, '7 ELEVEN INC                                      ', '7 ELEVEN INC                                      ', '4073994630', 'store1175@teamafricorp.com', NULL, '$2y$10$gzRDkZ9y4qTGC3lMH5fw6uhxt6E2AY81d/1E.UhLnyfojncRxZkNW', NULL, '2022-01-22 18:46:43', '2022-01-22 18:46:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1313, 'MARIA G CAMACHO NUNEZ                             ', 'MARIA G CAMACHO NUNEZ                             ', '7143608366', 'store1176@teamafricorp.com', NULL, '$2y$10$lGyfdFx375ahTPI.BySo4uMWkpiFgh7L7VwiiThdtf9O9082EgwTW', NULL, '2022-01-22 18:46:43', '2022-01-22 18:46:43', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1314, 'KINGS CRAB SEAFOOD AND STEAKHOUSE INC', 'KINGS CRAB SEAFOOD AND STEAKHOUSE INC', '2396562828', 'store1177@teamafricorp.com', NULL, '$2y$10$z5/6n4k8.4k6aVcpvymoTuF.ey2/mkN49UDxYY/Nl05SXlc4wCIiG', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1315, 'EPIC ICE LOUNGE LLC', 'EPIC ICE LOUNGE LLC', '2392183754', 'store1178@teamafricorp.com', NULL, '$2y$10$B754KPKlCQmjE7KAN92RW.RBk97vzAWOco15Z2i9P8WM38/huisrm', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1316, 'WOW VEES LLC', 'WOW VEES LLC', '2398004081', 'store1179@teamafricorp.com', NULL, '$2y$10$PJrv9uh/2.Q/f9smJK4kQ./y.8qExY/TztTncxUdVde2q6wQfE8SW', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1317, 'PIRATE HOOK SEAFOOD AND CHICKEN INC               ', 'PIRATE HOOK SEAFOOD AND CHICKEN INC               ', '2392049282', 'store1180@teamafricorp.com', NULL, '$2y$10$b3fS9hjXRM.NYjj1oA2jgeR/pht/ATjh9hP.WWonvSVwvzKyl5Wky', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1318, 'BLUE ROSE BAKEHOUSE LLC', 'BLUE ROSE BAKEHOUSE LLC', '2403927671', 'store1181@teamafricorp.com', NULL, '$2y$10$ZRnSoeeUrUkqDd5ShR1iD.JMSGtJxbF4aFIfJxQCU9SsKO5xkLLoi', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1319, 'APOVINI INC', 'APOVINI INC', '2393136475', 'store1182@teamafricorp.com', NULL, '$2y$10$2Yk4iXclYo4TCuS1PGU3TuXUSbCXlfUk44Ke5kOsiB63jkQzEp6Ee', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1320, 'ROOTS TEAS LLC', 'ROOTS TEAS LLC', '2395992921', 'store1183@teamafricorp.com', NULL, '$2y$10$HpPf2TocsGnGTQRpvu6YZesqrJG8cewIO2bMGBBMtTXM6pITblldW', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1321, 'FLORALE LLC', 'FLORALE LLC', '3074131755', 'store1184@teamafricorp.com', NULL, '$2y$10$3fEGsmAYXTbt4GFp2XoWr..xYagQOaKw7/8xDglUr8ZKKPkjCV.0i', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1322, 'SCHEEL BRITTANY DAWN', 'SCHEEL BRITTANY DAWN', '8635294484', 'store1185@teamafricorp.com', NULL, '$2y$10$GLvxc6XIe3YeerGjlVgzcuo3KmGfWAA0Js.3PjzSQTKHplGwPAnUO', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1323, 'CAFE DE LUXE LLC', 'CAFE DE LUXE LLC', '7183004767', 'store1186@teamafricorp.com', NULL, '$2y$10$VI5sGZZBAk6P7LMFis0kje./K0kKllBtil7xHkB5maMN9y4uOyOQm', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1324, 'EGGCETERA INC', 'EGGCETERA INC', '2397918227', 'store1187@teamafricorp.com', NULL, '$2y$10$NjHYWe/mxa2P2mVGvaWw/u1hHfVyKgsAdk5So4MuBsIO6ZP6TGWr.', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1325, 'ENCHANTED MACARONS LLC', 'ENCHANTED MACARONS LLC', '2394705439', 'store1188@teamafricorp.com', NULL, '$2y$10$odzobVLi23NS9cFnZ6Xtl.hACT2X2HLO/dBxcsdGkSo4zHH4JMHBi', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1326, 'EL GAUCHO INCA BISTRO INC', 'EL GAUCHO INCA BISTRO INC', '2396013202', 'store1189@teamafricorp.com', NULL, '$2y$10$IYDfH7rOK1Lv0r6NEoBe7.eZuUiGieNKvEbHZgKEuwWjE22.lwxZO', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1327, 'LEHNE BURGER ESTERO LLC                           ', 'LEHNE BURGER ESTERO LLC                           ', '2392995731', 'store1190@teamafricorp.com', NULL, '$2y$10$G3nP3NCk45X/gsUsFzaz3ODMCPDIyTBkNYUf.AtfqWj5.7cAlX.mm', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1328, 'DKGK INVESTMENTS LLC                              ', 'DKGK INVESTMENTS LLC                              ', '2395742141', 'store1191@teamafricorp.com', NULL, '$2y$10$G4.c3atiRdiRTNZNd0sNauP2myL.m7ibGppXEO.NkQeKDerl9m.1y', NULL, '2022-01-22 18:46:44', '2022-01-22 18:46:44', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1329, 'JACMEL CARIBBEAN RESTAURANT LLC', 'JACMEL CARIBBEAN RESTAURANT LLC', '2396000092', 'store1192@teamafricorp.com', NULL, '$2y$10$eYSSvcxzdTQI/LFJKPhvKOMOEXiHYP/4P9nJmwjlLR3nT4u9tcBTa', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1330, 'JOES FRESH CATCH LLC                              ', 'JOES FRESH CATCH LLC                              ', '2079759910', 'store1193@teamafricorp.com', NULL, '$2y$10$eSMaueOM72pNUlmcRmMNm.s4GLbuktD3MgDys/V9kULQT9PSvHP5y', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1331, 'BBR DONUTS LLC', 'BBR DONUTS LLC', '3057663723', 'store1194@teamafricorp.com', NULL, '$2y$10$PPwdl0mO9OdP.xtF4pZi3.tv.Dm.6xzrFqNPidrnHLLNmZhsVrbWO', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1332, 'FSI AND ALI INC', 'FSI AND ALI INC', '4073994630', 'store1195@teamafricorp.com', NULL, '$2y$10$yzdDfsxgvVjCX0xkdt5d9.T1c66GTDSDH45xhzFPOy2NXkSuUvVPa', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1333, 'MY CELTIC CORNER INC                              ', 'MY CELTIC CORNER INC                              ', '2393219183', 'store1196@teamafricorp.com', NULL, '$2y$10$OjV27OXZ8TvvR3xPt/EqmOPngJ8nqesNSfW1hr.rRJ.iQhfFQmRbq', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1334, 'SWEET REAL LLC                                    ', 'SWEET REAL LLC                                    ', '2396331213', 'store1197@teamafricorp.com', NULL, '$2y$10$/Anaf666PEo2ENZbpQk03.NgoWjsb2iu/EAw00yg4XtC.zkKAy2AG', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1335, 'TIENDA EL QUETZAL INC', 'TIENDA EL QUETZAL INC', '2399477600', 'store1198@teamafricorp.com', NULL, '$2y$10$rbKD205d2eFodfPOM.AqV.i0XQ7uk1uo/UT/Q8eMdTrRKdlKOaEwa', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1336, 'FREVELETTICOLBERT LINDA J', 'FREVELETTICOLBERT LINDA J', '8158736934', 'store1199@teamafricorp.com', NULL, '$2y$10$rfOxWec/Ez19Gv1DDc1Om.rcxp6a9o6OaaNff0oDw1SDbt8KfS6WK', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1337, 'WONDERLAND COOKIE DOUGH AND ICE CREAM LLC         ', 'WONDERLAND COOKIE DOUGH AND ICE CREAM LLC         ', '2398501876', 'store1200@teamafricorp.com', NULL, '$2y$10$EGs4C18/MF9b3VMgCHG2SehNLHupYiSKmHVb4MTQdSPz.cFYM1H2y', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1338, 'AMI 90LLC', 'AMI 90LLC', '2393623716', 'store1201@teamafricorp.com', NULL, '$2y$10$LTbFwXt3afQ/t1or6guLa.0GR6m0Hd.7fb2UWDQ09aBUAM1O.9vZ.', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1339, 'A M D EL AJACUTLA ICE CREAM CORPORATION', 'A M D EL AJACUTLA ICE CREAM CORPORATION', '2396346194', 'store1202@teamafricorp.com', NULL, '$2y$10$C1gFalumOiwPBHWH3i3/r.ue97d7fhBMUMjQTEPpAlUxW/khto0LO', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1340, 'GLADESMENS BEST LLC', 'GLADESMENS BEST LLC', '2393495053', 'store1203@teamafricorp.com', NULL, '$2y$10$9BjLcsLeVelyeGMP87u6qOevjCzry.1O0TdilbzwCpCl.EqBSYF32', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1341, 'PUNTA GORDA ISLE SECTION 22 HOMEOWNERS ASSOCIATION', 'PUNTA GORDA ISLE SECTION 22 HOMEOWNERS ASSOCIATION', '9416394151', 'store1204@teamafricorp.com', NULL, '$2y$10$bUoaIAu50GtJc3pbxNZD2uYWMaV/3sAhFWg4HglcL7OGW34/aWjaK', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1342, 'KONCRETE KITCHEN LLC                              ', 'KONCRETE KITCHEN LLC                              ', '9547409856', 'store1205@teamafricorp.com', NULL, '$2y$10$5CJB0gA1Y6W8.AIH4XL2M.fm3Uz6RZYPXEVvGDtNJTLUJu3gGacHS', NULL, '2022-01-22 18:46:45', '2022-01-22 18:46:45', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1343, 'JC ALL FLOORING INC', 'JC ALL FLOORING INC', '2396010906', 'store1206@teamafricorp.com', NULL, '$2y$10$AgdGoEmJUo0/kuUpyzX5auNBB7VyBQEXJyR54t69uZvcOdIOHORi6', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1344, 'HAPPY SUN ICE CREAM INC', 'HAPPY SUN ICE CREAM INC', '2392467409', 'store1207@teamafricorp.com', NULL, '$2y$10$2j2v7SIdpA/oN9G5QD/W2OqqXtLj/IHCXNAnDuxImonzxtY87PhuW', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1345, 'THE ZONE NUTRITION LLC', 'THE ZONE NUTRITION LLC', '2693171396', 'store1208@teamafricorp.com', NULL, '$2y$10$SR6QwSCM6eURN5bOj.F3cepqe7RRaSaNFlMDMCemYFl.aZU4OGfua', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1346, 'THE ZONE NUTRITION LLC                            ', 'THE ZONE NUTRITION LLC                            ', '2693171396', 'store1209@teamafricorp.com', NULL, '$2y$10$kzJwbYNjBaJolQzFY1YfXeGat1Zp8vjC5KS2d.zC3P0bAAwqjPiPS', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1347, 'MILBURY DOUGLAS V', 'MILBURY DOUGLAS V', '6038563055', 'store1210@teamafricorp.com', NULL, '$2y$10$It0L7fNcrrnI2aPkSmkNDeAAt5x.p3oToN5GbNPTz4GxWsubmvJu.', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1348, 'FLORIDA SHORES RESTAURANTS INC', 'FLORIDA SHORES RESTAURANTS INC', '2392097752', 'store1211@teamafricorp.com', NULL, '$2y$10$yS8PVu.ltTh1vqAShPTfdexjmq0O5AmGv8xzKq72HDuU.VHshLldO', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1349, 'BOBA TEA LLC                                      ', 'BOBA TEA LLC                                      ', '6194528572', 'store1212@teamafricorp.com', NULL, '$2y$10$DQWm.tHWgDk/M5xA1K9lwu4/ioL7xkJ4JXLHwFE5yU7xhVjNbFmnS', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1350, 'SHARKMIND LLC                                     ', 'SHARKMIND LLC                                     ', '2392885459', 'store1213@teamafricorp.com', NULL, '$2y$10$brdHwKtPgPTCT1WjnlDASOAQ/cmKpDFyGMR/EcOz8KKnlUz3Xj9Jq', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1351, 'FELETES HOLDINGS LLC                              ', 'FELETES HOLDINGS LLC                              ', '2397037651', 'store1214@teamafricorp.com', NULL, '$2y$10$3pWONSIT4orjTHF1c0aEXeMVFjdjsMhVPVD5XeUkG435XhMjkjOG6', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1352, 'GULF COAST NECTAR LLC', 'GULF COAST NECTAR LLC', '2392925803', 'store1215@teamafricorp.com', NULL, '$2y$10$laSM65UC9.V7kBuhitXP.OjmdMHmxaHQiThl2NrVTvupbVExctKbe', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1353, 'FDR WINGS IV LLC                                  ', 'FDR WINGS IV LLC                                  ', '2394002060', 'store1216@teamafricorp.com', NULL, '$2y$10$nw32gmY3oTAzKQJGovS/mOQgz.4TqD5GxKJh0KWUVRPHx/0cObAZa', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1354, 'STRAWBERRYSWEETWAY LLC', 'STRAWBERRYSWEETWAY LLC', '3218051740', 'store1217@teamafricorp.com', NULL, '$2y$10$Slvvv8CcpU3UZ6NPga8./egQaWvHjZpQvOouEjJYawiqkVMYvwxui', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1355, 'LIVING OUR BEST LIFE LLC', 'LIVING OUR BEST LIFE LLC', '6143822541', 'store1218@teamafricorp.com', NULL, '$2y$10$uuM6OBu8bmxZ9lUkVjy0QOxTEETjbCf9m1XwvT87rR20t8fgAFlNm', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1356, 'METTINOS LLC', 'METTINOS LLC', '2396010129', 'store1219@teamafricorp.com', NULL, '$2y$10$X9kt.6XswXaJEFkeOjl/c.kYRp5fhTBjMPfwL6TxN.nsfBzxTf7Ui', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1357, 'NAUTI PARROT OASIS IN', 'NAUTI PARROT OASIS IN', '2399909901', 'store1220@teamafricorp.com', NULL, '$2y$10$ZdHCv4vkRD0ZlAiTnoa.0uoJC4tIIYkB3pM/xLkDvRfBMgYDjvkq.', NULL, '2022-01-22 18:46:46', '2022-01-22 18:46:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1358, 'FRIEND FOOD STORE LLC                             ', 'FRIEND FOOD STORE LLC                             ', '7863446308', 'store1221@teamafricorp.com', NULL, '$2y$10$YeJdP2KYf3KPXE6Oqaw4pOtinBcAIwqPBi3844urPKzLCjhPW6IwS', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1359, 'ISLAND LOCO NUTS INC                              ', 'ISLAND LOCO NUTS INC                              ', '2243742048', 'store1222@teamafricorp.com', NULL, '$2y$10$9wsvsU13IOb6H40YKOfyKOuXT6FikwlA6qgl2crHRJWt9kK2545Ku', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1360, 'CHELLIS  ROCHELLE L', 'CHELLIS  ROCHELLE L', '2398229135', 'store1223@teamafricorp.com', NULL, '$2y$10$T8E2Hvh7P.el86u4jjUIzerHkPz9kKd6rJrmreju4oIXgQgZhtl7y', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1361, 'BEACH FOODIES LLC', 'BEACH FOODIES LLC', '2394720547', 'store1224@teamafricorp.com', NULL, '$2y$10$fRBSjMOfc2hZ3EG8z5aiceXTjVob/e0qv5RbUDlX6xRwvdLMZWtRS', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1362, 'M Z INVESTMENT INC', 'M Z INVESTMENT INC', '2393135583', 'store1225@teamafricorp.com', NULL, '$2y$10$/dcP6faiRdOj1DfrkK1QouCg9/.C2s7CTDzg9QX3pvyHDCH3lvSgO', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1363, 'MEDITERANEO LLC', 'MEDITERANEO LLC', '2399494038', 'store1226@teamafricorp.com', NULL, '$2y$10$dxVXZ971ft8DujY35RSJlO3xG6RP3BVQ/3ug1nG/IGJjv40QxMSLO', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1364, 'BREW BOX COFFEE COMPANY LLC', 'BREW BOX COFFEE COMPANY LLC', '3472033086', 'store1227@teamafricorp.com', NULL, '$2y$10$lUwsnc4TQPr3li3jVb9DKOltqHnFDptoXSqvSsxFaIFjyaPokk7MO', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1365, 'KORESHAN GAS INC                                  ', 'KORESHAN GAS INC                                  ', '2399499350', 'store1228@teamafricorp.com', NULL, '$2y$10$qz1aOdpjRX6SNdrDOdBCauCArnqrazNBlSWvtdwj6RF60ITjn/xWS', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1366, 'NBF HART AND SOUL LLC', 'NBF HART AND SOUL LLC', '2392996536', 'store1229@teamafricorp.com', NULL, '$2y$10$v2aRh/ngHCjsqjpT0LCk/OMYFttInqQ8AWe1k8URAw0PbJVJHJThm', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1367, 'D PIZZA JOINT LLC                                 ', 'D PIZZA JOINT LLC                                 ', '2399108206', 'store1230@teamafricorp.com', NULL, '$2y$10$82fN/Wx3AVIiPUSRjBNu/e2TmqgahEEGCIpCD7H1B.rMD2t4d1nnC', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1368, 'COCONUT ISLAND MARKET INC                         ', 'COCONUT ISLAND MARKET INC                         ', '2397383898', 'store1231@teamafricorp.com', NULL, '$2y$10$tDoDjqFGJIfsNz7x8lYz4OC4QNn4Qh.G4EEnvUse4PxLpkUaaksN2', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1369, 'THE NAUTI BAKER LLC', 'THE NAUTI BAKER LLC', '2393124955', 'store1232@teamafricorp.com', NULL, '$2y$10$6SabQlAWc0/emj7Gx6/ja.Le90WPwQOFGpEMIJZ812wJI0/QaBeLi', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1370, 'SANGIOVANNIS ITALIAN BAKERY LLC', 'SANGIOVANNIS ITALIAN BAKERY LLC', '2397890507', 'store1233@teamafricorp.com', NULL, '$2y$10$qx/c9GUBj7mbXNa3LL57LOLBMp5rH.b3a2bEfp2pTeZldCYMlJbP6', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1371, 'EINSTEIN AND NOAH CORP                            ', 'EINSTEIN AND NOAH CORP                            ', '2398296495', 'store1234@teamafricorp.com', NULL, '$2y$10$vfJkTcO.QHO1kknRKF9H3.2STOxcTtenG/Ox/ciUzCduvHQZFaypm', NULL, '2022-01-22 18:46:47', '2022-01-22 18:46:47', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1372, 'NR NETWORKS LLC                                   ', 'NR NETWORKS LLC                                   ', '2392167501', 'store1235@teamafricorp.com', NULL, '$2y$10$nPOHkgfTHESZVzpGmjK5peV9hB7AylXoe5jDe0iFlqPyM75GbLeTm', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1373, 'BCN PAELLAS LLC                                   ', 'BCN PAELLAS LLC                                   ', '2392217575', 'store1236@teamafricorp.com', NULL, '$2y$10$MuDNvac7v2r6xqAWNgckHOKFFCenScx.AgsoFzCrQW2jIZEf7afW.', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1374, 'SOUTHERN FOODS GROUP LLC', 'SOUTHERN FOODS GROUP LLC', '9542949229', 'store1237@teamafricorp.com', NULL, '$2y$10$.gCmXkOxJDo1YZSm9eAaVu/qrDiMQxGy04DjFp4dSazOsuDnQ61O.', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1375, 'SWEET ALIS LLC                                    ', 'SWEET ALIS LLC                                    ', '2399405321', 'store1238@teamafricorp.com', NULL, '$2y$10$rl6UgxY7MjE8ncGg89i3yOadNg2iI79FLfmtcxhmrjd58YCqCTLdy', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1376, 'CSC MERCHANTS CROSSING LLC                        ', 'CSC MERCHANTS CROSSING LLC                        ', '2396523181', 'store1239@teamafricorp.com', NULL, '$2y$10$BD3eaq6CKNSdAe0FkxVvwOjmIc4/4OEGy1gizvStas/PaQkHcCQMy', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1377, 'MIONE PIZZA LLC                                   ', 'MIONE PIZZA LLC                                   ', '2397728586', 'store1240@teamafricorp.com', NULL, '$2y$10$F7qwzuSWl0.9/MjlfqdWVO9vUcYB4Kir40PSW0M3jCewKv18tUVvm', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1378, 'NAUTI TIKI SEASONINGS LLC                         ', 'NAUTI TIKI SEASONINGS LLC                         ', '2393086121', 'store1241@teamafricorp.com', NULL, '$2y$10$Sz7tgwf2mkkh0usCI1yD7uoqBupflhJ52TVj0HTFAkPyHbasUOiZi', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1379, 'BMC OF BOKEELIA INC', 'BMC OF BOKEELIA INC', '2395584046', 'store1242@teamafricorp.com', NULL, '$2y$10$r2yoY4J/mMUA6m.ZjBTFYuArYuA2sAOO5Wtju0fu6rnoN4hyVLRRS', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1380, 'DOLCE GUSTO ITALIAN MARKET & PASTRY', 'DOLCE GUSTO ITALIAN MARKET & PASTRY', '2394828727', 'store1243@teamafricorp.com', NULL, '$2y$10$DR.VUEQEeCn8PPVjF1dXvuhdN/5OtRy0BZTSth77D/7Ltj2IZAlie', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);
INSERT INTO `vendors` (`id`, `f_name`, `l_name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `bank_name`, `branch`, `holder_name`, `account_no`, `image`, `status`, `firebase_token`, `auth_token`) VALUES
(1381, 'LA PARISIENNE LLC', 'LA PARISIENNE LLC', '2392220059', 'store1244@teamafricorp.com', NULL, '$2y$10$8Ot4GXntoECE/3sDm79ZgOiPAK/voSiL.T7RnGkJwitAp2JBkkgTa', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1382, 'BELLA VIDA BOCA GRANDE INC                        ', 'BELLA VIDA BOCA GRANDE INC                        ', '9418559534', 'store1245@teamafricorp.com', NULL, '$2y$10$KJmIL/FXWcRKzXFlkVs66eXVbaH1H4W83zIaGN9SV6hsxWFJl5I1G', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1383, 'BLACK JESSEMIAH', 'BLACK JESSEMIAH', '9073154504', 'store1246@teamafricorp.com', NULL, '$2y$10$yWPIoYDyAnzjxfFWTFOgve6HJBtd2XsyenBHxg2/k8SsUn.YxG3U6', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1384, 'DRUS WEST INDIAN ROTI SHOP LLC', 'DRUS WEST INDIAN ROTI SHOP LLC', '2397452519', 'store1247@teamafricorp.com', NULL, '$2y$10$7uSTJ7MFCZLVTK1J/SNZVOEzyPbIGX.bxYERY6bAqlcXdC/4lrxXG', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1385, 'FDR WINGS V LLC', 'FDR WINGS V LLC', '2394002060', 'store1248@teamafricorp.com', NULL, '$2y$10$V89bbIUDHcnOhVrpsvixgeePXzyQKvicn67wgKQ81xosbYJFlYSqW', NULL, '2022-01-22 18:46:48', '2022-01-22 18:46:48', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1386, 'BETTER STEAMING INC', 'BETTER STEAMING INC', '2392978739', 'store1249@teamafricorp.com', NULL, '$2y$10$7Gux9KlS4rLGBbbfEpnVxefdMHcF6/cGGNUYTYjz3QOzJ6Zjjz5WC', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1387, 'SWEITI INC', 'SWEITI INC', '2396001170', 'store1250@teamafricorp.com', NULL, '$2y$10$l5rLEshiJr3sTKbV/ETZ4.9x6ldnp5q9IQf9.A751sMz0rtts2PDG', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1388, 'CITANOS CAFETERIA INC', 'CITANOS CAFETERIA INC', '2394715738', 'store1251@teamafricorp.com', NULL, '$2y$10$Oj1D8n41TRcU0DhVJ0pcWutxSVQKexMZb4tPuirOGcPRUyBUnt2ni', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1389, 'NAVARRO  ALINA                                    ', 'NAVARRO  ALINA                                    ', '2392466698', 'store1252@teamafricorp.com', NULL, '$2y$10$2HIdJvrNhzrZGDAthAowh.EqBQyM18s0nsKkm.hULWclUHaV.3O4i', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1390, 'PINOCCHIOS ORIG ITAL ICE CREAM OF SANIBEL ISL INC ', 'PINOCCHIOS ORIG ITAL ICE CREAM OF SANIBEL ISL INC ', '2394726566', 'store1253@teamafricorp.com', NULL, '$2y$10$f/iYTvRTOzGdZSaFOsNXUOo.eQfnxeoseAZjsyjU/0WEtANG6Mt6i', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1391, 'BLISS VAPE LOUNGE LLC', 'BLISS VAPE LOUNGE LLC', '2392462493', 'store1254@teamafricorp.com', NULL, '$2y$10$pYsbH/HK48VuICbtCF.CXuQKxrzrWK/W.6h5AqZ/uWfMiH3LOAksi', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1392, 'BJS CAFE AND STUFF LLC', 'BJS CAFE AND STUFF LLC', '7325523640', 'store1255@teamafricorp.com', NULL, '$2y$10$TAX939n96ej3IIRAMOVL7Oo8Gx2ev7cJcojpfEFwkSTqO.q1UpQSa', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1393, 'QUESO TIME FL 1 LLC', 'QUESO TIME FL 1 LLC', '2399800616', 'store1256@teamafricorp.com', NULL, '$2y$10$Djal7sRTyXjQmoDPK1F9rexgT9Fzw/WFgV0nYMzWkuvsw7c5pFc8G', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1394, 'MOM & POPS CANDY KITCHEN COMPANY', 'MOM & POPS CANDY KITCHEN COMPANY', '8456291639', 'store1257@teamafricorp.com', NULL, '$2y$10$j6Po.WzmVCsjis.CVWYg1uMfO.vK85.YXA4xbxAZMP/2W4nMTB3bK', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1395, 'S & L PROPERTIES SKYLINE LLC', 'S & L PROPERTIES SKYLINE LLC', '6087422893', 'store1258@teamafricorp.com', NULL, '$2y$10$dcGUmbUG.WCpL9kVQqfG6OS22gMJd5gUs6braOQdwJtcZsqRHe44e', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1396, 'ANDERSON ENTERPRISE GROUP INC', 'ANDERSON ENTERPRISE GROUP INC', '2395418207', 'store1259@teamafricorp.com', NULL, '$2y$10$Pr4Jj086CdmPkAROn8DmHuz64MspoTv7CoKysDt3O1VqEcs2yZQeO', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1397, 'HOOK SEAFOOD & WINGS INC                          ', 'HOOK SEAFOOD & WINGS INC                          ', '2399845493', 'store1260@teamafricorp.com', NULL, '$2y$10$6nqkw1v3NXP6MGIP5hrQwu41ABWhRp8EYDKqAjm6nrzlXWo3cRvTa', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1398, 'AMD D RESTAURANT CORP', 'AMD D RESTAURANT CORP', '2396346194', 'store1261@teamafricorp.com', NULL, '$2y$10$SUwKVygSdYUq3wlHoRuq0uVLLRLLxNPgrOeejc/6OuUBAL1HK3t12', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1399, 'JOJOS BOWLS 121 LLC                               ', 'JOJOS BOWLS 121 LLC                               ', '8473637052', 'store1262@teamafricorp.com', NULL, '$2y$10$yD15F.YAClMwaG8lhnYCK.YGxiB.KENWA3cWxdc1qf.OktiXsyXAS', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1400, 'HART JAMES                                        ', 'HART JAMES                                        ', '8473050056', 'store1263@teamafricorp.com', NULL, '$2y$10$Qz.xdAsf04jTy8VdUm0dPu/Bm/a8f4YHcM79CYvgCJFQWz7da0nSm', NULL, '2022-01-22 18:46:49', '2022-01-22 18:46:49', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1401, 'HJ CUISINE INC', 'HJ CUISINE INC', '2398490622', 'store1264@teamafricorp.com', NULL, '$2y$10$4JRZCbLpB8BLRYjYXfEN6elqjS1RvGBu9NXVThPHgEwtFp5XP7sLe', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1402, 'BETTERSTEAMING INC                                ', 'BETTERSTEAMING INC                                ', '2392978739', 'store1265@teamafricorp.com', NULL, '$2y$10$KDPA3xuUB.pBRl0w6qPTmuP6X03s8GnizEvR0gjmylURjNlfnIhUm', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1403, 'TOPGOLF USA FT MYERS LLC                          ', 'TOPGOLF USA FT MYERS LLC                          ', '2145015052', 'store1266@teamafricorp.com', NULL, '$2y$10$kazLNbONGqsx9yjZSR7aUe3QYLgm8vMFNc.s4SEQl6kJkiR7i9G.m', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1404, 'REAL FRUIT SMOOTHES & ICE CREAM LLC               ', 'REAL FRUIT SMOOTHES & ICE CREAM LLC               ', '2392402323', 'store1267@teamafricorp.com', NULL, '$2y$10$/jMr0EtacfID3otwPOn14ONorMLouEczaW7ggyILzQMp84BQ3N/s.', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1405, 'EDIBITES LLC', 'EDIBITES LLC', '2292513938', 'store1268@teamafricorp.com', NULL, '$2y$10$Q/NBsAwdI9e7U6LMwprVBOlOEEHcek9o/X.WJAypksUjFisV/Z.UK', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1406, 'THAT BBQ PLACE LLC', 'THAT BBQ PLACE LLC', '2393128557', 'store1269@teamafricorp.com', NULL, '$2y$10$UmzZjiKm3n.c4ENZlAqdfu4qVskvKjix4WILqt/W6DmyYpiL9T7M2', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1407, 'PATRICIAS TAMALES LLC                             ', 'PATRICIAS TAMALES LLC                             ', '2394002060', 'store1270@teamafricorp.com', NULL, '$2y$10$o8epAxnNJtUANJI4ntJJveaiZPRkzndSAEErPyqDqNAuVHpDkoMmy', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1408, 'MICHOACANA ICE CREAM INC', 'MICHOACANA ICE CREAM INC', '2394382792', 'store1271@teamafricorp.com', NULL, '$2y$10$By8..EjDVVEgz4kwNINkj.Yx3kKcY44fZ4kK9s.niQyeJG/UH9HPa', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1409, 'MODEB LLC', 'MODEB LLC', '7276426565', 'store1272@teamafricorp.com', NULL, '$2y$10$jYgYeUjJ57sVEjOLMrmbO.3KYceTQiHijU4OCQrTfAlQiaBhac68S', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1410, 'BAHIA BOWLS BONITA SPRINGS LLC', 'BAHIA BOWLS BONITA SPRINGS LLC', '4436437938', 'store1273@teamafricorp.com', NULL, '$2y$10$NfsvbEuaDma1iOZWdlkb7.bXS8qZiL3ahNQ5dQ/JzFqJ5kcTQn93u', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1411, 'HIBACHI HOUSE INC', 'HIBACHI HOUSE INC', '2396728968', 'store1274@teamafricorp.com', NULL, '$2y$10$3N9pnE68DBxVKFRgCC810OEIeWgcC3vo8O73EHiBDzs8wgKm2k33S', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1412, 'ADAM NARDIS AND ERIN NARDIS', 'ADAM NARDIS AND ERIN NARDIS', '2392205918', 'store1275@teamafricorp.com', NULL, '$2y$10$SZ8F0orSvNbjiJvSjB5vXe4vCcLislmLBBo.OMqp5OLmAKh.7wLD2', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1413, 'GULYAS FACTORY CORP                               ', 'GULYAS FACTORY CORP                               ', '2395402000', 'store1276@teamafricorp.com', NULL, '$2y$10$s3UQAzynrPmP9NMsMKecyuELl.fccxV7ZDdbzBU5UK52rW6ef8zR6', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1414, 'CHOCOLATTES ROASTING LLC                          ', 'CHOCOLATTES ROASTING LLC                          ', '2398981216', 'store1277@teamafricorp.com', NULL, '$2y$10$dkExePUiOL5BcP6JYs/Dau8JLOGKcGtM5N4pEASYzBMsUUl7sVzrG', NULL, '2022-01-22 18:46:50', '2022-01-22 18:46:50', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1415, 'BRAVOFLORIDA LLC                                  ', 'BRAVOFLORIDA LLC                                  ', '5742714600', 'store1278@teamafricorp.com', NULL, '$2y$10$TCAUC1.nhOR9y10MmaauR.zH/R1Jw0uE8n/ZqsEGgkn7dK0OXi0Gm', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1416, 'CKJ ENTERPRISES INC                               ', 'CKJ ENTERPRISES INC                               ', '2395744454', 'store1279@teamafricorp.com', NULL, '$2y$10$NcuoiIsKweEoEA9thTJzhOWdu5QRIMENCRYNoNvcBkWYOkGrRmKbW', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1417, 'P B AND G FOODS                         ', 'P B AND G FOODS                         ', '2396942145', 'store1280@teamafricorp.com', NULL, '$2y$10$ATsKG638ODWU8abLsF97..n9mIgNvVNcJsBk6Mm9..e2N0LAAorxS', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1418, 'LIGHTHOUSE CAFE DE SANIBEL INC                    ', 'LIGHTHOUSE CAFE DE SANIBEL INC                    ', '2394720303', 'store1281@teamafricorp.com', NULL, '$2y$10$tKZKuae7vqaYCadmViX1xeC84yeYh9o.ssIGpMEKmQUypvwJgnnLi', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1419, 'S HOMSI INC                             ', 'S HOMSI INC                             ', '', 'store1282@teamafricorp.com', NULL, '$2y$10$QU54OFhPionSoALB0/cSBe412XryYoQjmTWJUf5WalRrq2Ee.7MAS', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1420, 'WELKER MOMS CRACKER BOX INC             ', 'WELKER MOMS CRACKER BOX INC             ', '2394664344', 'store1283@teamafricorp.com', NULL, '$2y$10$6Is7n0owDT3uVL/8v1yTwe5Sjxp/FY94HQy4VjpuJ8um.2Yh7vM.e', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1421, 'RED LOBSTER HOSPITALITY LLC                       ', 'RED LOBSTER HOSPITALITY LLC                       ', '2399368216', 'store1284@teamafricorp.com', NULL, '$2y$10$dhF83mJTGxcd5sSmQwxD9er9y0NAoriEKhfM2yA8r28JdqFFEYA6.', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1422, 'THE TEMPTATION RESTAURANT OF BOCA GRANDE LLC      ', 'THE TEMPTATION RESTAURANT OF BOCA GRANDE LLC      ', '9419642610', 'store1285@teamafricorp.com', NULL, '$2y$10$e9GBMz1OxaD4yh8UHpb1WeMR1FHVfveGIvwJGeAsVzAU.rcUE8ZZK', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1423, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '7327506350', 'store1286@teamafricorp.com', NULL, '$2y$10$QLJkqS9m2vtktQ33DUFwbeOCfJQSnFpvi7tEHCgq5SgkxYJnX/0Eq', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1424, 'WHISKEY CREEK GOLF CLUB INC             ', 'WHISKEY CREEK GOLF CLUB INC             ', '', 'store1287@teamafricorp.com', NULL, '$2y$10$qPRjfRYuDsnArIgRhA7VJuYQNm5E3UlPr7aI6oyka5G.NF6pJvo/2', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1425, '7 ELEVEN INC & MASSOOD ALI                        ', '7 ELEVEN INC & MASSOOD ALI                        ', '2395496799', 'store1288@teamafricorp.com', NULL, '$2y$10$nkmNRuqrvRemACD7hJoyFeo5eVTT7n1ciRLSHkP967sqUvXNPJ2da', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1426, '4 FAMILIES INC                                    ', '4 FAMILIES INC                                    ', '2394633402', 'store1289@teamafricorp.com', NULL, '$2y$10$TbPnyGpEqbDbSSsVCiOPv.vfA0OMMkXngcAAPdo9kcj47VwyroaWe', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1427, '7 ELEVEN INC & LSE OF SOUTHWEST FLORIDA INC       ', '7 ELEVEN INC & LSE OF SOUTHWEST FLORIDA INC       ', '2394729197', 'store1290@teamafricorp.com', NULL, '$2y$10$yhtPAxZCjzQaeni8qw/cdOzvS2xcF7WSNZ5mTlNeyJrGMrokZ1c72', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1428, 'MINETTIS LLC                                      ', 'MINETTIS LLC                                      ', '2399927719', 'store1291@teamafricorp.com', NULL, '$2y$10$kvAJIYpjQos/nLHH1qDm1eidiXvpFignz7Ls6/FOG0.A5UxHVSTZq', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1429, 'MARTIN ROBERT                           ', 'MARTIN ROBERT                           ', '', 'store1292@teamafricorp.com', NULL, '$2y$10$8E1G/d6Nsuze36cN3M989OtoouL5vAj2.4L5eemnUoZRp6/Sq4Nv6', NULL, '2022-01-22 18:46:51', '2022-01-22 18:46:51', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1430, 'SIX LAKES COUNTRY CLUB INC                        ', 'SIX LAKES COUNTRY CLUB INC                        ', '2399950595', 'store1293@teamafricorp.com', NULL, '$2y$10$cq.0ymyHf.cT7/ld5/pT7eXdXUVLkf5w/hBjyE7Wz4uwGtSJf9gPS', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1431, 'EL RIO GOLF CLUB                        ', 'EL RIO GOLF CLUB                        ', '', 'store1294@teamafricorp.com', NULL, '$2y$10$0YkgCg8URU6nT9eeO9Dgz.qrWG7wkCdw.0AmAEUjo240Bk7o6tKQO', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1432, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '8139106878', 'store1295@teamafricorp.com', NULL, '$2y$10$6EL0Ui5GGQxZxXhXSgEjlOnfjR3aONy5riWmTHc4tioWCyFeTNX5S', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1433, 'DEL PRADO FEC LLC                                 ', 'DEL PRADO FEC LLC                                 ', '2399472111', 'store1296@teamafricorp.com', NULL, '$2y$10$ThHTBm51MBjmD0MyaMOUDe1VU6KXdEM2SdLGN/deR6uH6sHb2HyoO', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1434, 'CHOW HWA CHENS LLC                                ', 'CHOW HWA CHENS LLC                                ', '2393691110', 'store1297@teamafricorp.com', NULL, '$2y$10$gif2vkKIqR.AaG9jS/MZ4ePCnlvsIyZGZs1gbCFILWUYaGwJwK16S', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1435, 'FURMAN ROBERT                           ', 'FURMAN ROBERT                           ', '', 'store1298@teamafricorp.com', NULL, '$2y$10$2sM/nwLqNyXiMtrFzbxNRu.8v8Y3KO6Rm3pVqKZ.4BtU4ue1QIrKe', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1436, 'MAYERON DONALD                                    ', 'MAYERON DONALD                                    ', '', 'store1299@teamafricorp.com', NULL, '$2y$10$Ih6HvCnc7jk55HzAzSNdg.PMD4JUWVRpik.VJYHRiqKMDqM9qH8ta', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1437, 'VERANDA THE                             ', 'VERANDA THE                             ', '2393322065', 'store1300@teamafricorp.com', NULL, '$2y$10$nxop0wdtSxbRUIBmbNHmae7Q2BxYeAWDtH1yD8UbhBc1Az0LLA9RO', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1438, 'QFRM 5 LLC                                        ', 'QFRM 5 LLC                                        ', '4077238103', 'store1301@teamafricorp.com', NULL, '$2y$10$PhHyIR3/UE4m1yenovRzwua7NesKdhV4kH9XJCb3QWZQT287mm8SO', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1439, 'EKAN LLC                                          ', 'EKAN LLC                                          ', '2399974021', 'store1302@teamafricorp.com', NULL, '$2y$10$6GlRJOqvbUO6hdzm4kJISOBi1J.PBWKUw.EkJtLLIg2eyDM9cgorG', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1440, 'SOUTHWEST ENTERPRISES INC               ', 'SOUTHWEST ENTERPRISES INC               ', '2394817377', 'store1303@teamafricorp.com', NULL, '$2y$10$bJfCtKqJJN/bPPoIWbnLS.TLIgTZClevWyxGj9ms1jXln28zfYcoe', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1441, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1304@teamafricorp.com', NULL, '$2y$10$Z.wO.SUJy/dkhtjWsiD/Uu21QSerTTYQxsK63zNRIm553ikcn2Zz2', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1442, 'S HOMSI INC                             ', 'S HOMSI INC                             ', '', 'store1305@teamafricorp.com', NULL, '$2y$10$NbKCa/uaic1Y9BUyxihik.lnPo8cqooP0LTRJ/V2BqdejvnuAoqVS', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1443, 'EURPOEAN AMERICAN BAKING COMPANY INC              ', 'EURPOEAN AMERICAN BAKING COMPANY INC              ', '2396947964', 'store1306@teamafricorp.com', NULL, '$2y$10$SufIUnRxCuri1uBL7KkTcObTA7c92lDhxxJSnbWhaZy3HqURcTHm.', NULL, '2022-01-22 18:46:52', '2022-01-22 18:46:52', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1444, 'BEACH TREATS LLC                                  ', 'BEACH TREATS LLC                                  ', '2394632300', 'store1307@teamafricorp.com', NULL, '$2y$10$7zO4EbePNxVMEKaHUMe5KuV3Q9ATDOJMSa3duKJqXTBRVzCJkRt46', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1445, 'JOF LLC                                           ', 'JOF LLC                                           ', '2399365494', 'store1308@teamafricorp.com', NULL, '$2y$10$/MgDehrfDJk/4uhgZFdOg.e1csTlfroSvKjfjfdhPwPpWJRjSo81C', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1446, 'TJF LLC                                           ', 'TJF LLC                                           ', '2399971367', 'store1309@teamafricorp.com', NULL, '$2y$10$7teCHCzKqgm/mOQvUOkaQue8XhDP4j9WQroXO9B0pnj8gkmubF/QS', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1447, 'P B AND G FOODS                         ', 'P B AND G FOODS                         ', '2399361020', 'store1310@teamafricorp.com', NULL, '$2y$10$b5V320jZ9gWks/gxM13uOenhKvEHc4Fpu4cEdhzUGeN1GG1XEF02G', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1448, 'P B AND G FOODS                         ', 'P B AND G FOODS                         ', '2399971313', 'store1311@teamafricorp.com', NULL, '$2y$10$M6/pbWSCpEHPP/bwmpSQ7./dc.K3ktCyzjQbW4F8mNl0VhaN/uqjm', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1449, 'YUCATAN WATERFRONT INC                            ', 'YUCATAN WATERFRONT INC                            ', '2392830113', 'store1312@teamafricorp.com', NULL, '$2y$10$f1ItQpcGJH5pl/DvQtMwtOSLCUi1qna6/Gnel8srst6dsMWppnAQe', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1450, 'ZORBAS PIZZA RESTAURANT INC                       ', 'ZORBAS PIZZA RESTAURANT INC                       ', '2399925005', 'store1313@teamafricorp.com', NULL, '$2y$10$CXTKMPiZG2zmRj8kazeveOmxGJDSAmYdLKnkgevd6i/sohsZrN7Tm', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1451, 'TJF LLC                                           ', 'TJF LLC                                           ', '2395492556', 'store1314@teamafricorp.com', NULL, '$2y$10$bMXTSgBvc1.gKNZQyGXZGef8fHIgyUrsMoNSYvupYWrCtn5UzMCl2', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1452, 'E W MANAGEMENT INC                                ', 'E W MANAGEMENT INC                                ', '', 'store1315@teamafricorp.com', NULL, '$2y$10$TFwPR4d.GxufRyPbCpTqleMErJ3os2Rm8UHe/lOW.a0qpCQx.EWeW', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1453, 'THE LANDINGS YACHT & GOLF CLUB                    ', 'THE LANDINGS YACHT & GOLF CLUB                    ', '2394823211', 'store1316@teamafricorp.com', NULL, '$2y$10$IN7LloT1MH.GnGcAD0HsyOCCnLI/RwVULJubvG228haW8sk4UdmHO', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1454, 'BROWNDOG FORT MYERS LLC                           ', 'BROWNDOG FORT MYERS LLC                           ', '2394823241', 'store1317@teamafricorp.com', NULL, '$2y$10$mgN0YknenmMvIE/GU6swQeU/qVnjbbm7KX5n8n6.Z8Xrd3cWf5cGS', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1455, 'K & R ADVENTURES LLC                    ', 'K & R ADVENTURES LLC                    ', '2394725323', 'store1318@teamafricorp.com', NULL, '$2y$10$raAXonYRUqqVHZbHNpj/TumvdXJLUrZQ9RogurFPDoQfSUwnINrze', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1456, 'THE TIMBERS OF SANIBEL                  ', 'THE TIMBERS OF SANIBEL                  ', '', 'store1319@teamafricorp.com', NULL, '$2y$10$8S5/whibr3545d7IdNZl2ur9aS/NKJZL5pWO.nUDydpHZR1DI.IwK', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1457, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1320@teamafricorp.com', NULL, '$2y$10$sjG8XaolCtOZG0nekfWT1uSHeZ9lRi0qLJgPxna9ktjMDzHq2Tbs.', NULL, '2022-01-22 18:46:53', '2022-01-22 18:46:53', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1458, 'CAPTIVA FOODS INC                                 ', 'CAPTIVA FOODS INC                                 ', '', 'store1321@teamafricorp.com', NULL, '$2y$10$WKV.LxhlayNeykqgI388NeXwtHyaM6Tc0ge7egAYq6S2v1YT8zdqm', NULL, '2022-01-22 18:46:54', '2022-01-22 18:46:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1459, 'J BAR J INC                             ', 'J BAR J INC                             ', '2399977982', 'store1322@teamafricorp.com', NULL, '$2y$10$C4bxgBmRpnaJW9DEXfOPTOxAyiO9qYLYzRNmUNvg6UsTCN8FkJyIm', NULL, '2022-01-22 18:46:54', '2022-01-22 18:46:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1460, '7 ELEVEN INC                                      ', '7 ELEVEN INC                                      ', '4072953076', 'store1323@teamafricorp.com', NULL, '$2y$10$s3SAoS8OBy2GfKBuqogkYu7F4OrkaV3uwOlaOUDW7eF4fltSF72bq', NULL, '2022-01-22 18:46:54', '2022-01-22 18:46:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1461, 'DOCS BEACH HOUSE INC                    ', 'DOCS BEACH HOUSE INC                    ', '2399926444', 'store1324@teamafricorp.com', NULL, '$2y$10$iWixiS5ybdRMhQfGN6C08Oi7GvZrZ7ddxC5kUT0PK18.OIcWzVeoa', NULL, '2022-01-22 18:46:54', '2022-01-22 18:46:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1462, 'MAILLAKAKIS STAVROS N                             ', 'MAILLAKAKIS STAVROS N                             ', '2394634707', 'store1325@teamafricorp.com', NULL, '$2y$10$UMo5p58tNXQIXxY5OnIMteKGvYh6z3sAssBQz5hyTgDyuZzRq4q3C', NULL, '2022-01-22 18:46:54', '2022-01-22 18:46:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1463, 'FURMAN INC                              ', 'FURMAN INC                              ', '', 'store1326@teamafricorp.com', NULL, '$2y$10$d7/LFPDlXBvbNayFijWCAuUSEytYavMrykVZ6mWprMFVT/ZUGnAiy', NULL, '2022-01-22 18:46:54', '2022-01-22 18:46:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1464, 'TLP REST CORP                                     ', 'TLP REST CORP                                     ', '', 'store1327@teamafricorp.com', NULL, '$2y$10$6YRpG5flYTQ9kdkSg0wGdOp2HWINpWJnRAeW1.oyo4KKgUGUGMRYO', NULL, '2022-01-22 18:46:54', '2022-01-22 18:46:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1465, 'LOBIANCO KEN A & JAMES J                          ', 'LOBIANCO KEN A & JAMES J                          ', '2396931168', 'store1328@teamafricorp.com', NULL, '$2y$10$icBgawO0kJMVbeiQCyqJQOwxHi.teAvr4ZEyXUEYfJrbMbCCzz6La', NULL, '2022-01-22 18:46:54', '2022-01-22 18:46:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1466, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '8132735165', 'store1329@teamafricorp.com', NULL, '$2y$10$zVVxDqJRzywhVRpCKXi8FeRdunuKgiTlOBnhQXETwYRtyXvJdctZm', NULL, '2022-01-22 18:46:54', '2022-01-22 18:46:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1467, 'TONY LAPI                                         ', 'TONY LAPI                                         ', '', 'store1330@teamafricorp.com', NULL, '$2y$10$EPk4Lth8VISZxuwtE727/Ofsk4yeNgLammEyJ.3.jBwF0ee8KCRcm', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1468, 'HALF SHELL LOUNGE INC                   ', 'HALF SHELL LOUNGE INC                   ', '2396336803', 'store1331@teamafricorp.com', NULL, '$2y$10$rlHjOzWU9FI1eFvoEZOVKO9JJRJ4A/tfZGCPnh6xZ3V6NYAutjRPm', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1469, 'TTV LLC                                           ', 'TTV LLC                                           ', '2399362003', 'store1332@teamafricorp.com', NULL, '$2y$10$ALrHNUuVfhxSOTBlKtDDiuZYBgZPmVNG.B2WjYaUt4fNVCzlyJXOO', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1470, 'PERKINS LLC                                       ', 'PERKINS LLC                                       ', '7703251306', 'store1333@teamafricorp.com', NULL, '$2y$10$mn43y69TiuO889QZkNp4i.iCv1L4lSA6VS6BZguraTwSN3fxnhbN6', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1471, 'ADAMS FOODS INC                                   ', 'ADAMS FOODS INC                                   ', '2392638666', 'store1334@teamafricorp.com', NULL, '$2y$10$jbDJdycSg2yrmQuB.oDd6O9M3tl2HtIH3Kudq6p7bEHIwHZzMRuZ6', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1472, 'ARCH RESTAURANTS INC                              ', 'ARCH RESTAURANTS INC                              ', '', 'store1335@teamafricorp.com', NULL, '$2y$10$LWQSliBmMbWmnxU4ioiA0.svulZB0NDjUhx9QDgLefSLZlH3uhs2C', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1473, 'SCHILLING MICHAEL', 'SCHILLING MICHAEL', '2394892226', 'store1336@teamafricorp.com', NULL, '$2y$10$1O74Ra4c0Zt8bWQpLI.49.HEEGQuIb0FHOTS46N.YUUk2j4eKQD8G', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1474, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1337@teamafricorp.com', NULL, '$2y$10$u5CC17SpgR96L26uWbWfHee0h69.jnwRDJFHByGeecWGSJ.o2Bs52', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1475, 'QFRM 6 LLC                                        ', 'QFRM 6 LLC                                        ', '4077238103', 'store1338@teamafricorp.com', NULL, '$2y$10$PG8LFvPBnDlbCiz0QHYNY.4.ghtK1WLJxYaCaX.7DNXSGVYGker4y', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1476, 'QFRM 5 LLC                                        ', 'QFRM 5 LLC                                        ', '4077238103', 'store1339@teamafricorp.com', NULL, '$2y$10$JQPbphyjnkx6Mn/ArkExHe.OvZv79vLslLqRxKrKVB2oePp1UZWwa', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1477, 'HALPERN DANIEL J                                  ', 'HALPERN DANIEL J                                  ', '4045235744', 'store1340@teamafricorp.com', NULL, '$2y$10$OJyrKKFFAnPJv2uMgSRoX.4A4YVhKwIWKT7H9iA8LTrSvE9k.EH7W', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1478, 'CARISCH INC DBA ARBY\'S                  ', 'CARISCH INC DBA ARBY\'S                  ', '9524734291', 'store1341@teamafricorp.com', NULL, '$2y$10$EGsJ.hjGDbRxafasL/GQ0.ei6lifg/qfvWnMAOZlcWdmgOOaYq9WS', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1479, 'NAPLES FT MYERS KENNEL CLUB             ', 'NAPLES FT MYERS KENNEL CLUB             ', '', 'store1342@teamafricorp.com', NULL, '$2y$10$rGpolEXlVnOazW0Jr.JU1u/AQe/7CKBA67692katJ9Zswk8juPkpm', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1480, '7 ELEVEN INC & 4 FAMILIES INC                     ', '7 ELEVEN INC & 4 FAMILIES INC                     ', '2394638726', 'store1343@teamafricorp.com', NULL, '$2y$10$XlaK8YGDN9XizlMzGWDA8.qDSZztsHUh4JGMI8ZKaKP9ukL.Zf9aa', NULL, '2022-01-22 18:46:55', '2022-01-22 18:46:55', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1481, 'GREENWOOD ALFRED                        ', 'GREENWOOD ALFRED                        ', '2399471000', 'store1344@teamafricorp.com', NULL, '$2y$10$.Nig89GOjJiDmxgNiEMcSenL9r8HtXCYCcDWdBlnjDRuuWJ53BXaG', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1482, 'FLR INC                                 ', 'FLR INC                                 ', '', 'store1345@teamafricorp.com', NULL, '$2y$10$WisgVLO.pihqV8QY8xav7.iuDyADun..GAp8HUfiG9iUNJ4XQXa/a', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1483, 'LA MOTTA SALVATORE                                ', 'LA MOTTA SALVATORE                                ', '2394825505', 'store1346@teamafricorp.com', NULL, '$2y$10$JC5ZmZuq/lkMYO21sslhKOswJ76/x5aLK2LrE5518KRE/SjXeafvC', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1484, 'HUT FLORIDA LLC                                   ', 'HUT FLORIDA LLC                                   ', '2395426422', 'store1347@teamafricorp.com', NULL, '$2y$10$XA78eWCzHpfam2vtMv4utu0ilcPU1IoXI57VoS6USH1HM1T0MQZFi', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1485, '7 ELEVEN INC AND FSI AND ALI INC                  ', '7 ELEVEN INC AND FSI AND ALI INC                  ', '2395747267', 'store1348@teamafricorp.com', NULL, '$2y$10$Kw78w2Jvtzgrk.gc7R5OS.lTSr0RSDLoWchzcyCxMElkoZnTF0RHm', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1486, '7 ELEVEN INC. AND 4 FAMILIES INC.                 ', '7 ELEVEN INC. AND 4 FAMILIES INC.                 ', '4073994630', 'store1349@teamafricorp.com', NULL, '$2y$10$5qDAn7yvqzlNJhSLtAvI8OFkk2d7ujU6G/TVBDhQO3dss68e7uxv2', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1487, 'GREENLIGHT COMPANIES OF FLORIDA INC               ', 'GREENLIGHT COMPANIES OF FLORIDA INC               ', '2394637557', 'store1350@teamafricorp.com', NULL, '$2y$10$8rEmyI77I/FT3ZCUqqiurui9mO94fPwF2nqZO3eHWRkdeJyALq3WC', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1488, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '2399479170', 'store1351@teamafricorp.com', NULL, '$2y$10$wlPESc8qFkPdbdAlaBYU2ulHUIgDoqXhRMb/Zc3tIpZOcTCbwnesa', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1489, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1352@teamafricorp.com', NULL, '$2y$10$kIJcLYRRzZzNNvoKD5yJ8.Vesz9OxuYgpDzujiytmVjj82hsrB5sC', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1490, '7 ELEVEN INC & MASSOOD ALI                        ', '7 ELEVEN INC & MASSOOD ALI                        ', '2392754100', 'store1353@teamafricorp.com', NULL, '$2y$10$.OuUyjuxBLDD1BPJUY116ePGXhFNZ.RPBGDBxkLL7waTYElD6qQom', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1491, 'SOUTH SEAS ISLAND RESORT                          ', 'SOUTH SEAS ISLAND RESORT                          ', '2394727555', 'store1354@teamafricorp.com', NULL, '$2y$10$OEmaVAYMHlw5m3EJG0mxqeP5.mYjHP7aj6y7Cmm3UQnspJgEsYiYS', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1492, 'JERRYS ENTERPRISES INC                  ', 'JERRYS ENTERPRISES INC                  ', '', 'store1355@teamafricorp.com', NULL, '$2y$10$crwD/IEmwbIAbNXaWlwnqepilmT/3in3ftNqVwUX663QbnxAlfolm', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1493, 'QFRM 5 LLC                                        ', 'QFRM 5 LLC                                        ', '4077238103', 'store1356@teamafricorp.com', NULL, '$2y$10$r2HtUWVUcqITRUNcw9Zbx.ufoTrHiudKgps5Gxv3k5xXJhqjhMwx2', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1494, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1357@teamafricorp.com', NULL, '$2y$10$wbzm92tTB.3vIPqkMeZ3bu7C58A5JDwThjg/d1EeJsuHikqpC.4HS', NULL, '2022-01-22 18:46:56', '2022-01-22 18:46:56', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1495, 'RLR INVESTMENTS LLC                               ', 'RLR INVESTMENTS LLC                               ', '9373821494', 'store1358@teamafricorp.com', NULL, '$2y$10$uKuQlaiu/iwq77PAbe0RNeu9FI5rf/k6KEbp/Zgu6FC1bsAx5ac02', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1496, 'PATEL NARENDRA                                    ', 'PATEL NARENDRA                                    ', '2399952195', 'store1359@teamafricorp.com', NULL, '$2y$10$nmk5oWTJBMf2tSN/Wh2mW.PFEqQed9DvyhZWVHSNBTnYyse5/ZZ0K', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1497, 'MERISTAR H & R OPERATIN CO', 'MERISTAR H & R OPERATIN CO', '2394723355', 'store1360@teamafricorp.com', NULL, '$2y$10$yS2U5bLn0ETwljmsG6mfeurL2ivgj6oCJ6kpqkLvBGKPwRA6GyHAy', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1498, 'CLIFFORD FORT MYERS LLC                           ', 'CLIFFORD FORT MYERS LLC                           ', '2392754222', 'store1361@teamafricorp.com', NULL, '$2y$10$Q9Qqs.bVgBkUwiErHYQRKeFBoEa62m82CfHaAn5IjbdpEEztZ21z.', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1499, 'J D LALLO INC                           ', 'J D LALLO INC                           ', '', 'store1362@teamafricorp.com', NULL, '$2y$10$Dv3XORh.z/t.qkyJQTZiSeziNr4u38rYompfw9jFxczKAfSQlEtmi', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1500, 'CRAB SHACK ACQUISITION LLC                        ', 'CRAB SHACK ACQUISITION LLC                        ', '2393321881', 'store1363@teamafricorp.com', NULL, '$2y$10$ifulDPhnLatVS/CmN620.ugNqdlT41t39QWS/x.fklMVTzPHAvy.K', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1501, 'HIDEAWAY COUNTRY CLUB REST              ', 'HIDEAWAY COUNTRY CLUB REST              ', '', 'store1364@teamafricorp.com', NULL, '$2y$10$p5oEY7wgFW.94rmoa0N/J.1mLgq5t0AzRqX.CW0hFUELnmsImvga6', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1502, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '8132735165', 'store1365@teamafricorp.com', NULL, '$2y$10$mvZLkMWl8ed0oo1mR615du0YDa.WRp1Ormkvxh.lFbO0KMUcaZZD6', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1503, 'SOUTH FLORIDA BARBEQUE INC                        ', 'SOUTH FLORIDA BARBEQUE INC                        ', '2394811155', 'store1366@teamafricorp.com', NULL, '$2y$10$e4CC9oEKH9jc4lZ0jAbmCOH4LcrKk/aEQra0Sxxk0vBFcvAjoQ1iW', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1504, 'FIDDLESTICKS COUNTRY CLUB               ', 'FIDDLESTICKS COUNTRY CLUB               ', '', 'store1367@teamafricorp.com', NULL, '$2y$10$wcT/VxOYhDKwEYy0aK5i/ew7A4zkkr5jHgyv8fcQA.lSykz98SLtK', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1505, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1368@teamafricorp.com', NULL, '$2y$10$URQjvRPgiZBriDi7MWJpnOn8.YVTP4kRIFw6lua6Y5W.5Y7g4IZsS', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1506, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1369@teamafricorp.com', NULL, '$2y$10$.IRRGUgydDTW6j6mhxqFSu2caaypTBOF5xOzzqsEtA6Sv36fpygBS', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1507, 'ARCH RESTAURANTS INC                              ', 'ARCH RESTAURANTS INC                              ', '2397683234', 'store1370@teamafricorp.com', NULL, '$2y$10$HjflTndTbWsXUUhngRlZkeDQW1yYgwnZe4TmVbA82YisXA2FF2hE6', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1508, 'CROSS CREEK OF FT MYERS COMMUNITY ASSOC INC       ', 'CROSS CREEK OF FT MYERS COMMUNITY ASSOC INC       ', '2395611444', 'store1371@teamafricorp.com', NULL, '$2y$10$aSHcfII4OM4qTVjzESJ.EuYuJ7uMoBjCYKoPigU2wf55C6ceRDurm', NULL, '2022-01-22 18:46:57', '2022-01-22 18:46:57', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1509, 'QFRM 6 LLC                                        ', 'QFRM 6 LLC                                        ', '4077238103', 'store1372@teamafricorp.com', NULL, '$2y$10$BV6DhAbP/zV9aNx5GE5UK.HtpOZITljisSMJ6To94QHSlyq3PjALu', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1510, 'ZABDA ENTERPRISES INC                             ', 'ZABDA ENTERPRISES INC                             ', '2393690200', 'store1373@teamafricorp.com', NULL, '$2y$10$rJsSgLaUlr5mvx36.WWHxucD4ufPbtx7LZ3.Suv4mla/RVgUe6Skm', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1511, 'MIONE PIZZA INC ATTN NANCY DRURY                  ', 'MIONE PIZZA INC ATTN NANCY DRURY                  ', '2395495500', 'store1374@teamafricorp.com', NULL, '$2y$10$6hzOGCxHo7la45JciFSjzufFcSmtpgh9jTTCV.bt6GxQaOiqCHaqi', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1512, 'CARISCH INC                                       ', 'CARISCH INC                                       ', '9524734291', 'store1375@teamafricorp.com', NULL, '$2y$10$jhuPT20YHmixXSbDQT.EQu15LYXmp/PykUt4rOpkJVDE/ics0JSuS', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1513, 'PELICANS NEST GOLF CLUB INC             ', 'PELICANS NEST GOLF CLUB INC             ', '2399472282', 'store1376@teamafricorp.com', NULL, '$2y$10$xaTJt4Ff/eUQXTQJVyolq.LdGB90.0NGJkhvaYEfmQoip/8dx6a9G', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1514, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '7327506350', 'store1377@teamafricorp.com', NULL, '$2y$10$Sz6yphm8Q7IZHmneYKFUwOc2uzqYi/e6qRFvXQVVLNixp2CLZmKx6', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1515, 'FUTURE ENERGY FLORIDA, INC.                       ', 'FUTURE ENERGY FLORIDA, INC.                       ', '2397680088', 'store1378@teamafricorp.com', NULL, '$2y$10$y3J81GbjJZznMTYG9ltvFO/V406s.3zoFI24AkcjVI7I3Zn8sPPcu', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1516, 'LAGS ENTERPRISES INC                    ', 'LAGS ENTERPRISES INC                    ', '', 'store1379@teamafricorp.com', NULL, '$2y$10$LxwSATkoMyMuDLWb956Rf.SzYp3yGkztPzdCWyBdgB1QUlU3OWBf.', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1517, 'IRBY BEECROFT INC                                 ', 'IRBY BEECROFT INC                                 ', '2399951900', 'store1380@teamafricorp.com', NULL, '$2y$10$gMcBqLB2ZYCp9ck0HfZIbuoMXFkmYy8kW3QRDCn0p4hUUza234a8m', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1518, 'EAST COAST WAFFLES INC                            ', 'EAST COAST WAFFLES INC                            ', '7703267022', 'store1381@teamafricorp.com', NULL, '$2y$10$n1vVAhwh3/Yxn5OO/.bSmOvfEInveGuj4aeITDEMZrX23R3gnoI1W', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1519, '7 ELEVEN INC & PANCHOLI CORP                      ', '7 ELEVEN INC & PANCHOLI CORP                      ', '2396930129', 'store1382@teamafricorp.com', NULL, '$2y$10$gF6PhBh3FA54rE6TFfrLZeV0IPgcLIIf1eKTbaCWQAxupkMckyGS2', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1520, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '7327506350', 'store1383@teamafricorp.com', NULL, '$2y$10$R3Da.T6CUKIR1Cer1H/5G.4VGIg7CFLCr0u31G67CoqGV8rTru5ly', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1521, 'WOGOMAN DALE                                      ', 'WOGOMAN DALE                                      ', '2394372565', 'store1384@teamafricorp.com', NULL, '$2y$10$Mxu.hEccU3APQT00IPRnouLqk0pLTNLlLc/qTNfIhL70/ehE0sHkK', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1522, 'COLORADO SOUTHERN                                 ', 'COLORADO SOUTHERN                                 ', '', 'store1385@teamafricorp.com', NULL, '$2y$10$ke9UxfmBOOzKHMuPS8ImGOOJsXs14ff/x0NcypgWNwCW.ri.KcYJK', NULL, '2022-01-22 18:46:58', '2022-01-22 18:46:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1523, 'ESTERO BAY HOTEL CO                     ', 'ESTERO BAY HOTEL CO                     ', '2394633838', 'store1386@teamafricorp.com', NULL, '$2y$10$556hIPT3UyZmFtlBTaU/tu8YTgEIiLeMHpxQb3xg7D4WyR.oFqXC2', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1524, 'GARRATT OF FT MYERS INC                           ', 'GARRATT OF FT MYERS INC                           ', '2394894822', 'store1387@teamafricorp.com', NULL, '$2y$10$a9TO2rjUsHdCcacK662gh.aDixOD56lX5cY8qDJl2V1KOGYDTWh7.', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1525, 'THIRSTYS INC                            ', 'THIRSTYS INC                            ', '', 'store1388@teamafricorp.com', NULL, '$2y$10$EWJuQgOdT0PyA3K7.7LNteSLnNSBOYBOG1IiMSqEE9BWS3eJQu6f.', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1526, 'SIAM HUT THAI RESTAURANT LLC                      ', 'SIAM HUT THAI RESTAURANT LLC                      ', '2399454247', 'store1389@teamafricorp.com', NULL, '$2y$10$.gMK.E63R.ZfzHudQzxKhe1QQPj0W8TT6hoAc1sOpInlImfj5w21C', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1527, '7 ELEVEN INC  ALAM ENTERPRISES 1 INC              ', '7 ELEVEN INC  ALAM ENTERPRISES 1 INC              ', '5188107128', 'store1390@teamafricorp.com', NULL, '$2y$10$4crsOJghPkV1FXoLWJLqEO/9pOlAzMdSYxugFEFMNt2IqdjHfRdcC', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1528, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '8132735165', 'store1391@teamafricorp.com', NULL, '$2y$10$GsvM3ycGRSi6VaYe5gxtt.eDc7aytpSzxrFfjDjJK1TOP9TcSs8z.', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1529, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1392@teamafricorp.com', NULL, '$2y$10$Z3Lrf/ckk3Ora8TWPPQtjezQooGzv47h5/vwCSqLRcRj4GVflYRCe', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1530, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1393@teamafricorp.com', NULL, '$2y$10$I8Ygv9FmKgv6MVazAwc64uGSlWoAu2TgvSwPOJ0KDD59fN1nJuD4G', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1531, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1394@teamafricorp.com', NULL, '$2y$10$fknOAFfnfgRWuOm6QFugouW4D3pwhb900t2by1G5voDswWaF1tOpe', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1532, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1395@teamafricorp.com', NULL, '$2y$10$hTrmtzhiopQq7x80BTd.Tujipzzv8Kg.6YNvrcIzM5ElITxR0OMma', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1533, 'CHICKS AHOY INC                         ', 'CHICKS AHOY INC                         ', '2393341566', 'store1396@teamafricorp.com', NULL, '$2y$10$ujUDUus.umnaFsLlIiWvJ.KlAcYDkojBf5eqB2irbN5DykbkfBWfK', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1534, 'BOB EVANS RESTAURANTS, LLC                        ', 'BOB EVANS RESTAURANTS, LLC                        ', '6148694844', 'store1397@teamafricorp.com', NULL, '$2y$10$M9tIWZlbhdOfWH1Bo8IH9evWKUee/j2KQ.qxQDGvU6QE3fbU85Fru', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1535, 'FLORIDA SE LLC                                    ', 'FLORIDA SE LLC                                    ', '2399367770', 'store1398@teamafricorp.com', NULL, '$2y$10$AhqDDui8DHwiMRT9ALJOQ..u8p5.FZuSqAmxVOT1yqiyuekatI1T2', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1536, 'SAKURA THAI LLC                                   ', 'SAKURA THAI LLC                                   ', '2399452999', 'store1399@teamafricorp.com', NULL, '$2y$10$f8e1QDovefTg17R.y7iYTOwynioAd1cOM8TT5mvgUf4HdWm3wjSsS', NULL, '2022-01-22 18:46:59', '2022-01-22 18:46:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1537, 'SCARPABG LLC                                      ', 'SCARPABG LLC                                      ', '9419640806', 'store1400@teamafricorp.com', NULL, '$2y$10$VMHpxAj7iEQJpfEr8tGuWuQwJU7KUv88qkFrXlJvbb2ahvwiMHtfS', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1538, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '7327506350', 'store1401@teamafricorp.com', NULL, '$2y$10$ws0uUWvG3UYzIvvdMJ7CwuyKuJP1kwJJd2K8GnsCf0zbU7nx2786W', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1539, 'FOREST CC MEMBERS ASSOC INC                       ', 'FOREST CC MEMBERS ASSOC INC                       ', '', 'store1402@teamafricorp.com', NULL, '$2y$10$pTDe8SzxFrFi2Qb.63I5vegbbqSLzHFRiJ00xQ2wPJQyTaEY.wp4K', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1540, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '8139106800', 'store1403@teamafricorp.com', NULL, '$2y$10$dHWw1emW0lEREfZgkz5yuejUvYRCYU4ofE5BYae4yUHlsDzqIgZ.W', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);
INSERT INTO `vendors` (`id`, `f_name`, `l_name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `bank_name`, `branch`, `holder_name`, `account_no`, `image`, `status`, `firebase_token`, `auth_token`) VALUES
(1541, 'KRINIS INC ATTN: TSOVOLOS CHRIS                   ', 'KRINIS INC ATTN: TSOVOLOS CHRIS                   ', '', 'store1404@teamafricorp.com', NULL, '$2y$10$xnThPlxBaoZtJu2G18YK4OaGa6J5eqrRnLlH6IE0eDGZDHeeU3yz2', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1542, 'GRAMMA DOTS OF SANIBEL LLC                        ', 'GRAMMA DOTS OF SANIBEL LLC                        ', '2394728138', 'store1405@teamafricorp.com', NULL, '$2y$10$x70eL1WLZymrHwOWAhEL/uc5dYGzX41pzScKZiS6.pXuhRHUeegmG', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1543, 'SAVAGE STEVE AND JOANN                  ', 'SAVAGE STEVE AND JOANN                  ', '', 'store1406@teamafricorp.com', NULL, '$2y$10$QQKGmOeb5E0lQAsJtm7Y5uUyoOc0tXtRK20fznYJgzbiGeziUjrjm', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1544, 'NEW CAPITAL CORPORATION                           ', 'NEW CAPITAL CORPORATION                           ', '2392780006', 'store1407@teamafricorp.com', NULL, '$2y$10$6HIApFOYBMcB2Lgzn.PkGOqqIxdCde7BixOtqy.XqDi9T/SEpR7rq', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1545, 'JOF LLC                                           ', 'JOF LLC                                           ', '2399360400', 'store1408@teamafricorp.com', NULL, '$2y$10$yVUDaju8oTg7pbzHuMpnH.HK0ZT2SdAL3WJVubENfsEFswUTAPC8u', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1546, 'G R L R INC                             ', 'G R L R INC                             ', '2394811717', 'store1409@teamafricorp.com', NULL, '$2y$10$/DKdIVaJhKj9NvEVepbMKOnx7hLgYht9UwxTFsCRfprs5kxazSUcW', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1547, 'SW FLORIDA PETROLEUM LLC                          ', 'SW FLORIDA PETROLEUM LLC                          ', '2394892524', 'store1410@teamafricorp.com', NULL, '$2y$10$p04GUnNlsWhD.RgJz1yxK.zZ0NcGlslbQDwfS7cBDouZAFMSMBto6', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1548, 'SW FLORIDA PETROLEUM LLC                          ', 'SW FLORIDA PETROLEUM LLC                          ', '2399972856', 'store1411@teamafricorp.com', NULL, '$2y$10$3BM6clukKWpfcmp.uQ/W4O2tF4wABsaeHGffMco/vJKc2U06myllS', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1549, 'HUNTERS RIDGE COMMUNITY ASSOCIATION INC           ', 'HUNTERS RIDGE COMMUNITY ASSOCIATION INC           ', '2399924900', 'store1412@teamafricorp.com', NULL, '$2y$10$oH7jfSZMKk07puXmqg1pNer6NvumPSaNcEG4ejBFilOr3p1PINECm', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1550, 'GREAT ATLANTIC MARINE INC               ', 'GREAT ATLANTIC MARINE INC               ', '', 'store1413@teamafricorp.com', NULL, '$2y$10$AEMWgaTGvFGjE5jblD76ueaBmeDyq/fXIN6NEQJxkVCd7STwJFZ8a', NULL, '2022-01-22 18:47:00', '2022-01-22 18:47:00', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1551, 'JOF LLC                                           ', 'JOF LLC                                           ', '2397681030', 'store1414@teamafricorp.com', NULL, '$2y$10$GD8y7xZFUhy7QGm05LpNHurcmCRNStJzQt1q5hHhDFaxrRHQdaaDO', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1552, 'SCHEIER THOMAS P                                  ', 'SCHEIER THOMAS P                                  ', '2398512969', 'store1415@teamafricorp.com', NULL, '$2y$10$nUOpyhEo9B0k0YjKKj4/qeH46dHS6t8bbARhayWgAlUJ2FKr2wdQm', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1553, 'ADAMS FOODS INC                                   ', 'ADAMS FOODS INC                                   ', '2392677070', 'store1416@teamafricorp.com', NULL, '$2y$10$HM9N9kpbHMex3EQ4oWpzQ.7SQs6asocL39R72zMrDG23.RWtUCt5a', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1554, 'CHILIS FLORIDA INC                                ', 'CHILIS FLORIDA INC                                ', '', 'store1417@teamafricorp.com', NULL, '$2y$10$eE6Kp8Sb9fWgxNXgu9P8l.FpXoli0wXFGiHwp/c7bACP5brWNcpsy', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1555, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '8132735165', 'store1418@teamafricorp.com', NULL, '$2y$10$PnB4fDOTJSXnWtf9gZ36Kuyn9ik8hLcgzBw73hSnl3H59g6lhI8Da', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1556, 'FM HOTEL COMPANY LTD                    ', 'FM HOTEL COMPANY LTD                    ', '2394370650', 'store1419@teamafricorp.com', NULL, '$2y$10$Kl1GvDkdu4ZuYZK50UgPaOVK9l2FyTYb.K.X1zx3F0NWYoqyAp7U2', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1557, 'BONITA BOAT HARBOR LLC                            ', 'BONITA BOAT HARBOR LLC                            ', '2394953222', 'store1420@teamafricorp.com', NULL, '$2y$10$dwy2cgtcUjK1rjdetrbRCevsEazcwwyWJX/hH6Ohg3GuYUf9hiM1C', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1558, 'VIJAY PATEL                             ', 'VIJAY PATEL                             ', '2396945775', 'store1421@teamafricorp.com', NULL, '$2y$10$rXqGXtgcnnw2OYK26MtpnOnUz2T8uGEpiK8zeMEKVFy8WGbo.PeGS', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1559, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '8132735165', 'store1422@teamafricorp.com', NULL, '$2y$10$FQf2L4v9HIOxdAUf1o3WKOBqUUPuvJ.FqwEegzo.uBSggcwda3wJK', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1560, 'SUNOCO RETAIL LLC                                 ', 'SUNOCO RETAIL LLC                                 ', '2396948146', 'store1423@teamafricorp.com', NULL, '$2y$10$J2oUHT/B.g/AgBn9UXgFc.Zfn.G6mE14iKMr/JehDQGkSXhQmyOv6', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1561, 'AT UR CONVENIENCE INC                             ', 'AT UR CONVENIENCE INC                             ', '2393901520', 'store1424@teamafricorp.com', NULL, '$2y$10$l1O5LKt8lBxUoCk2bR.MKOL3jA.7EG8vliZcci1BjM/9f2c289C1a', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1562, 'HUT FLORIDALLC                                    ', 'HUT FLORIDALLC                                    ', '2399475526', 'store1425@teamafricorp.com', NULL, '$2y$10$KqVNdxWVUSiugarUuz86/O4eZombEuX2DxweKZlCY8AiOWc/pkybu', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1563, 'SCHAAB CHRIS                                      ', 'SCHAAB CHRIS                                      ', '2395604444', 'store1426@teamafricorp.com', NULL, '$2y$10$CMtyQv/h9SPSkH4Fvpg0QO78MvmOwVnK6FsY0f.zphkmX9BwAUAzq', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1564, 'ST CHARLES YACHT CLUB INC               ', 'ST CHARLES YACHT CLUB INC               ', '', 'store1427@teamafricorp.com', NULL, '$2y$10$TCjJzds6mM32NCA3RKhFhOTWFjpd8qhim6Hw7ljRr9Nt6Ny//OnOy', NULL, '2022-01-22 18:47:01', '2022-01-22 18:47:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1565, 'SUNG SHAN MO                                      ', 'SUNG SHAN MO                                      ', '2393681866', 'store1428@teamafricorp.com', NULL, '$2y$10$GdTyDP2jQptfI1YlwJC4J.0U1A/JmYdBkjKQuxHpvmVGAG66KSEaS', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1566, 'SUNSHINE CAFE OF CAPTIVA LLC                      ', 'SUNSHINE CAFE OF CAPTIVA LLC                      ', '2394726200', 'store1429@teamafricorp.com', NULL, '$2y$10$OD8mBSRnugmAwD.S3Wml3OxOFoWMTVCTtMLwHJvbZ1iwT8GV0rzz2', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1567, 'PICA MARIO                              ', 'PICA MARIO                              ', '2399367275', 'store1430@teamafricorp.com', NULL, '$2y$10$rK/FzRzim27rbfQe0yIJcu08HAneaQiEeGnfanbB2Ft6yNlmy8s0i', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1568, 'SUTHERLAND INVESTMENTS INC                        ', 'SUTHERLAND INVESTMENTS INC                        ', '2395610010', 'store1431@teamafricorp.com', NULL, '$2y$10$hgUw6cR8P3fRkMLVgoA0ju7nSVZkAboQeVx101xjQqRnFn4AzNLPW', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1569, 'HARDEES RESTAURANT                      ', 'HARDEES RESTAURANT                      ', '', 'store1432@teamafricorp.com', NULL, '$2y$10$vG34j/cxs2roefqImhXzqON.YbzSHfMayuhfvHKNeIwBjwbMER0Z2', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1570, '7 ELEVEN INC & KELLARS KORNER INC                 ', '7 ELEVEN INC & KELLARS KORNER INC                 ', '2392673311', 'store1433@teamafricorp.com', NULL, '$2y$10$LaonTZYj.XoI/eqEeqGG..ENJigjtlUSRnbWbFx6pPtyAs3IPU6Lm', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1571, 'LUCKY SIAM LLC                                    ', 'LUCKY SIAM LLC                                    ', '2392750999', 'store1434@teamafricorp.com', NULL, '$2y$10$Nv44Y3qLNCjvnLudHCp5aOfGtLubLV0yA.vKdeTLSajejfBAhvoiO', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1572, 'WORTHINGTON MASTER ASSOC INC                      ', 'WORTHINGTON MASTER ASSOC INC                      ', '', 'store1435@teamafricorp.com', NULL, '$2y$10$kgPfXX14eS7VseNXft1qEOacQ6OKWxDqVC1KIP9GZ8muVUZZfddYK', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1573, 'K CORP LEE INC                          ', 'K CORP LEE INC                          ', '2397722289', 'store1436@teamafricorp.com', NULL, '$2y$10$r2cskYEhUxla6QRDKQIJ2O2EfiUllUSqTGPuSeGF3eN/oRjiwM2k6', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1574, 'SW FLA CHILI INC                        ', 'SW FLA CHILI INC                        ', '', 'store1437@teamafricorp.com', NULL, '$2y$10$X/n9jHv61DAIFpF/hO6vu.QPCgn5CG9y.gGqTcGea/YDsMykCWSJi', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1575, 'ORIENT INC                                        ', 'ORIENT INC                                        ', '', 'store1438@teamafricorp.com', NULL, '$2y$10$mgr7XZzl/rPdywHNgK4ClebvD2Ym7Hawcdhw.9AeIjiKqtsKaVjDe', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1576, 'LARRY C THOMPSON                                  ', 'LARRY C THOMPSON                                  ', '', 'store1439@teamafricorp.com', NULL, '$2y$10$.6dKuqzL0USrtc6sj9G2G.vf/gZkoGbYLJT.cOeT3HQOTvrMEeopy', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1577, 'SHRIRAM LLC                             ', 'SHRIRAM LLC                             ', '2394811636', 'store1440@teamafricorp.com', NULL, '$2y$10$6/qaTAlR1twYT1BQVnN0w.iVsVKKBfbJgR.juCShCndA3h/08hZTq', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1578, 'CARISCH INC                                       ', 'CARISCH INC                                       ', '2394734291', 'store1441@teamafricorp.com', NULL, '$2y$10$GmVlDy...CPxbrFZUFgjQuvRVh5s1/7Jo5VwxZjLmOL3JesPWjHqi', NULL, '2022-01-22 18:47:02', '2022-01-22 18:47:02', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1579, 'SUB11192 LLC                                      ', 'SUB11192 LLC                                      ', '2397680303', 'store1442@teamafricorp.com', NULL, '$2y$10$suOry11WVe7uXZIg6vLsE.cL2CLCAQgPMgx0tQrUxNLUsCmHcjs1y', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1580, 'COASTAL QSR LLC                                   ', 'COASTAL QSR LLC                                   ', '7068556395', 'store1443@teamafricorp.com', NULL, '$2y$10$vYQAtu7ajDYcfw8dC974A.fqrv7oFfrVEnuQzFZgD/9qdMV7m5J.a', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1581, 'MCAFEE SUSAN K                                    ', 'MCAFEE SUSAN K                                    ', '2395654525', 'store1444@teamafricorp.com', NULL, '$2y$10$wD7veSShQs1TV35Wmjys5ectuuOdlehBpOMvjBikqgmu2Ipwv.fYq', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1582, 'EAST COAST WAFFLES INC                            ', 'EAST COAST WAFFLES INC                            ', '7703267022', 'store1445@teamafricorp.com', NULL, '$2y$10$MIN/f0Z5LIFJpdJPJ5HWduSk93CqxD0aYh4VuCOIXJGE7/Izg3Pty', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1583, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '8009267784', 'store1446@teamafricorp.com', NULL, '$2y$10$OTzycz72Fs3cVEVogD3oG.jV1jRRBAnQoLeE8oczTDdkMzd1LXet.', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1584, 'IGUANA MIA INC                                    ', 'IGUANA MIA INC                                    ', '', 'store1447@teamafricorp.com', NULL, '$2y$10$4s/5vKvyox3ZTM0.4o8RlOdjxglEnEoxGzIv8Fnlt17EBH3Q9SNXC', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1585, 'DIMITRIOS INC                                     ', 'DIMITRIOS INC                                     ', '2394335659', 'store1448@teamafricorp.com', NULL, '$2y$10$wxBxmUlvBLBeObYIAMSPxu6e3IrMzN43q8ku7BVG1ERzoWRmTHmim', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1586, 'HEIMAN WAYNE K & DELORES M              ', 'HEIMAN WAYNE K & DELORES M              ', '2399640109', 'store1449@teamafricorp.com', NULL, '$2y$10$5/cmds0.8JUuITRwdw0H2OjKzCfHG1rDfE.lcCOqFGoHm.SDCAfRy', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1587, 'OUTBACK STEAKHOUSE OF FLORIDA LLC                 ', 'OUTBACK STEAKHOUSE OF FLORIDA LLC                 ', '2399361021', 'store1450@teamafricorp.com', NULL, '$2y$10$87s5USwXqsAQAYUX/70jWu28Kd6l4UWqHGH8xKCx1hYRJ9hNbhhUi', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1588, 'RIB CITY BAR-B-QUE                                ', 'RIB CITY BAR-B-QUE                                ', '2392756700', 'store1451@teamafricorp.com', NULL, '$2y$10$hRyT6t/J/eeJNvIu7.THT.pkYe9NEUWaaaA.GsqtxdjcH0OSGsuMq', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1589, 'TORCHIATI LLC                                     ', 'TORCHIATI LLC                                     ', '2394632600', 'store1452@teamafricorp.com', NULL, '$2y$10$5r22NhUDGBRN/KdYRlUOqORRha.TnuIGG0kHtekQfktPdeBPhuv6G', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1590, 'MELS DINER TOO                                    ', 'MELS DINER TOO                                    ', '2392757850', 'store1453@teamafricorp.com', NULL, '$2y$10$BonuxPp/61pQS8wvAYfFWOdPMywppnL133uGPrJ6XgMwJADCBWdEW', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1591, 'BOCA BAY PASS CLUB                                ', 'BOCA BAY PASS CLUB                                ', '', 'store1454@teamafricorp.com', NULL, '$2y$10$j.x6kjVK19mlA61D88wNH.OpVVigh5V7rJdqHvT6/ravR2hvHRCti', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1592, 'OLD COUNTRY STORE                                 ', 'OLD COUNTRY STORE                                 ', '', 'store1455@teamafricorp.com', NULL, '$2y$10$yqC891hQ1TvR6iS7aCFrTuXP/7.Lr74myUgsxbu5lweLugDxpdLAq', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1593, 'MAMMA PASTA INC                                   ', 'MAMMA PASTA INC                                   ', '2399363660', 'store1456@teamafricorp.com', NULL, '$2y$10$qjWLtLCheyPNqzWKp9lRGuxN17P1j4ZB3HZOMpVcEKAF45v9oYNDO', NULL, '2022-01-22 18:47:03', '2022-01-22 18:47:03', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1594, 'COASTAL QSR LLC                                   ', 'COASTAL QSR LLC                                   ', '7068556395', 'store1457@teamafricorp.com', NULL, '$2y$10$FzB1RrGFjk9j7iasdNX.CeBTdzn9z0j7fv7kog8Gv9Vq48cgX0XEy', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1595, 'CLEMENTINA CIMINATI                     ', 'CLEMENTINA CIMINATI                     ', '', 'store1458@teamafricorp.com', NULL, '$2y$10$jG/cFlrWc80jihAogzBvFeqOUyat8NG0fCZ1d4.KNdJc36TaZvX5O', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1596, 'BRAVOFLORIDA LLC                                  ', 'BRAVOFLORIDA LLC                                  ', '2393696303', 'store1459@teamafricorp.com', NULL, '$2y$10$UHl9TJ/yYJLUnrozcXGNqOX4IULETsxVNM0NuYNKr7c/OA9/JnBwq', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1597, 'SHAMROCK FMB TITLETOWN INC                        ', 'SHAMROCK FMB TITLETOWN INC                        ', '2394638881', 'store1460@teamafricorp.com', NULL, '$2y$10$51GGJtCU0ChKdYJsmwjTKOJpzVoqu0CgqoDykUEm4V4xP1QZNtU2O', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1598, 'SMITH DAVID C                                     ', 'SMITH DAVID C                                     ', '', 'store1461@teamafricorp.com', NULL, '$2y$10$.MwPvkxvX58n29lmV4O3U.ah7DVtE644zsZe6UkSWwvU0OfeqQgiG', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1599, 'EAST COAST WAFFLES INC                            ', 'EAST COAST WAFFLES INC                            ', '7703267022', 'store1462@teamafricorp.com', NULL, '$2y$10$h8EGyjopzX0G1RUS1ganVeDw0voPKGwdNoM8HwLK54xxiiPxzpyEq', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1600, 'QFRM 6 LLC                                        ', 'QFRM 6 LLC                                        ', '4077238103', 'store1463@teamafricorp.com', NULL, '$2y$10$gJECHXyXjcN5I66E2vY17e1LRPsjybHy.i2IdXWYRpmBk.0UXPaXq', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1601, 'SWFRI A DANPORT LTD                     ', 'SWFRI A DANPORT LTD                     ', '2399365556', 'store1464@teamafricorp.com', NULL, '$2y$10$cw7GP.9l3PqnKaw8etrZque82REY0iGF32nSli7i8qN35WrGFJ1Fi', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1602, 'KIATO INC                               ', 'KIATO INC                               ', '2395747554', 'store1465@teamafricorp.com', NULL, '$2y$10$9MzuijnJ6yx6lHQqnT7bRur926K9rdkSTPjOWFWFZj0u4.NzIIXES', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1603, 'SEMMER W J                              ', 'SEMMER W J                              ', '', 'store1466@teamafricorp.com', NULL, '$2y$10$Z2nzL/zP7.m.Xbt0lTHWgO6DHlgDhBzWLXcygZZYmRv5Qik69mycO', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1604, 'SD3 INC                                 ', 'SD3 INC                                 ', '2393697077', 'store1467@teamafricorp.com', NULL, '$2y$10$eckZIs/Q/HeqZPjKsJvsde74R4v1/b8lj83y0kM/IqrJ.Rsg5MOum', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1605, 'COASTAL QSR LLC                                   ', 'COASTAL QSR LLC                                   ', '7068556395', 'store1468@teamafricorp.com', NULL, '$2y$10$h0.GolQXLKKBnCODcFkHIOC.fLSOVKj5yaRF6yaLhvvKRljyCIwh.', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1606, 'PERKINS LLC                                       ', 'PERKINS LLC                                       ', '7703251306', 'store1469@teamafricorp.com', NULL, '$2y$10$Cta3Y42AzCyJpP6d0fApoOQ0UGUA4WO3EI/aNO6vRB.JvVLP.ldie', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1607, 'SOUTHERN RUSH BAR LLC                             ', 'SOUTHERN RUSH BAR LLC                             ', '2399979600', 'store1470@teamafricorp.com', NULL, '$2y$10$P.AzJv3uYjQL.fWm9wrueuzpMjNTeS/DR/pojOkQb40wzhChAvjAm', NULL, '2022-01-22 18:47:04', '2022-01-22 18:47:04', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1608, 'DARIO ZULJANI                                     ', 'DARIO ZULJANI                                     ', '2397728000', 'store1471@teamafricorp.com', NULL, '$2y$10$f7UCgMEoUbAa2mFMQKa5F.WfMpah1GxUTuYQ46snd0E5E7iTiTGAO', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1609, 'C & S RESTAURANT GROUP LLC                        ', 'C & S RESTAURANT GROUP LLC                        ', '2394664144', 'store1472@teamafricorp.com', NULL, '$2y$10$nC9kSuhsqmUYjNtOasxgyehjUSL27kB/StAAMhFEbx/3J7QsoEFkC', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1610, 'D ACUNTO JOAN                           ', 'D ACUNTO JOAN                           ', '', 'store1473@teamafricorp.com', NULL, '$2y$10$BbVr87cbx0eYt2vABorScuSWLj0UUdUIYWsMSXFf6rOmUloktJIyC', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1611, 'QFRM 7 LLC                                        ', 'QFRM 7 LLC                                        ', '4077238103', 'store1474@teamafricorp.com', NULL, '$2y$10$Gf2IFm0uBXrysjnq6bsleuxfu32CcOH8wD9H0oKtrdZX23R6ipBjm', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1612, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '2399393755', 'store1475@teamafricorp.com', NULL, '$2y$10$2O54rJhcSX74g5J.dX6zPO0QkmPBDwmeMHxrm46BKhUR8lMUHUu7q', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1613, 'DURANTE JOAN                                      ', 'DURANTE JOAN                                      ', '2399451700', 'store1476@teamafricorp.com', NULL, '$2y$10$dlIfjaLDKZEjAuvWJ4wN6OcATiELzDIQfllFhVde4BenVmY41SPaa', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1614, 'FURMAN ROBERT G                         ', 'FURMAN ROBERT G                         ', '', 'store1477@teamafricorp.com', NULL, '$2y$10$GroFUOxOvvfeZWMMrsLlJeya61D9rsdyI3ECCk4hJVzw3XM7NOaqq', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1615, 'RALPHS PLACE OF CAPE CORAL INC          ', 'RALPHS PLACE OF CAPE CORAL INC          ', '2395492040', 'store1478@teamafricorp.com', NULL, '$2y$10$FoYMKB4X3ETpaAlXe0yTdu0vzeaYkIp8LtwlX1dvbBnUuz08MhU1m', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1616, 'FUTURE ENERGY FLORIDA, INC                        ', 'FUTURE ENERGY FLORIDA, INC                        ', '2393690595', 'store1479@teamafricorp.com', NULL, '$2y$10$umkGU9PTU/U6xLcZDPK4zuZisUq3PZJQFB4EUEczzmdMNPTdGBCfi', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1617, 'SWFRI CAPE CORAL LTD                             ', 'SWFRI CAPE CORAL LTD                             ', '2399365556', 'store1480@teamafricorp.com', NULL, '$2y$10$kwa5KUbLe66Gco6PGcjAbOyggAgHE4hLrEiLW4l2hZe9uQS9tk6GW', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1618, 'BEACHED WHALE INC ATTN: FISHER JOSEPH             ', 'BEACHED WHALE INC ATTN: FISHER JOSEPH             ', '', 'store1481@teamafricorp.com', NULL, '$2y$10$7pC0jLiMZhP94ET56.IWj.EHy91/L/egT1Czaw14ZtiZ6VA3dKyta', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1619, 'LUCKY 8 INC                                       ', 'LUCKY 8 INC                                       ', '2393691188', 'store1482@teamafricorp.com', NULL, '$2y$10$Bww//yjX1CAQfoQk57jLIOrlIcJ70duqL.MGl5fO5Gm6r.daxWo9.', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1620, 'JEH WOK CUISINE INC                     ', 'JEH WOK CUISINE INC                     ', '2392758811', 'store1483@teamafricorp.com', NULL, '$2y$10$yXTCXcvqJB5UpNnpgfJqkeHsRZKEawegjTxaJiSBSgkw.ju4S00N6', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1621, 'PRATHER & COMPANY INC                   ', 'PRATHER & COMPANY INC                   ', '2392784422', 'store1484@teamafricorp.com', NULL, '$2y$10$F3yhSs4nuNUFvpNMjjWn1..Mk1jRdxxNI5/PM6ZkMKWLtl8wFXZ8W', NULL, '2022-01-22 18:47:05', '2022-01-22 18:47:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1622, 'TJF LLC                                           ', 'TJF LLC                                           ', '2399457377', 'store1485@teamafricorp.com', NULL, '$2y$10$QvOPe5uEgRCKcJ5HtF7ip.4o2HXvCEVnxCqdCxTQi1yUUoZBwi40y', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1623, 'BOSTON MARKET CORPORATION                         ', 'BOSTON MARKET CORPORATION                         ', '2392751779', 'store1486@teamafricorp.com', NULL, '$2y$10$DabpTnWOiy.7T05qqql18e6N2xKzjuIERZmWJyRWbqVtS1pd1mTCu', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1624, 'TARGET CORPORATION                                ', 'TARGET CORPORATION                                ', '2394818860', 'store1487@teamafricorp.com', NULL, '$2y$10$lkIxaYDY2sgYn20nSvGlk.uupauhi2yoclm0JXzehWctcvbaHNxEa', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1625, 'QFRM 7 LLC                                        ', 'QFRM 7 LLC                                        ', '4077238103', 'store1488@teamafricorp.com', NULL, '$2y$10$yOj2.WyLtQbqqFqO7ZqQAO2uvPSbLKlQSpzsH7Y4UODclsehoC/wW', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1626, 'THE CLAM BAKE INC                                 ', 'THE CLAM BAKE INC                                 ', '2394821930', 'store1489@teamafricorp.com', NULL, '$2y$10$.NlcU7L3feS3mGvkz47DSOeAzWHsMgk7BcFYD6x0B2C1QC.6b7Gsu', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1627, 'DOHERTY FLORIDA NO FORT MYERS LLC                 ', 'DOHERTY FLORIDA NO FORT MYERS LLC                 ', '2399957999', 'store1490@teamafricorp.com', NULL, '$2y$10$QYQZ17JB15l.dRXmKN384OfSOAKugzTydLL/q94d/y4mu6Yqycicu', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1628, 'OLDE HICKORY GOLF & COUNTRY CLUB                  ', 'OLDE HICKORY GOLF & COUNTRY CLUB                  ', '', 'store1491@teamafricorp.com', NULL, '$2y$10$KtHayPUrcNP6uL1CeDRRhuYAebXlooETOsLSw6Kg4J/E4Iy4lWb2i', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1629, 'WORTHINGTON MASTER ASSOCIATION                    ', 'WORTHINGTON MASTER ASSOCIATION                    ', '2394952025', 'store1492@teamafricorp.com', NULL, '$2y$10$0e6sXveY41r97PmbCvU/0edDOSp32.dGVf1/2i71viLcpprOJ6TqC', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1630, 'CARRABBAS ITALIAN GRILL LLC                       ', 'CARRABBAS ITALIAN GRILL LLC                       ', '2394330877', 'store1493@teamafricorp.com', NULL, '$2y$10$VGwzoQzptjZAiGPnV0H1Ae/7bP2PD90rR4kfdAgbWW6iDa.n3fTY6', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1631, 'COASTAL QSR LLC                                   ', 'COASTAL QSR LLC                                   ', '2397728600', 'store1494@teamafricorp.com', NULL, '$2y$10$PqMJOw1XMjd8SMLtPhOZleqKqRngYhqBuPLdyc1rAt1zEG14AZCpO', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1632, 'GOLIO JOSEPH N                                    ', 'GOLIO JOSEPH N                                    ', '2393696500', 'store1495@teamafricorp.com', NULL, '$2y$10$bNRM8Xu0wbQhmy9/EXriPOGL6Isw6SVLl3c9z3tgPNciWhttLBQY6', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1633, 'WATERFRONT CONCEPTS INC                           ', 'WATERFRONT CONCEPTS INC                           ', '', 'store1496@teamafricorp.com', NULL, '$2y$10$FrfAsDXcUx4zwknNzf7P4eZmy22hItnlwQ6X6MZ2YAq8cplaqxumC', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1634, 'SKIP ONE SEAFOOD INC                              ', 'SKIP ONE SEAFOOD INC                              ', '2394820433', 'store1497@teamafricorp.com', NULL, '$2y$10$ODRRZV7iUbd2NXYnQ8b2Te64jTgt9pLdFbInKu5yauJwZd0DJojfy', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1635, 'CARISCH INC                                       ', 'CARISCH INC                                       ', '9524734291', 'store1498@teamafricorp.com', NULL, '$2y$10$v650iqfeHnhzKyTUCtRvu.8gukjLeNugG47IH0wq9cg6wa7orV4au', NULL, '2022-01-22 18:47:06', '2022-01-22 18:47:06', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1636, 'TJF LLC                                           ', 'TJF LLC                                           ', '2399974797', 'store1499@teamafricorp.com', NULL, '$2y$10$SCQPv937ku.kBd8O1o0/2u/p9cy3cjk2LxooZRJPFSLj4gONHVqx6', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1637, 'COASTAL QSR LLC                                   ', 'COASTAL QSR LLC                                   ', '7068556395', 'store1500@teamafricorp.com', NULL, '$2y$10$TcaWL6BH2fli0zfzwgDghu9I9mDfgOzABy4F59g8cy6k1sYgliKgS', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1638, 'QFRM 7 LLC                                        ', 'QFRM 7 LLC                                        ', '4077238103', 'store1501@teamafricorp.com', NULL, '$2y$10$2At9P4/GNBFwU2OSelBhP./m4NPfzXlLwM6QD8DKjPYfgHBAex9cm', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1639, 'DOUBLEDAY RODNEY D                      ', 'DOUBLEDAY RODNEY D                      ', '2394332344', 'store1502@teamafricorp.com', NULL, '$2y$10$4Vw7lEP5j/QicraFqDlcr.Khda3gOq3FeQYK4EpFdYi0zvOQvf9eK', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1640, 'LP MANAGEMENT CORP                                ', 'LP MANAGEMENT CORP                                ', '', 'store1503@teamafricorp.com', NULL, '$2y$10$EHtS0VibwHdzvtsK0ixq/eXt/1SjxCwvmxQ6fxLAwtzTwv0/EH3Xi', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1641, 'SANIBEL MAJIK INC                       ', 'SANIBEL MAJIK INC                       ', '', 'store1504@teamafricorp.com', NULL, '$2y$10$UyGAUfhPy7kQEtW6Je1Fq.dls/sopKdDMI9S0lC4EhKIB2a0juIwi', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1642, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1505@teamafricorp.com', NULL, '$2y$10$.jOJWux8Es/V9ENhY2R4oO6imO9EpuS0MTJb8tscr56zrU6dQfd2O', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1643, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1506@teamafricorp.com', NULL, '$2y$10$GmfW8yuuxvT/J8G423aG6u2EQF1dLrrtrHvBbMOHm3Bvpg.gwnFX.', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1644, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1507@teamafricorp.com', NULL, '$2y$10$bqpTiuhfoqQ68Yo.CwznV.44SJ.C3JwrpMHyhGM4QSk0HSuqSV4l6', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1645, 'SCR FOODS INC                           ', 'SCR FOODS INC                           ', '', 'store1508@teamafricorp.com', NULL, '$2y$10$Ulp6HfPwI9DcPhsj1myPn.Ras68inL8SjzSOtaL93PAbuz4TpA6IS', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1646, 'MR MEES INC                                       ', 'MR MEES INC                                       ', '2392775616', 'store1509@teamafricorp.com', NULL, '$2y$10$Ni4YEavSHKTVJu6nqDdW4uupVmqUBSILS.NCfApbUiUtCNTH4capm', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1647, 'HOOTERS OF CAPE CORAL INC               ', 'HOOTERS OF CAPE CORAL INC               ', '', 'store1510@teamafricorp.com', NULL, '$2y$10$D3/KKFQT22zjPY.75PBqV.1en50VtWOC36pYojb0CNkkokkdkHDMC', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1648, 'PERKINS LLC                                       ', 'PERKINS LLC                                       ', '7703251306', 'store1511@teamafricorp.com', NULL, '$2y$10$rokFS4Js8IsgZegnWVuoNeKWVa.NyJozZYOH3hpP28z4zM9KuZKni', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1649, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1512@teamafricorp.com', NULL, '$2y$10$rPTwXj6CPYLeY3CEDXwQUuYdOetZ5cqucMlheoU6dKTxxnSJWU252', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1650, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '', 'store1513@teamafricorp.com', NULL, '$2y$10$ZP5tgGAv0HFjbNsf8yF9Te/SlLjujVLnMolavP.Zu1.EmSXFBUkeO', NULL, '2022-01-22 18:47:07', '2022-01-22 18:47:07', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1651, 'JRMZ ENTERPRISES INC                              ', 'JRMZ ENTERPRISES INC                              ', '2397685500', 'store1514@teamafricorp.com', NULL, '$2y$10$NdkA9pofLpF1Pz0vbQtFMeWGZDlCO/VPIOc2sq3ZtiATEkJ8.nrOS', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1652, 'MOUSETRAP DELI INC                      ', 'MOUSETRAP DELI INC                      ', '2394635634', 'store1515@teamafricorp.com', NULL, '$2y$10$/YfIPpQTTLETEebmOdCr7OZSMFtQvdVOxxbLcBqavZ9XFRbHZu74.', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1653, 'SZECHUAN TASTE LLC                                ', 'SZECHUAN TASTE LLC                                ', '2392771114', 'store1516@teamafricorp.com', NULL, '$2y$10$h3yZRGPFV8G1ANdHybOiduqsU2FAsHFFNdkAMwC.O2YtsWbzT9MvC', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1654, 'FURMANS INC                             ', 'FURMANS INC                             ', '', 'store1517@teamafricorp.com', NULL, '$2y$10$OE9MzbmNwDarbxzAg0s8Xu959gw2mkVMgp/qX2GPOwE2e1fcECXhy', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1655, 'BMC OF BOKEELIA INC                               ', 'BMC OF BOKEELIA INC                               ', '', 'store1518@teamafricorp.com', NULL, '$2y$10$sQlHAGTIi8zjKlKItd5l1OSCqYTmjAHAk3R5gJecO5nY26dZYMbmS', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1656, 'TJF LLC                                           ', 'TJF LLC                                           ', '2399361424', 'store1519@teamafricorp.com', NULL, '$2y$10$KL2p2iSTLw/G4gqYcl9VEOfQKbKMiF.84y3j65BtVcD7jY2AJV5FO', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1657, 'IGUANA MIA OF FT MYERS INC                        ', 'IGUANA MIA OF FT MYERS INC                        ', '', 'store1520@teamafricorp.com', NULL, '$2y$10$zGxTVTreP8IlxSTcCgc1Zuy17MW5PZljRdy1tlov0l9d0WusanXOO', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1658, 'PERKINS LLC                                       ', 'PERKINS LLC                                       ', '7703251306', 'store1521@teamafricorp.com', NULL, '$2y$10$DUQ1iNSqC11LreQJYGYvFOGWmMGboXMOStLKRsgbx7I9VwfrSpdyi', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1659, 'CHINA TASTE OF FORT MYERS LLC                     ', 'CHINA TASTE OF FORT MYERS LLC                     ', '2393371155', 'store1522@teamafricorp.com', NULL, '$2y$10$ueit7GsNp8MqB7sKZveo.eGpVPwlVA2oS3UMLSUGSPpJyqjM/83E2', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1660, 'CRAVOTTA  MARIO                                   ', 'CRAVOTTA  MARIO                                   ', '2397657520', 'store1523@teamafricorp.com', NULL, '$2y$10$ArLk5hsx1q1DGpECfwgczOAIHgjbgwLWkfAr3Px8UFLprEB.bZLEK', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1661, 'MARTAR INC                              ', 'MARTAR INC                              ', '', 'store1524@teamafricorp.com', NULL, '$2y$10$5KC5xMsqpbB/duY6x5svN.Yps4K/wvQSy26sqZxpAZ.NlUOKApt0C', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1662, 'GREEN FLASH RESTAURANT INC              ', 'GREEN FLASH RESTAURANT INC              ', '', 'store1525@teamafricorp.com', NULL, '$2y$10$QAW/H/4OmYOdDE8TljX1E.NfDrXjnUwvA7.dBQso0YG3WPcWDr08O', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1663, 'MID ISLAND WATER SPORTS                           ', 'MID ISLAND WATER SPORTS                           ', '2397078327', 'store1526@teamafricorp.com', NULL, '$2y$10$K305NDp6ys9qErAeSMm6e.lNvDKeTknDZ/JkSawgWPJopcGqKwFma', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1664, 'HIGHLAND WOODS GOLF & CC INC            ', 'HIGHLAND WOODS GOLF & CC INC            ', '', 'store1527@teamafricorp.com', NULL, '$2y$10$pPYMa.UokUu59o/UQccDzOK7OlgTmJDbjt8VcqfzqKxkc1Ev8avzK', NULL, '2022-01-22 18:47:08', '2022-01-22 18:47:08', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1665, 'PALMER ROBERT E                                   ', 'PALMER ROBERT E                                   ', '2394580183', 'store1528@teamafricorp.com', NULL, '$2y$10$7sdJsuZNpFudPZ3B.vu5GO4MwhDEOoobo5KtcaUnpP9L5eXiVbNaG', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1666, 'RARE HOSPITALITY MANAGEMENT LLC                   ', 'RARE HOSPITALITY MANAGEMENT LLC                   ', '2394373395', 'store1529@teamafricorp.com', NULL, '$2y$10$P/Et6YZOqZQ1uPzCASaFluoCASZ3WkLYlbytAG8NOWFGUDaq4oEYG', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1667, 'KIP AND TRACEY INC                      ', 'KIP AND TRACEY INC                      ', '', 'store1530@teamafricorp.com', NULL, '$2y$10$C//8o1XdJBqOIcy08L43Z.x8FIMt/9XJ9ub.l0kEUmu2KiHVo4QsC', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1668, 'ROBERT CAJUN EXPRESS INC                          ', 'ROBERT CAJUN EXPRESS INC                          ', '2399394074', 'store1531@teamafricorp.com', NULL, '$2y$10$cNeOOlgICIKPyu/3gy7c3eea.MbGBDIJtP6JTiIEux38usMhQfsEm', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1669, '7 ELEVEN INC AND RZL & K INC                      ', '7 ELEVEN INC AND RZL & K INC                      ', '2399479202', 'store1532@teamafricorp.com', NULL, '$2y$10$JLm07AA38xoFAaIrBTrC6OxRUR1XnjsSJbQKHwx7IA9wEIJurjLbS', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1670, 'MAYES MAXWELL                                     ', 'MAYES MAXWELL                                     ', '2394667444', 'store1533@teamafricorp.com', NULL, '$2y$10$8JvBTF0V4h4a0Wt7f5mmuuB2HPaobUaAsovF5Ui5UFqovhx/PYzxe', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1671, 'LAZY FLAMINGO II INC                    ', 'LAZY FLAMINGO II INC                    ', '', 'store1534@teamafricorp.com', NULL, '$2y$10$LqdTQPtVO2ISqygYVPuVIe7520fLMxrhG4dQt.DBJeY0mbG1QpCDa', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1672, 'FIRST WATCH ENTERPRISES INC                       ', 'FIRST WATCH ENTERPRISES INC                       ', '9419079800', 'store1535@teamafricorp.com', NULL, '$2y$10$KcrkvNAjA0X88n0Z3Yxf3Ov70eZCMNV8wXz55NWUeaPNsxBSyfRpW', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1673, 'PILOT TRAVEL CENTERS LLC                          ', 'PILOT TRAVEL CENTERS LLC                          ', '2396936868', 'store1536@teamafricorp.com', NULL, '$2y$10$328Nryl.KwlrzdVYyaBJV.mRUsEztntke8QKJpy2h2ySUMNCHzQlq', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1674, 'COASTAL QSR LLC                                   ', 'COASTAL QSR LLC                                   ', '7068556395', 'store1537@teamafricorp.com', NULL, '$2y$10$J6ndm1DAWjFIqNpVEp6WG.3mzHtqbgwTPvnaLEUodg7bDA1TZnN.W', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1675, 'CANTINA CAPTIVA LLC                     ', 'CANTINA CAPTIVA LLC                     ', '2393950882', 'store1538@teamafricorp.com', NULL, '$2y$10$1itJu2mf03wzSFldN2mysuH4cMioqVvVTwmxNuNWPLDkxkLJMXabC', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1676, 'CREATIVE SUSHI INC                                ', 'CREATIVE SUSHI INC                                ', '2394822126', 'store1539@teamafricorp.com', NULL, '$2y$10$I60tIzYPSEnygSxb8K/txeNpfU55QtWJS5JRpJOhph.wqRcF9wPla', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1677, 'TABLE4TWELVE LLC                                  ', 'TABLE4TWELVE LLC                                  ', '2399953272', 'store1540@teamafricorp.com', NULL, '$2y$10$nI1cEun0Qa8Mj5Jtq2bNZ.5v/TAZkRHXzqWhJKSw0lLWcEX1M/fLC', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1678, 'BCH GRILLE LLC                                    ', 'BCH GRILLE LLC                                    ', '2393695069', 'store1541@teamafricorp.com', NULL, '$2y$10$BuxEwBx2XGozjMNVjb.oCu/U5GKVM46y.CTQIGAt42GD7j47Cp6Fm', NULL, '2022-01-22 18:47:09', '2022-01-22 18:47:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1679, 'HUNTERS RIDGE COMMUNITY ASSOCIATION INC           ', 'HUNTERS RIDGE COMMUNITY ASSOCIATION INC           ', '2399924900', 'store1542@teamafricorp.com', NULL, '$2y$10$owCSdAvWOU9n9QwUfJh3Iu.Bb.pDr1JQizGun9nEED6rwaDvTcrlO', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1680, 'PIERHOUSE FT MYERS BEACH LTD                      ', 'PIERHOUSE FT MYERS BEACH LTD                      ', '', 'store1543@teamafricorp.com', NULL, '$2y$10$eYAlmkmjeTuaDBQtT42fNeW2dgcY/FGIa9YXCdgjGn6p4vKW0qiYu', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1681, 'ACTION BUSINESS CORPORATION             ', 'ACTION BUSINESS CORPORATION             ', '', 'store1544@teamafricorp.com', NULL, '$2y$10$ize17vIN0q7KrFIV.OddWe2ynFViUWRBaeGnRcCKRjaWX1znWOUPe', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1682, 'COASTAL QSR LLC                                   ', 'COASTAL QSR LLC                                   ', '7068556395', 'store1545@teamafricorp.com', NULL, '$2y$10$anObc.iwncvxbe5wIt9KnOj2YzsIEGeIMW5Nys3mpytneKt/7DFDy', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1683, 'LP MANAGEMENT CORP                                ', 'LP MANAGEMENT CORP                                ', '', 'store1546@teamafricorp.com', NULL, '$2y$10$NS.sj2iEi34LV5Lm.1HIaOAV4ru.n2JddHkbtM0h5sPT.xk5sTO3y', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1684, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '7327506350', 'store1547@teamafricorp.com', NULL, '$2y$10$RR1kgBjgRy11.bFuaEb1IeaHUc9wn/2Tl.idoggzZ/86zxtRa3hdO', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1685, 'COASTAL QSR LLC                                   ', 'COASTAL QSR LLC                                   ', '7068556395', 'store1548@teamafricorp.com', NULL, '$2y$10$vhtM7I37MZ7haiWeTgV0Xul1Sgn5/iqnl27VFTX6aCCgt7oZzKSM6', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1686, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '2399922024', 'store1549@teamafricorp.com', NULL, '$2y$10$g2/k.waUXN8bmm0ssy33aeqqdDv0OpdXcLjG8XZpGvRpE2mLu3yxa', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1687, 'S HOMSI INC                             ', 'S HOMSI INC                             ', '2399399020', 'store1550@teamafricorp.com', NULL, '$2y$10$5hakGuYCF6g1ZPJni67nmeedlU8NPx6OhC1bWiZmTo/ittCCcZxnK', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1688, 'COTTAGE PARTNERS LLC                              ', 'COTTAGE PARTNERS LLC                              ', '2397655440', 'store1551@teamafricorp.com', NULL, '$2y$10$YlGGLtrEsqWpBT1WqwHfCu6k7B0gd.y0T2w4AXyuV2mZIJOpjYxry', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1689, 'NFK RESTERAUNTS LLC                               ', 'NFK RESTERAUNTS LLC                               ', '2392830592', 'store1552@teamafricorp.com', NULL, '$2y$10$J5OfXIz7LwL3RrzAIQRmnemHngOl3xrpyeSmRQNdrCeOmqJbTvrXa', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1690, 'WOODYS PINE ISLAND LLC                            ', 'WOODYS PINE ISLAND LLC                            ', '2392835555', 'store1553@teamafricorp.com', NULL, '$2y$10$9n9zOs5v0MdUoU1a.14ULe3sfeI4VFQ0Wymt0uDmF2OBDMwNPE2bu', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1691, 'M S CASTLE INC                          ', 'M S CASTLE INC                          ', '2399457555', 'store1554@teamafricorp.com', NULL, '$2y$10$9w5NRXFyhkYseQ8De1PCfeQdMkW30c34XuoHJDAgojaeR2i0hg6Z2', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1692, 'CIRCLE K STORES INC                               ', 'CIRCLE K STORES INC                               ', '8139106800', 'store1555@teamafricorp.com', NULL, '$2y$10$9wqrykE2o9wuRJC8LW7VZuQZqepcQYad1TUyx9KNgsgI5SqExQuWi', NULL, '2022-01-22 18:47:10', '2022-01-22 18:47:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1693, 'FLAMINGO FOODS INC                                ', 'FLAMINGO FOODS INC                                ', '2399451555', 'store1556@teamafricorp.com', NULL, '$2y$10$gsues6Hwt7QjScUSWgLMvuFJV.F1o5hzfmjNLjEWAh8mtaj6Cmef2', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1694, 'R TEES INC                                        ', 'R TEES INC                                        ', '2393681110', 'store1557@teamafricorp.com', NULL, '$2y$10$7/rW4vXpSPELbNfB/bsthuq7RxgpMm0U1MGY5GGPo.spFqa7mqqke', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1695, 'SUNSET GRILL INC                                  ', 'SUNSET GRILL INC                                  ', '', 'store1558@teamafricorp.com', NULL, '$2y$10$Ulal3wznVG.fFqqJHX1.GuQL5f4.OsVWZsHImJE7sbKtMbftOvC6m', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1696, 'PJMRC VENTURES INC                                ', 'PJMRC VENTURES INC                                ', '2394890070', 'store1559@teamafricorp.com', NULL, '$2y$10$T.KQwrx0ba80lp6NIrTLS.lQ155bvXqrgzbddDw8gizR/WLa1t61.', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);
INSERT INTO `vendors` (`id`, `f_name`, `l_name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `bank_name`, `branch`, `holder_name`, `account_no`, `image`, `status`, `firebase_token`, `auth_token`) VALUES
(1697, 'ADAMS FOODS INC                                   ', 'ADAMS FOODS INC                                   ', '', 'store1560@teamafricorp.com', NULL, '$2y$10$GYxeL1za28OeWpyqlY4AZOjbEcEi4PJd1ZdNTn6SRDf8vs/eeCAe.', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1698, '7 ELEVEN INC & CONVEINCE WITH STEIL INC           ', '7 ELEVEN INC & CONVEINCE WITH STEIL INC           ', '2394547441', 'store1561@teamafricorp.com', NULL, '$2y$10$Y2iD1NmQ.C3mu21OodLegu3lL57xBSo5A/ZM1Y/szMopV9/.X7T8K', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1699, '7 ELEVEN INC  FSI & ALI INC                      ', '7 ELEVEN INC  FSI & ALI INC                      ', '2397689513', 'store1562@teamafricorp.com', NULL, '$2y$10$pWft2NLsIhhyv1DJqAnCROAL4D0WsnT4CI2kG4A762hVTNmhmQBee', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1700, 'SOB INC                                 ', 'SOB INC                                 ', '2394633474', 'store1563@teamafricorp.com', NULL, '$2y$10$ABfXkvZrcLJVy06irbSOf.mKDR2hSJaMypVBjfdRSsDOFQFdVkGza', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1701, 'THREE GIRLS INC                         ', 'THREE GIRLS INC                         ', '9416282429', 'store1564@teamafricorp.com', NULL, '$2y$10$kdbGZmEQVQClkcY3sgcaput4Y3FTvy8uSH4iriy5ga9kurXD/c8we', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1702, '7 ELEVEN INC & SEKHON CORP                        ', '7 ELEVEN INC & SEKHON CORP                        ', '2394339507', 'store1565@teamafricorp.com', NULL, '$2y$10$8MQe0dzIoOFHS4LiJQgyG.cLuVWQH8CxLCzOXatWTWV8fGrRroxte', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1703, 'MAJIK WEST INC                          ', 'MAJIK WEST INC                          ', '', 'store1566@teamafricorp.com', NULL, '$2y$10$lS3a4iFVsFT5TgRMdIjl1OWcCQHCdxmXx4bRjjtUJRdi.S9VM1XGu', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1704, 'FUTURA GROUP LLC                                  ', 'FUTURA GROUP LLC                                  ', '2399361831', 'store1567@teamafricorp.com', NULL, '$2y$10$Z9DMxf3comsqeHkexo1tu.OYAFSyQflc/ulNgMjkQXw4aaalD1Zry', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1705, 'CH5 EAGLE RIDGE DRIVE                             ', 'CH5 EAGLE RIDGE DRIVE                             ', '2394491800', 'store1568@teamafricorp.com', NULL, '$2y$10$yj.qNY4fC/RN1dxAcgleguMn3QXMg.A4V6ewIDXrsBJYn9.dUk/B2', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1706, 'YADON INC                                         ', 'YADON INC                                         ', '2393694478', 'store1569@teamafricorp.com', NULL, '$2y$10$ytgewiA442iFYwn5fMF2x.RAj33/DV5zGeOetWG8LvJQy.7htAhZ6', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1707, 'LOOSE CABOOSE OF BOCA GRANDE INC                  ', 'LOOSE CABOOSE OF BOCA GRANDE INC                  ', '9419640440', 'store1570@teamafricorp.com', NULL, '$2y$10$FAYmppPAJWWpQICxlQz1hu6Ukk.XjBlb3outzCu3UB/25DXMcYFoy', NULL, '2022-01-22 18:47:11', '2022-01-22 18:47:11', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1708, 'SANIBEL VENDING LLC                               ', 'SANIBEL VENDING LLC                               ', '2396936226', 'store1571@teamafricorp.com', NULL, '$2y$10$ShGS02K8spgX87rgxMo3reug.oCTeKBr2uHuKz2A7c7jGuVQxKXpW', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1709, 'CATERING EXTRAORDINAR INC                         ', 'CATERING EXTRAORDINAR INC                         ', '2399310522', 'store1572@teamafricorp.com', NULL, '$2y$10$MIkk8HBI9BnqHZwvI1ayD.xAL17LIKL750phZKk.cOW.AcKe/kQhq', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1710, '7 ELEVEN INC & HARLEEN & AMAN INC                 ', '7 ELEVEN INC & HARLEEN & AMAN INC                 ', '2392755439', 'store1573@teamafricorp.com', NULL, '$2y$10$yj0Ga/QQTwLs73PvrAZ6qu7npfBJwCm23rXFs0e/4oUAj1Shy.i0u', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1711, 'ME OF NAPLES INC                        ', 'ME OF NAPLES INC                        ', '', 'store1574@teamafricorp.com', NULL, '$2y$10$ssbYRc8wMSnrjgG3sXFV5eYKsqAqydGicNREhRyHPZ8EPvfmKdh.G', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1712, '7 ELEVEN INC & RAWAL INC                          ', '7 ELEVEN INC & RAWAL INC                          ', '2392756217', 'store1575@teamafricorp.com', NULL, '$2y$10$4VahgbJOdM8wLY7RDa..Z.2tzrdP0toAJXNFwHLXdaO0KGTbaAOxa', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1713, 'THE SHELL FACTORY LC                    ', 'THE SHELL FACTORY LC                    ', '2399952141', 'store1576@teamafricorp.com', NULL, '$2y$10$vjt0T6CzvOaCYCQqdCdAHujE6GmGu0u010ht3BhmfUoq.SujpRsw2', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1714, 'MILLERS ALE HOUSE INC                             ', 'MILLERS ALE HOUSE INC                             ', '2399314160', 'store1577@teamafricorp.com', NULL, '$2y$10$2h2SRjGKAlP3EV7pWLhL5.RvFut794.cSpjTXiio6RNrTcy3xU4Ie', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1715, 'COASTAL QSR LLC                                   ', 'COASTAL QSR LLC                                   ', '2394377177', 'store1578@teamafricorp.com', NULL, '$2y$10$0ul.9O51sLwXosDiIY6JHeIAPm3Yy59rRQ1HmJbkfuyRGe5byWegG', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1716, 'CAPTIVA NOOK LLC                        ', 'CAPTIVA NOOK LLC                        ', '2393954000', 'store1579@teamafricorp.com', NULL, '$2y$10$y8wEFJI5XFowd5insH25QuCL5c10CtTjZVWBg4ZChRIF0sguR52gy', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1717, 'PINCHERS CRAB SHACK OF BONITA SPRINGS INC         ', 'PINCHERS CRAB SHACK OF BONITA SPRINGS INC         ', '2394315504', 'store1580@teamafricorp.com', NULL, '$2y$10$7Q58fUne0HSwmNCYNoVuX.0l4LIPQqmXVbHMZLKQbe2/s98rrJPxO', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1718, 'R-80 RIB CITY INC                                 ', 'R-80 RIB CITY INC                                 ', '2392756700', 'store1581@teamafricorp.com', NULL, '$2y$10$6.wjXiAM9iraLvmz0XjCLO9rLGFCpKtMF1USIA1CZ2Qazo76ALtWa', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1719, 'LAZY DAZE  LLC                                    ', 'LAZY DAZE  LLC                                    ', '', 'store1582@teamafricorp.com', NULL, '$2y$10$Q4OV0PknzTrE1yxNhxNmfeDTT3jRUFctdSopz4382v2aoM09gKSNS', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1720, 'SHANTI 11 CORP                                    ', 'SHANTI 11 CORP                                    ', '2394373555', 'store1583@teamafricorp.com', NULL, '$2y$10$6ZOJ8ixL1tIS9LjRfUdFXeRS1KIx7RmHU/5wnHEypr3OuI.LPj7nm', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1721, 'SUNSHINE RESTAURANT MERGER SUB LLC                ', 'SUNSHINE RESTAURANT MERGER SUB LLC                ', '2392740922', 'store1584@teamafricorp.com', NULL, '$2y$10$/n/54.eAhbmUuDx9wIFTweW8Ic7NG2h2Sa8fW7xyP7MxO8U6ahAdu', NULL, '2022-01-22 18:47:12', '2022-01-22 18:47:12', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1722, 'HOST INTERNATIONAL INCORPORATED                   ', 'HOST INTERNATIONAL INCORPORATED                   ', '2395617047', 'store1585@teamafricorp.com', NULL, '$2y$10$frhcy5dn1ythaqsxNVH02emCIarx/pkIKA0CDCEBvsx88aIVqaFL.', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1723, 'FAIZA ENTERPRISES INC                             ', 'FAIZA ENTERPRISES INC                             ', '2394989315', 'store1586@teamafricorp.com', NULL, '$2y$10$ihMHn4il02rWGjIMfvztM.2D6aQzQH8MpVlAODf.C0k4UNB40Kyxy', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1724, 'E E CALCARA LLC                                   ', 'E E CALCARA LLC                                   ', '2399472202', 'store1587@teamafricorp.com', NULL, '$2y$10$kTodhdtVIzvc2be7XfEsLubq.4pX5Z4fI7gxJsmImTU42G35db5o6', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1725, '7 ELEVEN CORP                                     ', '7 ELEVEN CORP                                     ', '4073994630', 'store1588@teamafricorp.com', NULL, '$2y$10$wrPSrKuBo726V7ewOtttkei4B9I74mv/cCboa.Q/WvruozRCvXmzy', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1726, '7 ELEVEN INC & MANHAR INC                         ', '7 ELEVEN INC & MANHAR INC                         ', '2394376152', 'store1589@teamafricorp.com', NULL, '$2y$10$N3c0LFe4Nuxq5UOiDAzzau2sMzQOqNs/CGYdUYK1ZAwnQS1fHGJB6', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1727, '7 ELEVEN INC &  520 BONITA INC                    ', '7 ELEVEN INC &  520 BONITA INC                    ', '2392953076', 'store1590@teamafricorp.com', NULL, '$2y$10$.4yc/RLpajkZCmj1uUdc7.G/ojneKVWWBbfz2Exw.PhWOu/BxZ5OW', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1728, 'RNJ ENTERPRISES LIMITED INC                       ', 'RNJ ENTERPRISES LIMITED INC                       ', '', 'store1591@teamafricorp.com', NULL, '$2y$10$p7XySYBDbQM3daVPO0IgpOrhb487XXXjBYQCXoY5aavacvBOCIfl2', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1729, 'NICK & STELLAS PERFECTO PIZZA INC       ', 'NICK & STELLAS PERFECTO PIZZA INC       ', '', 'store1592@teamafricorp.com', NULL, '$2y$10$Bx1vz2Ey6XM9e4plnIG3yOMI9VjR.w3.9YLb.Y45hqDDNGmrS9H1W', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1730, 'A & N OF LEE COUNTY INC                 ', 'A & N OF LEE COUNTY INC                 ', '2399979939', 'store1593@teamafricorp.com', NULL, '$2y$10$id73Xq7GgiYoxmmIhDH3hOt.TvpT4VhF11gv4CwkZZ0/nmXI0mZ.O', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1731, 'BRAVOFLORIDA LLC                                  ', 'BRAVOFLORIDA LLC                                  ', '2394585011', 'store1594@teamafricorp.com', NULL, '$2y$10$96j8ovr5XwGxDYqlAgStKeu9X6BCgEIjxoDHI4z/Mketd5tDrEkT.', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1732, 'DTS RESTAURANTS INC                               ', 'DTS RESTAURANTS INC                               ', '2395737225', 'store1595@teamafricorp.com', NULL, '$2y$10$/qg/oLsTPc22qZb19umvUOLWWrTm4FuRu4LVQk/4UPNUBYyXdRc2O', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1733, '7 ELEVEN INC & AYUTAN ENTERPRISES INC             ', '7 ELEVEN INC & AYUTAN ENTERPRISES INC             ', '2399366112', 'store1596@teamafricorp.com', NULL, '$2y$10$ZhAYckRMq9KZ1wrLO1QB8OJYK58n4pHRSVL.c9jda7WLLt6B3Hmcu', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1734, 'PITSOUNI DINING INC                               ', 'PITSOUNI DINING INC                               ', '2394150220', 'store1597@teamafricorp.com', NULL, '$2y$10$D.xeINUlNKpTrGJR70kL7O7bcRIDryEyN9KrFT9FUEZEHBKXa6dSW', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1735, 'TRADERS SANIBEL LLC                     ', 'TRADERS SANIBEL LLC                     ', '2394724455', 'store1598@teamafricorp.com', NULL, '$2y$10$KiuW2iPjhvZDk6EOc/PFU.Kg1p/Bl0dwm8DQxz7ZS2ozWY8JiBguu', NULL, '2022-01-22 18:47:13', '2022-01-22 18:47:13', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1736, '7 ELEVEN INC & FORT MOUNTAIN CORP                 ', '7 ELEVEN INC & FORT MOUNTAIN CORP                 ', '2399954362', 'store1599@teamafricorp.com', NULL, '$2y$10$i5lATAhWfXPQx6WverwjSO1rp8ew3DfRzJOYZLq7lnfcfJfm0lmTa', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1737, 'SHADOW WOOD COUNTRY CLUB INC                      ', 'SHADOW WOOD COUNTRY CLUB INC                      ', '2399926000', 'store1600@teamafricorp.com', NULL, '$2y$10$WYUmfLKF7ik3.zvUkY49HuaoTJWqdSKPNi3ogYpVnvVHgsKUq1/Na', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1738, 'CHANSLER GARY W                         ', 'CHANSLER GARY W                         ', '', 'store1601@teamafricorp.com', NULL, '$2y$10$5PBJc1oNYtxGWA0gl7oLieE5eARGtXporrRIQ0lzPS6wzNZTVCndi', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1739, 'DOHERTY FLORIDA CAPE CORAL LLC                    ', 'DOHERTY FLORIDA CAPE CORAL LLC                    ', '2394585155', 'store1602@teamafricorp.com', NULL, '$2y$10$PnI8DU8nhsM4wmimY0CpM.fuBo4ftc.X7N/xjR9QLqek0LzeayuZG', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1740, 'DOHERTY FLORIDA SOUTH FT MYERS LLC                ', 'DOHERTY FLORIDA SOUTH FT MYERS LLC                ', '2394891811', 'store1603@teamafricorp.com', NULL, '$2y$10$ZZf7b25SoWE9/j0Z4dXKO.XsCj4tbyMqkGn4OToSX1dF.Peqv4rb2', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1741, '7 ELEVEN INC & SUCHANA & SAIF ENTERPRISES INC     ', '7 ELEVEN INC & SUCHANA & SAIF ENTERPRISES INC     ', '2394728696', 'store1604@teamafricorp.com', NULL, '$2y$10$Q5SYp3uoFU5gBgOm7e23FexlMcAb/X7Qlb/hhBO3MHxzJj2sN/OJm', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1742, 'ACME SEAFOOD INC                                  ', 'ACME SEAFOOD INC                                  ', '2392825520', 'store1605@teamafricorp.com', NULL, '$2y$10$rglHueDT7n.ziic/QWGNS.1qys1Iezuq9YX270Emz3oAIRR2JcICu', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1743, 'SPIRAL ISLAND INC                                 ', 'SPIRAL ISLAND INC                                 ', '2392829264', 'store1606@teamafricorp.com', NULL, '$2y$10$dm5dJXLznjpCXdfSdsq.Y.ikJv/pDQXvEflaNOwtbQ5GYLaHsvsjq', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1744, 'LAZY FLAMINGO III INC                   ', 'LAZY FLAMINGO III INC                   ', '2392835959', 'store1607@teamafricorp.com', NULL, '$2y$10$Ld9UWI6SjWCNMOql8cpyeu77TuHM7cpvP4dQBOzea/9UjpbKDlULC', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1745, 'ISHA ALI ENTERPRISES INC                          ', 'ISHA ALI ENTERPRISES INC                          ', '2393685544', 'store1608@teamafricorp.com', NULL, '$2y$10$Plvstx.xBZmEkuh8kGaDruSht41mgrzmtchQl5Ha6sy52mLhTas6q', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1746, 'SPRING RUN GOLF CLUB INC', 'SPRING RUN GOLF CLUB INC', '2399923811', 'store1609@teamafricorp.com', NULL, '$2y$10$OcJe6i85MvHp5qoKJ4CoqeWmIbz53CPQMYobK0D2yhj4o8twl3WFC', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1747, 'LA CASITA MEXICAN BISTRO INC            ', 'LA CASITA MEXICAN BISTRO INC            ', '2394151050', 'store1610@teamafricorp.com', NULL, '$2y$10$f3noBsTcT/QsfiXk3gFKs.hVer7gBCSFwD8ChdKT2JGbx3F3TRKwG', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1748, 'RIB CITY SB INC                                   ', 'RIB CITY SB INC                                   ', '2394580383', 'store1611@teamafricorp.com', NULL, '$2y$10$TNcxVQY96wV1u.4gIzruP.qIOkMu2vKokP2Vo2wunJJW9qkZz4Hk.', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1749, 'QUEENIE INC                                       ', 'QUEENIE INC                                       ', '2394320098', 'store1612@teamafricorp.com', NULL, '$2y$10$THwarUZbzn5WgncnqyN48evIBsh.FLfeM/vbdeni8NouhqHnROQn2', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1750, 'IGUANA MIA OF BONITA SPRINGS I                    ', 'IGUANA MIA OF BONITA SPRINGS I                    ', '2392756339', 'store1613@teamafricorp.com', NULL, '$2y$10$thlF0BR6YMdE7mlxeRo99.0UuMLPuSIY9.6UdJN1OU7FPycRE44/.', NULL, '2022-01-22 18:47:14', '2022-01-22 18:47:14', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1751, 'SPEEDWAY LLC                                      ', 'SPEEDWAY LLC                                      ', '8009267784', 'store1614@teamafricorp.com', NULL, '$2y$10$8xSMQCwFCQfcTVsUOnJLRO6a5fdeApvIbTiOeU7P/.2jWvVw4QK1K', NULL, '2022-01-22 18:47:15', '2022-01-22 18:47:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1752, '7 ELEVEN INC & 2DSN INC                           ', '7 ELEVEN INC & 2DSN INC                           ', '2399491395', 'store1615@teamafricorp.com', NULL, '$2y$10$ZuE1Do1OYppNLgO2MMeFJ.tJ9YD7hDtzgJkrkDLYyxXPuvC61eSlq', NULL, '2022-01-22 18:47:15', '2022-01-22 18:47:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1753, 'TAYLOR JOSEPH                                     ', 'TAYLOR JOSEPH                                     ', '2393323200', 'store1616@teamafricorp.com', NULL, '$2y$10$eMt9AZETGK.ueO4SbCfG3OrmZVM0X8rE2lSoIctJYEthZg.srRluC', NULL, '2022-01-22 18:47:15', '2022-01-22 18:47:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1754, 'K CORP LEE INC                                    ', 'K CORP LEE INC                                    ', '2395739680', 'store1617@teamafricorp.com', NULL, '$2y$10$xrzYC7Usa6wS9eEhdCQ1k.RZLk1TvLnPn1R1e7qANKBHZ8v0qcnYC', NULL, '2022-01-22 18:47:15', '2022-01-22 18:47:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1755, 'Jason', 'Billips', '3047076010', 'sergeantmover@ratenow.com', NULL, '$2y$10$vd6zgxqwWXzRCS/c9.km8Obgt4hgUdVSlUroMrpC5ys1c4gHbdx5S', NULL, '2022-02-16 08:04:26', '2022-02-16 08:04:26', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL),
(1756, 'Angelinas', 'Ristorante', '239-390-3187', 'angelinas@ratenow.com', NULL, '$2y$10$1gMgtQP4VmnX39yIxstx7unnnKn7HjZeHihqb9zkzDFWGMoMwZj3K', NULL, '2022-02-18 04:36:17', '2022-02-19 04:32:58', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vendor_employees`
--

CREATE TABLE `vendor_employees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `f_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_role_id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firebase_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `food_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `restaurant_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_requests`
--

CREATE TABLE `withdraw_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` bigint(20) UNSIGNED DEFAULT NULL,
  `transaction_note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `zones`
--

CREATE TABLE `zones` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coordinates` polygon NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `restaurant_wise_topic` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_wise_topic` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deliveryman_wise_topic` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `zones`
--

INSERT INTO `zones` (`id`, `name`, `coordinates`, `status`, `created_at`, `updated_at`, `restaurant_wise_topic`, `customer_wise_topic`, `deliveryman_wise_topic`) VALUES
(1, 'Zone1', 0x0000000001030000000100000006000000f7d3d69cf60265c0490b4b0093435440f7d3d69cf65c65c006257566761150c061476dcd695f22c0ecd356e19c304fc0115852c6120c5e4032f5647b46a5534011525b73dae74dc051e0924d795a5340f7d3d69cf60265c0490b4b0093435440, 1, '2021-11-11 15:43:28', '2021-11-11 15:43:28', 'zone_1_restaurant', 'zone_1_customer', 'zone_1_delivery_man'),
(2, 'zone2', 0x00000000010300000001000000050000009331b97eb0c739406aeb7cf1ecb251409331b97eb04b3d40f42cefa91ac52ac05626d70ff6cc6440db58c6572aab18405626d70f765c64404a18fd4947af53409331b97eb0c739406aeb7cf1ecb25140, 1, '2021-11-11 15:44:06', '2021-11-11 15:44:06', 'zone_2_restaurant', 'zone_2_customer', 'zone_2_delivery_man'),
(3, 'Zone3', 0x000000000103000000010000000600000086d40d2b034655408d94ce8014083c4086d40d2b132755403ab78cc13a703b4063d40d2b295c5540e6205f3bf2053b4086d40d2bf77e554095b3c7b4757b3b4063d40d2bed6a5540c0bee4750b0d3c4086d40d2b034655408d94ce8014083c40, 1, '2021-11-18 16:50:06', '2021-11-18 16:50:06', 'zone_3_restaurant', 'zone_3_customer', 'zone_3_delivery_man'),
(4, 'ktm', 0x000000000103000000010000000600000035802eb1255055402abbb99d0ec83b4004802e71b45b5540c909df7ecac43b401f802ef1325d554000691e4d3fa93b4039802e71095255409d30ecfa49a63b4023802eb1ce4c5540546917a340b03b4035802eb1255055402abbb99d0ec83b40, 1, '2021-11-22 22:43:52', '2021-11-22 22:43:52', 'zone_4_restaurant', 'zone_4_customer', 'zone_4_delivery_man');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_transactions`
--
ALTER TABLE `account_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_ons`
--
ALTER TABLE `add_ons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `admin_roles`
--
ALTER TABLE `admin_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_wallets`
--
ALTER TABLE `admin_wallets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attributes`
--
ALTER TABLE `attributes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_settings`
--
ALTER TABLE `business_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `campaigns`
--
ALTER TABLE `campaigns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conversations`
--
ALTER TABLE `conversations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coupons_code_unique` (`code`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_addresses`
--
ALTER TABLE `customer_addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_histories`
--
ALTER TABLE `delivery_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_man_wallets`
--
ALTER TABLE `delivery_man_wallets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_men`
--
ALTER TABLE `delivery_men`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `delivery_men_phone_unique` (`phone`);

--
-- Indexes for table `discounts`
--
ALTER TABLE `discounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `d_m_reviews`
--
ALTER TABLE `d_m_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_verifications`
--
ALTER TABLE `email_verifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_roles`
--
ALTER TABLE `employee_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item_campaigns`
--
ALTER TABLE `item_campaigns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mail_configs`
--
ALTER TABLE `mail_configs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_delivery_histories`
--
ALTER TABLE `order_delivery_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_transactions`
--
ALTER TABLE `order_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `phone_verifications`
--
ALTER TABLE `phone_verifications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone_verifications_phone_unique` (`phone`);

--
-- Indexes for table `provide_d_m_earnings`
--
ALTER TABLE `provide_d_m_earnings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `restaurant_reviews`
--
ALTER TABLE `restaurant_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant_wallets`
--
ALTER TABLE `restaurant_wallets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant_zone`
--
ALTER TABLE `restaurant_zone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `soft_credentials`
--
ALTER TABLE `soft_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `track_deliverymen`
--
ALTER TABLE `track_deliverymen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`);

--
-- Indexes for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendor_employees`
--
ALTER TABLE `vendor_employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vendor_employees_email_unique` (`email`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdraw_requests`
--
ALTER TABLE `withdraw_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zones`
--
ALTER TABLE `zones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `zones_name_unique` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_transactions`
--
ALTER TABLE `account_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `add_ons`
--
ALTER TABLE `add_ons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_roles`
--
ALTER TABLE `admin_roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_wallets`
--
ALTER TABLE `admin_wallets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attributes`
--
ALTER TABLE `attributes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `business_settings`
--
ALTER TABLE `business_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `campaigns`
--
ALTER TABLE `campaigns`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1352;

--
-- AUTO_INCREMENT for table `conversations`
--
ALTER TABLE `conversations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `customer_addresses`
--
ALTER TABLE `customer_addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `delivery_histories`
--
ALTER TABLE `delivery_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `delivery_man_wallets`
--
ALTER TABLE `delivery_man_wallets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `delivery_men`
--
ALTER TABLE `delivery_men`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `discounts`
--
ALTER TABLE `discounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `d_m_reviews`
--
ALTER TABLE `d_m_reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_verifications`
--
ALTER TABLE `email_verifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_roles`
--
ALTER TABLE `employee_roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=591;

--
-- AUTO_INCREMENT for table `item_campaigns`
--
ALTER TABLE `item_campaigns`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mail_configs`
--
ALTER TABLE `mail_configs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100002;

--
-- AUTO_INCREMENT for table `order_delivery_histories`
--
ALTER TABLE `order_delivery_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_transactions`
--
ALTER TABLE `order_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `phone_verifications`
--
ALTER TABLE `phone_verifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `provide_d_m_earnings`
--
ALTER TABLE `provide_d_m_earnings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1675;

--
-- AUTO_INCREMENT for table `restaurant_reviews`
--
ALTER TABLE `restaurant_reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `restaurant_wallets`
--
ALTER TABLE `restaurant_wallets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `restaurant_zone`
--
ALTER TABLE `restaurant_zone`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `soft_credentials`
--
ALTER TABLE `soft_credentials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `track_deliverymen`
--
ALTER TABLE `track_deliverymen`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user_notifications`
--
ALTER TABLE `user_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1757;

--
-- AUTO_INCREMENT for table `vendor_employees`
--
ALTER TABLE `vendor_employees`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `withdraw_requests`
--
ALTER TABLE `withdraw_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `zones`
--
ALTER TABLE `zones`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
